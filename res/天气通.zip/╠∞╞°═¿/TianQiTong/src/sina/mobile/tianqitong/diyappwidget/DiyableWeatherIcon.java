package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getWeatherIconMode;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.puTempWeatherIconMode;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getTempOrCurrent;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getWeatherInfo;
import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.WeatherIconMode;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import android.view.View.OnClickListener;

class DiyableWeatherIcon extends AbstractDiyableUnitWithItsOptionItemsAreRadioButtons<WeatherIconMode> implements OnClickListener {

	private float mScale;
	private boolean mTempAtRight;

	private DiyableBG mBg;

	private int mWeatherIconId;

	public DiyableWeatherIcon(AWType type, float scale, boolean tempAtRight, DiyableBG bg) {
		super(type);
		mScale = scale;
		mTempAtRight = tempAtRight;
		mBg = bg;

		remakeParams();
	}

	@Override
	public void drawOnCanvas(Canvas c) {

		Bitmap weatherIcon = getBitmap(getActivity().getResources(),get4x2WeatherIcon());//BitmapFactory.decodeResource(getActivity().getResources(), get4x2WeatherIcon());

		Rect weatherIconRect = getDrawBounds();

		Matrix m = new Matrix();

		m.postTranslate(weatherIconRect.left, weatherIconRect.top);
		m.postScale(mScale, mScale);
		c.drawBitmap(weatherIcon, m, null);

		int weahterIconHeight = weatherIconRect.bottom - weatherIconRect.top;
		weatherIcon = null;

		float density = ((float) c.getDensity()) / 160f;

		if (getTempValue() == WeatherIconMode.CONDITION && getType() == AWType._1ST_4X2) {
			int temperature = getConditionTemperature();
			if (temperature != WeatherInfo.INVALID_TEMPERATURE) {
				String text = temperature + "℃";
				Paint p = new Paint();
				p.setColor(mBg.getTextColor());
				p.setTextSize((int) (17d * density));
				p.setAntiAlias(true);

				if (mTempAtRight) {
					int w = (int) p.measureText(text);
					c.drawText(text, weatherIconRect.right - w, weatherIconRect.top + weahterIconHeight - 15, p);
				} else {
					c.drawText(text, weatherIconRect.left, weatherIconRect.top + weahterIconHeight, p);
				}
			}

		}
	}

	@Override
	public View[] makeOptions() {

		WeatherIconMode[] mode = new WeatherIconMode[] { WeatherIconMode.CONDITION, WeatherIconMode.FORECAST };

		String[] optionTexts = new String[mode.length];

		for (int i = 0; i < mode.length; i++) {
			optionTexts[i] = "";

			switch (mode[i]) {
			case CONDITION: {
				optionTexts[i] = "实况天气";
			}
				break;
			case FORECAST: {
				optionTexts[i] = "预报天气";
			}
				break;

			}
		}

		View[] options = makeRadioOptions(mode, optionTexts);

		options[0].setOnClickListener(this);

		return options;
	}

	@Override
	public void putTempValue(WeatherIconMode tempValue) {
		puTempWeatherIconMode(getActivity(), getType(), tempValue);

	}

	@Override
	public Rect getTouchableBounds() {
		return getDrawBounds();
	}

	@Override
	protected Rect doMeasureDrawRect() {

		Options opts = new Options();
		opts.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(getActivity().getResources(), mWeatherIconId, opts);

		Rect weatherIconRect = new Rect(0, 0, (int) ((float) opts.outWidth * mScale) * opts.inTargetDensity / opts.inDensity, (int) ((float) opts.outHeight * mScale) * opts.inTargetDensity
				/ opts.inDensity);

		offsetRect(weatherIconRect);

		return weatherIconRect;
	}

	private int getConditionTemperature() {
		return getWeatherInfo().getCondition().getTemperature();
	}

	private int get4x2WeatherIcon() {

		WeatherInfo wi = getWeatherInfo();

		int ycode = WeatherInfo.getYcodeForCurrent(getTempValue(), wi);

		int temIconId = WeatherInfo.getWeatherIconFromYahooCode(ycode, WeatherInfo.ICON_TYPE_APPWIDGET, getActivity().getResources());
		if (temIconId != -1) {
			return temIconId;
		} else {
			return R.drawable.weathericon_appwidget_01;
		}

	}

	@Override
	protected void remakeParams() {
		super.remakeParams();
		mWeatherIconId = get4x2WeatherIcon();

	}

	@Override
	protected WeatherIconMode getValueFromTempSPFile() {
		return getWeatherIconMode(getActivity(), getType(), getTempOrCurrent());
	}

	@Override
	public String getOptionsTitle() {
		return "设置天气图标";
	}

	@Override
	public void onClick(View v) {

		int updateMode = SPUtility.getSPStringInteger(getActivity(), R.string.strint_update_type);
		if (updateMode != Constants.UPDATE_TYPE_CONDITION) {
			AppWidgetDiyTool awdt = (AppWidgetDiyTool) getActivity();
			awdt.showDialog(AppWidgetDiyTool.DIALOG_ID_CHANGE_TO_CONDITION_MODE);
		}

	}

}
