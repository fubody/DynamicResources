package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ResManagerHelp extends Activity implements OnClickListener {

	private String mTitle0 = "怎样添加桌面插件？";
	private String mTitle1 = "怎样添加皮肤？";
	private String mTitle2 = "插件丢失怎么办？";
	private String[] mTitle = new String[] { mTitle0, mTitle1, mTitle2 };

	private String mContent0 = "两种方法添加：\n" + "1.返回手机桌面->空白处长摁2秒以上" + "->菜单中选择添加小部件（Moto）或者小插件（HTC）" + "->列表中点选4X2天气通（如果提示没有足够空间，请在其他桌面空余处放置，需要预留1/2空闲屏幕）;\n"
			+ "2.Moto手机桌面->HOME键->添加小部件；HTC手机桌面->菜单键->个性化设置->小插件";
	private String mContent1 = "手机在线下载会消耗相应流量，" + "建议WLAN，3G用户使用；" + "您也可以通过到天气通论坛tianqitong.com/bbs皮肤语音DIY区下载个性皮肤文件拷贝到" + "手机SD卡TianQiTong\\AppWidgetSkin目录下。";
	private String mContent2 = "请在卸载天气通后，重新安装天气通到手机内存而非SD卡" + "（您可以在电脑上安装91助手，豌豆夹等第三方安装工具，手机连接电脑后双击天气通安装程序，" + "会出现提示框\"安装路径\"中选择安装到手机即可。";
	private String[] mContent = new String[] { mContent0, mContent1, mContent2 };

	private int mCurTitle = 0;

	private TextView mTvTitle;
	private TextView mTvContent;
	private TextView mTvBtn1;
	private TextView mTvBtn2;

	private TextView[] mTvBtns;
	private ImageView backBtn;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.resmgr_hlp);

		mTvTitle = (TextView) findViewById(R.id.title);
		mTvContent = (TextView) findViewById(R.id.content);
		mTvBtn1 = (TextView) findViewById(R.id.btn_1);
		mTvBtn2 = (TextView) findViewById(R.id.btn_2);
		backBtn = (ImageView) findViewById(R.id.back);

		mTvBtn1.setOnClickListener(this);
		mTvBtn2.setOnClickListener(this);
		backBtn.setOnClickListener(this);

		mTvBtns = new TextView[] { mTvBtn1, mTvBtn2 };

		setCurrent();

	}

	private void setCurrent() {
		mTvTitle.setText(mTitle[mCurTitle]);
		mTvContent.setText(mContent[mCurTitle]);
		int idx = 0;
		for (int i = 0; i <= 2; i++) {
			if (i != mCurTitle) {
				mTvBtns[idx].setText(mTitle[i]);
				mTvBtns[idx].setTag(i);
				idx++;
			}
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_1:
			mCurTitle = (Integer) v.getTag();
			setCurrent();
			break;
		case R.id.btn_2:
			mCurTitle = (Integer) v.getTag();
			setCurrent();
			break;
		case R.id.back:
			finish();
			break;
		}

	}
}
