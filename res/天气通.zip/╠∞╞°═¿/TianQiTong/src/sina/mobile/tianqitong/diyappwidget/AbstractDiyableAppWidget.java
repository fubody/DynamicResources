package sina.mobile.tianqitong.diyappwidget;

import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;

public abstract class AbstractDiyableAppWidget {

	private static final boolean gUseCache = true;// TODO 大写

	private AbstractDiyableUnit[] mDiyableUnits;

	private int mWidthPixels;
	private int mHeightPixels;

	private Bitmap mCache;

	private AWType mType;

	AbstractDiyableAppWidget(int widthPixels, int heightPixels, AWType type) {
		mWidthPixels = widthPixels;
		mHeightPixels = heightPixels;
		mDiyableUnits = newDiyableUnits();
		mType = type;
	}

	protected abstract AbstractDiyableUnit[] newDiyableUnits();

	final AWType getType() {
		return mType;
	}

	synchronized final void releaseCache() {
		mCache = null;
	}

	final void draw(Canvas canvas) {
		if (gUseCache) {
			synchronized (this) {
				if (mCache == null) {
					mCache = Bitmap.createBitmap(mWidthPixels, mHeightPixels, Config.ARGB_8888);
					Canvas tc = new Canvas(mCache);
					doDraw(tc, mDiyableUnits);
				}
				canvas.drawBitmap(mCache, 0, 0, null);
			}
		} else {
			doDraw(canvas, mDiyableUnits);
		}
	}

	final void reDraw(Canvas canvas) {
		synchronized (this) {
			mCache = null;
		}
		layout();
		draw(canvas);
	}

	final int getWidthPixels() {
		return mWidthPixels;
	}

	final int getHeightPixels() {
		return mHeightPixels;
	}

	protected abstract void doDraw(Canvas canvas, AbstractDiyableUnit[] diyableUnits);

	final void layout() {
		doLayout(mDiyableUnits);
	}

	protected abstract void doLayout(AbstractDiyableUnit[] diyableUnits);

	// TODO
	AbstractDiyableUnit[] getDiyableUnits() {
		return mDiyableUnits;
	}
}
