package sina.mobile.tianqitong.citymanager;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_GET_PAST_WEATHER_INFO_XML_FROM_SERVER;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_BUNDLE_REQUEST_ARGS;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_CITYCODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_BAD_XML;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_NETWORK_DOWN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SERVER_DOWN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_STORAGE_ERROR;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SUCCESSFUL;

import java.lang.ref.WeakReference;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.SubHelperGetPastWeatherData;
import sina.mobile.tianqitong.service.SubHelperUpdateWeatherData;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.MsgResponseHandler;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.utility.CityUtil;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import sina.mobile.tianqitong.service.utility.WarningCache;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CitySelector extends Activity implements ServiceConnection, MsgResponseHandler, OnChildClickListener, OnGroupClickListener, TextWatcher, android.view.View.OnClickListener,
		OnItemClickListener {
	public static final int CITYTYPE_CHN = 0;
	public static final int CITYTYPE_INT = 1;
	public static final int CURRENTSCREEN_HOTCITY = 0;
	public static final int CURRENTSCREEN_SEARCHCITY = 1;
	public static final int ENTERTYPE_TEXTCHANGED = 0;
	public static final int ENTERTYPE_CLICK_MORE = 1;
	public static final int REQUEST_CODE_LOCATE_CITY = 11;
	public static final int TEXT_MORE_COLOR = 0xff3789ab;
	private TianQiTongService _service;
	private Handler _handler;
	private CitysAdapter _adapter;
	private ExpandableListView _elvCitys;
	private GridView mGridView;
	private GridViewAdapter mGridViewAdapter;
	private String[] mCitysHot = null;
	private BroadcastReceiver _br = null;
	private int mCityType = CITYTYPE_CHN;// 0:chn;1:int
	private int mCurrentScreen = CURRENTSCREEN_HOTCITY;// 0:hotcity;1:searchCity
	private int mEnterType = ENTERTYPE_TEXTCHANGED;// 0:onTextChage;1:点击更多
	private TextView mTextViewCityHot;
// private ImageView mCityHotInt;
// private ImageView mCityHotChn;
	private EditText _etKeyWord;
	private ImageView mButtonUseGPS;
	private RelativeLayout mRlCityTitle;
	private boolean _isFirstRun = false;
	private boolean _setAlarmCity = false;
	private String _currentDelCityCode;
	private String mKeyWord = "";

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.city_selector);

		Intent i = getIntent();
		_setAlarmCity = i.getBooleanExtra("set_alarm_city", false);
		_currentDelCityCode = i.getStringExtra("currentdelcitycode");

		_handler = new Handler();

		if (savedInstanceState != null && savedInstanceState.containsKey("firstRun")) {
			_isFirstRun = savedInstanceState.getBoolean("firstRun");
		} else {
			_isFirstRun = SPUtility.getSPStringArray(CitySelector.this, R.string.strs_cached_citys, ',').length == 0;
		}

		if (_isFirstRun) {
			showDialog(DIALOG_ID_FIRST_USE);
		} else {
			showDialog(DIALOG_ID_LOADING_CITYS);
		}

		getCitysByType(mCityType);
		mGridViewAdapter = new GridViewAdapter();

		_adapter = new CitysAdapter();
		_elvCitys = (ExpandableListView) findViewById(R.id.citys);
		_etKeyWord = (EditText) findViewById(R.id.key_word);
		_elvCitys.setAdapter(_adapter);
		_elvCitys.setGroupIndicator(null);
		_elvCitys.setOnGroupClickListener(this);

		_elvCitys.setOnChildClickListener(this);

		_etKeyWord.addTextChangedListener(this);
		mButtonUseGPS = (ImageView) findViewById(R.id.use_gps);
		mRlCityTitle = (RelativeLayout) findViewById(R.id.city_foreign_or_local);
		mGridView = (GridView) findViewById(R.id.citys_hot_grid);
		mGridView.setAdapter(mGridViewAdapter);
		mGridView.setOnItemClickListener(this);
		mTextViewCityHot = (TextView) findViewById(R.id.city_hot_text);
// mCityHotInt = (ImageView) findViewById(R.id.city_hot_int);
// mCityHotChn = (ImageView) findViewById(R.id.city_hot_chn);
// mCityHotInt.setOnClickListener(this);
// mCityHotChn.setOnClickListener(this);
// mCityHotChn.setImageResource(R.drawable.city_hot_chn_selector_pressed);
		mButtonUseGPS.setOnClickListener(this);
		bindService(new Intent(CitySelector.this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

	}

	public void onSaveInstanceState(Bundle state) {
		state.putBoolean("firstRun", _isFirstRun);
	}

	@Override
	public final void onServiceConnected(ComponentName name, IBinder service) {
		_service = ((TianQiTongService.TianQiTongBinder) service).getService();

		new Thread() {
			public void run() {
				_handler.post(new Runnable() {
					public void run() {
						removeDialog(DIALOG_ID_LOADING_CITYS);
					}
				});

			}
		}.start();

		/*
		 * _br = new BroadcastReceiver() { Intent i;
		 * 
		 * public void onReceive(Context context, Intent intent) { String action = intent.getAction(); if (action.equals(ACTION_BC_ONE_CITY_UPDATED)) {
		 * 
		 * i = intent; String cityCode = i.getStringExtra(MSG_DATA_KEY_STR_CITYCODE); i.putExtra(MSG_DATA_KEY_STR_CITYCODE, cityCode);
		 * 
		 * if (_currentDelCityCode != null && !_currentDelCityCode.equals(cityCode)) {
		 * 
		 * _service.deleteWeatherData(_currentDelCityCode); _service.deleteWarningData(_currentDelCityCode); if (WarningCache.cache.containsKey(cityCode)) { WarningCache.remove(cityCode); }
		 * 
		 * }
		 * 
		 * if (_setAlarmCity) { runOnUiThread(new Runnable() {
		 * 
		 * @Override public void run() { String cityCode = i.getStringExtra(MSG_DATA_KEY_STR_CITYCODE); SPUtility.putSPString(CitySelector.this, R.string.str_alarm_tts_city_code, cityCode);
		 * 
		 * } });
		 * 
		 * }
		 * 
		 * CitySelector.this.runOnUiThread(new Runnable() { public void run() { tcDismissDialog(DIALOG_ID_DOWNLOADING); // if(intentt==null){ // CitySelector.this.setResult(resultCode); // }else{ //
		 * CitySelector.this.setResult(resultCode, intentt); // } // if(intentt==null){ // CitySelector.this.setResult(resultCode); // }else{ // CitySelector.this.setResult(resultCode, intentt); // }
		 * // CitySelector.this.finish(); // System.out.println("===="); // System.out.println(resultCode); // System.out.println(intentt); // if(intentt!=null){ //
		 * System.out.println(intentt.getExtras()); // }
		 * 
		 * } });
		 * 
		 * } } };
		 * 
		 * IntentFilter filter = new IntentFilter(); filter.addAction(ACTION_BC_ONE_CITY_UPDATED); registerReceiver(_br, filter);
		 */

	}

	private Runnable _updateList = new Runnable() {

		@Override
		public void run() {
			String[] cityCodes = SPUtility.getSPStringArray(CitySelector.this, R.string.strs_cached_citys, ',');
// if (mEnterType == ENTERTYPE_TEXTCHANGED) {// 搜索进入
// _adapter.citys = CityUtil.getMainAndSubCityNames(getResources(), cityCodes, mKeyWord);
// _adapter.notifyDataSetInvalidated();
// } else {// 更多进入
// if (mCityType == CITYTYPE_CHN) {
// _adapter.citys = CityUtil.getSpecialCityNames(getResources(), cityCodes, mKeyWord, true);
// } else {
// _adapter.citys = CityUtil.getSpecialCityNames(getResources(), cityCodes, mKeyWord, false);
// }
			_adapter.citys = CityUtil.getSpecialCityNames(getResources(), cityCodes, mKeyWord, mCityType == CITYTYPE_CHN ? true : false);
			_adapter.notifyDataSetInvalidated();
// }

		}
	};

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		mKeyWord = _etKeyWord.getText().toString();
		_updateList.run();
		if (mKeyWord == null || mKeyWord.length() == 0) {
			if (mEnterType == ENTERTYPE_TEXTCHANGED) {
				ifShowExpandableListView(false);
			}
			for (int p = 0; p < _adapter.getGroupCount(); p++) {
				_elvCitys.collapseGroup(p);

			}
		} else {
			if (mCurrentScreen == CURRENTSCREEN_HOTCITY) {
				mEnterType = ENTERTYPE_TEXTCHANGED;
				ifShowExpandableListView(true);
			}
// for (int p = 0; p < _adapter.getGroupCount(); p++) {
// _elvCitys.expandGroup(p);
// }
		}

	}

	private void ifShowExpandableListView(boolean ifShow) {
		if (ifShow) {
			mCurrentScreen = CURRENTSCREEN_SEARCHCITY;
			_elvCitys.setVisibility(View.VISIBLE);
			mGridView.setVisibility(View.GONE);
			mButtonUseGPS.setVisibility(View.GONE);
			mRlCityTitle.setVisibility(View.GONE);
		} else {
			mCurrentScreen = CURRENTSCREEN_HOTCITY;
			_elvCitys.setVisibility(View.GONE);
			mGridView.setVisibility(View.VISIBLE);
			mButtonUseGPS.setVisibility(View.VISIBLE);
			mRlCityTitle.setVisibility(View.VISIBLE);
		}

	}

	public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

// String cityName = (String) _adapter.getChild(groupPosition, childPosition);
// String formatName = formatCityName(cityName);
// String cityCode = CityUtil.getSubCityCode(getResources(), cityName);
// 更新前加入判断
		if (Utility.isAirplaneModeOn(getApplicationContext())) {
			Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, this);
			dg.show();
			return true;
		}

		if (!Utility.getAvailableNetWork(getApplicationContext())) {
			Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, this);
			dg.show();
			return true;
		}
		// 结束
		String cityCode = (String) _adapter.getChildCityCode(groupPosition, childPosition);
		showDialog(DIALOG_ID_DOWNLOADING);
		mCurUpdateReqNum = _service.updateWeatherData(cityCode, new WeakReference<MsgResponseHandler>(this));
		return true;

	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {

	}

	@Override
	public void afterTextChanged(Editable s) {

	}

	private void getCitysByType(int cityType) {
		if (null != mCitysHot && mCitysHot.length > 0) {
			mCitysHot = null;
		}
// String[] citysStr = null;
		if (cityType == 0) {// chn
			mCitysHot = getResources().getStringArray(R.array.hot_chn_citys_str);
		} else {
			mCitysHot = getResources().getStringArray(R.array.hot_int_citys_str);
		}
	}

	private static final int DIALOG_ID_FIRST_USE = 0;

	private static final int DIALOG_ID_DOWNLOADING = 2;
// private static final int DIALOG_ID_WELCOME = 3;
	private static final int DIALOG_ID_NETWORK_DOWN = 4;
	private static final int DIALOG_ID_SERVER_DOWN = 5;
	private static final int DIALOG_ID_CANT_WRITE_FILE = 6;
	private static final int DIALOG_ID_LOADING_CITYS = 7;
	private static final int DIALOG_ID_IF_USE_CACHED_CITY = 8;
	private static final int DIALOG_ID_ASK_ENABLE_PROVIDER = 9;

	public Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_FIRST_USE: {

			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.light_dark_text_dialog, null);
			((TextView) v.findViewById(R.id.light_msg)).setText(R.string.pickcity_light);
			((TextView) v.findViewById(R.id.dark_msg)).setText(R.string.pickcity_dark);
			AlertDialog.Builder b = new AlertDialog.Builder(this);

			b.setView(v);

			b.setTitle(R.string.pickcity_title);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setCancelable(true);
			b.setPositiveButton("添加城市", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					_isFirstRun = false;
					removeDialog(DIALOG_ID_FIRST_USE);
					// add for 1.7 如果没有添加过城市的话，直接进入定位 lyang
					if (true) {
						Intent intent = new Intent(CitySelector.this, LocateManager.class);
						intent.putExtra(IntentActionConstants.EXTRA_WEATHER_AUTO_LOCATE, true);
						startActivityForResult(intent, REQUEST_CODE_LOCATE_CITY);
					}

				}
			});
			return b.create();
		}
		case DIALOG_ID_DOWNLOADING: {
			ProgressDialog dialog = new ProgressDialog(this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setMessage("正在更新天气数据......");
			dialog.setCancelable(false);
			dialog.setOnCancelListener(new OnCancelListener() {

				@Override
				public void onCancel(DialogInterface dialog) {
					SubHelperUpdateWeatherData.getInstance(_service).cancelRequest(mCurUpdateReqNum);
					mCurUpdateReqNum = -1;

					boolean isUseHistoryWeather = !SPUtility.getSPBoolean(CitySelector.this, R.string.boolean_use_history_weather_check);
					if (isUseHistoryWeather) {
						SubHelperGetPastWeatherData.getInstance(_service).cancelRequest(mUpdatePastReqNum);
						mUpdatePastReqNum = -1;
					}
				}
			});
			dialog.setOnDismissListener(new OnDismissListener() {

				@Override
				public void onDismiss(DialogInterface dialog) {
					if (intentt == null) {
						CitySelector.this.setResult(resultCode);
					} else {
						// 只有成功的时候finish
						CitySelector.this.setResult(resultCode, intentt);
						CitySelector.this.finish();
					}

				}
			});
			return dialog;
		}
		case DIALOG_ID_NETWORK_DOWN: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("无法更新");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage("更新天气需要网络连接，请开启移动网络或者WLAN。");
			b.setPositiveButton("设置", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {

					String action = "android.settings.WIRELESS_SETTINGS";

					final PackageManager packageManager = getPackageManager();
					final Intent intent = new Intent(action);
					List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
					if (list.size() > 0) {
						startActivity(intent);
					} else {
						Toast.makeText(CitySelector.this, "无法调用设置界面。", Toast.LENGTH_SHORT).show();
					}

				}
			});
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
		case DIALOG_ID_SERVER_DOWN: {
			AlertDialog.Builder b = new Builder(this);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setTitle("天气通提示");
			b.setMessage("抱歉！连接网络失败，请您查看您的网络设置，WLAN用户请检查您是否获得了访问权限。").setCancelable(true).setPositiveButton("确定", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
		case DIALOG_ID_CANT_WRITE_FILE: {
			AlertDialog.Builder b = new Builder(this);
			b.setMessage("写文件错误，请尝试重新启动天气通。").setCancelable(true).setPositiveButton("OK", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			});
			return b.create();
		}
		case DIALOG_ID_LOADING_CITYS: {
			ProgressDialog dialog = ProgressDialog.show(this, "", "正在装载城市，请稍等...", true);
			return dialog;
		}

		}
		return null;
	}

	public void onDestroy() {
		super.onDestroy();

		try {
			// unregisterReceiver(_br);
		} catch (Exception e) {
			e.printStackTrace();
		}
		unbindService(this);
		_adapter = null;
	}

	@Override
	public final void onServiceDisconnected(ComponentName name) {
		_service = null;

	}

	public static final int RESULT_EXCEPTION = 2;
	public static final int CITY_ALREADY_EXITS = 3;

	public void tcDismissDialog(int id) {
		try {
			dismissDialog(id);
		} catch (IllegalArgumentException iae) {

		}
	}

	int resultCode = Activity.RESULT_CANCELED;
	private Intent intentt = null;

	@Override
	public void handle(Message msg) {
		Bundle responseDate = msg.getData();
		int responseCode = responseDate.getInt(MSG_DATA_KEY_INT_RESPONSE_CODE);
		boolean isUseHistoryWeather = !SPUtility.getSPBoolean(CitySelector.this, R.string.boolean_use_history_weather_check);
		final Bundle requestArgs = responseDate.getBundle(MSG_DATA_KEY_BUNDLE_REQUEST_ARGS);
		int eventId = msg.arg2;
		switch (eventId) {
		case MSG_ARG2_GET_PAST_WEATHER_INFO_XML_FROM_SERVER: {
			switch (responseCode) {

			case RESPONSE_CODE_SUCCESSFUL: {
				final String cityCode = requestArgs.getString(MSG_DATA_KEY_STR_CITYCODE);
				intentt = new Intent();
				intentt.putExtra(MSG_DATA_KEY_STR_CITYCODE, cityCode);
				resultCode = Activity.RESULT_OK;

				if (_currentDelCityCode != null && !_currentDelCityCode.equals(cityCode)) {

					_service.deleteWeatherData(_currentDelCityCode);
					_service.deleteWarningData(_currentDelCityCode);
					if (WarningCache.cache.containsKey(cityCode)) {
						WarningCache.remove(cityCode);
					}

				}

				if (_setAlarmCity) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							SPUtility.putSPString(CitySelector.this, R.string.str_alarm_tts_city_code, cityCode);

						}
					});

				}

				CitySelector.this.runOnUiThread(new Runnable() {
					public void run() {
						tcDismissDialog(DIALOG_ID_DOWNLOADING);
					}
				});

			}
				break;

			case RESPONSE_CODE_STORAGE_ERROR: {
				intentt = null;
				resultCode = RESULT_EXCEPTION;

				tcDismissDialog(DIALOG_ID_DOWNLOADING);
				showDialog(DIALOG_ID_CANT_WRITE_FILE);
			}
				break;
			case RESPONSE_CODE_NETWORK_DOWN:
			case RESPONSE_CODE_SERVER_DOWN:
			case RESPONSE_CODE_BAD_XML: {
				intentt = null;
				resultCode = RESULT_EXCEPTION;

				tcDismissDialog(DIALOG_ID_DOWNLOADING);
				showDialog(DIALOG_ID_SERVER_DOWN);
			}
				break;
			case MsgUtility.RESPONSE_CODE_USER_CANCELED: {
				tcDismissDialog(DIALOG_ID_DOWNLOADING);
			}
				break;
			default:
				intentt = null;
				resultCode = RESULT_EXCEPTION;
				tcDismissDialog(DIALOG_ID_DOWNLOADING);
			}
			break;
		}

		case MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER: {
			switch (responseCode) {

			case RESPONSE_CODE_SUCCESSFUL: {
				final String cityCode = requestArgs.getString(MSG_DATA_KEY_STR_CITYCODE);

				if (isUseHistoryWeather) {
					mUpdatePastReqNum = _service.updatePastWeatherData(cityCode, new WeakReference<MsgResponseHandler>(this));
					return;
				}

				intentt = new Intent();
				intentt.putExtra(MSG_DATA_KEY_STR_CITYCODE, cityCode);
				resultCode = Activity.RESULT_OK;

				if (_currentDelCityCode != null && !_currentDelCityCode.equals(cityCode)) {

					_service.deleteWeatherData(_currentDelCityCode);
					_service.deleteWarningData(_currentDelCityCode);
					if (WarningCache.cache.containsKey(cityCode)) {
						WarningCache.remove(cityCode);
					}

				}

				if (_setAlarmCity) {
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							SPUtility.putSPString(CitySelector.this, R.string.str_alarm_tts_city_code, cityCode);

						}
					});

				}

				CitySelector.this.runOnUiThread(new Runnable() {
					public void run() {
						tcDismissDialog(DIALOG_ID_DOWNLOADING);
					}
				});

// if (_currentDelCityCode != null && !_currentDelCityCode.equals(cityCode)) {
//
// _service.deleteWeatherData(_currentDelCityCode);
// _service.deleteWarningData(_currentDelCityCode);
// if (WarningCache.cache.containsKey(cityCode)) {
// WarningCache.remove(cityCode);
// }
//
// }
//
// if (_setAlarmCity) {
// runOnUiThread(new Runnable() {
//
// Override
// public void run() {
// String cityCode = requestArgs.getString(MSG_DATA_KEY_STR_CITYCODE);
// SPUtility.putSPString(CitySelector.this, R.string.str_alarm_tts_city_code, cityCode);
//
// }
// });
//
// }
// tcDismissDialog(DIALOG_ID_DOWNLOADING);
// finish();
			}
				break;

			case RESPONSE_CODE_STORAGE_ERROR: {
				intentt = null;
				resultCode = RESULT_EXCEPTION;

				tcDismissDialog(DIALOG_ID_DOWNLOADING);
				showDialog(DIALOG_ID_CANT_WRITE_FILE);
			}
				break;
			case RESPONSE_CODE_NETWORK_DOWN:
			case RESPONSE_CODE_SERVER_DOWN:
			case RESPONSE_CODE_BAD_XML: {
				intentt = null;
				resultCode = RESULT_EXCEPTION;

				tcDismissDialog(DIALOG_ID_DOWNLOADING);
				showDialog(DIALOG_ID_SERVER_DOWN);
// setResult(RESULT_EXCEPTION);
// tcDismissDialog(DIALOG_ID_DOWNLOADING);
// // showDialog(DIALOG_ID_SERVER_DOWN);
// // 改为给toast
// Toast.makeText(CitySelector.this, "服务器错误，请过一段时间重试。", Toast.LENGTH_SHORT).show();
			}
				break;
			case MsgUtility.RESPONSE_CODE_USER_CANCELED: {
				tcDismissDialog(DIALOG_ID_DOWNLOADING);
			}
				break;
			default:
				intentt = null;
				resultCode = RESULT_EXCEPTION;
				tcDismissDialog(DIALOG_ID_DOWNLOADING);
			}
			break;

		}
		}

	}

// Override
// public void handleNotify(Message msg) {
// }
	/**
	 * 原有的城市展现出来为广州.番禺.广东 搜索时将其格式化为番禺.广州.广东
	 * 
	 * */

	private String formatSearchString(String subCityName) {
		String subCityNameForSearch = "";
		if (subCityName.indexOf(".") == -1) {
			subCityNameForSearch = subCityName;
		} else {
			String ss = subCityName.substring(0, subCityName.lastIndexOf("."));
			if (ss.indexOf(".") != -1) {
				StringBuffer sb = new StringBuffer();
				String[] subCityNameArray = Utility.split(ss, '.');
				for (int k = subCityNameArray.length - 1; k >= 0; k--) {
					sb.append(subCityNameArray[k]);
					if (k != 0) {
						sb.append(".");
					}
				}
				subCityNameForSearch = sb.toString() + subCityName.substring(subCityName.lastIndexOf("."));
			} else {
				subCityNameForSearch = subCityName;
			}
		}
		return subCityNameForSearch;
	}

	private class CitysAdapter extends BaseExpandableListAdapter {

		CityModel[][] citys = new CityModel[0][0];

		@Override
		public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
			if (convertView == null) {
				LayoutInflater li = (LayoutInflater) CitySelector.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = li.inflate(R.layout.city_selector_expandablelist_item, null);
				LinearLayout cityListLayout = (LinearLayout) convertView.findViewById(R.id.city_list_layout);
				ImageView iv = (ImageView) convertView.findViewById(R.id.img);
				TextView tv = (TextView) convertView.findViewById(R.id.text);
				TextView mainName = (TextView) convertView.findViewById(R.id.main_name);
				ImageButton changeType = (ImageButton) convertView.findViewById(R.id.changeType);
				convertView.setTag(new View[] { iv, tv, mainName, changeType, cityListLayout });
			}
			ImageView iv = (ImageView) ((View[]) convertView.getTag())[0];
			TextView tv = (TextView) ((View[]) convertView.getTag())[1];
			TextView mainName = (TextView) ((View[]) convertView.getTag())[2];
			ImageButton changeType = (ImageButton) ((View[]) convertView.getTag())[3];
			LinearLayout cityListLayout = (LinearLayout) ((View[]) convertView.getTag())[4];
			if (isExpanded) {
				iv.setImageResource(R.drawable.city_expandablelist_expanded);
			} else {
				iv.setImageResource(R.drawable.city_expandablelist_unexpanded);
			}
			{
				cityListLayout.setVisibility(View.VISIBLE);
				changeType.setVisibility(View.GONE);
			}

			// 先城市后省份
			if (groupPosition < citys[0].length) {
				iv.setVisibility(View.GONE);
				String subMainName = (String) getGroupMainName(groupPosition);
				if (subMainName != null && !subMainName.equals("")) {// 当为空说明，城市名和省名相同
					mainName.setVisibility(View.VISIBLE);
					if (getShowType(groupPosition) == CityModel.TYPE_KEY_2_PART) {
						tv.setText((String) getGroup(groupPosition) + "·");
						tv.setTextColor(Color.WHITE);
						mainName.setText(subMainName);
						mainName.setTextColor(Color.GRAY);
					} else {
						tv.setText((String) getGroup(groupPosition));
						tv.setTextColor(Color.GRAY);
						mainName.setText("·" + subMainName);
						mainName.setTextColor(Color.WHITE);
					}

				} else {
					mainName.setVisibility(View.INVISIBLE);
					tv.setText((String) getGroup(groupPosition));
					tv.setTextColor(Color.WHITE);
				}
			} else {
				if ((mKeyWord == null || mKeyWord.length() == 0) && groupPosition == 0) {
					changeType.setVisibility(View.VISIBLE);
					cityListLayout.setVisibility(View.GONE);
					if (mCityType == CITYTYPE_CHN) {
						changeType.setBackgroundResource(R.drawable.city_int_selector);
					} else {
						changeType.setBackgroundResource(R.drawable.city_chn_selector);
					}
					changeType.setOnClickListener(CitySelector.this);
// iv.setImageResource(R.drawable.exchange_between_local_foreign);

				} else {
					iv.setVisibility(View.VISIBLE);
					mainName.setVisibility(View.INVISIBLE);
					tv.setText((String) getGroup(groupPosition));
					tv.setTextColor(Color.WHITE);
				}

			}

// String stringForSearchCity = formatSearchString((String) getGroup(groupPosition));

			return convertView;
		}

		@Override
		public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

			if (convertView == null) {
				LayoutInflater li = (LayoutInflater) CitySelector.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = li.inflate(R.layout.city_selector_expandablelist_item, null);
				ImageView iv = (ImageView) convertView.findViewById(R.id.img);
				TextView tv = (TextView) convertView.findViewById(R.id.text);
				convertView.setTag(new View[] { iv, tv });
				iv.setVisibility(View.INVISIBLE);
			}

			TextView tv = (TextView) ((View[]) convertView.getTag())[1];

			tv.setText((String) getChild(groupPosition, childPosition));
			return convertView;
		}

		@Override
		public Object getChild(int groupPosition, int childPosition) {
			String r;
			if (groupPosition < citys[0].length) {
				r = null;
			} else {
				r = citys[groupPosition - citys[0].length + 1][childPosition + 1].getSubName();
			}
			return r;
		}

		public String getChildCityCode(int groupPosition, int childPosition) {
			String r;
			if (groupPosition < citys[0].length) {
				r = null;
			} else {
				r = citys[groupPosition - citys[0].length + 1][childPosition + 1].getCityCode();
			}
			return r;
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return (groupPosition << 32) | childPosition;
		}

		@Override
		public int getChildrenCount(int groupPosition) {
			int r = 0;
			if (citys.length > 0) {
				if (groupPosition >= citys[0].length) {
					r = citys[groupPosition - citys[0].length + 1].length - 1;
				}
			}

			return r;

		}

		@Override
		public Object getGroup(int groupPosition) {
			String r;
			if (groupPosition < citys[0].length) {
				r = citys[0][groupPosition].getSubCityNameForSearchNew();
			} else {
				r = citys[groupPosition - citys[0].length + 1][0].getMainName();
			}
			return r;
		}

		public String getGroupCityCode(int groupPosition) {
			String r;
			if (groupPosition < citys[0].length) {
				r = citys[0][groupPosition].getCityCode();
			} else {
				r = citys[groupPosition - citys[0].length + 1][0].getCityCode();
			}
			return r;
		}

		public String getGroupMainName(int groupPosition) {
			String r;
			if (groupPosition < citys[0].length) {
				r = citys[0][groupPosition].getSubMainName();
			} else {
				r = citys[groupPosition - citys[0].length + 1][0].getMainName();
			}
			return r;
		}

		// type 2 搜索临汾 表现为 洪洞.临汾
		public int getShowType(int groupPosition) {

			if (groupPosition < citys[0].length) {
				return citys[0][groupPosition].getType();

			} else {
				return -1;
			}
		}

		@Override
		public int getGroupCount() {
			if (citys.length > 0) {
				return citys[0].length + citys.length - 1;
			}
			return 0;
		}

		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}

		@Override
		public boolean hasStableIds() {
			return true;
		}

		@Override
		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}

	}

	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.use_gps: {
			startActivityForResult(new Intent(CitySelector.this, LocateManager.class), REQUEST_CODE_LOCATE_CITY);
		}
			break;
		case R.id.changeType: {
// ((ImageView)v).clearFocus();
			if ((mKeyWord == null || mKeyWord.length() == 0)) {
				mCityType = (mCityType + 1) % 2;
				for (int p = 0; p < _adapter.getGroupCount(); p++) {
					_elvCitys.collapseGroup(p);

				}
			}

			_updateList.run();
		}
			break;
// case R.id.city_hot_int: {
// if (mCityType != CITYTYPE_INT) {
// mCityType = CITYTYPE_INT;
// getCitysByType(mCityType);
// mGridViewAdapter.notifyDataSetInvalidated();
// // mTextViewCityHot.setText("国际热门城市");
// _etKeyWord.setHint("纽约/niuyue/new york");
// mCityHotChn.setImageResource(R.drawable.city_hot_chn_selector_normal);
// mCityHotInt.setImageResource(R.drawable.city_hot_int_selector_pressed);
// }
//
// }
// break;
// case R.id.city_hot_chn: {
// if (mCityType != CITYTYPE_CHN) {
// mCityType = CITYTYPE_CHN;
// getCitysByType(mCityType);
// mGridViewAdapter.notifyDataSetInvalidated();
// // mTextViewCityHot.setText("国内热门城市");
// _etKeyWord.setHint("北京/beijing/bj");
//
// mCityHotInt.setImageResource(R.drawable.city_hot_int_selector_normal);
// mCityHotChn.setImageResource(R.drawable.city_hot_chn_selector_pressed);
// }
// }
// break;
		}

	}

	private class GridViewAdapter extends BaseAdapter {

		public int getCount() {
			return mCitysHot.length;
		}

		public Object getItem(int position) {
			return mCitysHot[position];
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			TextView iv = null;
			if (convertView == null) {
				LayoutInflater inflater = (LayoutInflater) CitySelector.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				View r = inflater.inflate(R.layout.city_selector_grid_item, null);
				convertView = r.findViewById(R.id.city_name);
				iv = (TextView) convertView;
			} else {
				iv = (TextView) convertView;
			}
			iv.setText(mCitysHot[position]);
			if (position == mCitysHot.length - 1) {
				iv.setTextColor(TEXT_MORE_COLOR);
			} else {
				iv.setTextColor(Color.WHITE);
			}
			return iv;
		}

		public GridViewAdapter() {
			super();

		}

	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if (arg2 != mCitysHot.length - 1) {
			String cityCode = null;
			cityCode = CityUtil.getSubCityCode(getResources(), mCitysHot[arg2]);
			if (_service.getCityName(cityCode) != null) {
				StringBuffer toastString = new StringBuffer();
				toastString.append("您已添加过").append(mCitysHot[arg2]).append(",请选择其它城市");
				Toast.makeText(CitySelector.this, toastString.toString(), Toast.LENGTH_SHORT).show();
				toastString = null;
			} else {
				// 更新前加入判断
				if (Utility.isAirplaneModeOn(getApplicationContext())) {
					Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, this);
					dg.show();
					return;
				}

				if (!Utility.getAvailableNetWork(getApplicationContext())) {
					Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, this);
					dg.show();
					return;
				}
				// 结束
				showDialog(DIALOG_ID_DOWNLOADING);
				mCurUpdateReqNum = _service.updateWeatherData(cityCode, new WeakReference<MsgResponseHandler>(this));
			}

		} else {
			mEnterType = ENTERTYPE_CLICK_MORE;
			_updateList.run();
			ifShowExpandableListView(true);
		}

	}

	private int mCurUpdateReqNum = -1;
	private int mUpdatePastReqNum = -1;

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (mCurrentScreen == CURRENTSCREEN_SEARCHCITY && keyCode == KeyEvent.KEYCODE_BACK) {
			_etKeyWord.setText("");
			mEnterType = ENTERTYPE_TEXTCHANGED;
			mCityType = CITYTYPE_CHN;
			ifShowExpandableListView(false);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
		// TODO Auto-generated method stub
		if (groupPosition < _adapter.citys[0].length) {
// String cityName = (String) _adapter.getGroup(groupPosition);
// String formatName = formatCityName(cityName);
// String cityCode = CityUtil.getSubCityCode(getResources(), formatName);
// 更新前加入判断
			if (Utility.isAirplaneModeOn(getApplicationContext())) {
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, this);
				dg.show();
				return true;
			}

			if (!Utility.getAvailableNetWork(getApplicationContext())) {
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, this);
				dg.show();
				return true;
			}
			// 结束
			String cityCode = (String) _adapter.getGroupCityCode(groupPosition);
			showDialog(DIALOG_ID_DOWNLOADING);
			mCurUpdateReqNum = _service.updateWeatherData(cityCode, new WeakReference<MsgResponseHandler>(this));

			return true;
		} else if ((mKeyWord == null || mKeyWord.length() == 0) && groupPosition == 0) {
			mCityType = (mCityType + 1) % 2;
			for (int p = 0; p < _adapter.getGroupCount(); p++) {
				_elvCitys.collapseGroup(p);

			}
			_updateList.run();
			return true;
		}
		return false;
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {

		case REQUEST_CODE_LOCATE_CITY: {
			switch (resultCode) {
			case Activity.RESULT_OK: {// 定位成功后，如果为替换则删除
				if (data != null) {
					String cityCode = data.getStringExtra(MSG_DATA_KEY_STR_CITYCODE);

					if (cityCode != null) {
						// 更新前加入判断
						if (Utility.isAirplaneModeOn(getApplicationContext())) {
							Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, this);
							dg.show();
							return;
						}

						if (!Utility.getAvailableNetWork(getApplicationContext())) {
							Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, this);
							dg.show();
							return;
						}
						// 结束
						showDialog(DIALOG_ID_DOWNLOADING);
						mCurUpdateReqNum = _service.updateWeatherData(cityCode, new WeakReference<MsgResponseHandler>(this));
					}
				}
			}
				break;
			case Activity.RESULT_CANCELED: {
				// finish();
				Toast.makeText(CitySelector.this, "您取消了本次定位。", Toast.LENGTH_SHORT).show();
			}
				break;
			case CitySelector.RESULT_EXCEPTION: {// 定位失败，暂不做处理

			}
				break;

			case CITY_ALREADY_EXITS: {// 看是否需要直接finish掉，暂不处理
// finish();
			}
				break;
			default:
// finish();
				break;
			}
		}
			break;

		}
	}

}
