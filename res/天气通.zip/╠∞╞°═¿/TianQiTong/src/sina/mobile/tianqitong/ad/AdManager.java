package sina.mobile.tianqitong.ad;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.TianQiTongDataStorage;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.TianQiTongXmlParseUtils;
import sina.mobile.tianqitong.service.frm.MsgResponseHandler;
import sina.mobile.tianqitong.service.model.AdList;
import sina.mobile.tianqitong.service.model.AdList.AdEntity;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataList;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataListItem;
import sina.mobile.tianqitong.service.simplelistdata.TQTSimpleDataManager;
import sina.mobile.tianqitong.service.simplelistdata.TQTSimpleDataManager.TQTSimpleDataDelegate;
import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import sina.mobile.tianqitong.service.utility.Utility;
import android.os.Handler;
import android.os.Looper;

/**
 * 广告管理
 * 
 * @author zhangxi
 * 
 */
public class AdManager implements TQTSimpleDataDelegate {

	private TianQiTongService mService;

	private TQTSimpleDataManager mDataManager;

	public AdManager(TianQiTongService service) {
		super();

		mDataManager = new TQTSimpleDataManager(this, new AdList(null), "forecast.sina.cn", "/android/biz.php", Constants.ADLIST_FILENAME, service, true);
		mService = service;
	}

	public void close() {
		mDataManager.close();
	}

	public TQTSimpleDataManager getDataManager() {
		return mDataManager;
	}

	public void refreshAdEntities(WeakReference<MsgResponseHandler> sender) {
		mDataManager.refresh(sender);
	}

	public AdEntity[] getAdEntitys() {
		TQTListDataListItem[] tmp = mDataManager.getListData().getAll();
		AdEntity[] r = new AdEntity[tmp.length];
		System.arraycopy(tmp, 0, r, 0, r.length);
		return r;
	}

	private String getTimeStamp() {
		File f = new File(TianQiTongDataStorage.getCacheDir(mService), Constants.ADLIST_FILENAME);
		if (!f.exists()) {
			return null;
		}
		FileInputStream inStream = null;
		try {
			inStream = new FileInputStream(f);
			AdList sl = TianQiTongXmlParseUtils.parseAdList(inStream, true);
			if (sl.getTimeStamp() != null) {
				return sl.getTimeStamp();
			}
		} catch (IOException e) {
			TianQiTongLog.addException(e);
		} finally {
			if (inStream != null) {
				try {
					inStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	@Override
	public void buildNetworkRequestGetArgs(TQTSimpleDataManager manager, HashMap<String, String> getArgs) {
		getArgs.put("pt", "1");
		String dpi = mService.getString(R.string.dpi);
		String size = mService.getString(R.string.size);
		String aspect = mService.getString(R.string.aspect);
		String resolution = size + "-" + aspect + "-" + dpi;
		getArgs.put("resolution", resolution);
		getArgs.put("device", android.os.Build.MODEL + "/" + android.os.Build.VERSION.RELEASE);
		getArgs.put("ver", mService.getString(R.string.ver));
		getArgs.put("pd", "0");
		getArgs.put("uid", TianQiTongService.getIMEI(mService));

		// #ifdef PID
		// #expand String pid="%PID%";// 渠道
//@		String pid="%PID%";// 渠道
// @
		// #else
		String pid = "free";// 渠道
		// #endif
		getArgs.put("pid", pid);
		String timeStamp = getTimeStamp();
		if (timeStamp != null) {
			getArgs.put("timestamp", timeStamp);
		}
	}

	@Override
	public TQTListDataList parseResponseData(TQTSimpleDataManager manager, InputStream is) throws IOException {
		return TianQiTongXmlParseUtils.parseAdList(is, false);
	}

	@Override
	public TQTListDataListItem[] getCustomTQTLisDataListItems(TQTSimpleDataManager manager) {
		return new TQTListDataListItem[] {};
	}

	@Override
	public TQTListDataListItem makeLocalListItem(TQTSimpleDataManager manager, File f) {
		return null;
	}

	@Override
	public File getSDDir(TQTSimpleDataManager manager) {
		return Utility.getADSDir();
	}

	@Override
	public void newHandler(Looper looper) {
		mDataManager.newHandler(looper);

	}

	public void setDataManagerListener(Handler listener) {
		mDataManager.setDataManagerListener(listener);
	}
}
