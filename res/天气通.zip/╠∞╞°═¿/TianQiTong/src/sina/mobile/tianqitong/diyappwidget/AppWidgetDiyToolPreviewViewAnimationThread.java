package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCurAWType;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCurDiyableUnits;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCurPreview;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCursorAnimation;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCursorBmp;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCursorRadius;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getFingerBmp;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getFingerPressAnimation;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getWallpaper;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Transformation;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;

public class AppWidgetDiyToolPreviewViewAnimationThread extends Thread {

	private SurfaceHolder mSurfaceHolder;
	private Handler mUIHandler;

	private int mState;
	public static final int STATE_NO_ANIMATION = 0;
	public static final int STATE_PLAY_TUTORIAL = 1;
	public static final int STATE_PLAY_DIY_CURSOR_ANIMATION = 2;

	private boolean mPlay = false;

	private Rect mDirtyRect;

	public AppWidgetDiyToolPreviewViewAnimationThread(SurfaceHolder surfaceHolder, Handler handler) {
		mSurfaceHolder = surfaceHolder;

		mUIHandler = handler;

		float density = getDensity();

		switch (getCurAWType()) {
		case _1ST_4X1: {
			mDirtyRect = new Rect(0, 0, (int) (320d * density), (int) (120d * density));
		}
			break;
		case _1ST_4X2:
		case _2ND_4X2: {
			mDirtyRect = new Rect(0, 0, (int) (320d * density), (int) (240d * density));
		}
		}
	}

	@Override
	public void run() {
		while (mPlay) {
			Canvas c = null;

			try {

				synchronized (mSurfaceHolder) {

					c = mSurfaceHolder.lockCanvas(mDirtyRect);

					doDrawBG(c);

					updateAnimation();

					doDrawCursor(c);

				}
			} finally {
				if (c != null) {
					mSurfaceHolder.unlockCanvasAndPost(c);
				}
			}

		}
	}

	private void doDrawBG(Canvas c) {
		if (mMillisecondAtFrameBeginning != -1) {
			mMillisecondPerFrame = System.currentTimeMillis() - mMillisecondAtFrameBeginning;
// System.out.println((1000 * 1000 / mMillisecondPerFrame) / 1000);
		}
		mMillisecondAtFrameBeginning = System.currentTimeMillis();

		Bitmap bgbmp = getWallpaper();
		c.drawBitmap(bgbmp, 0, 0, null);

		getCurPreview(c);

	}

	private void doDrawCursor(Canvas c) {
		Paint p = new Paint();
		p.setAlpha((int) (255d * mCursorAlpha));
		c.drawBitmap(getCursorBmp(), mCursorMatrix, p);

		if (mState == STATE_PLAY_TUTORIAL) {
			p = new Paint();
			p.setAlpha((int) (255d * mFingerAlpha));
			c.drawBitmap(getFingerBmp(), mFingerMatrix, p);
		}
	}

	private int mCursorPosIdx = 0;
	private Matrix mCursorMatrix;
	private float mCursorAlpha;

	private Matrix mFingerMatrix;
	private float mFingerAlpha;

	private long mTutorialStateTime = -1;
	private static final long TOTORIAL_STATE = 2000;

	private long mMillisecondPerFrame;
	private long mMillisecondAtFrameBeginning = -1L;

	public int getCursorPosIdx() {
		return mCursorPosIdx;
	}

	private Runnable mTutorialHideShowMenuRunnable = new Runnable() {

		@Override
		public void run() {
			((AppWidgetDiyTool) getActivity()).hideAndShowDiyUnitOption(false);

		}
	};

	private void updateAnimation() {

// System.out.println("state=" + mState);
		switch (mState) {
		case STATE_NO_ANIMATION: {
			mCursorMatrix = new Matrix();
			mCursorAlpha = 0.0f;
		}
			break;

		case STATE_PLAY_TUTORIAL: {
// if (mDiyableUnits == null) {
// return;
// }
			AbstractDiyableUnit[] diyableUnits = getCurDiyableUnits().getDiyableUnits();
			if (mTutorialStateTime == -1) {
				mTutorialStateTime = System.currentTimeMillis();
			}
			if (System.currentTimeMillis() - mTutorialStateTime >= TOTORIAL_STATE) {
				mTutorialStateTime = System.currentTimeMillis();
				mCursorPosIdx++;

				getFingerPressAnimation().reset();
				getFingerPressAnimation().start();

				if (mCursorPosIdx == diyableUnits.length) {
					mCursorPosIdx = 0;
					setPlayState(AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_DIY_CURSOR_ANIMATION);
					((AppWidgetDiyTool) getActivity()).tutorialFinished();
				}
				mUIHandler.post(mTutorialHideShowMenuRunnable);
			}

		}
// break;
		case STATE_PLAY_DIY_CURSOR_ANIMATION: {

			AWType type = getCurAWType();
			if (type == null) {
				return;
			}
			AbstractDiyableUnit[] diyableUnits = getCurDiyableUnits().getDiyableUnits();

			if (diyableUnits.length == 0) {
				return;
			}

			int left, top;
			{
				Transformation cursorTransformation = new Transformation();
				getCursorAnimation().getTransformation(System.currentTimeMillis(), cursorTransformation);
				mCursorMatrix = cursorTransformation.getMatrix();

				boolean isBg = (type == AWType._1ST_4X2 && mCursorPosIdx == _1st4x2DiyableAppWidget.IDX_WIDGET_BG);
				isBg = isBg || (type == AWType._1ST_4X1 && mCursorPosIdx == _1st4x1DiyableAppWidget.IDX_WIDGET_BG);
				isBg = isBg || (type == AWType._2ND_4X2 && mCursorPosIdx == _2nd4x2DiyableAppWidget.IDX_WIDGET_BG);

				Rect rect = diyableUnits[mCursorPosIdx].getDrawBounds();
				if (isBg) {
					left = rect.left;
					top = rect.top;
				} else {
					left = rect.left + Math.abs(rect.left - rect.right) / 2 - getCursorBmp().getWidth() / 2;
					top = rect.top + Math.abs(rect.top - rect.bottom) / 2 - getCursorBmp().getHeight() / 2;
				}

				mCursorMatrix.postTranslate(left, top);
				mCursorAlpha = cursorTransformation.getAlpha();
			}

			if (mState == STATE_PLAY_TUTORIAL) {
				Transformation fingerTransformation = new Transformation();
				getFingerPressAnimation().getTransformation(System.currentTimeMillis(), fingerTransformation);
				mFingerMatrix = fingerTransformation.getMatrix();
				mFingerMatrix.postTranslate(left + getFingerBmp().getWidth() / 5, top + getFingerBmp().getHeight() * 2 / 5);
				mFingerAlpha = fingerTransformation.getAlpha();

			}

		}
			break;
		}

	}

	public void setPlayState(int state) {
		mState = state;
// System.out.println(mState + " " + state);
		if (mState == STATE_PLAY_DIY_CURSOR_ANIMATION) {
			mUIHandler.removeCallbacks(mTutorialHideShowMenuRunnable);
		}
	}

	public void setPlay(boolean play) {

		mPlay = play;
		if (mPlay) {
			getCursorAnimation().start();
		}
	}

	public void setSurfaceSize(int width, int height) {

	}

	public boolean setCursorPos(int downx, int downy, int upx, int upy) {

		AbstractDiyableUnit[] diyableUnits = getCurDiyableUnits().getDiyableUnits();

		if (diyableUnits.length == 0) {
			return false;
		}

		float density = getDensity();

		int radius = (int) ((float) getCursorRadius() * density);

		int foundI = -1;

		for (int i = 0; i < diyableUnits.length; i++) {
			Rect cr = diyableUnits[i].getTouchableBounds();
			if (cr.contains(downx, downy) && cr.contains(upx, upy)) {
				if (foundI == -1) {
					foundI = i;
				} else {
					int sizec = Math.abs((cr.right - cr.left) * (cr.bottom - cr.top));
					Rect fr = diyableUnits[foundI].getTouchableBounds();
					int sizefound = Math.abs((fr.right - fr.left) * (fr.bottom - fr.top));
					if (sizec < sizefound) {
						foundI = i;
					}
				}
			}
		}

		if (foundI == -1) {
			return false;
		} else {
			AppWidgetDiyTool awdtActivity = (AppWidgetDiyTool) getActivity();
			if (mCursorPosIdx != foundI) {
				diyableUnits[mCursorPosIdx].onOkPressed();
				mCursorPosIdx = foundI;

				awdtActivity.hideAndShowDiyUnitOption(true);

			} else {
				if (!awdtActivity.menuIsShown()) {
					awdtActivity.showDiyUnitOption(true);
				}
			}

		}

		return false;
	}

	void makeOptionMenu(LinearLayout ll, TextView title, boolean remake, boolean prepare) {

		AbstractDiyableUnit[] diyableUnits = getCurDiyableUnits().getDiyableUnits();

		if (diyableUnits.length == 0) {
			return;
		}

		title.setText(diyableUnits[mCursorPosIdx].getOptionsTitle());

		View[] menuItems = diyableUnits[mCursorPosIdx].getOptions(remake, prepare);
		ll.removeAllViews();
		for (View v : menuItems) {
			ViewGroup vg = ((ViewGroup) (v.getParent()));
			if (vg != null) {
				vg.removeView(v);
			}

			ll.addView(v);
		}

		for (View v : menuItems) {
			if (v instanceof RadioButton) {
				RadioButton rbtn = (RadioButton) v;
				if (rbtn.isChecked()) {

					Rect rbtnrect = new Rect();
					rbtn.getDrawingRect(rbtnrect);
					ll.offsetDescendantRectToMyCoords(rbtn, rbtnrect);

					ScrollView sv = (ScrollView) ll.getParent();
					sv.requestChildRectangleOnScreen(ll, rbtnrect, true);

				}
			} else {
				break;
			}
		}

	}

}
