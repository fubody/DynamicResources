package sina.mobile.tianqitong.service.frm;

public interface MsgFunction extends MsgRequestExecutor, MsgResponseHandler {

}
