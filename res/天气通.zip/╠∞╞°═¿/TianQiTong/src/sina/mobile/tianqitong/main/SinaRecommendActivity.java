package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import android.app.TabActivity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import android.widget.TabHost;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabWidget;
import android.widget.TextView;

public class SinaRecommendActivity extends TabActivity /*implements View.OnClickListener*/ {
	private static final String SOFTWARE = "software";
	private static final String WEBSITE = "website";
	private static final String CONSTELLATION_URL = "http://ast.sina.cn";
	private static final String LOTTERY_URL = "http://3g.sina.com.cn/dpool/lottery/jh_index.php";
	private static final String FLIGHT_URL = "http://3g.sina.com.cn/iask/tools/flight.php";
	private static final String TRAIN_URL = "http://3g.sina.com.cn/iask/tools/train_index.php";
	private static final String TRAFFIC_URL = "http://3g.sina.com.cn/iask/tools2/traffic/index3.php";
	private static final String BST_URL = "http://3g.sina.com.cn/3g/bst";
	private TabWidget mTabWidget;
	private RadioGroup mButton;
	private TabHost mTabHost;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sina_recommend_main);

		mTabHost = getTabHost();
		
		mButton = (RadioGroup) findViewById(R.id.tabRadio);
		mButton.setOnCheckedChangeListener(new ButtonChecked());
		TabHost.TabSpec spec;
		mTabWidget = mTabHost.getTabWidget();

		Intent intent = new Intent(this, SinaSoftWareActivity.class);

		spec = mTabHost.newTabSpec(SOFTWARE).setIndicator("").setContent(intent);
		mTabHost.addTab(spec);

		Intent intent2 = new Intent(this, SinaWebSiteActivity.class);
		spec = mTabHost.newTabSpec(WEBSITE).setIndicator("").setContent(intent2);
		mTabHost.addTab(spec);

		/*// 为了消除滑动时候上下的黑边
		FrameLayout frameLayout = mTabHost.getTabContentView();
		frameLayout.setPadding(frameLayout.getPaddingLeft(), frameLayout.getPaddingTop() - 5, frameLayout.getPaddingRight(), frameLayout.getPaddingBottom() - 3);
*/
		/*//setTabBackground(R.drawable.software_selected, R.drawable.website_normal);
		mTabHost.setOnTabChangedListener(new OnTabChangeListener() {
			@Override
			public void onTabChanged(String arg0) {
				if (arg0.equals(SOFTWARE)) {
					setTabBackground(R.drawable.software_selected, R.drawable.website_normal);
				} else if (arg0.equals(WEBSITE)) {
					setTabBackground(R.drawable.software_normal, R.drawable.website_selected);
				}
			}
		});*/

		//init();
	}
	
	private class ButtonChecked implements OnCheckedChangeListener {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {

			switch (checkedId) {
			case R.id.button1: {

				mTabHost.setCurrentTabByTag(SOFTWARE);
			}
				break;
			case R.id.button2: {
				mTabHost.setCurrentTabByTag(WEBSITE);
			}
				break;

			}

		}
	}

	private void setTabBackground(int resId1, int resId2) {
		View softewareView = mTabWidget.getChildAt(0);
		softewareView.setBackgroundDrawable(getResources().getDrawable(resId1));
		View websiteView = mTabWidget.getChildAt(1);
		websiteView.setBackgroundDrawable(getResources().getDrawable(resId2));
	}

	/*private void init() {
		TextView constellationTv = (TextView) findViewById(R.id.constellation);
		constellationTv.setOnClickListener(this);

		TextView lotteryTv = (TextView) findViewById(R.id.lottery);
		lotteryTv.setOnClickListener(this);

		TextView flightTv = (TextView) findViewById(R.id.flight);
		flightTv.setOnClickListener(this);

		TextView trainTv = (TextView) findViewById(R.id.train);
		trainTv.setOnClickListener(this);

		TextView trafficTv = (TextView) findViewById(R.id.traffic);
		trafficTv.setOnClickListener(this);

		TextView bstTv = (TextView) findViewById(R.id.bst);
		bstTv.setOnClickListener(this);
	}

	private void startActivitySafely(String url) {
		Uri uri = Uri.parse(url);
		try {
			Intent intent = new Intent();
			intent.setAction(Intent.ACTION_VIEW);
			intent.setData(uri);
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.constellation:
			startActivitySafely(CONSTELLATION_URL);
			break;
		case R.id.lottery:
			startActivitySafely(LOTTERY_URL);
			break;
		case R.id.flight:
			startActivitySafely(FLIGHT_URL);
			break;
		case R.id.train:
			startActivitySafely(TRAIN_URL);
			break;
		case R.id.traffic:
			startActivitySafely(TRAFFIC_URL);
			break;
		case R.id.bst:
			startActivitySafely(BST_URL);
			break;
		}

	}*/

}