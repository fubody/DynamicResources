package sina.mobile.tianqitong.citymanager;

import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_ALARM_TTS_CITY_CHANGED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_CACHE_CITYS_CHANGED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION;
import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import sina.mobile.tianqitong.service.utility.WarningCache;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 这个是用户用来管理关注城市的界面。
 * 
 * @author 黄恪
 * 
 */
public class CityManager extends Activity implements ServiceConnection, OnClickListener, Callback {

	/**
	 * 天气通服务
	 */
	private TianQiTongService _service;

	/**
	 * 
	 */
	private Handler _handler;

	/**
	 * 刷新列表用的消息
	 */
	private static final int MSG_WHAT_REFRESH_LIST = 0;

	private static final int MSG_WHAT_CREATE_TEMPICON = 2;

	public static final int SUPPORT_MAX_CITY_NUMBER = 9;

	/**
	 * 添加城市按钮
	 */
	private ImageView _btAdd = null;

	/**
	 * 城市容器
	 */
	private LinearLayout _llCitys = null;

	/**
	 * 删除城市的确认对话框
	 */
	private static final int DIALOG_ID_DELETE_CITY = 0;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		_handler = new Handler(this);

		setContentView(R.layout.city_manager);
		_btAdd = (ImageView) findViewById(R.id.add);
		_llCitys = (LinearLayout) findViewById(R.id.citys);

		_btAdd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (_llCitys.getChildCount() == SUPPORT_MAX_CITY_NUMBER) {
					Toast.makeText(CityManager.this, "天气通目前最多支持同时关注" + SUPPORT_MAX_CITY_NUMBER + "个城市。", Toast.LENGTH_SHORT).show();
				} else {
					startActivityForResult(new Intent(CityManager.this, CitySelector.class), REQUEST_CODE_ADD_CITY);

				}

			}
		});

		if (savedInstanceState != null && savedInstanceState.containsKey("currentDelCityCode")) {
			_currentDelCityCode = savedInstanceState.getString("currentDelCityCode");
			_currentDelCityName = savedInstanceState.getString("currentDelCityName");
		}

		bindService(new Intent(CityManager.this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);
	}

	private BroadcastReceiver _br;

	@Override
	public final void onServiceConnected(ComponentName name, IBinder service) {
		_service = ((TianQiTongService.TianQiTongBinder) service).getService();

		_br = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				if (action.equals(ACTION_BC_CACHE_CITYS_CHANGED)) {
					Message msg = Message.obtain();
					msg.what = MSG_WHAT_REFRESH_LIST;
					_handler.sendMessage(msg);
					// 更新提醒

				} else if (action.equals(ACTION_BC_ALARM_TTS_CITY_CHANGED)) {

					String cityCode = SPUtility.getSPString(CityManager.this, R.string.str_alarm_tts_city_code);
					String cityName = _service.getCityName(cityCode);
					Toast.makeText(CityManager.this, cityName + "为默认城市", Toast.LENGTH_SHORT).show();
					Intent notiIntent = new Intent(ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION);
					context.startService(notiIntent);

					for (int i = 0; i < _llCitys.getChildCount(); i++) {
						View vv = _llCitys.getChildAt(i);
						String tCityCode = (String) vv.getTag();
						RadioButton rbSetDefault = (RadioButton) vv.findViewById(R.id.set_default);
						if (rbSetDefault != null) {
							View ivTTS = vv.findViewById(R.id.tts);
							if (cityCode.equals(tCityCode)) {
								rbSetDefault.setChecked(true);
								ivTTS.setVisibility(View.VISIBLE);
							} else {
								rbSetDefault.setChecked(false);
								ivTTS.setVisibility(View.GONE);
							}
						}

					}
				}
			}
		};
		IntentFilter filter = new IntentFilter();
		filter.addAction(ACTION_BC_CACHE_CITYS_CHANGED);
		filter.addAction(ACTION_BC_ALARM_TTS_CITY_CHANGED);
		registerReceiver(_br, filter);

		// 绑定成功，用从服务拿到的数据更新界面
		Message msg = Message.obtain();
		msg.what = MSG_WHAT_REFRESH_LIST;
		_handler.sendMessage(msg);

	}

	private ImageView _ivTempIcon = null;

	@Override
	public boolean handleMessage(Message msg) {
		switch (msg.what) {
		case MSG_WHAT_CREATE_TEMPICON: {
			if (_ivTempIcon == null) {
				String ttscityCode = SPUtility.getSPString(this, R.string.str_alarm_tts_city_code);

				for (int i = 0; i < _llCitys.getChildCount(); i++) {
					View vv = _llCitys.getChildAt(i);
					String tCityCode = (String) vv.getTag();
					RadioButton rbSetDefault = (RadioButton) vv.findViewById(R.id.set_default);

					if (ttscityCode.equals(tCityCode)) {
						_ivTempIcon = (ImageView) findViewById(R.id.tempicon);
						Bitmap bmp = Bitmap.createBitmap(rbSetDefault.getWidth(), rbSetDefault.getHeight(), Config.ARGB_8888);
						Canvas c = new Canvas(bmp);
						rbSetDefault.draw(c);
						_ivTempIcon.setScaleType(ScaleType.FIT_XY);
						_ivTempIcon.setImageBitmap(bmp);

						break;
					}
				}
			}
			return true;
		}
// break;
		case MSG_WHAT_REFRESH_LIST: {
			// 更新界面
			String[] _cityCodes = new String[] {};
			_cityCodes = _service.getCityCodes();

			_llCitys.removeAllViews();
			LayoutInflater inflater = (LayoutInflater) CityManager.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			String ttscityCode = SPUtility.getSPString(this, R.string.str_alarm_tts_city_code);
			for (String cityCode : _cityCodes) {

				View v = inflater.inflate(R.layout.city_manager_item, null);
				v.setTag(cityCode);

				TextView tvCityName = (TextView) v.findViewById(R.id.city_name);
				String cityName = _service.getCityName(cityCode);
				String[] tmps = Utility.split(cityName, '.');
				String shortCityName = tmps[tmps.length - 1];
				tvCityName.setText(shortCityName);

				View tmp = v.findViewById(R.id.change_current_city);
				tmp.setOnClickListener(this);
				tmp.setTag(cityCode);

				ImageView btDel = ((ImageView) v.findViewById(R.id.del));
				btDel.setOnClickListener(this);
				btDel.setTag(cityCode);

				RadioButton rbSetDefault = (RadioButton) v.findViewById(R.id.set_default);
				rbSetDefault.setOnClickListener(this);
				rbSetDefault.setTag(cityCode);

				View ivTTS = v.findViewById(R.id.tts);
				if (cityCode.equals(ttscityCode)) {
					rbSetDefault.setChecked(true);
					ivTTS.setVisibility(View.VISIBLE);
					if (_ivTempIcon == null) {
						_handler.sendEmptyMessage(MSG_WHAT_CREATE_TEMPICON);
					}

				} else {
					rbSetDefault.setChecked(false);
					ivTTS.setVisibility(View.GONE);
				}

				View ivGPS = v.findViewById(R.id.gps);
				if (cityCode.startsWith(Constants.AUTO_LOCATE_CITYCODE_PREFIX)) {
					ivGPS.setVisibility(View.VISIBLE);
				} else {
					ivGPS.setVisibility(View.GONE);
				}
				v.requestLayout();

				_llCitys.addView(v);

			}

			if (_llCitys.getChildCount() == SUPPORT_MAX_CITY_NUMBER) {
				_btAdd.setEnabled(false);
			} else {
				_btAdd.setEnabled(true);
			}

			return true;
		}
// break;
		}
		return false;
	}

	public void onDestroy() {
		unbindService(this);
		if (_br != null) {
			unregisterReceiver(_br);
		}
		super.onDestroy();
	}

	@Override
	public final void onServiceDisconnected(ComponentName name) {
		_service = null;
	}

	public static final int REQUEST_CODE_ADD_CITY = 0;
	public static final int REQUEST_CODE_REPLACE_CURRENT = 1;

	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case REQUEST_CODE_ADD_CITY: {
			switch (resultCode) {
			case Activity.RESULT_OK: {

			}

				break;
			case CitySelector.RESULT_EXCEPTION: {
				finish();
			}
				break;

			default:
				break;
			}
		}
			break;
		case REQUEST_CODE_REPLACE_CURRENT: {

			switch (resultCode) {
			case Activity.RESULT_OK: {
				_service.deleteWeatherData(_currentDelCityCode);
				_service.deleteWarningData(_currentDelCityCode);
				if (WarningCache.cache.containsKey(_currentDelCityCode)) {
					WarningCache.remove(_currentDelCityCode);
					}
				_currentDelCityCode = null;
				Message tmsg = Message.obtain();
				tmsg.what = MSG_WHAT_REFRESH_LIST;
				_handler.sendMessage(tmsg);
			}

				break;
			case CitySelector.RESULT_EXCEPTION: {
				finish();
			}
				break;

			default:
				break;
			}

		}
			break;
		}

	}

	private String _currentDelCityCode = null;
	private String _currentDelCityName = null;

	public void onSaveInstanceState(Bundle state) {
		state.putString("currentDelCityName", _currentDelCityName);
		state.putString("currentDelCityCode", _currentDelCityCode);
	}

	public Dialog onCreateDialog(int dialogId) {
		switch (dialogId) {
		case DIALOG_ID_DELETE_CITY: {
			AlertDialog.Builder adb = new Builder(this);
			// 应该在onprepare的时候设定标题，但是这里必须有非0长度字符串占位置。
			adb.setTitle("删除城市");
			String cityName = _currentDelCityName;
			if (_llCitys.getChildCount() == 1) {
				adb.setMessage(cityName + "是最后一个城市了，确定选其它城市替换么？");
			} else {
				adb.setMessage("确定删除" + cityName + "?");

			}
			adb.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					if (_llCitys.getChildCount() == 1) {
						// 跳转进选择城市界面。
						startActivityForResult(new Intent(CityManager.this, CitySelector.class), REQUEST_CODE_REPLACE_CURRENT);
					} else {
						_service.deleteWeatherData(_currentDelCityCode);
						_service.deleteWarningData(_currentDelCityCode);
						if (WarningCache.cache.containsKey(_currentDelCityCode)) {
							WarningCache.remove(_currentDelCityCode);
							}
						_currentDelCityCode = null;
						Message tmsg = Message.obtain();
						tmsg.what = MSG_WHAT_REFRESH_LIST;
						_handler.sendMessage(tmsg);
					}
					removeDialog(DIALOG_ID_DELETE_CITY);

				}
			});
			adb.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_DELETE_CITY);
				}
			});
			return adb.create();
		}

		}
		return null;
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.del: {
			String cityCode = (String) v.getTag();
			_currentDelCityCode = cityCode;
			_currentDelCityName = _service.getCityName(cityCode);
			showDialog(DIALOG_ID_DELETE_CITY);

		}
			break;
		case R.id.city_name:
		case R.id.change_current_city: {
			String cityCode = (String) v.getTag();
			SPUtility.putSPString(this, R.string.str_current_city_code, cityCode);
			finish();
		}
			break;
		case R.id.set_default: {
			String cityCode = (String) v.getTag();
			SPUtility.putSPString(this, R.string.str_alarm_tts_city_code, cityCode);
			SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_setting_alarm_city_at_citymanager);
		}
			break;
		}

	}

}
