package sina.mobile.tianqitong.main;

import java.util.ArrayList;
import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.model.WarningInfo;
import sina.mobile.tianqitong.service.model.WeekRecommendListInfo;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_LEVEL;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_TITLE;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_CONTENT;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_DATE;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_ADDRESS;

public class WarningDialogManager extends Activity implements OnClickListener{

	private LinearLayout layout_custom,layout_fix;
	private ScrollView scrollview_custom,scrollview_fix;
	private TextView webFrom;
	private ArrayList<String> mWarningDateArray;
	private ArrayList<String> mWarningLevelArray;
	private ArrayList<String> mWarningTitleArray;
	private ArrayList<String> mWarningContentArray;
	private String mWarningAddress = "";
	private int warnNum = 0;
	private ImageView backBtn;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Bundle bundle = getIntent().getExtras();
		mWarningLevelArray = bundle.getStringArrayList(BUNDLE_WARNING_LEVEL);
		mWarningTitleArray = bundle.getStringArrayList(BUNDLE_WARNING_TITLE);
		mWarningContentArray = bundle.getStringArrayList(BUNDLE_WARNING_CONTENT);
		mWarningAddress = bundle.getString(BUNDLE_WARNING_ADDRESS);
		mWarningDateArray = bundle.getStringArrayList(BUNDLE_WARNING_DATE);
		warnNum = mWarningLevelArray.size();
		
	
		
		if (warnNum == 1) {	
			setContentView(R.layout.warning_layout_for_one);
			backBtn = (ImageView) findViewById(R.id.back);
			backBtn.setOnClickListener(this);
			
			scrollview_custom = (ScrollView) findViewById(R.id.warning_scrollview_custom);
			scrollview_custom.setVisibility(View.VISIBLE);
			layout_custom = (LinearLayout) findViewById(R.id.warning_layout_custom);
			for (int i = 0; i < warnNum; i++) {
				View itemView = getItemView(i);
				layout_custom.addView(itemView);
			}
			webFrom = (TextView) findViewById(R.id.warning_item_website);
			webFrom.setText("--来自中国气象频道");
			
		}else{
			setContentView(R.layout.warning_layout);
			backBtn = (ImageView) findViewById(R.id.back);
			backBtn.setOnClickListener(this);
			
			scrollview_fix = (ScrollView) findViewById(R.id.warning_scrollview_fix);
			scrollview_fix.setVisibility(View.VISIBLE);
			layout_fix = (LinearLayout) findViewById(R.id.warning_layout_fix);
			for (int i = 0; i < warnNum; i++) {
				View itemView = getItemView(i);
				layout_fix.addView(itemView);
			}
			webFrom = (TextView) findViewById(R.id.warning_item_website);
			webFrom.setText("--来自中国气象频道");
		}

	
	
	}

	
	private View getItemView(int position) {

		LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View View = layoutInflater.inflate(R.layout.warning_item_layout, null);
		ImageView mPic = (ImageView) View.findViewById(R.id.warning_item_image);
		TextView mTitle = (TextView) View.findViewById(R.id.warning_item_title);
		TextView mContent = (TextView) View.findViewById(R.id.warning_item_content);
		TextView mDate = (TextView) View.findViewById(R.id.warning_item_date);

		if (mWarningLevelArray.get(position).contains("黄")) {
// mTitle.setTextColor(MainActivity._warningColors[0]);
			mPic.setImageResource(MainActivity._warningImage[0]);
		} else if (mWarningLevelArray.get(position).contains("橙")) {
// mTitle.setTextColor(MainActivity._warningColors[1]);
			mPic.setImageResource(MainActivity._warningImage[1]);
		} else if (mWarningLevelArray.get(position).contains("红")) {
// mTitle.setTextColor(MainActivity._warningColors[2]);
			mPic.setImageResource(MainActivity._warningImage[2]);
		} else if (mWarningLevelArray.get(position).contains("蓝")) {
// mTitle.setTextColor(MainActivity._warningColors[3]);
			mPic.setImageResource(MainActivity._warningImage[3]);
		}
		mTitle.setText(mWarningTitleArray.get(position));
		mContent.setText(mWarningContentArray.get(position));
		mDate.setText(mWarningDateArray.get(position));

		return View;

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.back:
			finish();
			break;
		}

	}
}
