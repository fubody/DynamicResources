package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_URL;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.SinaRecommendManager;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.frm.HandlerObserver;
import sina.mobile.tianqitong.service.frm.MsgRequestExecutorHelper;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.model.DownloadItem;
import sina.mobile.tianqitong.service.model.SinaRecommendModel;
import sina.mobile.tianqitong.service.model.SinaSoftWareListItemInfo;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class SinaSoftWareActivity extends ListActivity {

	private SinaRecommendManager mSinaRecommendManager;
	private List<SinaSoftWareListItemInfo> mListItemInfo = new ArrayList<SinaSoftWareListItemInfo>();
	private SoftWareListAdapter mAdapter = null;
	private TianQiTongDownloadManger mTianQiTongDownloadManger = null;
	private HashMap<String, SinaRecommendModel> mHolderViewHashMap = new HashMap();
	private DownLoadListener mDownLoadListener = null;
	private ButtonCancelListener mDownLoadCancelListener = null;
	private HashSet<String> mDowningSet = new HashSet();
	private SinaSoftWareListItemInfo mDownLoadSoftware = null;
	private HashMap<Integer, View> mViewHashMap = new HashMap();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mDownLoadListener = new DownLoadListener();
		mDownLoadCancelListener = new ButtonCancelListener();

		mSinaRecommendManager = SinaRecommendManager.getInstance(null);
		HandlerObserver.registerObserver(mHandler, null);

		mSinaRecommendManager.refreshRecommendList(null);

		mTianQiTongDownloadManger = TianQiTongDownloadManger.getInstance(null);

		mAdapter = new SoftWareListAdapter(this);
		setListAdapter(mAdapter);
		buildData();
		mAdapter.setData(mListItemInfo);

	}

	private Handler mHandler = new Handler() {

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerObserver.NTY2HANDLER_MSG_WHAT_SINA_RECOMMEND_LIST_UPDATED: {
				buildData();
			}
				break;
			case HandlerObserver.NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_PROGRESS_UPDATED: {

				String url = msg.getData().getString(MSG_DATA_KEY_STR_URL);
				int type = mTianQiTongDownloadManger.getDownloadItem(url).getType();

				if (type == DownloadItem.TYPE_SINA_RECOMMEND_ICON && msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP) == 100) {
					SinaSoftWareListItemInfo itemInfo = mUrlKeyHashMap.get(url);
					if (itemInfo != null)
						itemInfo.refreshFile(url);
					mAdapter.notifyDataSetChanged();
				}

				if (type == DownloadItem.TYPE_SINA_SOFTWARE) {
					SinaSoftWareListItemInfo itemInfo = mUrlKeyHashMap.get(url);

					String currlyDownKeyName = itemInfo.getKeyName();

					SinaRecommendModel recommendModel = mHolderViewHashMap.get(currlyDownKeyName);
					if (recommendModel != null) {
						mAdapter.notifyDataSetChanged();
						recommendModel.mItemInfo.setPresent(msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP) + "%");
						recommendModel.mItemInfo.setProgress(msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP));
						/*recommendModel.mHodler.mProgressBar.setProgress(msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP));
						recommendModel.mHodler.mPresent.setText(msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP) + "%");*/
						
					}
					if (msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP) == 100) {
						mDowningSet.remove(currlyDownKeyName);
						mUrlKeyHashMap.get(url).refreshFile(url);
						if (recommendModel != null) {
							recommendModel.mItemInfo.setPresent("0%");
							recommendModel.mItemInfo.setProgress(0);
						}
						mAdapter.notifyDataSetChanged();
						creatInstallDialog(itemInfo);

					}
				}

			}
				break;

			}
		};
	};

	private void creatInstallDialog(final SinaSoftWareListItemInfo itemInfo) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("安装提示");
		builder.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
		builder.setMessage("是否安装已下载的软件?");
		builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				try {
					Intent intent = new Intent();
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.setAction(android.content.Intent.ACTION_VIEW);
					intent.setDataAndType(Uri.fromFile(itemInfo.getSinaRecommendApkFile()), "application/vnd.android.package-archive");
					startActivity(intent);
				} catch (ActivityNotFoundException e) {
					e.printStackTrace();
				}

			}
		});
		builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}

	private String mSdDir = null;
	private String mFilePath = null;
	private HashMap<String, SinaSoftWareListItemInfo> mUrlKeyHashMap = new HashMap();

	private void buildData() {
		SinaSoftWareListItemInfo[] recommendInfos = (SinaSoftWareListItemInfo[]) mSinaRecommendManager.getRecommendInfos(SinaSoftWareListItemInfo.TYPE_SOFTWARE);
		HashSet iconSet = new HashSet();
		mSdDir = getSDPath();
		mListItemInfo.clear();
		if (recommendInfos != null) {
			for (int i = 0; i < recommendInfos.length; i++) {
				mListItemInfo.add(recommendInfos[i]);

				if (recommendInfos[i].getIconFile() == null && recommendInfos[i].getIconHttpUrl() != null) {
					iconSet.add(recommendInfos[i].getIconHttpUrl());
					mUrlKeyHashMap.put(recommendInfos[i].getIconHttpUrl(), recommendInfos[i]);
				}

				/*
				 * if (recommendInfos[i].getSinaRecommendApkFile() == null && recommendInfos[i].getSinaRecommendApkHttpUrl() != null) {
				 * mUrlKeyHashMap.put(recommendInfos[i].getSinaRecommendApkHttpUrl(), recommendInfos[i]); }
				 */
				mUrlKeyHashMap.put(recommendInfos[i].getSinaRecommendApkHttpUrl(), recommendInfos[i]);

			}

		}

		mAdapter.notifyDataSetChanged();
		if (mSdDir != null) {
			mFilePath = mSdDir + "/TianQiTong/SinaRecommend/";
		} else {
			return;
		}

		if (iconSet.size() != 0) {
			String[] urls = new String[iconSet.size()];
			iconSet.toArray(urls);
			int[] types = new int[iconSet.size()];
			String[] filePaths = new String[iconSet.size()];
			for (int i = 0; i < iconSet.size(); i++) {
				types[i] = DownloadItem.TYPE_SINA_RECOMMEND_ICON;
				filePaths[i] = mFilePath + getNameFromUrl(urls[i]);
			}

			mTianQiTongDownloadManger.downloadAll(urls, types, filePaths, true);
		}

	}

	private String getNameFromUrl(String str) {
		return str.substring(str.lastIndexOf("/") + 1, str.length());
	}

	private String getSDPath() {
		File sdDir = null;

		if (Utility.sdAvailiable()) {
			sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
		}
		if (sdDir != null) {
			return sdDir.toString();
		} else {
			return null;
		}

	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		if (!Utility.sdAvailiable()) {
			Toast.makeText(SinaSoftWareActivity.this, "找不到sd卡", Toast.LENGTH_LONG).show();
			return;
		}

		SinaRecommendModel model = (SinaRecommendModel) v.getTag();
		mDownLoadSoftware = model.mItemInfo;
		model.mHodler.mDownLoadBtn.setVisibility(View.GONE);
		mDowningSet.add(model.mItemInfo.getKeyName());
		model.mHodler.mProgressBar.setVisibility(View.VISIBLE);
		model.mHodler.mPresent.setVisibility(View.VISIBLE);
		model.mHodler.mCancelBtn.setVisibility(View.VISIBLE);
		model.mHodler.mSize.setVisibility(View.GONE);
		String[] urls = { model.mItemInfo.getSinaRecommendApkHttpUrl() };
		int[] types = { DownloadItem.TYPE_SINA_SOFTWARE };
		String[] filePaths = { mFilePath + getNameFromUrl(model.mItemInfo.getSinaRecommendApkHttpUrl()) };
		mTianQiTongDownloadManger.downloadAll(urls, types, filePaths, true);

		// 用户点击下载上传id给服务器做统计数据
		mSinaRecommendManager.sendClickIdForService(mDownLoadSoftware.getId(), null);

	}

	private class SoftWareListAdapter extends BaseAdapter {

		private LayoutInflater mInflater;
		List<SinaSoftWareListItemInfo> mListData = new ArrayList<SinaSoftWareListItemInfo>();

		public void setData(List<SinaSoftWareListItemInfo> listData) {
			mListData = listData;

		}

		public SoftWareListAdapter(Context context) {
			mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return mListData.size();
		}

		@Override
		public Object getItem(int arg0) {
			return mListData.get(arg0);
		}

		@Override
		public long getItemId(int arg0) {
			return arg0;
		}

		@Override
		public View getView(int idx, View arg1, ViewGroup arg2) {
			SoftwareViewHolder holder = null;
			/*
			 * if (arg1 == null) { holder=new SoftwareViewHolder(); arg1 = mInflater.inflate(R.layout.software_list_item, null); holder.init(arg1, mListData, idx); arg1.setTag(holder);
			 * 
			 * }else{ holder = (SoftwareViewHolder)arg1.getTag(); }
			 */
			View itemView = null;

			/*
			 * String key = mListData.get(idx).getKeyName(); Log.d("xxxx","------arg0-------:"+idx); if(!mHolderViewHashMap.containsKey(key)) { holder = new SoftwareViewHolder(); itemView =
			 * mInflater.inflate(R.layout.software_list_item, null); mViewHashMap.put(idx, itemView); holder.init(itemView, mListData, idx); itemView.setTag(holder); }else{ itemView =
			 * mViewHashMap.get(idx); arg2.removeView(itemView); holder = (SoftwareViewHolder)itemView.getTag(); }
			 */
			holder = new SoftwareViewHolder();
			itemView = mInflater.inflate(R.layout.software_list_item, null);
			holder.init(itemView, mListData, idx);
			itemView.setTag(mHolderViewHashMap.get(mListData.get(idx).getKeyName()));
			holder.update(idx, mListData);

			return itemView;
		}

	}

	public class SoftwareViewHolder {
		public ImageView mIcon;
		public TextView mName;
		public TextView mSize;
		public TextView mClass;
		public TextView mBrief;
		public ImageView mDownLoadBtn;
		public ProgressBar mProgressBar;
		public TextView mPresent;
		private Button mCancelBtn;

		private void init(View arg1, List<SinaSoftWareListItemInfo> listData, int position) {
			SinaSoftWareListItemInfo item = listData.get(position);
			mIcon = (ImageView) arg1.findViewById(R.id.icon);
			mName = (TextView) arg1.findViewById(R.id.name);
			mSize = (TextView) arg1.findViewById(R.id.size);
			mClass = (TextView) arg1.findViewById(R.id.class_tv);
			mBrief = (TextView) arg1.findViewById(R.id.brief);
			mDownLoadBtn = (ImageView) arg1.findViewById(R.id.down_load_image);
			mDownLoadBtn.setOnClickListener(mDownLoadListener);
			mDownLoadBtn.setTag(item);
			mProgressBar = (ProgressBar) arg1.findViewById(R.id.down_load_progress);
			mPresent = (TextView) arg1.findViewById(R.id.present);
			mCancelBtn = (Button) arg1.findViewById(R.id.cancel);
			//mCancelBtn.setOnClickListener(mDownLoadCancelListener);
			//mCancelBtn.setTag(item);
			SinaRecommendModel model = new SinaRecommendModel(item, this);
			mHolderViewHashMap.put(item.getKeyName(), model);

			if (mDowningSet.contains(item.getKeyName())) {
				mDownLoadBtn.setVisibility(View.GONE);
				mCancelBtn.setVisibility(View.VISIBLE);
				mProgressBar.setVisibility(View.VISIBLE);
				mPresent.setVisibility(View.VISIBLE);
				mSize.setVisibility(View.GONE);

				SinaRecommendModel recommendModel = mHolderViewHashMap.get(item.getKeyName());
				if (recommendModel != null) {
					recommendModel.mHodler.mProgressBar.setProgress(recommendModel.mItemInfo.getProgress());
					recommendModel.mHodler.mCancelBtn.setOnClickListener(mDownLoadCancelListener);
					recommendModel.mHodler.mCancelBtn.setTag(item);
					if(TextUtils.isEmpty(recommendModel.mItemInfo.getPresent())){
						recommendModel.mHodler.mPresent.setText("0%");
					}else{
						recommendModel.mHodler.mPresent.setText(recommendModel.mItemInfo.getPresent());
					}
					
				}
			}
		}

		private void update(int position, List<SinaSoftWareListItemInfo> listData) {
			SinaSoftWareListItemInfo itemInfo = listData.get(position);
			// mIcon.setImageResource((Integer)((mListData.get(position).get("icon"))));
			mName.setText(itemInfo.getName());
			mSize.setText(itemInfo.getSize());
			mClass.setText(itemInfo.getClassification());
			mBrief.setText(itemInfo.getBrief());
			itemInfo.setIcon(mIcon);
		}

	}

	private class DownLoadListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			if (!Utility.sdAvailiable()) {
				Toast.makeText(SinaSoftWareActivity.this, "找不到sd卡", Toast.LENGTH_LONG).show();
				return;
			}

			mDownLoadSoftware = (SinaSoftWareListItemInfo) v.getTag();
			v.setVisibility(View.GONE);
			mDowningSet.add(mDownLoadSoftware.getKeyName());
			mHolderViewHashMap.get(mDownLoadSoftware.getKeyName()).mHodler.mProgressBar.setVisibility(View.VISIBLE);
			mHolderViewHashMap.get(mDownLoadSoftware.getKeyName()).mHodler.mPresent.setVisibility(View.VISIBLE);
			mHolderViewHashMap.get(mDownLoadSoftware.getKeyName()).mHodler.mCancelBtn.setVisibility(View.VISIBLE);
			mHolderViewHashMap.get(mDownLoadSoftware.getKeyName()).mHodler.mSize.setVisibility(View.GONE);
			String[] urls = { mDownLoadSoftware.getSinaRecommendApkHttpUrl() };
			int[] types = { DownloadItem.TYPE_SINA_SOFTWARE };
			String[] filePaths = { mFilePath + getNameFromUrl(mDownLoadSoftware.getSinaRecommendApkHttpUrl()) };
			mTianQiTongDownloadManger.downloadAll(urls, types, filePaths, true);
			mAdapter.notifyDataSetChanged();
			mSinaRecommendManager.sendClickIdForService(mDownLoadSoftware.getId(), null);
		}
	}

	private class ButtonCancelListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			SinaSoftWareListItemInfo item = (SinaSoftWareListItemInfo) v.getTag();
			mTianQiTongDownloadManger.cancelRequest(item.getSinaRecommendApkHttpUrl());
			mDowningSet.remove(item.getKeyName());
			item.setPresent("0%");
			item.setProgress(0);
			mAdapter.notifyDataSetChanged();
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (!mDowningSet.isEmpty()) {
				creatCancelDownloadDialog();
				return true;

			}
		}
		return super.onKeyDown(keyCode, event);
	}

	private void creatCancelDownloadDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("正在下载确定要退出吗？");
		builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				SinaRecommendModel recommendModel = null;
				for (String keyName : mDowningSet) {
					recommendModel = mHolderViewHashMap.get(keyName);
					if (recommendModel != null) {
						mTianQiTongDownloadManger.cancelRequest(recommendModel.mItemInfo.getSinaRecommendApkHttpUrl());
						recommendModel.mItemInfo.setPresent("0%");
						recommendModel.mItemInfo.setProgress(0);
					}
				}
				mDowningSet.clear();
				finish();
			}
		});
		builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}

}
