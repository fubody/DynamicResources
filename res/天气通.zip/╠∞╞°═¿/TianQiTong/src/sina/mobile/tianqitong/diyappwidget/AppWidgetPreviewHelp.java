package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;
import sina.mobile.tianqitong.R;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.os.Bundle;
import android.text.TextPaint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;

public class AppWidgetPreviewHelp extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		HelpView hv = new HelpView(this);
		FrameLayout.LayoutParams fllp = new FrameLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		hv.setLayoutParams(fllp);
		setContentView(hv);
		hv.start();

	}

	private class HelpView extends View implements AnimationListener {

		public HelpView(Context context) {
			super(context);
			mFingerBmp = BitmapFactory.decodeResource(getResources(), R.drawable.awpv_help_finger);
			mCursorBmp = DiyableAppWidgetPreviewManager.getCursorBmp();
// mLineBmp = BitmapFactory.decodeResource(getResources(), R.drawable.awpv_help_dragline);

			int screenW = DiyableAppWidgetPreviewManager.getWidthPixels();
			int screenH = DiyableAppWidgetPreviewManager.getHeightPixels();

			mFingerAnimPress2Edit = AnimationUtils.loadAnimation(getContext(), R.anim.awpv_help_finger_press_to_edit);
			mFingerAnimPress2Edit.initialize(mFingerBmp.getWidth(), mFingerBmp.getHeight(), screenW, screenH);
			mFingerAnimPress2Edit.setAnimationListener(this);

			mFingerAnimRelease2Edit = AnimationUtils.loadAnimation(getContext(), R.anim.awpv_help_finger_release_to_edit);
			mFingerAnimRelease2Edit.initialize(mFingerBmp.getWidth(), mFingerBmp.getHeight(), screenW, screenH);
			mFingerAnimRelease2Edit.setAnimationListener(this);

			mFingerAnimPress2Change = AnimationUtils.loadAnimation(getContext(), R.anim.awpv_help_finger_press_to_change);
			mFingerAnimPress2Change.initialize(mFingerBmp.getWidth(), mFingerBmp.getHeight(), screenW, screenH);
			mFingerAnimPress2Change.setAnimationListener(this);

			mFingerAnimMove2Change = AnimationUtils.loadAnimation(getContext(), R.anim.awpv_help_finger_move_to_change);
			mFingerAnimMove2Change.initialize(mFingerBmp.getWidth(), mFingerBmp.getHeight(), screenW, screenH);
			mFingerAnimMove2Change.setAnimationListener(this);

			mFingerAnimRelease2Change = AnimationUtils.loadAnimation(getContext(), R.anim.awpv_help_finger_release_to_change);
			mFingerAnimRelease2Change.initialize(mFingerBmp.getWidth(), mFingerBmp.getHeight(), screenW, screenH);
			mFingerAnimRelease2Change.setAnimationListener(this);

			mCursorAnimClick2Edit = AnimationUtils.loadAnimation(getContext(), R.anim.awpv_help_cursor_on_click_to_edit);
			mCursorAnimClick2Edit.initialize(mCursorBmp.getWidth(), mCursorBmp.getHeight(), screenW, screenH);
			mCursorAnimClick2Edit.setAnimationListener(this);

			mFingerAnimClick2Edit = mFingerAnimPress2Edit;
			mFingerAnimDrag2Change = mFingerAnimPress2Change;

		}

		void start() {

			mFingerAnimClick2Edit.start();
			mFingerAnimDrag2Change.start();
		}

		void stop() {

		}

		private Animation mFingerAnimClick2Edit;
		private Animation mFingerAnimPress2Edit;
		private Animation mFingerAnimRelease2Edit;

		private Animation mFingerAnimDrag2Change;
		private Animation mFingerAnimPress2Change;
		private Animation mFingerAnimMove2Change;
		private Animation mFingerAnimRelease2Change;

		private Animation mCursorAnimClick2Edit;

		private Bitmap mFingerBmp;
		private Bitmap mCursorBmp;
// private Bitmap mLineBmp;

		private boolean mDrawCursor = false;

		private long mStartTime = -1L;

		public void onDraw(Canvas canvas) {

			long currentTime = System.currentTimeMillis();
			if (mStartTime == -1L) {
				mStartTime = currentTime;
			}
			int second = (int) ((currentTime - mStartTime) / 1000L);
			second = 5 - second;
			if (second <= -1) {
				finish();
				overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
				return;
			}

			canvas.drawColor(0x90000000);

			if (!mDrawCursor) {

			} else {
				Transformation outT = new Transformation();
				Paint p = new Paint();
				mCursorAnimClick2Edit.getTransformation(currentTime, outT);
				p.setAlpha((int) (outT.getAlpha() * 255f));
				canvas.drawBitmap(mCursorBmp, outT.getMatrix(), p);
			}
			{
				Transformation outT = new Transformation();
				Paint p = new Paint();
				mFingerAnimClick2Edit.getTransformation(currentTime, outT);
				p.setAlpha((int) (outT.getAlpha() * 255f));
				canvas.drawBitmap(mFingerBmp, outT.getMatrix(), p);
			}

			{

				float density = getDensity();
				float x = 160f * density;
				float y = getResources().getDimension(R.dimen.awpv_help_edit_y);
				String text = "点击预览区编辑";
				float textSize = getResources().getDimension(R.dimen.awpv_help_lable_text_size);

				drawTextWithBounder(canvas, text, (int) x, (int) y, Color.BLACK, Color.WHITE, (int) textSize);

			}
//
// {
//
// float density = getDensity();
// canvas.drawBitmap(mLineBmp, 60f * density, 200f * density, null);
// }

			{
				Transformation outT = new Transformation();
				Paint p = new Paint();
				mFingerAnimDrag2Change.getTransformation(currentTime, outT);
				p.setAlpha((int) (outT.getAlpha() * 255f));
				canvas.drawBitmap(mFingerBmp, outT.getMatrix(), p);
			}

			{

				float density = getDensity();
				float x = 160f * density;
				float y = getResources().getDimension(R.dimen.awpv_help_drag_y);
				String text = "左右滑动浏览更多";
				float textSize = getResources().getDimension(R.dimen.awpv_help_lable_text_size);

				drawTextWithBounder(canvas, text, (int) x, (int) y, Color.BLACK, Color.WHITE, (int) textSize);

			}

			{

				float density = getDensity();
				float x = 160f * density;
				float y = getResources().getDimension(R.dimen.awpv_help_second_y);
				String text = "" + second;
				float textSize = getResources().getDimension(R.dimen.awpv_help_second_text_size);

				drawTextWithBounder(canvas, text, (int) x, (int) y, Color.BLACK, Color.WHITE, (int) textSize);

			}

			invalidate();

		}

		@Override
		public void onAnimationStart(Animation animation) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onAnimationEnd(Animation animation) {
			if (animation == mFingerAnimPress2Edit) {
				mFingerAnimClick2Edit = mFingerAnimRelease2Edit;
				mFingerAnimClick2Edit.reset();
				mFingerAnimClick2Edit.start();
				mDrawCursor = true;
				mCursorAnimClick2Edit.reset();
				mCursorAnimClick2Edit.start();

			} else if (animation == mFingerAnimRelease2Edit) {
				mDrawCursor = false;
				postDelayed(new Runnable() {

					@Override
					public void run() {
						mFingerAnimClick2Edit = mFingerAnimPress2Edit;
						mFingerAnimClick2Edit.reset();
						mFingerAnimClick2Edit.start();
					}
				}, 500L);

			} else if (animation == mCursorAnimClick2Edit) {
				mDrawCursor = false;
			} else if (animation == mFingerAnimPress2Change) {
				mFingerAnimDrag2Change = mFingerAnimMove2Change;
				mFingerAnimDrag2Change.reset();
				mFingerAnimDrag2Change.start();
			} else if (animation == mFingerAnimMove2Change) {
				mFingerAnimDrag2Change = mFingerAnimRelease2Change;
				mFingerAnimDrag2Change.reset();
				mFingerAnimDrag2Change.start();
			} else if (animation == mFingerAnimRelease2Change) {
				mFingerAnimDrag2Change = mFingerAnimPress2Change;
				mFingerAnimDrag2Change.reset();
				mFingerAnimDrag2Change.start();
			}

		}

		@Override
		public void onAnimationRepeat(Animation animation) {
			// TODO Auto-generated method stub

		}

		public boolean onTouchEvent(MotionEvent event) {

			super.onTouchEvent(event);

			finish();
			overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
			return true;
		}

	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		finish();
		overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
		return super.onKeyDown(keyCode, event);
	}

	private static final void drawTextWithBounder(Canvas canvas, String text, int x, int y, int color, int bcolor, int textSize) {
		TextPaint tp = new TextPaint();
		tp.setColor(bcolor);
		tp.setAntiAlias(true);
		tp.setTextSize(textSize);
		tp.setTextAlign(Align.CENTER);

		for (int ox = -1; ox <= 1; ox++) {
			for (int oy = -1; oy <= 1; oy++) {
				canvas.drawText(text, x + ox, y + oy, tp);
			}
		}
		tp = new TextPaint();
		tp.setColor(color);
		tp.setAntiAlias(true);
		tp.setTextSize(textSize);
		tp.setTextAlign(Align.CENTER);
		canvas.drawText(text, x, y, tp);
	}
}
