package sina.mobile.tianqitong.service.model;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.zip.ZipException;

import org.xmlpull.v1.XmlPullParserException;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidgetskinpkg.TianQiTongAppWidgetSkinManager;
import sina.mobile.tianqitong.appwidgetskinpkg.TianQiTongAppWidgetSkinManager.SkinCfg;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataList;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataListItem;
import sina.mobile.tianqitong.service.utility.BitmapCache;
import sina.mobile.tianqitong.service.utility.Utility;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.ImageView;

public class AppWidgetSkin extends TQTListDataListItem {

	private AppWidgetSkin() {
		super(DownloadItem.TYPE_APPWIDGET);
	}

	public static final byte TYPE_4X2 = 0;
	public static final byte TYPE_4X1 = 1;
	private byte mType = -1;

	public final byte getAppWidgetType() {
		return mType;
	}

	public static final byte ID_DEFAULT_1st4x2 = 0;
	public static final byte ID_DEFAULT_2nd4x2 = 1;
	public static final byte ID_DEFAULT_1st4x1 = 2;
// public static final byte ID_NOT_DOWNLOADED_YET = 3;
// public static final byte ID_DOWNLOADED = 4;
// public static final byte ID_CUSTOM = 5;
	private byte mId = -1;

	public final byte getId() {
		return mId;
	}

	/**
	 * ID_DEFAULT情况有意义，图标资源id。
	 */
	private int mIconResId = 0;

// /**
// * ID_NOT_DOWNLOADED_YET情况有意义，图标下载地址。
// */
// private String mIconHttpUrl = null;
//
// /**
// * ID_NOT_DOWNLOADED_YET情况有意义，图标文件。
// */
// private File mIconFile = null;

// /**
// * ID_NOT_DOWNLOADED_YET情况有意义，皮肤包下载地址。
// */
// private String mSkinPkgHttpUrl = null;

// /**
// * ID_DOWNLOADED和ID_CUSTOM情况有意义，sd卡上皮肤包文件。
// */
// private File mSkinPkgFile = null;

	/**
	 * 名字。
	 */
	private String mName = null;

	/**
	 * 几颗星。最高5星。
	 */
	private int mStarCount = 4;

	/**
	 * 作者名字。
	 */
	protected String mAuthor = null;

	/**
	 * 皮肤包尺寸。
	 */
	private long mFileSizeKb = -1L;

	/**
	 * ID_READY_FOR_DOWNLOAD情况有意义，皮肤包排列位置。
	 */
	private int mIdx = -1;

// public synchronized void refreshFile() {
// mIconFile = getLocalFileAbsolutePathFromHttpUrl(mIconHttpUrl);
// mSkinPkgFile = getLocalFileAbsolutePathFromHttpUrl(mSkinPkgHttpUrl);
// }

// public synchronized void refreshFile(String url) {
// if (url.equals(mIconHttpUrl)) {
// mIconFile = getLocalFileAbsolutePathFromHttpUrl(mIconHttpUrl);
// } else if (url.equals(mSkinPkgHttpUrl)) {
// mSkinPkgFile = getLocalFileAbsolutePathFromHttpUrl(mSkinPkgHttpUrl);
// if (mSkinPkgFile == null) {
// mId = ID_NOT_DOWNLOADED_YET;
// } else {
// mId = ID_DOWNLOADED;
// }
// }
// }

	/**
	 * 从xml文件的元素创建一个AppWidgetSkin
	 * 
	 * @param id
	 * @param iconUrl
	 * @param soundName
	 * @param starCount
	 * @param authorName
	 * @param fileSizeKb
	 * @param fileUrl
	 * @return
	 */
	public static AppWidgetSkin makeAppWidgetSkin(String iconHttpUrl, String skinPkgHttpUrl, byte type, String name, String author, int starCount, long fileSizeKb, int idx) {
		AppWidgetSkin se = new AppWidgetSkin();

// se.mIconHttpUrl = iconHttpUrl;
		se.putAutoDownloadHttpUrl(DownloadItem.TYPE_APPWIDGET_PREVIEW_ICON, iconHttpUrl);
		se.mName = name;
		se.mStarCount = starCount;
		se.mAuthor = author;
		se.mFileSizeKb = fileSizeKb;
// se.mSkinPkgHttpUrl = skinPkgHttpUrl;
		se.setMainUrl(skinPkgHttpUrl);
		se.mIdx = idx;
		se.mType = type;

// se.refreshFile();

// if (se.mSkinPkgFile == null) {
// se.mId = ID_NOT_DOWNLOADED_YET;
// } else {
// se.mId = ID_DOWNLOADED;
// }

		return se;
	}

	/**
	 * 从本地桌面插件皮肤包文件创建AppWidgetSkin
	 * 
	 * @param localFileName
	 * @return
	 */
	public static AppWidgetSkin makeLocalAppWidgetSkin(File localSkinPkgFile) {
		AppWidgetSkin se = new AppWidgetSkin();
		SkinCfg cfg = null;
		try {
			cfg = TianQiTongAppWidgetSkinManager.getCfg(localSkinPkgFile);
		} catch (ZipException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}
		if (cfg == null) {
			return null;
		}

		File f = localSkinPkgFile;
		if (f.exists() && f.isFile()) {

// se.mSkinPkgFile = f;
			se.setMainFileAbsolutePath(f.getAbsolutePath());
			se.mFileSizeKb = f.length() / 1024L;
			se.mName = cfg.Name;
			se.mAuthor = cfg.Author;
			se.mType = cfg.Type.equals("4x2") ? TYPE_4X2 : (cfg.Type.equals("4x1") ? TYPE_4X1 : -1);
		} else {
			throw new IllegalStateException();
		}

// se.mId = ID_CUSTOM;

		se.mStarCount = 0;

		return se;
	}

	/**
	 * 创建表示默认桌面插件，即可自定义桌面插件的AppWidgetSkin
	 * 
	 * @return
	 */
	private static AppWidgetSkin getDefaultAppWidgetSkin(String name, byte type, int iconResId, byte id) {
		AppWidgetSkin se = new AppWidgetSkin();
		se.mName = name;
		se.mAuthor = "天气通官方";
		se.mStarCount = 4;
		se.mId = id;
		se.mType = type;
		se.mIconResId = iconResId;
		return se;
	}

	public static final AppWidgetSkin getDefault1st4x2AppWidgetSkin() {
		// TODO icon
		return getDefaultAppWidgetSkin("默认4x2", TYPE_4X2, R.drawable.appwidgeticon_1st4x2, ID_DEFAULT_1st4x2);
	}

	public static final AppWidgetSkin getDefault2nd4x2AppWidgetSkin() {
		// TODO icon
		return getDefaultAppWidgetSkin("简明4x2", TYPE_4X2, R.drawable.appwidgeticon_2nd4x2, ID_DEFAULT_2nd4x2);
	}

	public static final AppWidgetSkin getDefault1st4x1AppWidgetSkin() {
		// TODO icon
		return getDefaultAppWidgetSkin("默认4x1", TYPE_4X1, R.drawable.appwidgeticon_1st4x1, ID_DEFAULT_1st4x1);
	}

	public boolean isDefaultAppWidget() {
		switch (getId()) {
		case AppWidgetSkin.ID_DEFAULT_1st4x1:
		case AppWidgetSkin.ID_DEFAULT_1st4x2:
		case AppWidgetSkin.ID_DEFAULT_2nd4x2: {
			return true;
		}
		default: {
			return false;
		}
		}
	}

	public static final String DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX = "sina.mobile.tianqitong.defaultappwidgetskin";

	public static final String DEFAULT_1ST4X2_KEYNAME = DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX + ID_DEFAULT_1st4x2;
	public static final String DEFAULT_2ND4X2_KEYNAME = DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX + ID_DEFAULT_2nd4x2;
	public static final String DEFAULT_1ST4X1_KEYNAME = DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX + ID_DEFAULT_1st4x1;

	/**
	 * 取得除去后缀的皮肤包文件名。这个字符串作为key使用。
	 * 
	 * @return
	 */
	public String getKey() {
		switch (mId) {
		case ID_DEFAULT_1st4x2:
		case ID_DEFAULT_2nd4x2:
		case ID_DEFAULT_1st4x1: {
			return DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX + mId;
		}
		default: {
			return super.getKey();
		}
		}
	}

	/**
	 * 按照url取文件的本地路径。
	 * 
	 * @param url
	 * @return
	 */
	protected File getLocalFileAbsolutePathFromHttpUrl(String url) {
		String[] tmp = Utility.split(url, '/');
		String fileName = tmp[tmp.length - 1];
		File f = null;
		if (mType == TYPE_4X1) {
			f = new File(Utility.getAppWidget4x1Dir(), fileName);
		} else if (mType == TYPE_4X2) {
			f = new File(Utility.getAppWidget4x2Dir(), fileName);
		}

		if (f.exists() && f.isFile()) {
			return f;
		} else {
			return null;
		}
	}

	public void setIcon(ImageView iv) {
		switch (mId) {
		case ID_DEFAULT_1st4x1:
		case ID_DEFAULT_1st4x2:
		case ID_DEFAULT_2nd4x2: {
			iv.setImageResource(mIconResId);
		}
			break;
		default: {

			String path = getMainFileAbsolutePath();
			if (path != null) {
				File f = new File(path);
				if (f.exists() && f.isFile()) {
					try {
						Bitmap icon = TianQiTongAppWidgetSkinManager.getIcon(f, getKey());
						iv.setImageBitmap(icon);
						return;
					} catch (ZipException ze) {
						ze.printStackTrace();
						// 如果有异常，没有return，就会走到最下面使用default
					} catch (IOException ioe) {
						ioe.printStackTrace();
						// 如果有异常，没有return，就会走到最下面使用default
					}
				}
			}
			
			{
				path = getAutoDownloadSDFileAbsolutePath(DownloadItem.TYPE_APPWIDGET_PREVIEW_ICON);
				if (path != null) {
					File f = new File(path);
					if (f.exists() && f.isFile()) {
						iv.setImageBitmap(BitmapCache.getBitmap(path));
						return;
					}
				}
			}

			iv.setImageResource(R.drawable.item_default);
		}
		}
	}

// private File checkAndGetLocalFile(File f) {
// if (mId == ID_DEFAULT_1st4x1 || mId == ID_DEFAULT_1st4x2 || mId == ID_DEFAULT_2nd4x2) {
// return null;
// } else {
// if (f == null) {
// return null;
// } else {
// if (f.exists() && f.isFile()) {
// return f;
// } else {
// refreshFile();
// return null;
// }
// }
// }
// }

	public boolean isIconDownloaded() {
		String path = getAutoDownloadSDFileAbsolutePath(DownloadItem.TYPE_APPWIDGET_PREVIEW_ICON);
		if (path == null) {
			return false;
		}
		File f = new File(path);
		if (f.exists() && f.isFile()) {
			return true;
		}
		return false;
	}

	public File getIconFile() {
		String path = getAutoDownloadSDFileAbsolutePath(DownloadItem.TYPE_APPWIDGET_PREVIEW_ICON);
		if (path == null) {
			return null;
		}
		File f = new File(path);
		if (f.exists() && f.isFile()) {
			return null;
		}
		return f;
	}

	/**
	 * 取tts文件路径。没有下载，或者是默认包，返回null。
	 * 
	 * @return
	 */
	public File getSkinPkgFile() {
		String path = getMainFileAbsolutePath();
		if (path == null) {
			return null;
		}
		File f = new File(path);
		if (f.exists() && f.isFile()) {
			return f;
		}
		return null;
	}

	/**
	 * 取tts包的远程位置。<br>
	 * 
	 * @return
	 */
	public String getSkinPkgHttpUrl() {
		return getMainUrl();
	}

// public String getIconHttpUrl() {
// return mIconHttpUrl;
// }

	public String getName() {
		return mName;
	}

	public int getStarCount() {
		return mStarCount;
	}

	public String getAuthor() {
		return mAuthor;
	}

	public long getFileSizeKb() {
		return mFileSizeKb;
	}

	public int getIdx() {
		return mIdx;
	}

	public String toString() {
		switch (mId) {
		case ID_DEFAULT_1st4x1:
		case ID_DEFAULT_1st4x2:
		case ID_DEFAULT_2nd4x2: {
			return "default " + mName;
		}
		default: {
			return "pkg " + getKey();
		}
		}
	}
}
