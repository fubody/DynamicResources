package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_1STBTN_RUN_APP;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_2NDBTN_RUN_APP;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_PLAY_OR_STOP_PLAY_TTS;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_RUN_WEIBO;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_SWITCH_WIDGET_CITY;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL;
import static sina.mobile.tianqitong.service.IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS;
import static sina.mobile.tianqitong.service.IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS_PLAYORSTOPTTS_FROM_APPWIDGET;

import java.util.ArrayList;

import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyButton;
import sina.mobile.tianqitong.main.MainActivity;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.setting.TTSSetting;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

public class PendingIntentUtil {
	/**
	 * 进入天气通的主界面
	 * 
	 * @return
	 */
	public static PendingIntent getTianQiTong(Context context) {

		Intent i1 = new Intent(context, MainActivity.class);
		i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
		i1.putExtra(IntentActionConstants.INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET, true);
		PendingIntent pi1 = PendingIntent.getActivity(context, 0, i1, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi1;
	}
	
	/**
	 * 进入时钟
	 * 
	 * @return
	 */
	public static PendingIntent getClock(Context context) {
		Intent i1 = new Intent();
		String[] name = getClockName(context);
		if(!name[0].equals("") && !name[1].equals("")){
			i1.setClassName(name[0], name[1]);
		}else{
			i1.setClass(context, MainActivity.class);
		}
		i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
		i1.putExtra(IntentActionConstants.INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET, true);
		PendingIntent pi1 = PendingIntent.getActivity(context, 0, i1, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi1;
	}
	
	public  static String[] getClockName(Context context) {
		String [] name = new String[2];
		String pkgName = "";
		String activityName = "";
		boolean isClock = false;
		String []clockName = {"com.android.alarmclock/com.android.alarmclock.AlarmClock",
				"com.motorola.blur.alarmclock/com.motorola.blur.alarmclock.DigitalClock",
				"com.htc.android.worldclock/com.htc.android.worldclock.WorldClockTabControl",
				"com.android.deskclock/com.android.deskclock.DeskClock",
				"com.google.android.deskclock/com.android.deskclock.DeskClock",
		"jp.co.sharp.android.timerapps/jp.co.sharp.android.timerapps.TimerAppsActivity",
		"com.motorola.blur.alarmclock/com.motorola.blur.alarmclock.AlarmClock"};
		
		Intent intent1 =new Intent(Intent.ACTION_MAIN,null);
		intent1.addCategory(Intent.CATEGORY_LAUNCHER);
		
		ArrayList<ResolveInfo> packages =(ArrayList<ResolveInfo>) context.getPackageManager().queryIntentActivities(intent1,PackageManager.PERMISSION_GRANTED);
		
		if(packages != null && packages.size() > 0){
			for(ResolveInfo info : packages){
				if(!isClock){
					for(int i = 0; i < clockName.length;i ++){
						if(clockName[i].equals(info.activityInfo.packageName + "/" + info.activityInfo.name)){
							pkgName = info.activityInfo.packageName;
							activityName = info.activityInfo.name;
							isClock = true;
							break;
						}else{
							isClock = false;
						}
					}
				}
			}
		}
		name[0] = pkgName;
		name[1] = activityName;
		return name;
	}

	/**
	 * 播放天气预报
	 * 
	 * @param context
	 * @return
	 */
	public static PendingIntent getTTSPlaying(Context context) {

		Intent i0 = new Intent(ACTION_START_SERVICE_PLAY_OR_STOP_PLAY_TTS);
		if (i0.getExtras() != null) {
			i0.getExtras().clear();
		}

		i0.putExtra(EXTRA_KEY_START_SERVICE_OTHER_PARAMS, EXTRA_KEY_START_SERVICE_OTHER_PARAMS_PLAYORSTOPTTS_FROM_APPWIDGET);

		PendingIntent pi = PendingIntent.getService(context, -1, i0, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi;
	}

	/**
	 * 天气通的时间设置
	 * 
	 * @param context
	 * @return
	 */
	public static PendingIntent getSetingAlam(Context context) {

		Intent i1 = new Intent(context, TTSSetting.class);
		i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		PendingIntent pi1 = PendingIntent.getActivity(context, 0, i1, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi1;
	}

	/**
	 * 改变城市的名字
	 * 
	 * @param context
	 * @return
	 */
	public static PendingIntent getChangeCiteName(Context context) {

		Intent i2 = new Intent(ACTION_START_SERVICE_SWITCH_WIDGET_CITY);
		PendingIntent pi2 = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi2;
	}

	public static PendingIntent getRunWeibo(Context context) {

		Intent i2 = new Intent(ACTION_START_SERVICE_RUN_WEIBO);
		PendingIntent pi2 = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi2;
	}

	/**
	 * 更新天气数据
	 * 
	 * @param context
	 * @return
	 */
	public static PendingIntent getUpdateWeatherDate(Context context) {

		Intent i2 = new Intent(ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL);
		i2.putExtra(IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS, IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS_UPDATEWEATHERS_SHOW_TOAST);
		PendingIntent pi2 = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi2;
	}

	/**
	 * 
	 * @param context
	 * @return
	 */

	public static PendingIntent getOtherApp(Context context, String pkgname, String clsname, DiyButton diybtn) {

		Intent i2 = null;
		switch (diybtn) {
		case _1ST_BUTTON: {
			i2 = new Intent(ACTION_START_SERVICE_1STBTN_RUN_APP);
		}
			break;
		case _2ND_BUTTON: {
			i2 = new Intent(ACTION_START_SERVICE_2NDBTN_RUN_APP);
		}
			break;
		}

		if (pkgname != null && pkgname.length() != 0) {
			i2.putExtra("pkgname", pkgname);
			i2.putExtra("clsname", clsname);
		}
		PendingIntent pi2 = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
		return pi2;
	}

}
