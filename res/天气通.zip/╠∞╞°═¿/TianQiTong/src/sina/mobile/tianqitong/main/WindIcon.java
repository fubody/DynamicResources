package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;

/**
 * 显示风向图标和风力等级数据,图标的大小由图片大小固定。
 * 
 * @author 骆灿
 * 
 */
public class WindIcon extends View {
	private Context mContext;

	/** 图标旋转大小 */
	private int mDegree = 0;

	/** 判断是不是风向标中的第一个 */
	private boolean isFirstWindIcon;

	/** 风力等级数据 */
	private String mWindLevelText = "2";

	private float mTextSize = 20;

	private static Bitmap mWindIcon;
	private static Bitmap mWindArrowIcon;
	private static Bitmap mDarkWindIcon;
	private static Bitmap mDarkWindArrowIcon;
	private static int mIconWidth;

	private static final int WIND_LEVEL_DARK_TEXT_COLOR = 0xff5b5c5d;
	private static final int WIND_LEVEL_TEXT_COLOR = 0xff117199;

	public WindIcon(Context context, AttributeSet attrs) {
		super(context, attrs);
		mContext = context;
		if (mWindIcon == null) {
			mWindIcon = ((BitmapDrawable) context.getResources().getDrawable(R.drawable.wind_icon)).getBitmap();
			mWindArrowIcon = ((BitmapDrawable) context.getResources().getDrawable(R.drawable.wind_icon_arrow)).getBitmap();
			mDarkWindIcon = ((BitmapDrawable) context.getResources().getDrawable(R.drawable.wind_icon_dark)).getBitmap();
			mDarkWindArrowIcon = ((BitmapDrawable) context.getResources().getDrawable(R.drawable.wind_icon_arrow_dark)).getBitmap();
			mIconWidth = mWindIcon.getWidth();
		}

		isFirstWindIcon = (getId() == R.id.wind_0);

		DisplayMetrics dm = new DisplayMetrics();
		((Activity) getContext()).getWindowManager().getDefaultDisplay().getMetrics(dm);
		float d = dm.density;
		mTextSize = 13.3f * d;
	}

	/**
	 * 设置风力图标旋转角度
	 * 
	 * @param degree
	 *            图标旋转角度
	 * @param windLevel
	 *            风力值
	 */
	public void setDegreeAndWindText(int degree, String windLevel) {
		if (mDegree != degree || mWindLevelText != windLevel) {
			mDegree = degree;
			mWindLevelText = windLevel;
			invalidate();
		}
	}

	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension(mIconWidth, mIconWidth);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setAntiAlias(true);

		boolean isUseHistoryWeather = !SPUtility.getSPBoolean(mContext, R.string.boolean_use_history_weather_check);

		// 画风向标
		canvas.save();
		if (isUseHistoryWeather && isFirstWindIcon) {
			canvas.rotate(mDegree, mIconWidth / 2, mIconWidth / 2);
			canvas.drawBitmap(mDarkWindArrowIcon, 0, 0, paint);
			paint.setColor(WIND_LEVEL_DARK_TEXT_COLOR);
		} else {
			canvas.rotate(mDegree, mIconWidth / 2, mIconWidth / 2);
			canvas.drawBitmap(mWindArrowIcon, 0, 0, paint);
			paint.setColor(WIND_LEVEL_TEXT_COLOR);
		}
		canvas.restore();

		if (isUseHistoryWeather && isFirstWindIcon) {
			canvas.drawBitmap(mDarkWindIcon, 0, 0, paint);
		} else {
			canvas.drawBitmap(mWindIcon, 0, 0, paint);
		}

		// 画风力值
		paint.setTextSize(mTextSize);

		Rect r = new Rect();
		paint.getTextBounds(mWindLevelText, 0, mWindLevelText.length(), r);
		float xBegin = ((float) getWidth()) / 2 - ((float) r.right) / 2;
		float yBegin = ((float) getHeight()) / 2 - ((float) r.top) / 2;

		canvas.drawText(mWindLevelText, xBegin, yBegin, paint);
	}
}
