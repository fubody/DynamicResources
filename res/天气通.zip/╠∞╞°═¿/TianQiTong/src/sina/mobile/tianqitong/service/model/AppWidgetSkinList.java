package sina.mobile.tianqitong.service.model;

import java.io.Serializable;

import sina.mobile.tianqitong.service.simplelistdata.TQTListDataList;

public class AppWidgetSkinList extends TQTListDataList {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public int mPageNo;
	public int mPageCount;
	public String mTimeStamp = null;
}