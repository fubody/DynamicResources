package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.service.utility.BitmapCache;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import static java.lang.Integer.*;

public class MainActivityBG extends AnimationDrawable {

	private int mOldBgId = Integer.MIN_VALUE;
	private int mNewBgId = Integer.MIN_VALUE;

	private int mOldX = Integer.MIN_VALUE;
	private int mNewX = Integer.MIN_VALUE;

	private Context mContext;

	private static final int DURATION = 500;
	private static final int FRAMES = 5;
	private static final int FRAME_DURATION = DURATION / FRAMES;
	private static final int S = 256;

	public MainActivityBG(Context context, int oldBgId, int newBgId, int oldX, int newX) {
		super();
		mContext = context;
		mOldBgId = oldBgId;
		mNewBgId = newBgId;
		mOldX = oldX;
		mNewX = newX;

		int alphaS = 255 * S;
		int alphaStepS = alphaS / FRAMES;

		for (int i = 0; i < FRAMES; i++) {
			addFrame(new MainActivityBGFrame(alphaS / S), FRAME_DURATION);
			alphaS -= alphaStepS;
		}
	}

	public class MainActivityBGFrame extends Drawable {

		private int mOldAlpha = 255;

		public MainActivityBGFrame(int oldAlpha) {
			super();
			mOldAlpha = oldAlpha;
		}

		@Override
		public void draw(Canvas canvas) {
			if (mOldX != MIN_VALUE && mOldAlpha != 0 && mOldBgId != MIN_VALUE) {
				Bitmap bmp = BitmapCache.getBitmap(mOldBgId, mContext.getResources());
				Matrix m = new Matrix();
				m.postTranslate(mOldX, 0);
				Paint p = new Paint();
				p.setAlpha(mOldAlpha);
				canvas.drawBitmap(bmp, m, p);
				bmp = null;
			}
			if (mNewX != MIN_VALUE && mOldAlpha != 255 && mNewBgId != MIN_VALUE) {
				Bitmap bmp = BitmapCache.getBitmap(mNewBgId, mContext.getResources());
				Matrix m = new Matrix();
				m.postTranslate(mNewX, 0);
				Paint p = new Paint();
				p.setAlpha(255 - mOldAlpha);
				canvas.drawBitmap(bmp, m, p);
				bmp = null;
			}
		}

		@Override
		public void setAlpha(int alpha) {

		}

		@Override
		public void setColorFilter(ColorFilter cf) {

		}

		@Override
		public int getOpacity() {
			return 0;
		}

	}

}
