package sina.mobile.tianqitong.appwidgetskinpkg;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_UPDATE_APPWIDGET;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_BOOLEAN_AW_JUST_UPDATE_BTN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_BOOLEAN_AW_UPDATE_CLOCK;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_FILE_FILE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_AWTYPE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_S_DATA;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_BAD_XML;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SUCCESSFUL;
import static sina.mobile.tianqitong.service.frm.MsgUtility.sendResponse;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidget.Widget4x1Provider;
import sina.mobile.tianqitong.appwidget.WidgetProvider;
import sina.mobile.tianqitong.main.Splash;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.MsgRequestExecutorHelper;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.text.format.Time;
import android.view.View;
import android.widget.RemoteViews;

public final class TianQiTongAppWidgetSkinManager extends MsgRequestExecutorHelper {
	public String toString() {
		return "TianQiTongAppWidgetSkinManager";
	}

	private static TianQiTongAppWidgetSkinManager _instance;

	WeakReference<TianQiTongService> _wrService;

	private TianQiTongAppWidgetSkinManager(TianQiTongService service) {
		_wrService = new WeakReference<TianQiTongService>(service);
		AppWidgetSkinUtility.init(service);
	}

	public static final TianQiTongAppWidgetSkinManager getInstance(TianQiTongService service) {
		boolean invalidInstance = _instance == null || _instance._wrService.get() == null;
		if (invalidInstance) {
			if (service == null) {
				throw new IllegalStateException();
			} else {
				_instance = new TianQiTongAppWidgetSkinManager(service);
			}
		}
		return _instance;
	}

	public static final void clearInstance() {
		_instance = null;
	}

	static File m4x2ZipSkinFile = null;
	static File m4x1ZipSkinFile = null;

	private AppWidgetSkin[] m4x2AppWidgetSkins;
	private AppWidgetSkin[] m4x1AppWidgetSkins;
	private static final int IDX_PORT = 0;
	private static final int IDX_LAND = 1;

	public RemoteViews buildRemoteViews(WeatherInfo wi, boolean justUpdateBtn, final int type, boolean updateClock) {

		final String prefix;
		final File cacheDir;
		final File mZipSkinFile;

		if (type == AppWidgetSkin.TYPE_4X2) {
			prefix = AppWidgetSkin.CACHE_4X2BMP_PREFIX;
			cacheDir = AppWidgetSkinUtility.get4x2AppWidgetSkinCacheDir();
			mZipSkinFile = m4x2ZipSkinFile;
		} else if (type == AppWidgetSkin.TYPE_4X1) {
			prefix = AppWidgetSkin.CACHE_4X1BMP_PREFIX;
			cacheDir = AppWidgetSkinUtility.get4x1AppWidgetSkinCacheDir();
			mZipSkinFile = m4x1ZipSkinFile;
		} else {
			prefix = "";
			cacheDir = null;
			mZipSkinFile = null;
			throw new IllegalStateException();
		}

		Context context = _wrService.get();
		final AppWidgetSkin[] mAppWidgetSkins;
		{
			if (!AppWidgetSkinUtility.checkCacheDir(mZipSkinFile, cacheDir)) {
				if (type == AppWidgetSkin.TYPE_4X2) {
					m4x2AppWidgetSkins = AppWidgetSkin.getAppWidgetSkins(type);
				} else if (type == AppWidgetSkin.TYPE_4X1) {
					m4x1AppWidgetSkins = AppWidgetSkin.getAppWidgetSkins(type);
				}

				AppWidgetSkinUtility.releaseCacheDir(context, type);
				try {
					_wrService.get()._uiHandler.post(new Runnable() {
						public void run() {
							RemoteViews rv = new RemoteViews(_wrService.get().getPackageName(), R.layout.loading_appwidget);
							AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(_wrService.get());
							if (type == AppWidgetSkin.TYPE_4X2) {
								int[] _4x2_ids = appWidgetManager.getAppWidgetIds(new ComponentName(_wrService.get(), WidgetProvider.class));
								appWidgetManager.updateAppWidget(_4x2_ids, rv);
							} else if (type == AppWidgetSkin.TYPE_4X1) {
								int[] _4x1_ids = appWidgetManager.getAppWidgetIds(new ComponentName(_wrService.get(), Widget4x1Provider.class));
								appWidgetManager.updateAppWidget(_4x1_ids, rv);
							}
						}
					});
// 此时当cache目录被release之后，目录就不存在了，必须重新创建。
					if (type == AppWidgetSkin.TYPE_4X2) {
						AppWidgetSkinUtility.get4x2AppWidgetSkinCacheDir();
					} else if (type == AppWidgetSkin.TYPE_4X1) {
						AppWidgetSkinUtility.get4x1AppWidgetSkinCacheDir();
					}
					AppWidgetSkinUtility.makeCacheDir(context, mZipSkinFile, cacheDir);
				} catch (Exception e) {
					AppWidgetSkinUtility.releaseCacheDir(context, type);
					e.printStackTrace();
				}
			}

			if (type == AppWidgetSkin.TYPE_4X2) {
				if (m4x2AppWidgetSkins == null) {
					m4x2AppWidgetSkins = AppWidgetSkin.getAppWidgetSkins(type);
				}
				mAppWidgetSkins = m4x2AppWidgetSkins;
			} else if (type == AppWidgetSkin.TYPE_4X1) {
				if (m4x1AppWidgetSkins == null) {
					m4x1AppWidgetSkins = AppWidgetSkin.getAppWidgetSkins(type);
				}
				mAppWidgetSkins = m4x1AppWidgetSkins;
			} else {
				throw new IllegalStateException();
			}

			for (AppWidgetSkin aws : mAppWidgetSkins) {
				try {
					if (aws.mLayoutUntis == null) {
						aws.parseLayoutXml();
					}
				} catch (XmlPullParserException e) {
					continue;
				} catch (IOException e) {
					continue;
				}
			}
			if (mAppWidgetSkins[IDX_PORT].mLayoutUntis == null && mAppWidgetSkins[IDX_LAND].mLayoutUntis == null) {
				AppWidgetSkinUtility.releaseCacheDir(context, type);
				return null;
			}
		}

		RemoteViews rv = null;
		{
			int btnfrm;
			try {
				btnfrm = TianQiTongAppWidgetSkinManager.getCfg(mZipSkinFile).ButtonFrame;
			} catch (Exception e) {
				return null;
			}

			int layoutId = R.layout.skin_changable_appwidget_with_2nd_btnfrm;
			int portcount = 0;
			int landcount = 0;

			if (type == AppWidgetSkin.TYPE_4X2) {
				switch (btnfrm) {
				case 0: {
					layoutId = R.layout.skin_changable_appwidget_with_1st_btnfrm;
					portcount = _1stPort4x2BtnCount;
					landcount = land4x2BtnCount;
				}
					break;
				case 1: {
					layoutId = R.layout.skin_changable_appwidget_with_2nd_btnfrm;
					portcount = _2ndPort4x2BtnCount;
					landcount = land4x2BtnCount;
				}
					break;
				case 2: {
					layoutId = R.layout.skin_changable_appwidget_with_3ed_btnfrm;
					portcount = _3edPort4x2BtnCount;
					landcount = land4x2BtnCount;
				}
					break;
				default: {
					layoutId = R.layout.skin_changable_appwidget_with_2nd_btnfrm;
					portcount = _2ndPort4x2BtnCount;
					landcount = land4x2BtnCount;
				}
					break;
				}
			} else if (type == AppWidgetSkin.TYPE_4X1) {
				layoutId = R.layout.skin_changable_4x1_appwidget;
				portcount = port4x1BtnCount;
				landcount = land4x1BtnCount;
			} else {
				portcount = 0;
				landcount = 0;
			}

			rv = new RemoteViews(context.getPackageName(), layoutId);

			// 调试按钮用的代码
// {
// Bitmap emptybmp = Bitmap.createBitmap(5, 5, Config.RGB_565);
// Canvas c = new Canvas(emptybmp);
// c.drawColor(Color.RED);
//
// for (int i = 0; i < portcount; i++) {
// rv.setViewVisibility(gPortBtnPos[i], View.VISIBLE);
// rv.setImageViewBitmap(gPortBtnPos[i], emptybmp);
// }
// for (int pos : gLandBtnPos) {
// rv.setViewVisibility(pos, View.VISIBLE);
// rv.setImageViewBitmap(pos, emptybmp);
// }
// }

			{
				Bitmap emptybmp = Bitmap.createBitmap(1, 1, Config.ARGB_8888);
				Canvas c = new Canvas(emptybmp);
				c.drawColor(0x01000000);
				for (int i = 0; i < portcount; i++) {
					rv.setViewVisibility(gPort4x1And4x2BtnPos[i], View.INVISIBLE);
					rv.setImageViewBitmap(gPort4x1And4x2BtnPos[i], emptybmp);
				}
				for (int i = 0; i < landcount; i++) {
					rv.setViewVisibility(gLand4x1And4x2BtnPos[i], View.INVISIBLE);
					rv.setImageViewBitmap(gLand4x1And4x2BtnPos[i], emptybmp);
				}
			}

		}

		{
			final long curtime = System.currentTimeMillis();
			File dir = context.getFilesDir();

			File[] fs = dir.listFiles(new FilenameFilter() {

				@Override
				public boolean accept(File dir, String name) {
					if (name.startsWith(prefix) && name.endsWith(".png")) {

						String tmp = name.substring(0, name.length() - 4);
						String[] tmps = Utility.split(tmp, '_');
						String time = tmps[2];
						long millisecond = Long.parseLong(time);
						if (curtime - millisecond > 180000L) {// 3分钟
							return true;
						}
					}
					return false;
				}
			});
			for (File f : fs) {
				f.delete();
			}
			fs = null;
		}

		{
			if (!justUpdateBtn) {
				for (AppWidgetSkin aws : mAppWidgetSkins) {
					if ((aws.hasClock() && updateClock) || (!updateClock)) {
						try {
							aws.draw(wi, context);
						} catch (IOException e) {
							continue;
						}
					}
				}
			}
			Uri tmpUri = mAppWidgetSkins[IDX_PORT].mAppWidgetBmpUri;
			if (tmpUri != null) {
				rv.setImageViewUri(R.id.skin_port, tmpUri);
			}
			tmpUri = mAppWidgetSkins[IDX_LAND].mAppWidgetBmpUri;
			if (tmpUri != null) {
				rv.setImageViewUri(R.id.skin_land, tmpUri);
			}
		}

		{
			for (AppWidgetSkin aws : mAppWidgetSkins) {
				aws.setBtnOnRemoteViews(context, rv);
			}
		}

		return rv;

	}

	private static final int _1stPort4x2BtnCount = 40;
	private static final int _2ndPort4x2BtnCount = 70;
	private static final int _3edPort4x2BtnCount = 36;

	private static final int land4x2BtnCount = 70;

	private static final int port4x1BtnCount = 40;
	private static final int land4x1BtnCount = 32;

	static final int[] gPort4x1And4x2BtnPos = new int[] { R.id.port_btn0, R.id.port_btn1, R.id.port_btn2, R.id.port_btn3, R.id.port_btn4, R.id.port_btn5, R.id.port_btn6, R.id.port_btn7,
			R.id.port_btn8, R.id.port_btn9, R.id.port_btn10, R.id.port_btn11, R.id.port_btn12, R.id.port_btn13, R.id.port_btn14, R.id.port_btn15, R.id.port_btn16, R.id.port_btn17, R.id.port_btn18,
			R.id.port_btn19, R.id.port_btn20, R.id.port_btn21, R.id.port_btn22, R.id.port_btn23, R.id.port_btn24, R.id.port_btn25, R.id.port_btn26, R.id.port_btn27, R.id.port_btn28, R.id.port_btn29,
			R.id.port_btn30, R.id.port_btn31, R.id.port_btn32, R.id.port_btn33, R.id.port_btn34, R.id.port_btn35, R.id.port_btn36, R.id.port_btn37, R.id.port_btn38, R.id.port_btn39, R.id.port_btn40,
			R.id.port_btn41, R.id.port_btn42, R.id.port_btn43, R.id.port_btn44, R.id.port_btn45, R.id.port_btn46, R.id.port_btn47, R.id.port_btn48, R.id.port_btn49, R.id.port_btn50, R.id.port_btn51,
			R.id.port_btn52, R.id.port_btn53, R.id.port_btn54, R.id.port_btn55, R.id.port_btn56, R.id.port_btn57, R.id.port_btn58, R.id.port_btn59, R.id.port_btn60, R.id.port_btn61, R.id.port_btn62,
			R.id.port_btn63, R.id.port_btn64, R.id.port_btn65, R.id.port_btn66, R.id.port_btn67, R.id.port_btn68, R.id.port_btn69, };

	static final int[] gLand4x1And4x2BtnPos = new int[] { R.id.land_btn0, R.id.land_btn1, R.id.land_btn2, R.id.land_btn3, R.id.land_btn4, R.id.land_btn5, R.id.land_btn6, R.id.land_btn7,
			R.id.land_btn8, R.id.land_btn9, R.id.land_btn10, R.id.land_btn11, R.id.land_btn12, R.id.land_btn13, R.id.land_btn14, R.id.land_btn15, R.id.land_btn16, R.id.land_btn17, R.id.land_btn18,
			R.id.land_btn19, R.id.land_btn20, R.id.land_btn21, R.id.land_btn22, R.id.land_btn23, R.id.land_btn24, R.id.land_btn25, R.id.land_btn26, R.id.land_btn27, R.id.land_btn28, R.id.land_btn29,
			R.id.land_btn30, R.id.land_btn31, R.id.land_btn32, R.id.land_btn33, R.id.land_btn34, R.id.land_btn35, R.id.land_btn36, R.id.land_btn37, R.id.land_btn38, R.id.land_btn39, R.id.land_btn40,
			R.id.land_btn41, R.id.land_btn42, R.id.land_btn43, R.id.land_btn44, R.id.land_btn45, R.id.land_btn46, R.id.land_btn47, R.id.land_btn48, R.id.land_btn49, R.id.land_btn50, R.id.land_btn51,
			R.id.land_btn52, R.id.land_btn53, R.id.land_btn54, R.id.land_btn55, R.id.land_btn56, R.id.land_btn57, R.id.land_btn58, R.id.land_btn59, R.id.land_btn60, R.id.land_btn61, R.id.land_btn62,
			R.id.land_btn63, R.id.land_btn64, R.id.land_btn65, R.id.land_btn66, R.id.land_btn67, R.id.land_btn68, R.id.land_btn69, };

	@Override
	public void executeRequest(int event, int requestNum, Bundle args) {
		switch (event) {
		case MSG_ARG2_UPDATE_APPWIDGET: {

			TianQiTongLog.addNormalLog("updateProviders");

			File zipFile = (File) args.getSerializable(MSG_DATA_KEY_FILE_FILE);
			WeatherInfo wi = (WeatherInfo) args.getSerializable(MSG_DATA_KEY_S_DATA);
			boolean justUpdateBtn = args.getBoolean(MSG_DATA_KEY_BOOLEAN_AW_JUST_UPDATE_BTN);
			boolean updateClock = args.getBoolean(MSG_DATA_KEY_BOOLEAN_AW_UPDATE_CLOCK);

			String strType = args.getString(MSG_DATA_KEY_STR_AWTYPE);
			final int type;
			if (strType.equals("4x2")) {
				type = AppWidgetSkin.TYPE_4X2;
			} else if (strType.equals("4x1")) {
				type = AppWidgetSkin.TYPE_4X1;
			} else {
				throw new IllegalArgumentException();
			}

			TianQiTongService service = _wrService.get();

			if (wi == null) {
				AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(service);
				if (type == AppWidgetSkin.TYPE_4X2) {
					int[] _4x2_ids = appWidgetManager.getAppWidgetIds(new ComponentName(service, WidgetProvider.class));
					if (_4x2_ids.length > 0) {
						Time _time = new Time();
						_time.setToNow();

						int hour = _time.hour;
						if (!DateFormat.is24HourFormat(service)) {
							if (hour > 12) {
								hour -= 12;
							}
						}

						int hour0 = hour / 10;
						int hour1 = hour % 10;
						int minute0 = _time.minute / 10;
						int minute1 = _time.minute % 10;
						int[] _numberDrawableIds = new int[] { R.drawable.clock_0, R.drawable.clock_1, R.drawable.clock_2, R.drawable.clock_3, R.drawable.clock_4, R.drawable.clock_5,
								R.drawable.clock_6, R.drawable.clock_7, R.drawable.clock_8, R.drawable.clock_9, };
						RemoteViews views = new RemoteViews(service.getPackageName(), R.layout.appwidget_4x2_default);

						views.setImageViewResource(R.id.widget_hour_0, _numberDrawableIds[hour0]);
						views.setImageViewResource(R.id.widget_hour_1, _numberDrawableIds[hour1]);
						views.setImageViewResource(R.id.widget_minute_0, _numberDrawableIds[minute0]);
						views.setImageViewResource(R.id.widget_minute_1, _numberDrawableIds[minute1]);

						Intent intent = new Intent(service, Splash.class);
						PendingIntent pi = PendingIntent.getActivity(service, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
						views.setOnClickPendingIntent(R.id.widget_bg, pi);

						appWidgetManager.updateAppWidget(_4x2_ids, views);

					}
				} else {
					int[] _4x1_ids = appWidgetManager.getAppWidgetIds(new ComponentName(service, Widget4x1Provider.class));
					if (_4x1_ids.length > 0) {
						RemoteViews views = new RemoteViews(service.getPackageName(), R.layout.appwidget_4x1_default);
						Intent intent = new Intent(service, Splash.class);
						PendingIntent pi = PendingIntent.getActivity(service, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
						views.setOnClickPendingIntent(R.id.bg, pi);
						views.setOnClickPendingIntent(R.id.tip, pi);
						appWidgetManager.updateAppWidget(_4x1_ids, views);
					}
				}

				return;
			}

			if (type == AppWidgetSkin.TYPE_4X2) {
				if (zipFile != null) {
					m4x2ZipSkinFile = zipFile;
				} else {
					if (m4x2ZipSkinFile == null) {
						throw new IllegalArgumentException();
					}
				}
			} else if (type == AppWidgetSkin.TYPE_4X1) {
				if (zipFile != null) {
					m4x1ZipSkinFile = zipFile;
				} else {
					if (m4x1ZipSkinFile == null) {
						throw new IllegalArgumentException();
					}
				}
			} else {
				throw new IllegalStateException();
			}

			Bundle data = new Bundle();

			final RemoteViews rv;
			if (type == AppWidgetSkin.TYPE_4X2) {
				String keyName = SPUtility.getSPString(service, R.string.appwidget_key_name_4X2);
				if (Utility.sdAvailiable() && !keyName.startsWith(sina.mobile.tianqitong.service.model.AppWidgetSkin.DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX)) {
					if (m4x2ZipSkinFile.isFile() && m4x2ZipSkinFile.exists()) {
						rv = buildRemoteViews(wi, justUpdateBtn, type, updateClock);
					} else {//如果zip文件被手动删除的话，则重置
						SPUtility.putSPString(service, R.string.appwidget_key_name_4X2, sina.mobile.tianqitong.service.model.AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME);
						AppWidgetSkinUtility.releaseCacheDir(service, sina.mobile.tianqitong.appwidgetskinpkg.AppWidgetSkin.TYPE_4X2);
						rv = WidgetProvider.updateAppWidget(service, service);
					}
				} else {
					AppWidgetSkinUtility.releaseCacheDir(service, sina.mobile.tianqitong.appwidgetskinpkg.AppWidgetSkin.TYPE_4X2);
					rv = WidgetProvider.updateAppWidget(service, service);
				}
			} else if (type == AppWidgetSkin.TYPE_4X1) {
				String keyName = SPUtility.getSPString(service, R.string.appwidget_key_name_4X1);
				if (Utility.sdAvailiable() && !keyName.startsWith(sina.mobile.tianqitong.service.model.AppWidgetSkin.DEFAULT_APPWIDGETSKIN_KEYNAME_PREFIX)) {
					if (m4x1ZipSkinFile.isFile() && m4x1ZipSkinFile.exists()) {
						rv = buildRemoteViews(wi, justUpdateBtn, type, updateClock);
					} else {
						SPUtility.putSPString(service, R.string.appwidget_key_name_4X1, sina.mobile.tianqitong.service.model.AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME);
						AppWidgetSkinUtility.releaseCacheDir(service, sina.mobile.tianqitong.appwidgetskinpkg.AppWidgetSkin.TYPE_4X1);
						rv = Widget4x1Provider.updateAppWidget(service, service);
					}

				} else {
					AppWidgetSkinUtility.releaseCacheDir(service, sina.mobile.tianqitong.appwidgetskinpkg.AppWidgetSkin.TYPE_4X1);
					rv = Widget4x1Provider.updateAppWidget(service, service);
				}
			} else {
				throw new IllegalStateException();
			}

			if (rv != null && _wrService.get() != null) {
				_wrService.get()._uiHandler.post(new Runnable() {
					public void run() {
						AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(_wrService.get());
						if (type == AppWidgetSkin.TYPE_4X2) {
							int[] _4x2_ids = appWidgetManager.getAppWidgetIds(new ComponentName(_wrService.get(), WidgetProvider.class));
							appWidgetManager.updateAppWidget(_4x2_ids, rv);
						} else if (type == AppWidgetSkin.TYPE_4X1) {
							int[] _4x1_ids = appWidgetManager.getAppWidgetIds(new ComponentName(_wrService.get(), Widget4x1Provider.class));
							appWidgetManager.updateAppWidget(_4x1_ids, rv);
						}

					}
				});
				data.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_SUCCESSFUL);
			} else {
				data.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_BAD_XML);
			}

			sendResponse(requestNum, data);

		}
			break;
		}

	}

	@Override
	public int[] getValidEvents() {
		return new int[] { MSG_ARG2_UPDATE_APPWIDGET };
	}

	// In memory cache.
	private static Map<String, SoftReference<Bitmap>> mCache = new HashMap<String, SoftReference<Bitmap>>();

	public static final Bitmap getIcon(File zipSkin, String keyName) throws ZipException, IOException {
		// TODO 这段代码解决了列表头像有时候会变白的问题，不知是否确定是这样的问题，但经过一个机器的测试，的确没有了这样的问题
		if (mCache.get(keyName) != null && mCache.get(keyName).get() != null) {
			return mCache.get(keyName).get();
		}

		ZipFile zf = new ZipFile(zipSkin);
		ZipEntry ze = zf.getEntry("icon.png");
		if (ze == null) {
			return null;
		}
		BufferedInputStream bis = null;
		try {
			bis = new BufferedInputStream(zf.getInputStream(ze));

			Bitmap r = BitmapFactory.decodeStream(bis);
			mCache.put(keyName, new SoftReference<Bitmap>(r));

			return r;
		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static final class SkinCfg {
		public String Name = "未知插件";
		public String Author = "未知作者";
		public int Version = 1;
		public String Type = "4x2";
		public int ButtonFrame = 1;

	}

	public static final SkinCfg getCfg(File zipSkin) throws ZipException, IOException, XmlPullParserException {
		if(!zipSkin.getName().endsWith(".zip")){
			return null;
		}
		ZipFile zf = new ZipFile(zipSkin);
		ZipEntry ze = zf.getEntry("cfg.xml");
		if (ze == null) {
			return null;
		}

		BufferedInputStream bis = null;
		try {
			bis = new BufferedInputStream(zf.getInputStream(ze));

			XmlPullParserFactory factory;
			XmlPullParser xpp;

			factory = XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			xpp = factory.newPullParser();
			xpp.setInput(bis, null);
			int eventType = xpp.getEventType();

			while (eventType != XmlPullParser.END_DOCUMENT) {

				switch (eventType) {
				case XmlPullParser.START_TAG: {
					if (xpp.getName().equals("AppWidget")) {

						SkinCfg cfg = new SkinCfg();

						for (int i = 0; i < xpp.getAttributeCount(); i++) {
							String attrName = xpp.getAttributeName(i);
							String attrValue = xpp.getAttributeValue(i);
							if (attrName.equals("Name")) {
								cfg.Name = attrValue;
							} else if (attrName.equals("Author")) {
								cfg.Author = attrValue;
							} else if (attrName.equals("Version")) {
								cfg.Version = Integer.parseInt(attrValue);
							} else if (attrName.equals("Type")) {
								cfg.Type = attrValue;
							} else if (attrName.equals("ButtonFrame")) {
								cfg.ButtonFrame = Integer.parseInt(attrValue);
							}
						}

						return cfg;
					}
				}
				}

				eventType = xpp.next();
			}

		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return new SkinCfg();

	}

	public static void clearBitmapCache() {
		mCache.clear();
	}
}
