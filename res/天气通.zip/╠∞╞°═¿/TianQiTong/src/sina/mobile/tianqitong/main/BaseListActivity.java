package sina.mobile.tianqitong.main;

import java.util.ArrayList;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.simplelistdata.TQTSimpleDataManager;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public abstract class BaseListActivity extends Activity implements Handler.Callback {

	protected ListView listView = null;
	private View centerView = null;

	protected MyBaseAdapter mMyBaseAdapter = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.listview_tanqitong);

		listView = (ListView) findViewById(R.id.desk_plug_list);
		listView.setDivider(null);
		mStar = BitmapFactory.decodeResource(getResources(), R.drawable.item_star);
		mStarNo = BitmapFactory.decodeResource(getResources(), R.drawable.item_star_no);

		View headView = LayoutInflater.from(this).inflate(R.layout.listviewofdesk_plugin_head, null);
		TextView headText = (TextView) headView.findViewById(R.id.head_title);
		if (!TextUtils.isEmpty(getHeadText())) {
			headText.setText(getHeadText());
		}

		centerView = LayoutInflater.from(this).inflate(R.layout.listviewofdesk_plugin_center, null);
	
		TextView centerText = (TextView) centerView.findViewById(R.id.center_text);
		if (!TextUtils.isEmpty(getCenterText())) {
			centerText.setText(getCenterText());
		}

		View footView = LayoutInflater.from(this).inflate(R.layout.listviewofdesk_plugin_foot, null);
		listView.addHeaderView(headView);
		listView.addFooterView(footView);

		mMyBaseAdapter = new MyBaseAdapter(this);

		listView.setAdapter(mMyBaseAdapter);

	}

	protected class MyBaseAdapter extends BaseAdapter {
		private LayoutInflater mInflater;
		List<?> mListData = new ArrayList();

		public void setListData(List<?> mListData) {
			this.mListData = mListData;
		}

		public MyBaseAdapter(Context context) {
			mInflater = LayoutInflater.from(context);
		}

		public int getCount() {
			return mListData.size();
		}

		public Object getItem(int position) {
			return mListData.get(position);
		}

		public boolean areAllItemsEnabled() {
			return false;
		}

		public boolean isEnabled(int position) {
			return false;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			if (mListData.get(position) == null) {
				return centerView;
			}

			return constructConvertView(convertView, mInflater, position, mListData);
		}

	}

	protected abstract View constructConvertView(View convertView, LayoutInflater mInflater, int position, List<?> mListData);

	private Bitmap mStar = null;

	private Bitmap mStarNo = null;

	protected Bitmap getStartsBitmap(int count) {

		int width = mStar.getWidth();
		int height = mStar.getHeight();

		Bitmap[] mStars = null;

		if (count > 5 || count < 2) {
			return mStar;
		}

		if (mStars == null) {
			mStars = new Bitmap[5];

			for (int i = 0; i < mStars.length; i++) {

				Bitmap output = Bitmap.createBitmap(width * mStars.length, height, Config.ARGB_4444);
				Canvas canvas = new Canvas(output);
				for (int j = 0; j <= i; j++) {
					canvas.drawBitmap(mStar, j * width, 0, null);
				}
				for (int z = i + 1; z < mStars.length; z++) {
					canvas.drawBitmap(mStarNo, z * width, 0, null);
				}
				mStars[i] = output;
			}
		}

		return mStars[count - 1];
	}

	protected abstract String getHeadText();

	protected abstract String getCenterText();

	/**
	 * 构建列表数据
	 */
	protected abstract void buildData();

	@Override
	public final boolean handleMessage(Message msg) {
		switch (msg.what) {
		case TQTSimpleDataManager.MSG_WHAT_LIST_UPDATED: {
			Log.d("TQTDATAMANAGER", "list_updated");
			buildData();
		}
			break;
		case TQTSimpleDataManager.MSG_WHAT_AUTO_DOWNLOAD_DONE: {
			Log.d("TQTDATAMANAGER", "autodownload_done");
			mMyBaseAdapter.notifyDataSetChanged();
		}
			break;
		case TQTSimpleDataManager.MSG_WHAT_MAIN_DOWNLOAD_DONE: {
			Log.d("TQTDATAMANAGER", "maindownload_done");
			String url = msg.getData().getString(TQTSimpleDataManager.MSG_DATA_KEY_STR_URL);
			onMainDownloadDone(url);
			mMyBaseAdapter.notifyDataSetInvalidated();

		}
			break;
		case TQTSimpleDataManager.MSG_WHAT_MAIN_DOWNLOAD_PROGRESS_UPDATED: {
			int progress = msg.getData().getInt(TQTSimpleDataManager.MSG_DATA_KEY_INT_PROGRESS);
			String url = msg.getData().getString(TQTSimpleDataManager.MSG_DATA_KEY_STR_URL);
			onMainDownloadProgressUpdated(url, progress);

		}
			break;
		default: {
			return false;
		}
	
	}
		return true;
	}

	public abstract void onMainDownloadDone(String url);

	public abstract void onMainDownloadProgressUpdated(String url, int progress);

}
