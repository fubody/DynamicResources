package sina.mobile.tianqitong.appwidgetskinpkg;

import sina.mobile.tianqitong.service.model.WeatherInfo;
import android.graphics.Canvas;
import android.graphics.Rect;

public class LayoutUnit extends AbstractSkinLayoutUnit {

	protected LayoutUnit(AppWidgetSkin aws) {
		super(aws);
	}

	private int w = Integer.MIN_VALUE;
	private int h = Integer.MIN_VALUE;

	@Override
	protected Rect doMeasureDrawRectWAndH() {
		Rect r = new Rect(0, 0, w, h);
		return r;
	}

	@Override
	protected boolean setSubValue(String attrName, String attrValue) {
		if (attrName.equals("w")) {
			w = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("h")) {
			h = AppWidgetSkinUtility.px(attrValue);
		} else {
			return false;
		}
		return true;
	}

	@Override
	public void draw(Canvas c) {

	}

	@Override
	public void setWeatherInfo(WeatherInfo wi) {

	}

	@Override
	boolean isClockUnit() {
		// TODO Auto-generated method stub
		return false;
	}

}
