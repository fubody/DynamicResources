/*
 * This is a modified version of a class from the Android Open Source Project. The original copyright and license information follows.
 * 
 * Copyright (C) 2008 The Android Open Source Project
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied. See the License for the specific language governing permissions and limitations under the License.
 */

package sina.mobile.tianqitong.citymanager;

import java.util.LinkedList;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.main.MainActivity;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.setting.TTSSetting;
import android.R.integer;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class DragLayer extends RelativeLayout implements DragSource, View.OnLongClickListener, View.OnClickListener {
	private DragController mDragController;
	private Rect[] mRects = new Rect[9];
	private LinkedList<CityWeathInfo> mLinkedList = new LinkedList();
	private MainActivity context;

	public DragLayer(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = (MainActivity) context;
	}

	@Override
	public void setDragController(DragController dragger) {
		this.mDragController = dragger;
	}

	@Override
	public void onDropCompleted(View target, boolean success) {

	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		return mDragController.onInterceptTouchEvent(ev);
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		return mDragController.onTouchEvent(ev);
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		super.onLayout(changed, l, t, r, b);
		int count = getChildCount();
		int[] location = new int[2];
		getLocationOnScreen(location);
		// System.out.println(location[0] + "########" + count + "#######" + location[1]);
		for (int i = 1; i < count; i++) {
			Rect outRect = new Rect();
			View c = getChildAt(i);
			c.getHitRect(outRect);
			// System.out.println("HitRect--" + outRect.toString());
			// outRect.offsetTo(location[0], location[1]);
			Rect outRect2 = new Rect(outRect.left + location[0], outRect.top + location[1], outRect.right + location[0], outRect.bottom + location[1]);
			// System.out.println("outRect.offset--" + outRect2.toString());
			mRects[i - 1] = outRect2;
			// System.out.println("===========");
		}

	}

	protected void onFinishInflate() {
		initDragLayer();
	}

	private CityView[] r = new CityView[9];

	public void initDragLayer() {

		r[0] = (CityView) findViewById(R.id.view1);
		r[1] = (CityView) findViewById(R.id.view2);
		r[2] = (CityView) findViewById(R.id.view3);
		r[3] = (CityView) findViewById(R.id.view4);
		r[4] = (CityView) findViewById(R.id.view5);
		r[5] = (CityView) findViewById(R.id.view6);
		r[6] = (CityView) findViewById(R.id.view7);
		r[7] = (CityView) findViewById(R.id.view8);
		r[8] = (CityView) findViewById(R.id.view9);
		// 要显示出 +
		r[0].setWeathViewVisibility(View.INVISIBLE);
		r[0].setAddViewVisibility(View.VISIBLE);
	}

	public void setColor(int bgInt) {
		for (CityView cv : r) {
			cv.cityName.setTextColor(colorCityName[bgInt]);

			cv.mWeacher.setTextColor(colorWeacher[bgInt]);
			if (cv.isDay) {
				cv.temH.setTextColor(colorTemH[bgInt]);
				cv.mTemDiv.setTextColor(colorDiv[bgInt]);

				cv.temL.setTextColor(colorTemL[bgInt]);
			} else {
				cv.temH.setTextColor(colorTemL[bgInt]);
				cv.mTemDiv.setTextColor(colorTemL[bgInt]);
				cv.temL.setTextColor(colorTemH[bgInt]);
			}

		}
	}

	private int[] colorCityName = { 0xffffffff, 0xffffffff, 0xff48260b, 0xff2981c1, 0xff221b25, 0xff0f5586, 0xffffffff, 0xff2c2c2c, 0xffffffff };

	private int[] colorTemH = { 0xffffffff, 0xfffba450, 0xffffcd48, 0xfffe8b13, 0xfff79509, 0xffff8915, 0xfffba450, 0xfffba450, 0xfffba450 };

	private int[] colorDiv = { 0xffffffff, 0xfffba450, 0xffffcd48, 0xfffe8b13, 0xfff79509, 0xfffc8d21, 0xfffba450, 0xfffba450, 0xfffba450 };

	private int[] colorTemL = { 0xff177cc4, 0xffffffff, 0xff4894bc, 0xff4199c2, 0xff39a2de, 0xff105983, 0xff6ecaff, 0xff63a4c5, 0xff6ecaff };

	private int[] colorWeacher = { 0xff034277, 0xffffffff, 0xff6e3d1d, 0xff2686a9, 0xff423a4c, 0xff034277, 0xff3599ed, 0xff537184, 0xff32363f };

	public void cleanDateList() {
		for (int i = 0; i < r.length; i++) {
			r[i].onlyHasBg();
		}
		mLinkedList.clear();
	}

	public boolean addCityWeathInfo(CityWeathInfo cwi, int index) {
// System.out.println("===addCityWeathInfo======" + index);
		r[index].changViewVisibility(true);
		r[index].setCityWeathInfo(cwi);
		mLinkedList.add(cwi);
		r[index].setOnLongClickListener(this);
		r[index].setOnClickListener(this);
		//added by Maojianwei 用于只有一个城市时更换城市后隐藏占位空白
		if(isOnlyOneCity()) {
			for(int i=2; i<=8; i++) {
				r[i].setVisibility(INVISIBLE);
			}
		}
		return true;
	}

	public void setAddViewOnclick() {
		if (mLinkedList.size() != 9) {
			r[mLinkedList.size()].changViewVisibility(false);
			ImageView addImageView = (ImageView) r[mLinkedList.size()].findViewById(R.id.add_view);
			addImageView.setOnClickListener(this);
		}
	}

	public void deleteCityWeathInfo(int index) {
		// System.out.println("=============deleteCityWeathInfo=============" + index);
		if (isOnlyOneCity()) {
			Intent intent = new Intent(context, CitySelector.class);
			intent.putExtra("currentdelcitycode", mLinkedList.get(index).cityCode);
			context.startActivity(intent);

			return;
		}

		r[index].mDiverof9city.setVisibility(View.INVISIBLE);
		r[index].mIsGps.setVisibility(View.INVISIBLE);
	
		// System.out.println("=================one===============" + mLinkedList.size());
		if (mLinkedList.size() != 9) {
			r[mLinkedList.size()].changViewVisibility(false);
			r[mLinkedList.size()].findViewById(R.id.add_view).setVisibility(View.INVISIBLE);
			r[mLinkedList.size()].setOnLongClickListener(null);
			r[mLinkedList.size()].setOnClickListener(null);
		}
		String deleteCityCode = mLinkedList.get(index).cityCode;
		mLinkedList.remove(index);
		// System.out.println("=================tow===============" + mLinkedList.size());
		for (int i = index; i < mLinkedList.size(); i++) {
			r[i].setCityWeathInfo(mLinkedList.get(i));
		}

		if (mLinkedList.size() != 9) {
			r[mLinkedList.size()].changViewVisibility(false);
			ImageView addImageView = (ImageView) r[mLinkedList.size()].findViewById(R.id.add_view);
			addImageView.setVisibility(View.VISIBLE);
			addImageView.setOnClickListener(this);
		}

		if (mDeleteCityListener != null) {
			mDeleteCityListener.onDeleteCity(deleteCityCode);
		}
		
		//added by Maojianwei
		//通知刷新UI，当删除的城市是被设置为语音播报城市时才有用
		Intent intent = new Intent(IntentActionConstants.ACTION_BC_ALL_UPDATED);
		context.sendBroadcast(intent);
		//删除九宫格城市后隐藏占位空白背景
		if(mLinkedList.size() < 9) {
			for(int i=0; i<8-mLinkedList.size(); i++) {
				r[8-i].setVisibility(INVISIBLE);
			}
		}
	}

	@Override
	public int containsIn9Grid(int x, int y) {
		// System.out.println("===========containsIn9Grid====================" + mLinkedList.size());
		int j = -1;
		// 这里只从有数据的个子里面找
		for (int i = 0; i < mLinkedList.size(); i++) {
			if (mRects[i].contains(x, y)) {
				if (r[i].getVisibility() == View.INVISIBLE)
					break;

				// System.out.println("enter 9 grid and index is ===" + i);
				j = i;
				mDragController.onEnterGridView(r[i]);
				break;
			}
		}
		return j;
	}

	public static final int REQUEST_CODE_ADD_CITY = 0;
	public static final int REQUEST_CODE_REPLACE_CURRENT = 1;

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.add_view) {
			context.startActivityForResult(new Intent(context, CitySelector.class), REQUEST_CODE_ADD_CITY);
		} else {
			String str = (String) v.getTag();
			int index = Integer.parseInt(str);
			if (index > mLinkedList.size() - 1) {
				return;
			}

			CityWeathInfo cwi = mLinkedList.get(index);

			MainActivity.gChangeCity = cwi.cityCode;
			context.click9GridAnimToRight();
			// context.click9GridAnimToRight();
		}

	}

	@Override
	public boolean onLongClick(View v) {

		mDragController.startDrag(v, this, DragController.DRAG_ACTION_MOVE);
		return false;
	}

	@Override
	public void tradeCityWeathInfo(int one, int other) {
		if (r[one].getCityWeathInfo() == null || r[other].getCityWeathInfo() == null)
			return;

		String oneCityCode = r[one].getCityWeathInfo().cityCode;
		String otherCityCode = r[other].getCityWeathInfo().cityCode;

		String[] cityCodes = SPUtility.getSPStringArray(context, R.string.strs_cached_citys, ',');
		StringBuilder sb = new StringBuilder();
		int oneIndex = 0;
		int otherIndex = 0;
		for (int i = 0; i < cityCodes.length; i++) {
			if (oneCityCode.equals(cityCodes[i])) {
				oneIndex = i;
			}
			if (otherCityCode.equals(cityCodes[i])) {
				otherIndex = i;
			}
		}
		cityCodes[oneIndex] = otherCityCode;
		cityCodes[otherIndex] = oneCityCode;
		mLinkedList.remove(oneIndex);
		mLinkedList.add(oneIndex, r[other].getCityWeathInfo());
		mLinkedList.remove(otherIndex);
		mLinkedList.add(otherIndex, r[one].getCityWeathInfo());
		r[one].setVisibility(View.VISIBLE);
		r[other].setVisibility(View.VISIBLE);

		r[one].setCityWeathInfo(mLinkedList.get(oneIndex));
		r[other].setCityWeathInfo(mLinkedList.get(otherIndex));

		for (int i = 0; i < cityCodes.length; i++) {
			sb.append(cityCodes[i]);
			sb.append(",");
		}

		SPUtility.putSPString(context, R.string.strs_cached_citys, sb.toString());

	}

	public DeleteCityListener mDeleteCityListener;

	public void setDeleteCityListener(DeleteCityListener deleteCityListener) {
		this.mDeleteCityListener = deleteCityListener;
	}

	public interface DeleteCityListener {
		void onDeleteCity(String cityCode);
	}

	@Override
	public boolean isOnlyOneCity() {
		boolean isOnlyOne = false;
		if (mLinkedList.size() == 1) {
			isOnlyOne = true;
		}
		return isOnlyOne;
	}

	public String getDefauldCityCode() {
		return mLinkedList.get(0).cityCode;
	}
}
