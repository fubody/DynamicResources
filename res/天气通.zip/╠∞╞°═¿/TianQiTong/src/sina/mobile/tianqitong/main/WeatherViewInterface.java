package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;

interface WeatherViewInterface {
	void updateUI(TianQiTongService service, String cityName, WeatherInfo fi, boolean noAnim, int skin);

	void finishAnim();

}
