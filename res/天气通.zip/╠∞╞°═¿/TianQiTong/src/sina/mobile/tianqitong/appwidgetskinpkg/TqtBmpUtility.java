package sina.mobile.tianqitong.appwidgetskinpkg;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;

public final class TqtBmpUtility {
	private TqtBmpUtility() {

	}

	public static final int[] getTqtBmpFileWH(File tqtbmp, int density) throws FileNotFoundException {

		if (true) {
			BufferedInputStream bis = null;
			try {
				bis = new BufferedInputStream(new FileInputStream(tqtbmp));
				Options o = new Options();
				o.inJustDecodeBounds = true;
				BitmapFactory.decodeStream(bis, null, o);
				return new int[] { o.outWidth, o.outHeight };

			} finally {
				if (bis != null) {
					try {
						bis.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

		} else {
// DataInputStream dis = null;
//
// try {
// dis = new DataInputStream(new BufferedInputStream(new FileInputStream(tqtbmp)));
// int width;
// int height;
// width = dis.readInt();
// height = dis.readInt();
// return new int[] { width, height };
// } catch (FileNotFoundException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// } finally {
// if (dis != null) {
// try {
// dis.close();
// } catch (IOException e) {
// e.printStackTrace();
// }
// }
// }
			return new int[] { 0, 0 };
		}

	}

	public static final Bitmap loadTqtBmpFile(File tqtbmp, int density) throws FileNotFoundException {

		if (true) {
			BufferedInputStream bis = null;
			try {
				bis = new BufferedInputStream(new FileInputStream(tqtbmp));

				Bitmap r = null;
				r = BitmapFactory.decodeStream(bis);
				return r;
			} finally {
				if (bis != null) {
					try {
						bis.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

		}

// DataInputStream dis = null;
//
// try {
// dis = new DataInputStream(new BufferedInputStream(new FileInputStream(tqtbmp)));
// int width;
// int height;
// width = dis.readInt();
// height = dis.readInt();
//
// ArrayList<Integer> pixelList = new ArrayList<Integer>();
//
// while (true) {
// try {
// int pixel = dis.readInt();
// pixelList.add(pixel);
// } catch (EOFException eofe) {
// break;
// }
// }
//
// int[] pixels = new int[pixelList.size()];
// for (int i = 0; i < pixelList.size(); i++) {
// pixels[i] = pixelList.get(i);
// }
//
// Bitmap r = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
// r.setPixels(pixels, 0, width, 0, 0, width, height);
// r.setDensity(density);
//
// return r;
//
// } catch (FileNotFoundException e) {
// e.printStackTrace();
// } catch (IOException e) {
// e.printStackTrace();
// } finally {
// if (dis != null) {
// try {
// dis.close();
// } catch (IOException e) {
// e.printStackTrace();
// }
// }
// }
//
		return null;

	}

	public static final void storeAsTqtBmpFile(File tqtbmp, Bitmap bmp) throws FileNotFoundException {
		if (true) {

			BufferedOutputStream bos = null;

			try {
				bos = new BufferedOutputStream(new FileOutputStream(tqtbmp));
				bmp.compress(CompressFormat.PNG, 100, bos);
			} finally {
				if (bos != null) {
					try {
						bos.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			return;
		}

// DataOutputStream dos = null;
// try {
// dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tqtbmp)));
// int width = bmp.getWidth();
// int height = bmp.getHeight();
//
// dos.writeInt(width);
// dos.writeInt(height);
//
// int[] pixels = new int[width * height];
// bmp.getPixels(pixels, 0, width, 0, 0, width, height);
//
// for (int pixel : pixels) {
// dos.writeInt(pixel);
// }
// } catch (FileNotFoundException e) {
// e.printStackTrace();
// } catch (IOException e) {
// e.printStackTrace();
// } finally {
// if (dos != null) {
// try {
// dos.close();
// } catch (IOException e) {
// e.printStackTrace();
// }
// }
// }
	}

}
