package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.putTempAppPackageNameAndActivityName;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCurAWType;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCurDiyableUnits;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.init;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.releaseBitmapCacheAndWallpaper;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.repaintPreview;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.setCurAWType;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WIDGET;

import java.util.ArrayList;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidget.Widget4x1Provider;
import sina.mobile.tianqitong.appwidget.WidgetProvider;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyButton;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class AppWidgetDiyTool extends Activity implements ServiceConnection, OnClickListener {

	private AppWidgetDiyToolPreviewView mPreviewView;

	private LinearLayout mOptionsItemContainer;
	private View mOptionsMenuFrame;
	private RelativeLayout mMainContainer;

	private TextView mOptionsMenuTitle;

	private View mHelpView;

	public void onStop() {
		super.onStop();
		releaseBitmapCacheAndWallpaper();
	}

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.appwidget_diy_tool);

		Intent i = getIntent();
		int type = i.getIntExtra("type", 0);
		AWType awtype = AWType.getAWType(type);

		DiyAppWidgetAttrUtil.maybeCreateTempAttrs(this, awtype);
		init(this, null, null, FileGettable.TEMP);
		setCurAWType(awtype);

		mMainContainer = (RelativeLayout) findViewById(R.id.main);
		mOptionsItemContainer = (LinearLayout) findViewById(R.id.options);
		mOptionsMenuFrame = findViewById(R.id.option_menu_frame);
		mOptionsMenuTitle = (TextView) findViewById(R.id.title);

		if (!SPUtility.getSPBoolean(this, R.string.boolean_awdt_help_shown)) {
			mPreviewView = new AppWidgetDiyToolPreviewView(this, awtype, AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_TUTORIAL);
		} else {
			mPreviewView = new AppWidgetDiyToolPreviewView(this, awtype, AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_DIY_CURSOR_ANIMATION);
		}

		mPreviewView.setFocusable(false);
		RelativeLayout.LayoutParams rllp = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		rllp.addRule(RelativeLayout.ALIGN_PARENT_TOP, -1);
		rllp.addRule(RelativeLayout.CENTER_HORIZONTAL, -1);
		mPreviewView.setLayoutParams(rllp);
		mMainContainer.addView(mPreviewView, 0);

		if (!SPUtility.getSPBoolean(this, R.string.boolean_awdt_help_shown)) {
			SPUtility.putSPBoolean(this, R.string.boolean_awdt_help_shown, true);
			mHelpView = new View(this);
			mHelpView.setClickable(true);
			mHelpView.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					mPreviewView.mThread.setPlayState(AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_DIY_CURSOR_ANIMATION);
					mMainContainer.removeView(mHelpView);
					mHelpView = null;
				}
			});
			rllp = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
			rllp.addRule(RelativeLayout.ALIGN_PARENT_TOP, -1);
			rllp.addRule(RelativeLayout.CENTER_HORIZONTAL, -1);
			mHelpView.setLayoutParams(rllp);
			mMainContainer.addView(mHelpView);
		}

		showDiyUnitOption(true);

		bindService(new Intent(this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

	}

	void tutorialFinished() {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				mMainContainer.removeView(mHelpView);
				mHelpView = null;

			}
		});
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (mHelpView != null) {
			if (mPreviewView.mThread != null) {
				mPreviewView.mThread.setPlayState(AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_DIY_CURSOR_ANIMATION);
			}
			mMainContainer.removeView(mHelpView);
			mHelpView = null;
			return true;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	public void onDestroy() {
		super.onDestroy();
		unbindService(this);
	}

	private static final int MENUITEM_ID_CANCEL = 0;
	private static final int MENUITEM_ID_OK = 1;
	private static final int MENUITEM_ID_TO_DEFAULT = 2;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

// menu.add(Menu.NONE, MENUITEM_ID_OK, Menu.NONE, "应用");
// menu.add(Menu.NONE, MENUITEM_ID_CANCEL, Menu.NONE, "取消");
// menu.add(Menu.NONE, MENUITEM_ID_TO_DEFAULT, Menu.NONE, "还原默认");
		return false;
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		if (menuIsShown()) {
			return false;
		} else {
			return true;
		}
	}

	private TianQiTongService mService;

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case MENUITEM_ID_CANCEL: {
			cancelPressed();
		}
			break;
		case MENUITEM_ID_OK: {
			savePressed();
		}
			break;
		case MENUITEM_ID_TO_DEFAULT: {
			setDefaultPressed();
		}
			break;
		}
		return true;

	}

	private static final int DIALOG_ID_ASK_SAVE_AND_APPLY = 0;
	private static final int DIALOG_ID_WAITING = 1;
	static final int DIALOG_ID_GET_APP = 2;
	static final int DIALOG_ID_CHANGE_TO_CONDITION_MODE = 3;
	private static final int DIALOG_ID_ASK_APPLY = 4;
	private static final int DIALOG_ID_NO_WIDGET = 5;

	private ArrayList<ActivityInfo> mLaunchableActivity = null;

	@Deprecated
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_ASK_SAVE_AND_APPLY: {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setPositiveButton(R.string.yes, this);
			builder.setNegativeButton(R.string.no, this);
			builder.setTitle("退出自定义设置");
			builder.setMessage("是否保存并应用？");
			return builder.create();
		}
		case DIALOG_ID_ASK_APPLY: {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setPositiveButton(R.string.yes, this);
			builder.setNegativeButton(R.string.no, this);
			builder.setTitle("退出自定义设置");
			builder.setMessage("是否应用？");
			return builder.create();
		}
		case DIALOG_ID_WAITING: {
			ProgressDialog pd = new ProgressDialog(this);
			pd.setIndeterminate(true);
			pd.setCancelable(false);
			pd.setMessage("请稍等......");
			return pd;
		}
		case DIALOG_ID_GET_APP: {

			if (mLaunchableActivity == null) {
				mLaunchableActivity = new ArrayList<ActivityInfo>();
				PackageManager pm = getPackageManager();
				List<ApplicationInfo> ail = pm.getInstalledApplications(0);

				for (ApplicationInfo ai : ail) {

					Intent intenti = new Intent();
					intenti.setPackage(ai.packageName);
					intenti.addCategory(Intent.CATEGORY_LAUNCHER);
					intenti.setAction(Intent.ACTION_MAIN);
					List<ResolveInfo> tmplist = new ArrayList<ResolveInfo>();
					try {
						tmplist = pm.queryIntentActivities(intenti, 0);
					} catch (Exception e) {
						e.printStackTrace();
					}

					if (tmplist.size() > 0) {
						for (ResolveInfo ri : tmplist) {
							mLaunchableActivity.add(ri.activityInfo);
						}
					} else {
// System.out.println("---->" + ai.packageName);
					}

				}
				ail = null;
			}

			AlertDialog.Builder builder = new AlertDialog.Builder(this);

			builder.setTitle("选择应用");
			builder.setAdapter(new BaseAdapter() {

				@Override
				public int getCount() {
					return mLaunchableActivity.size();
				}

				@Override
				public Object getItem(int position) {
					return mLaunchableActivity.get(position);
				}

				@Override
				public long getItemId(int position) {
					return position;
				}

				@Override
				public View getView(int position, View convertView, ViewGroup parent) {
					View r = convertView;
					if (convertView == null) {
						LayoutInflater li = getLayoutInflater();
						r = li.inflate(R.layout.appwidget_diy_tool_app_listitem, null);

						ImageView icon = (ImageView) r.findViewById(R.id.icon);
						TextView name = (TextView) r.findViewById(R.id.name);

						r.setTag(new View[] { icon, name });
					}

					View[] vs = (View[]) r.getTag();
					ImageView icon = (ImageView) vs[0];
					TextView name = (TextView) vs[1];
					PackageManager pm = getPackageManager();

					ActivityInfo ai = mLaunchableActivity.get(position);

					icon.setImageDrawable(ai.loadIcon(pm));
					name.setText(ai.loadLabel(pm));

					return r;
				}

			}, new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					if (mDiyBtn != null) {
						ActivityInfo ai = mLaunchableActivity.get(which);
						PackageManager pm = getPackageManager();
						putTempAppPackageNameAndActivityName(getActivity(), getCurAWType(), ai.packageName, ai.name, mDiyBtn);
						RadioButton rbtn = (RadioButton) mOptionsItemContainer.getChildAt(mOptionsItemContainer.getChildCount() - 1);
						rbtn.setText("其它应用(" + ai.loadLabel(pm) + ")");
					}

				}
			});
			return builder.create();
		}
		case DIALOG_ID_CHANGE_TO_CONDITION_MODE: {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage("使用实况方式显示天气图标，建议把更新方式改为实况模式，是否修改更新模式？");
			builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					SPUtility.putSPStringInteger(AppWidgetDiyTool.this, R.string.strint_update_type, Constants.UPDATE_TYPE_CONDITION);

				}
			});
			builder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					((RadioButton) mOptionsItemContainer.getChildAt(1)).setChecked(true);
					((RadioButton) mOptionsItemContainer.getChildAt(0)).setChecked(false);

				}
			});
			return builder.create();
		}
		case DIALOG_ID_NO_WIDGET:
			String size = "4x2";
			String space = "1/2";

			if (getCurAWType() == AWType._1ST_4X1) {
				size = "4x1";
				space = "1/4";
			}
			StringBuilder sb = new StringBuilder();
			sb.append("您当前还没有添加");
			sb.append(size);
			sb.append("天气桌面插件，需要手动添加。\n返回手机桌面->空白处长摁2秒以上->菜单中 选择添加小部件(Moto)或者小插件(HTC)->列表中点选");
			sb.append(size);
			sb.append("天气通(如果提示没有足够空间，请在其他桌面空余处放置， 需要预留");
			sb.append(space);
			sb.append("空闲屏幕)；\n注：天气桌面丢失，请卸载后，重新安装天气通到手机内存而非SD卡 -详情见菜单->更多->天气通常见问题");

			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("添加插件提示");
			builder.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			builder.setMessage(sb.toString());
			builder.setPositiveButton(R.string.ok, new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}

			});
			return builder.create();

		}
		return null;
	}

	DiyButton mDiyBtn = null;

	private boolean mMenuIsShown = false;

	public boolean menuIsShown() {
		return mMenuIsShown;
	}

	public void showDiyUnitOption(boolean prepare) {

		if (true) {
			// http://10.210.74.6/browse/ATQT-181
			// 去掉动画
			mMenuIsShown = true;
			mOptionsMenuFrame.setVisibility(View.VISIBLE);
			mPreviewView.makeOptionMenu(mOptionsItemContainer, mOptionsMenuTitle, false, prepare);
			return;
		}

		mMenuIsShown = true;

		mOptionsMenuFrame.setVisibility(View.VISIBLE);
		mPreviewView.makeOptionMenu(mOptionsItemContainer, mOptionsMenuTitle, false, prepare);

		Animation a = AnimationUtils.loadAnimation(AppWidgetDiyTool.this, R.anim.appwidget_diy_tools_optmenu_in);
		a.initialize(mOptionsMenuFrame.getWidth(), mOptionsMenuFrame.getHeight(), mMainContainer.getWidth(), mMainContainer.getHeight());

		mOptionsMenuFrame.setAnimation(a);
		mOptionsMenuFrame.setVisibility(View.VISIBLE);
		a.start();

	}

	public void hideDiyUnitOption() {
		if (true) {
			// http://10.210.74.6/browse/ATQT-181
			// 去掉动画
			mMenuIsShown = false;
			mOptionsMenuFrame.setVisibility(View.GONE);
			return;
		}

		mMenuIsShown = false;

		mOptionsMenuFrame.setVisibility(View.GONE);

		Animation outAnim = AnimationUtils.loadAnimation(this, R.anim.appwidget_diy_tools_optmenu_out);
		outAnim.initialize(mOptionsMenuFrame.getWidth(), mOptionsMenuFrame.getHeight(), mMainContainer.getWidth(), mMainContainer.getHeight());

		mOptionsMenuFrame.setAnimation(outAnim);
		outAnim.start();
		mMainContainer.invalidate();

	}

	public void hideAndShowDiyUnitOption(final boolean prepare) {

		if (true) {
			// http://10.210.74.6/browse/ATQT-181
			// 去掉动画
			mMenuIsShown = true;
			mOptionsMenuFrame.setVisibility(View.VISIBLE);
			mPreviewView.makeOptionMenu(mOptionsItemContainer, mOptionsMenuTitle, false, prepare);
			mMainContainer.invalidate();
			return;
		}

		if (mMenuIsShown) {
			mMenuIsShown = false;

			Animation outAnim = AnimationUtils.loadAnimation(this, R.anim.appwidget_diy_tools_optmenu_out);
			outAnim.initialize(mOptionsMenuFrame.getWidth(), mOptionsMenuFrame.getHeight(), mMainContainer.getWidth(), mMainContainer.getHeight());

			// System.out.println(frame.getWidth() + " " + frame.getHeight() + " " + parent.getWidth() + " " + parent.getHeight());

			outAnim.setAnimationListener(new AnimationListener() {

				@Override
				public void onAnimationStart(Animation animation) {
					// TODO Auto-generated method stub

				}

				@Override
				public void onAnimationRepeat(Animation animation) {
					// TODO Auto-generated method stub

				}

				@Override
				public void onAnimationEnd(Animation animation) {

					mPreviewView.makeOptionMenu(mOptionsItemContainer, mOptionsMenuTitle, false, prepare);

					Animation a = AnimationUtils.loadAnimation(AppWidgetDiyTool.this, R.anim.appwidget_diy_tools_optmenu_in);
					a.initialize(mOptionsMenuFrame.getWidth(), mOptionsMenuFrame.getHeight(), mMainContainer.getWidth(), mMainContainer.getHeight());

					mOptionsMenuFrame.setAnimation(a);
					mOptionsMenuFrame.setVisibility(View.VISIBLE);
					a.start();

					mMenuIsShown = true;
				}
			});
			mOptionsMenuFrame.setAnimation(outAnim);
			outAnim.start();
			mMainContainer.invalidate();
		} else {
			showDiyUnitOption(prepare);
		}

	}

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		mService = ((TianQiTongService.TianQiTongBinder) service).getService();
	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		mService = null;

	}

	public void onBackPressed() {
		if (menuIsShown()) {
			AbstractDiyableUnit[] diyableUnits = getCurDiyableUnits().getDiyableUnits();

			if (diyableUnits.length == 0) {
				return;
			}
			if (mPreviewView.mThread == null) {
				return;
			}
			diyableUnits[mPreviewView.mThread.getCursorPosIdx()].onOkPressed();
			hideDiyUnitOption();
		} else {
			if (getCurAWType() == null) {
				setResult(Activity.RESULT_CANCELED, null);
				finish();
				overridePendingTransition(R.anim.appwidget_preview_scale_in, R.anim.appwidget_diy_tools_fade_out);
				return;
			}
			if (DiyAppWidgetAttrUtil.needSave(this, getCurAWType())) {
				showDialog(DIALOG_ID_ASK_SAVE_AND_APPLY);
			} else {
				int a = SPUtility.getSPInteger(this, R.string.strint_which_default_4x2);
				int b = getCurAWType().getId();
				if (a != b && (getCurAWType() != AWType._1ST_4X1)) {
					showDialog(DIALOG_ID_ASK_APPLY);
				} else {
					cancelPressed();
				}

			}

		}
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		switch (which) {
		case DialogInterface.BUTTON_NEGATIVE: {
			cancelPressed();
		}
			break;
		case DialogInterface.BUTTON_POSITIVE: {
			savePressed();
		}
			break;
		case DialogInterface.BUTTON_NEUTRAL: {
			setDefaultPressed();

		}
			break;
		}

	}

	private void setDefaultPressed() {

		showDialog(DIALOG_ID_WAITING);
		releaseBitmapCacheAndWallpaper();
		new Thread() {
			public void run() {
				DiyAppWidgetAttrUtil.restoreToDefault(AppWidgetDiyTool.this, getCurAWType());
				DiyAppWidgetAttrUtil.clearTemp(AppWidgetDiyTool.this, getCurAWType());

				Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET);
				startService(i);

				boolean retry = true;
				mPreviewView.mThread.setPlay(false);
				while (retry) {
					try {
						mPreviewView.mThread.join();
						retry = false;
					} catch (InterruptedException e) {
					}
				}

				runOnUiThread(new Runnable() {
					public void run() {
						Intent data = new Intent();
						data.putExtra("type", getCurAWType().getId());
						setResult(Activity.RESULT_OK, data);
						removeDialog(DIALOG_ID_WAITING);
						finish();
// overridePendingTransition(R.anim.appwidget_preview_scale_in, R.anim.appwidget_diy_tools_fade_out);
					}
				});

			}
		}.start();

	}

	private void savePressed() {
		showDialog(DIALOG_ID_WAITING);
		releaseBitmapCacheAndWallpaper();
		new Thread() {
			public void run() {
				DiyAppWidgetAttrUtil.saveTemp(AppWidgetDiyTool.this, getCurAWType());

				if (getCurAWType() != AWType._1ST_4X1) {
					SPUtility.putSPInteger(AppWidgetDiyTool.this, R.string.strint_which_default_4x2, getCurAWType().getId());
				}

				Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET);
				startService(i);

				boolean retry = true;

				if (mPreviewView.mThread != null) {
					mPreviewView.mThread.setPlay(false);
					while (retry) {
						try {
							mPreviewView.mThread.join();
							retry = false;
						} catch (InterruptedException e) {
						}
					}
				}

				runOnUiThread(new Runnable() {
					public void run() {
						Intent data = new Intent();
						data.putExtra("type", getCurAWType().getId());
						setResult(Activity.RESULT_OK, data);
						removeDialog(DIALOG_ID_WAITING);
						if (getCurAWType() == AWType._1ST_4X1) {
							if (!have4x1Widget()) {
								showDialog(DIALOG_ID_NO_WIDGET);
							} else {
								finish();
							}
						} else if (getCurAWType() == AWType._1ST_4X2 || getCurAWType() == AWType._2ND_4X2) {
							if (!have4x2Widget()) {
								showDialog(DIALOG_ID_NO_WIDGET);
							} else {
								finish();
							}
						}

						// finish();
// overridePendingTransition(R.anim.appwidget_preview_scale_in, R.anim.appwidget_diy_tools_fade_out);
					}
				});

			}
		}.start();

	}

	private boolean have4x2Widget() {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
		int[] _4x2_ids = appWidgetManager.getAppWidgetIds(new ComponentName(this, WidgetProvider.class));
		if (_4x2_ids.length == 0) {
			return false;
		} else {
			return true;
		}
	}

	private boolean have4x1Widget() {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
		int[] _4x1_ids = appWidgetManager.getAppWidgetIds(new ComponentName(this, Widget4x1Provider.class));
		if (_4x1_ids.length == 0) {
			return false;
		} else {
			return true;
		}
	}

	private void cancelPressed() {
		DiyAppWidgetAttrUtil.clearTemp(this, getCurAWType());

		AbstractDiyableUnit[] diyableUnits = getCurDiyableUnits().getDiyableUnits();

		for (AbstractDiyableUnit adu : diyableUnits) {
			adu.remakeParams();
		}
		repaintPreview(getCurAWType());

		setResult(Activity.RESULT_CANCELED, null);
		finish();
// overridePendingTransition(R.anim.appwidget_preview_scale_in, R.anim.appwidget_diy_tools_fade_out);

	}

}
