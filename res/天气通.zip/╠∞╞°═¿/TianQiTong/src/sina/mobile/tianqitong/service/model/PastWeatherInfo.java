package sina.mobile.tianqitong.service.model;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;

public class PastWeatherInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 当天以前的以前的预报列表
	 */
	private ForeCast[] mPastForecasts;

	/**
	 * 数据是否有效
	 */
	private boolean isVaild = false;

	/**
	 * 取过去多少天的预报数据。
	 * 
	 * @return
	 */
	public ForeCast[] getPastForecasts() {
		ForeCast[] r = new ForeCast[mPastForecasts.length];
		System.arraycopy(mPastForecasts, 0, r, 0, r.length);
		return r;
	}

	public static PastWeatherInfo createEmptyWeatherInfo(String cityCode, String cityName) {

		PastWeatherInfo pwi = new PastWeatherInfo();
		ForeCast fc = ForeCast.EMPTY;
		pwi.mPastForecasts = new ForeCast[] { fc, fc, fc, fc, fc };
		pwi.isVaild = false;
		return pwi;
	}

	public static final PastWeatherInfo parsePastWeatherInfo(byte[] file) throws IOException {

		if (file == null) {
			return null;
		}
		ByteArrayInputStream is = new ByteArrayInputStream(file);
		return parsePastWeatherInfo(is);
	}

	public static final PastWeatherInfo parsePastWeatherInfo(InputStream is) throws IOException {
		XmlPullParserFactory factory;
		XmlPullParser xpp;

		try {
			factory = XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			xpp = factory.newPullParser();
			xpp.setInput(is, null);
			int eventType = xpp.getEventType();

			ArrayList<ForeCast> fcal = new ArrayList<WeatherInfo.ForeCast>();
			PastWeatherInfo pwi = new PastWeatherInfo();

			while (eventType != XmlPullParser.END_DOCUMENT) {

				switch (eventType) {
				case XmlPullParser.START_TAG: {
					if (xpp.getName().equals("foreca") || xpp.getName().equals("night")) {
						String date = WeatherInfo.INVALID_PUBDATE;
						int code = WeatherInfo.INVALID_CODE;
						int code2 = WeatherInfo.INVALID_CODE;
						String text = WeatherInfo.INVALID_TEXT;
						int low = (int) WeatherInfo.INVALID_TEMPERATURE;
						int high = (int) WeatherInfo.INVALID_TEMPERATURE;
						String wind = WeatherInfo.INVALID_WIND;
						for (int i = 0; i < xpp.getAttributeCount(); i++) {
							String attrName = xpp.getAttributeName(i);
							String attrValue = xpp.getAttributeValue(i);
							if (attrName.equals("date")) {
								date = attrValue;
							} else if (attrName.equals("code")) {
								code = Integer.parseInt(attrValue);
							} else if (attrName.equals("code2")) {
								code2 = Integer.parseInt(attrValue);
							} else if (attrName.equals("text")) {
								text = attrValue;
							} else if (attrName.equals("low")) {
								try {
									low = Integer.parseInt(attrValue);
								} catch (NumberFormatException nfe) {
									nfe.printStackTrace();
								}
							} else if (attrName.equals("high")) {
								try {
									high = Integer.parseInt(attrValue);
								} catch (NumberFormatException nfe) {
									nfe.printStackTrace();
								}
							} else if (attrName.equals("wind")) {
								wind = attrValue;
							}
						}

						int fctype = xpp.getName().equals("foreca") ? ForeCast.TYPE_ALL_DAY : ForeCast.TYPE_NIGHT;
						ForeCast fc = new ForeCast(date, code, code2, text, low, high, wind, fctype);
						fcal.add(fc);
					}
				}
				}
				eventType = xpp.next();
			}
			pwi.mPastForecasts = new ForeCast[fcal.size()];
			fcal.toArray(pwi.mPastForecasts);
			return pwi;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 用当前天气和历史天气来构成 昨天和当前的天气预报
	 * 
	 * @param curWi
	 *            当前的天气预报
	 * @param pastWi
	 *            过去的天气预报
	 * @return
	 */
	public static ForeCast[] getYeasterdayAndForecast(final WeatherInfo curWiInfo, final PastWeatherInfo pastWiInfo) {
		ForeCast[] wi = new ForeCast[5];
		ForeCast[] pastWi = pastWiInfo.getPastForecasts();
		ForeCast[] curWi = curWiInfo.getForecasts();

		wi[0] = pastWi[1];
		System.arraycopy(curWi, 0, wi, 1, wi.length - 1);

		// 如果历史天气无效的话，填上前一天的历史天气日期，不然会显示-1,-1.
		if (!pastWiInfo.isVaild) {
			Date date = getPreviousDay(curWi[0].getDateYearNum(), curWi[0].getDateMonthNum() - 1, curWi[0].getDateDayNum());

			wi[0].setDateMonthNum(date.getMonth() + 1);
			wi[0].setDateDayNum(date.getDate());
		}

		if (!curWiInfo.isDay()) { // 黑夜的情况下没有高温，为了补齐当前天气的最高温度
			wi[1].setHigh(pastWi[0].getHigh());
			wi[1].setYcode(pastWi[0].getYcode());
		}
		return wi;
	}

	/**
	 * 获取当前天气的前一天，该方法为了解决用户更新安装包时， 没有更新历史天气的时，时间显示为无效月份和日期的问题
	 * 
	 * @param year
	 *            年
	 * @param month
	 *            月
	 * @param day
	 *            日
	 * @return date Date
	 */
	public static Date getPreviousDay(int year, int month, int day) {
		Calendar calendar = Calendar.getInstance();
		Date date = new Date(year, month, day);
		calendar.setTime(date);
		calendar.add(Calendar.DATE, -1);

		return calendar.getTime();
	}
}
