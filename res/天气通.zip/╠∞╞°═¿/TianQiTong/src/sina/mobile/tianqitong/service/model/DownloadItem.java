package sina.mobile.tianqitong.service.model;

import java.io.File;

public final class DownloadItem {
	private String mUrl;
	private int mType;
	private String mAbsolutePath;
	private long mTimeStamp;

	private int mRequestNum = -1;

	private int mProgress;

	public static final int TYPE_TTS = 0;
	public static final int TYPE_TTS_PREVIEW_MP3 = 1;
	public static final int TYPE_TTS_PREVIEW_ICON = 2;
	public static final int TYPE_APPWIDGET = 3;
	public static final int TYPE_APPWIDGET_PREVIEW_JPG = 4;
	public static final int TYPE_APPWIDGET_PREVIEW_ICON = 5;
	public static final int TYPE_NEW_VERSION = 6;
	public static final int TYPE_SINA_RECOMMEND_ICON = 9;
	public static final int TYPE_SINA_SOFTWARE = 8;
	public static final int TYPE_AD_ICON = 7;
	public static final int TYPE_SINA_WEBSITE_ICON = 10;
	public static final int TYPE_AD_DOWNLOAD = 11;
	public static final int TYPE_WEEK_RECOMMEND_ICON = 12;

	private DownloadItem() {

	}

	/**
	 * 
	 * @param url
	 * @param type
	 * @param absolutePath
	 * @param timeStamp
	 * @param size
	 *            kb
	 * @return
	 */
	public static DownloadItem makeCachedDownloadItem(String url, int type, String absolutePath, long timeStamp) {
		DownloadItem di = new DownloadItem();
		di.mUrl = url;
		di.mType = type;
		di.mAbsolutePath = absolutePath;
		di.mTimeStamp = timeStamp;

		di.mRequestNum = -1;

		File f = new File(absolutePath);
		if (f.exists() && f.isFile()) {
			di.mProgress = 100;
		} else {
			di.mProgress = 0;
		}

		return di;
	}

	public static DownloadItem makeReadyDownloadItem(String url, int type, String absolutePath, int requestNum) {

		File f = new File(absolutePath);
		if (f.exists()) {
			f.delete();
		}

		DownloadItem di = new DownloadItem();
		di.mUrl = url;
		di.mType = type;
		di.mAbsolutePath = absolutePath;
		di.mTimeStamp = System.currentTimeMillis();

		di.mRequestNum = requestNum;

		di.mProgress = 0;
		return di;
	}

	public synchronized void setProgress(int progress) {
		mProgress = progress;
		if (mProgress == 100) {
			mRequestNum = -1;
		}
	}

	public void cancel() {
		mRequestNum = -1;
	}

	public String getUrl() {
		return mUrl;
	}

	public String getPath() {
		return mAbsolutePath;
	}

	public int getType() {
		return mType;
	}

	public long getTimeStamp() {
		return mTimeStamp;
	}

	public synchronized int getProgress() {
		return mProgress;
	}

	public int getRequestNum() {
		return mRequestNum;
	}
}
