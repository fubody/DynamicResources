package sina.mobile.tianqitong.diyappwidget;

import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AppWidgetDiyToolPreviewView extends SurfaceView implements SurfaceHolder.Callback {

	private int mState;

	public AppWidgetDiyToolPreviewView(AppWidgetDiyTool context, AWType type, int state) {
		super(context);
		init(context, type, state);
	}

	AppWidgetDiyToolPreviewViewAnimationThread mThread;

	private void init(AppWidgetDiyTool c, AWType type, int state) {

		// register our interest in hearing about changes to our surface
		SurfaceHolder holder = getHolder();
		holder.addCallback(this);
		mState = state;

		// create thread only; it's started in surfaceCreated()
		mThread = new AppWidgetDiyToolPreviewViewAnimationThread(holder, new Handler());

		setFocusable(true); // make sure we get key events

	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		mThread.setSurfaceSize(width, height);
	}

	/*
	 * Callback invoked when the Surface has been created and is ready to be used.
	 */
	public void surfaceCreated(SurfaceHolder holder) {
		mThread = new AppWidgetDiyToolPreviewViewAnimationThread(holder, new Handler());
		// start the thread here so that we don't busy-wait in run()
		// waiting for the surface to be created
		mThread.setPlay(true);
		mThread.setPlayState(mState);
		mThread.start();
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		// we have to tell thread to shut down & wait for it to finish, or else
		// it might touch the Surface after we return and explode
		boolean retry = true;
		mThread.setPlay(false);
		while (retry) {
			try {
				mThread.join();
				retry = false;
			} catch (InterruptedException e) {
			}
		}
		mThread = null;

	}

	private int mDownX = -1;
	private int mDownY = -1;

// public void makeOptionMenu(LinearLayout ll, TextView title) {
// mThread.makeOptionMenu(ll, title);
// }

	public void makeOptionMenu(LinearLayout ll, TextView title, boolean remake, boolean prepare) {
		mThread.makeOptionMenu(ll, title, remake, prepare);
	}

	public boolean onTouchEvent(MotionEvent event) {

// if (mThread.getPlayState() == AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_TUTORIAL) {
// mThread.setPlayState(AppWidgetDiyToolPreviewViewAnimationThread.STATE_PLAY_DIY_CURSOR_ANIMATION);
// return true;
// }

		int action = event.getAction();
		int x = (int) event.getX();
		int y = (int) event.getY();
		switch (action) {
		case MotionEvent.ACTION_DOWN: {

			mDownX = x;
			mDownY = y;

		}
			break;
		case MotionEvent.ACTION_UP: {
			mThread.setCursorPos(mDownX, mDownY, x, y);
		}
			break;
		case MotionEvent.ACTION_MOVE: {

		}
			break;
		default: {
			mDownX = -1;
			mDownY = -1;
		}
		}

		return true;

	}

}
