package sina.mobile.tianqitong.service.frm;

// import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_WHAT_NOTIFY;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_WHAT_REQUEST;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_WHAT_RESPONSE;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

/**
 * 把两个可同步可异步的接口封装成异步的
 * 
 * @author 黄恪
 * 
 */
public abstract class MsgFunctionHelper extends MsgRequestExecutorHelper implements MsgResponseHandler {

	@Override
	public final void handle(Message msg) {
		_handler.sendMessage(msg);
	}

// Override
// public final void handleNotify(Message msg) {
// _handler.sendMessage(msg);
// }

	public final void newHandler(Looper looper) {
		_handler = new Handler(looper) {
			public void handleMessage(Message msg) {

				int type = msg.what;
				int event = msg.arg2;

				switch (type) {

				case MSG_WHAT_REQUEST: {
					int requestNum = msg.arg1;
					Bundle args = (Bundle) msg.getData().clone();
					executeRequest(event, requestNum, args);
				}
					break;
				case MSG_WHAT_RESPONSE: {
					Bundle datas = (Bundle) msg.getData().clone();
					Bundle requestArgs = datas.getBundle(MsgUtility.MSG_DATA_KEY_BUNDLE_REQUEST_ARGS);
					int refRequestNum = requestArgs.getInt(MsgUtility.MSG_DATA_KEY_INT_REF_REQUEST_NUM);
					int responseCode = datas.getInt(MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE);
					handleResponse(event, responseCode, requestArgs, datas, refRequestNum);
				}
					break;
// case MSG_WHAT_NOTIFY: {
// Bundle datas = (Bundle) msg.getData().clone();
// handleNotify(event, datas);
// }
// break;
				}
			}
		};

	}

	public abstract void handleResponse(int event, int responseCode, Bundle requestArgs, Bundle datas, int refRequestNum);

// public abstract void handleNotify(int event, Bundle datas);

}
