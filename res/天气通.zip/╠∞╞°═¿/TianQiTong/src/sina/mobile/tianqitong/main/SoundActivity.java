package sina.mobile.tianqitong.main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.SoundEntityManger;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.SoundEntity;
import sina.mobile.tianqitong.service.utility.BitmapCache;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class SoundActivity extends BaseListActivity implements ServiceConnection {
	private SoundEntityManger mSoundEntityManger = null;

	private ArrayList<SoundEntity> mListData = new ArrayList<SoundEntity>();
	private long mWhichUsing;
	private MediaPlayer mMediaPlayer = null;

	private ButtonTypeDelete mButtonTypeDelete = null;
	private ButtonTypeAudition mButtonTypeAudition = null;
	private ButtonTypeDown mButtonTypeDown = null;
	private ButtonChecked mButtonChecked = null;
	private ButtonCancel mButtonCancel = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		mWhichUsing = SPUtility.getSPStringLong(SoundActivity.this, R.string.str_tts_file_id);
		super.onCreate(savedInstanceState);
		// 获取的插件的使用的id

		mButtonTypeDelete = new ButtonTypeDelete();
		mButtonTypeAudition = new ButtonTypeAudition();
		mButtonTypeDown = new ButtonTypeDown();
		mButtonChecked = new ButtonChecked();
		mButtonCancel = new ButtonCancel();

		getApplicationContext().bindService(new Intent(this, TianQiTongService.class), this, BIND_AUTO_CREATE);

	}

	@Override
	protected String getHeadText() {
		return "本地语音";
	}

	@Override
	protected String getCenterText() {
		return "个性语音";
	}

	@Override
	protected void buildData() {

		SoundEntity[] se = mSoundEntityManger.getSoundEntitys();

		mListData.clear();
		for (int i = 0; i < se.length; i++) {
			mListData.add(se[i]);
			if (se[i].getFileUrl() != null && se[i].getId() != SoundEntity.DEFAULT_TTS_ID) {
				if (se[i].getFileUrl() != null) {
					urlKeyHashMap.put(se[i].getFileUrl(), se[i]);
				}
			}
		}
		orderListData();

		mMyBaseAdapter.notifyDataSetChanged();

		{
			boolean isdefault = mWhichUsing == SoundEntity.DEFAULT_TTS_ID;

			if (isdefault) {

			} else {
				boolean currentOk = false;
				if (Utility.sdAvailiable()) {
					String pkgName = SPUtility.getSPString(this, R.string.str_tts_file_path);
					File f = new File(pkgName);
					if (f.exists() && f.isFile()) {
						currentOk = true;
					}

				}
				if (!currentOk) {
					mWhichUsing = SoundEntity.DEFAULT_TTS_ID;
					SPUtility.putSPString(this, R.string.str_tts_file_path, "default");
					SPUtility.putSPString(this, R.string.str_tts_file_id, "-100");
					mWhichUsing = -100;
				}
			}
		}

	}

	private HashMap<String, HolderView> holderViewHashMap = new HashMap<String, HolderView>();

	@Override
	protected View constructConvertView(View convertView, LayoutInflater mInflater, int position, List<?> mListData) {
		HolderView mHolderView = null;
		SoundEntity se = (SoundEntity) mListData.get(position);

		convertView = mInflater.inflate(R.layout.listviewofsound_item, null);

		mHolderView = new HolderView(convertView);
		holderViewHashMap.put(se.getKey(), mHolderView);

		mHolderView.constructView(position, se);
		return convertView;
	}

	private class HolderView {
		ImageView headSculpture = null;
		TextView soundName = null;
		ImageView stars = null;
		ImageView downImageView = null;
		TextView progressText = null;
		ImageView audition = null;
		ImageView deleteSound = null;
		TextView authorName = null;
		TextView fileSize = null;
		BgProgressBar downProgressBar = null;
		ImageView soundUsing = null;
		ImageView dividerHorizontal = null;
		RadioButton useButton = null;
		LinearLayout mLinearLayout = null;
		ImageView cancel = null;
		View convertView = null;

		public HolderView(View convertView) {
			this.convertView = convertView;
			headSculpture = (ImageView) convertView.findViewById(R.id.head_sculpture);
			soundName = (TextView) convertView.findViewById(R.id.sound_name);
			stars = (ImageView) convertView.findViewById(R.id.stars);
			downImageView = (ImageView) convertView.findViewById(R.id.down);

			progressText = (TextView) convertView.findViewById(R.id.progress_text);

			audition = (ImageView) convertView.findViewById(R.id.audition);
			deleteSound = (ImageView) convertView.findViewById(R.id.delete_sound);
			authorName = (TextView) convertView.findViewById(R.id.author_name);
			fileSize = (TextView) convertView.findViewById(R.id.file_size);
			downProgressBar = (BgProgressBar) convertView.findViewById(R.id.myProgressBar);

			soundUsing = (ImageView) convertView.findViewById(R.id.sound_using);
			dividerHorizontal = (ImageView) convertView.findViewById(R.id.divider_horizontal);
			useButton = (RadioButton) convertView.findViewById(R.id.useButton);

			mLinearLayout = (LinearLayout) convertView.findViewById(R.id.progress_text_cancel);
			cancel = (ImageView) convertView.findViewById(R.id.suond_cancel);
		}

		public View constructView(int position, SoundEntity se) {

			if (mWhichUsing == se.getId()) {
				useButton.setChecked(true);
				soundUsing.setVisibility(View.VISIBLE);
			} else {
				useButton.setChecked(false);
				soundUsing.setVisibility(View.GONE);
			}

			soundName.setText(se.getSoundNameStr());
			stars.setImageBitmap(getStartsBitmap(se.getStartCountInt()));
			authorName.setText(se.getAuthorNameStr());
			if (se.getFileSizeStr() != -1)
				fileSize.setText(se.getFileSizeStr() + "k");
			if (se.getIconFile() != null) {
				Bitmap bm = null;

				String key = se.getKey();
				if (BitmapCache.getCustomBitmap(key) != null) {
					bm = BitmapCache.getCustomBitmap(key);
				} else {
					bm = BitmapFactory.decodeFile(se.getIconFile().getAbsolutePath());
					BitmapCache.putCustomBitmap(key, bm);
				}

				headSculpture.setImageBitmap(bm);
			}

			if (se.getId() == SoundEntity.DEFAULT_TTS_ID || se.getFileFile() != null) {
				useButton.setVisibility(View.VISIBLE);
			} else {
				useButton.setVisibility(View.INVISIBLE);
			}

			if (se.getId() == SoundEntity.DEFAULT_TTS_ID) {
				audition.setVisibility(View.GONE);
				deleteSound.setVisibility(View.GONE);
				headSculpture.setImageResource(R.drawable.head_sculpture);
			} else {
				audition.setVisibility(View.VISIBLE);
				if (se.getFileFile() != null) {
					deleteSound.setVisibility(View.VISIBLE);
				} else {
					deleteSound.setVisibility(View.INVISIBLE);
				}

			}

			if (tdl.isInDownloadItems(se.getFileUrl()) != -1) {
				downImageView.setVisibility(View.GONE);
				mLinearLayout.setVisibility(View.VISIBLE);
				downProgressBar.setVisibility(View.VISIBLE);
				progressText.setText(tdl.isInDownloadItems(se.getFileUrl()) + "%");

			} else {
				if (se.getId() == SoundEntity.DEFAULT_TTS_ID || se.getFileFile() != null) {
					downImageView.setVisibility(View.INVISIBLE);
				} else {
					downImageView.setVisibility(View.VISIBLE);
				}
				mLinearLayout.setVisibility(View.INVISIBLE);
				downProgressBar.setVisibility(View.INVISIBLE);
			}
			downImageView.setTag(se);
			downImageView.setOnClickListener(mButtonTypeDown);
			// }
			audition.setTag(se);
			audition.setOnClickListener(mButtonTypeAudition);

			useButton.setTag(se);
			useButton.setOnCheckedChangeListener(mButtonChecked);

			deleteSound.setTag(se);
			deleteSound.setOnClickListener(mButtonTypeDelete);

			cancel.setTag(se);
			cancel.setOnClickListener(mButtonCancel);

			if ((indexOfDivideCenter - 1) == position || (indexOfDivideBottom - 1) == position) {
				dividerHorizontal.setVisibility(View.INVISIBLE);
			} else {
				dividerHorizontal.setVisibility(View.VISIBLE);
			}

			return this.convertView;
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		releaseMediaPlayer();
	}

	private void releaseMediaPlayer() {
		if (mMediaPlayer != null) {
			mMediaPlayer.release();
			mMediaPlayer = null;
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		releaseMediaPlayer();
		mListData.clear();
		holderViewHashMap.clear();
	}

	/**
	 * 以图片或者试听的Url作为key找到它所包含的SoundEntity
	 */
	private HashMap<String, SoundEntity> urlKeyHashMap = new HashMap<String, SoundEntity>();

	private int indexOfDivideCenter = 0;
	private int indexOfDivideBottom = 0;

	private void orderListData() {
		ArrayList<SoundEntity> hasdownListData = new ArrayList<SoundEntity>();
		ArrayList<SoundEntity> notdownListData = new ArrayList<SoundEntity>();
		SoundEntity defaultSE = null;
		for (SoundEntity se : mListData) {
			if (se == null) {
				continue;
			}
			if (se.getId() != SoundEntity.DEFAULT_TTS_ID) {
				if (se.getFileFile() == null) {
					notdownListData.add(se);
				}
				if (se.getFileFile() != null) {
					hasdownListData.add(se);
				}
			} else {
				defaultSE = se;
			}
		}

		mListData.clear();
		mListData.add(defaultSE);
		mListData.addAll(hasdownListData);
		indexOfDivideCenter = mListData.size();
		mListData.add(null);
		mListData.addAll(notdownListData);
		mMyBaseAdapter.setListData(mListData);
		indexOfDivideBottom = mListData.size();
	}

	private SoundEntity deleteSoundEntity;

	public static final int TIANQITONG_DIALOG_DELETE = 2;

	public Dialog onCreateDialog(int id) {
		AlertDialog.Builder b = null;
		switch (id) {
		case TIANQITONG_DIALOG_DELETE: {
			b = new AlertDialog.Builder(this);
			b.setTitle("删除提示");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage("确定要删除吗？");
			b.setPositiveButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					deleteSoundEntity.getFileFile().delete();

					if (SPUtility.getSPStringLong(SoundActivity.this, R.string.str_tts_file_id) == deleteSoundEntity.getId()) {
						SPUtility.putSPString(SoundActivity.this, R.string.str_tts_file_path, "default");
						SPUtility.putSPString(SoundActivity.this, R.string.str_tts_file_id, "-100");
						mWhichUsing = -100L;

					}

					buildData();

					mMyBaseAdapter.notifyDataSetChanged();

				}
			});
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(TIANQITONG_DIALOG_DELETE);
				}
			});

		}
		}
		if (b != null) {
			return b.create();
		}
		return null;
	}

	// //////////////////////////按钮监听//////////////////////////////////
	// private HashSet<String> downUrl = new HashSet();

	/**
	 * 下载语言包的监听
	 * 
	 * @author zhangxi
	 * 
	 */
	private class ButtonTypeDown implements OnClickListener {
		@Override
		public void onClick(View v) {

			if (!Utility.sdAvailiable()) {
				Toast.makeText(SoundActivity.this, "找不到sd卡", Toast.LENGTH_LONG).show();
				return;
			}

			if (Utility.isAirplaneModeOn(getApplicationContext())) {
// Toast.makeText(SoundActivity.this, "飞行模式中，请联网后再试！", Toast.LENGTH_LONG).show();
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, SoundActivity.this);
				dg.show();
				return;
			}

			if (!Utility.getAvailableNetWork(getApplicationContext())) {
// Toast.makeText(SoundActivity.this, "无可用网络，请稍后再试！", Toast.LENGTH_LONG).show();
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, SoundActivity.this);
				dg.show();
				return;
			}

			SoundEntity downLoadSoundEntity = (SoundEntity) v.getTag();

			if (holderViewHashMap.get(downLoadSoundEntity.getKey()) == null) {
				return;
			}
			v.setVisibility(View.GONE);
			holderViewHashMap.get(downLoadSoundEntity.getKey()).mLinearLayout.setVisibility(View.VISIBLE);
			holderViewHashMap.get(downLoadSoundEntity.getKey()).downProgressBar.setVisibility(View.VISIBLE);

			downLoadSoundEntity.downloadMainUrl(false);

		}
	}

	private class ButtonTypeDelete implements OnClickListener {
		@Override
		public void onClick(View v) {
			deleteSoundEntity = (SoundEntity) v.getTag();
			showDialog(TIANQITONG_DIALOG_DELETE);
		}
	}

	private class ButtonChecked implements OnCheckedChangeListener {

		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			SoundEntity se = (SoundEntity) buttonView.getTag();

			mWhichUsing = se.getId();
			if (se.getId() == SoundEntity.DEFAULT_TTS_ID) {
				SPUtility.putSPString(SoundActivity.this, R.string.str_tts_file_path, "default");
				SPUtility.putSPString(SoundActivity.this, R.string.str_tts_file_id, "-100");
			} else {
				SPUtility.putSPString(SoundActivity.this, R.string.str_tts_file_path, se.getFileFile().getAbsolutePath());
				SPUtility.putSPString(SoundActivity.this, R.string.str_tts_file_id, se.getId() + "");
			}
			mMyBaseAdapter.notifyDataSetChanged();
		}

	}

	private class ButtonTypeAudition implements OnClickListener {
		@Override
		public void onClick(View v) {
			try {
				SoundEntity se = (SoundEntity) v.getTag();

				if (mMediaPlayer != null) {
					if (mMediaPlayer.isPlaying()) {
						mMediaPlayer.stop();
					}
				}
				mMediaPlayer = new MediaPlayer();

				if (se.getAuditionFileFile() == null) {
					Toast.makeText(SoundActivity.this, " 试听语音没有被下载", Toast.LENGTH_SHORT).show();
					return;
				}
				mMediaPlayer.setDataSource(se.getAuditionFileFile().getAbsolutePath());
				mMediaPlayer.prepare();
				mMediaPlayer.start();

			} catch (IllegalArgumentException e) {

				e.printStackTrace();
			} catch (IllegalStateException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

	private class ButtonCancel implements OnClickListener {
		@Override
		public void onClick(View v) {
			SoundEntity se = (SoundEntity) v.getTag();
			se.cancelDownloadingMainUrl();
			mMyBaseAdapter.notifyDataSetChanged();
		}
	}

	private TianQiTongDownloadManger tdl = null;

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		TianQiTongService lservice = ((TianQiTongService.TianQiTongBinder) service).getService();
		mSoundEntityManger = lservice.getSoundEntityManger();
		Handler handler = new Handler(this);
		mSoundEntityManger.getDataManager().setDataManagerListener(handler);
		mSoundEntityManger.getDataManager().refresh(null);

		// TianQiTongDownloadManger tm =TianQiTongDownloadManger.getInstance(null);

		// tm.getDownloadItems(DownloadItem.)

		buildData();
		tdl = TianQiTongDownloadManger.getInstance(null);

	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onMainDownloadDone(String url) {
		SoundEntity s = urlKeyHashMap.get(url);
		String currlyDownKeyName = s.getKey();
		HolderView hv = holderViewHashMap.get(currlyDownKeyName);
		if (hv != null) {
			hv.mLinearLayout.setVisibility(View.GONE);
			hv.downProgressBar.setVisibility(View.GONE);
		}
		orderListData();
	}

	@Override
	public void onMainDownloadProgressUpdated(String url, int progress) {
		SoundEntity s = urlKeyHashMap.get(url);

		String currlyDownKeyName = s.getKey();

		HolderView hv = holderViewHashMap.get(currlyDownKeyName);

		if (hv != null) {
			hv.downImageView.setVisibility(View.GONE);
			hv.mLinearLayout.setVisibility(View.VISIBLE);
			hv.downProgressBar.setVisibility(View.VISIBLE);
			hv.downProgressBar.setProgress(progress);
			hv.progressText.setText(progress + "%");
		}
	}

}
