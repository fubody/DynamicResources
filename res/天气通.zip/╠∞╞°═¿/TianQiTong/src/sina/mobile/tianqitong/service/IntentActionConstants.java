package sina.mobile.tianqitong.service;

public interface IntentActionConstants {

	/**
	 * 传递给全屏动画Acitivity的，用来表示播放哪个动画
	 */
	public static final String INTENT_EXTRA_KEY_FULL_SCREEN_ANIMATION_ID = "anim_id";

	/**
	 * 传递给MainActivity的，表示需要进入到哪个页面。
	 */
	public static final String INTENT_EXTRA_KEY_PAGE = "page";

	/**
	 * 传递给MainActivity的，为true表示是从appwidget启动的。需要把当前城市换成插件城市。
	 */
	public static final String INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET = "sina.mobile.tianqitong.start_mainactivity_from_widget";

	/**
	 * 目前是传给MainActivity的，表示是定时播报要求弹出的，如果没有其他操作，播报完毕要自动关闭并锁屏。
	 */
	public static final String INTENT_EXTRA_FORCE_POPUP_AND_AUTO_FINISH_AND_LOCK = "popup_and_finish";

	/**
	 * 传递给MainActivity，用来显示引导。
	 */
	public static final String INTENT_EXTRA_FIRST_RUN = "first_run";

	/**
	 * 定时用的action。设定定时的时候作为pendingIntent的action，然后在TianQiTongReciever接收。<br>
	 */
	public static final String ACTION_ALARM = "sina.mobile.tianqitong.action.ALARM";

	/**
	 * 定时广播中，表示定时的类型。具体的取值，在TianQiTongAlarm里<br>
	 */
	public static final String BUNDLE_KEY_INT_ALARM_TYPE = "alarm_type";

	public static final String BUNDLE_KEY_LONG_ALARM_TIME = "alarm_time";

	public static final String BUNDLE_KEY_INT_NOTIFICATION_TYPE = "noti_type";

	public static final String BUNDLE_KEY_LONG_NOTIFICATION_TIME = "noti_time";

	public static final String BUNDLE_NOTIFICATION_INFO = "noti_info";

	public static final String BUNDLE_NOTIFICATION_TITLE_LEFT = "noti_city";

	public static final String BUNDLE_NOTIFICATION_TITLE_RIGHT = "noti_temp";

	public static final String BUNDLE_NOTIFICATION_CONDITION = "noti_condition";

	/*
	 * 预警相关参数
	 */
	public static final String BUNDLE_WARNING_LEVEL = "warning_level";
	public static final String BUNDLE_WARNING_TITLE = "warning_title";
	public static final String BUNDLE_WARNING_CONTENT = "warning_content";
	public static final String BUNDLE_WARNING_DATE = "warning_date";
	public static final String BUNDLE_WARNING_ADDRESS = "warning_address";

	public static final String ACTION_DATE_CHANGED = "android.intent.action.DATE_CHANGED";
	/**
	 * 每分钟更新widget上的时钟。
	 */
	public static final String ACTION_BC_UPDATE_WIDGET_CLOCK = "sina.mobile.tianqitong.action.update_widget_clock";

	/**
	 * 是否自动弹出自动定位。
	 */
	public static final String EXTRA_WEATHER_AUTO_LOCATE = "auto_locate_when_firstrun";
	/*
	 * 用户引导相关参数
	 */
	public static final String BUNDLE_GUIDE_TYPE = "guide_type";
	public static final String BUNDLE_GUIDE_TYPE_VALUE_MAIN = "guide_main";
	public static final String BUNDLE_GUIDE_TYPE_VALUE_CITYDRAG = "guide_city_drag";
	/**
	 * tts正在播放。<br>
	 * 语音播放开始，需要把播放图标换成停止播放图标。
	 */
	public static final String ACTION_BC_TTS_PLAYING = "sina.mobile.tianqitong.action.BC_TTS_PLAYING";

	/**
	 * tts播放完毕。<br>
	 * 目前两个用途，一个是定时语音播报弹出之后，用户没有操作，播放完毕之后要关闭界面；<br>
	 * 语音播报结束，需要把停止播放图标换成播放图标。
	 */
	public static final String ACTION_BC_TTS_PLAYING_FINISHED = "sina.mobile.tianqitong.action.BC_TTS_PLAYING_FINISHED";

	public static final String ACTION_BC_CURRENT_CITY_CHANGED = "sina.mobile.tianqitong.action.BC_CURRENT_CITY_CHANGED";
	public static final String ACTION_BC_WIDGET_CITY_CHANGED = "sina.mobile.tianqitong.action.BC_WIDGET_CITY_CHANGED";
	public static final String ACTION_BC_ALARM_TTS_CITY_CHANGED = "sina.mobile.tianqitong.action.BC_ALARM_TTS_CITY_CHANGED";
	public static final String ACTION_BC_NOTIFICATION_CITY_CHANGED = "sina.mobile.tianqitong.action.BC_NOTIFICATION_CITY_CHANGED";
	public static final String ACTION_BC_CACHE_CITYS_CHANGED = "sina.mobile.tianqitong.action.BC_CACHE_CITYS_CHANGED";
	public static final String ACTION_BC_ALL_UPDATED = "sina.mobile.tianqitong.action.BC_ALL_UPDATED";

	public static final String ACTION_BC_ONE_CITY_UPDATED = "sina.mobile.tianqitong.action.BC_ONE_CITY_UPDATED";
	public static final String ACTION_BC_PAST_WEATHER_UPDATED = "sina.mobile.tianqitong.action.BC_PAST_WEATHER_UPDATED";
	
	public static final String BUNDLE_KEY_STR_CITYCODE = "citycode";

	public static final String ACTION_BC_WEATHER_NOTIFICATION = "sina.mobile.tianqitong.action.BC_WEATHER_NOTIFICATION";
	public static final String ACTION_BC_WEATHER_CHECK_NEXT = "sina.mobile.tianqitong.action.BC_BC_WEATHER_CHECK_NEXT";
	public static final String ACTION_BC_FESTIVAL_NOTIFICATION = "sina.mobile.tianqitong.action.BC_FESTIVAL_NOTIFICATION";
	public static final String ACTION_BC_JIEQI_NOTIFICATION = "sina.mobile.tianqitong.action.BC_JIEQI_NOTIFICATION";
	public static final String ACTION_BC_REMOVE_WEATHER_LAST_NOTI = "sina.mobile.tianqitong.action.BC_REMOVE_WEATHER_LAST_NOTI";
	public static final String ACTION_BC_REMOVE_FESTIVAL_LAST_NOTI = "sina.mobile.tianqitong.action.BC_REMOVE_FESTIVAL_LAST_NOTI";
	public static final String ACTION_BC_REMOVE_JIEQI_LAST_NOTI = "sina.mobile.tianqitong.action.BC_REMOVE_JIEQI_LAST_NOTI";
	public static final String ACTION_BC_FESTIVAL_CHECK_NEXT = "sina.mobile.tianqitong.action.BC_FESTIVAL_CHECK_NEXT";
	public static final String ACTION_BC_JIEQI_CHECK_NEXT = "sina.mobile.tianqitong.action.BC_JIEQI_CHECK_NEXT";
	public static final String START_SERVICE_NOTIFICATION_TIME_TYPE = "noti_time_type";
	public static final String EXTRA_KEY_BC_INITTQT_BOOLEAN_FIRST_TIME = "first_time";

	public static final String ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL = "sina.mobile.tianqitong.action.startservice.wake_up_and_update_all";
	public static final String ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL_AND_PLAYTTS_MAYBE_POPUP = "sina.mobile.tianqitong.action.startservice.wake_up_and_update_all_and_play_tts_maybe_popup";
	public static final String ACTION_START_SERVICE_SWITCH_WIDGET_CITY = "sina.mobile.tianqitong.action.startservice.switch_appwidget_city";
	public static final String ACTION_START_SERVICE_PLAY_OR_STOP_PLAY_TTS = "sina.mobile.tianqitong.action.startservice.play_or_stop_play_tts";
	public static final String ACTION_START_SERVICE_UPDATE_WIDGET = "sina.mobile.tianqitong.action.startservice.update_appwidget";
	public static final String ACTION_START_SERVICE_UPDATE_WIDGET_BTN = "sina.mobile.tianqitong.action.startservice.update_appwidget_btn";
	public static final String ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION = "sina.mobile.tianqitong.action.startservice.update_weather_notification";
	public static final String ACTION_START_SERVICE_UPDATE_JIEQI_NOTIFICATION = "sina.mobile.tianqitong.action.startservice.update_jieqi_notification";
	public static final String ACTION_START_SERVICE_UPDATE_FESTIVAL_NOTIFICATION = "sina.mobile.tianqitong.action.startservice.update_festival_notification";

	public static final String ACTION_START_SERVICE_UPDATE_JIEQI_NOTIFICATION_NEXT = "sina.mobile.tianqitong.action.startservice.update_jieqi_notification_next";
	public static final String ACTION_START_SERVICE_UPDATE_FESTIVAL_NOTIFICATION_NEXT = "sina.mobile.tianqitong.action.startservice.update_festival_notification_next";
	public static final String ACTION_START_SERVICE_UPDATE_WIDGET_CLOCK = "sina.mobile.tianqitong.action.startservice.update_widget_clock";
	public static final String ACTION_START_SERVICE_UPDATE_4x1WIDGET = "sina.mobile.tianqitong.action.startservice.update_4x1appwidget";
	public static final String ACTION_START_SERVICE_UPDATE_4x2WIDGET = "sina.mobile.tianqitong.action.startservice.update_4x2appwidget";
	public static final String ACTION_START_SERVICE_RUN_WEIBO = "sina.mobile.tianqitong.action.startservice.run_weibo";
	public static final String ACTION_START_SERVICE_1STBTN_RUN_APP = "sina.mobile.tianqitong.action.startservice.appwidget_1stbtn_run_app";
	public static final String ACTION_START_SERVICE_2NDBTN_RUN_APP = "sina.mobile.tianqitong.action.startservice.appwidget_2ndbtn_run_app";

	public static final String EXTRA_KEY_START_SERVICE_OTHER_PARAMS = "start_service_other_params";
	public static final int EXTRA_KEY_START_SERVICE_OTHER_PARAMS_PLAYORSTOPTTS_FROM_APPWIDGET = 0;
	public static final int EXTRA_KEY_START_SERVICE_OTHER_PARAMS_UPDATEWEATHERS_SHOW_TOAST = 1;

}
