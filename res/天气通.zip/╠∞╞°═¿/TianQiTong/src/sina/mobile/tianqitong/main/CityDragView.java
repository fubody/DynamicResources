package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.citymanager.CityWeathInfo;
import sina.mobile.tianqitong.citymanager.DragController;
import sina.mobile.tianqitong.citymanager.DragController.DragListener;
import sina.mobile.tianqitong.citymanager.DragLayer;
import sina.mobile.tianqitong.citymanager.DragLayer.DeleteCityListener;
import sina.mobile.tianqitong.citymanager.DragSource;
import sina.mobile.tianqitong.citymanager.RubbishBoxView;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.WarningCache;
import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class CityDragView extends RelativeLayout implements View.OnLongClickListener, WeatherViewInterface, DragListener, DeleteCityListener {
	private DragController mDragController;
	private DragLayer mDragLayer;
	private RubbishBoxView mRubbishBoxView = null;
	private Animation pushIn;
	private Animation pushOut;
	Context context;
//	ImageView mMicImg;

	// AnimationDrawable frameAnimation;

	public CityDragView(Context context) {
		super(context);
	}

	public CityDragView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		RelativeLayout.LayoutParams lllp = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		setLayoutParams(lllp);
		
		//适配480X640分辨率        added by Maojianwei 
		DisplayMetrics dm = getResources().getDisplayMetrics();
		if(480 == dm.widthPixels && 640 == dm.heightPixels) {
			LayoutInflater.from(context).inflate(R.layout.city_drag_manager_480x640, this, true);
		} else {
			LayoutInflater.from(context).inflate(R.layout.city_drag_manager, this, true);
		}
		
		mDragController = new DragController(context);
		mDragController.setFloatView((ImageView) findViewById(R.id.float_view));
//		mMicImg = (ImageView) findViewById(R.id.mic);

		// frameAnimation = (AnimationDrawable) mMicImg.getBackground();
		setupViews();
		initAnim();

	}

	private void setupViews() {

		mDragLayer = (DragLayer) findViewById(R.id.dragLayer);
		mDragLayer.setDragController(mDragController);
		mDragLayer.setDeleteCityListener(this);
		mRubbishBoxView = (RubbishBoxView) findViewById(R.id.rbv);

		mDragController.setDropTarget(mRubbishBoxView);
		mDragController.setRubbishListener(this);
	}

	private void initAnim() {
		pushIn = AnimationUtils.loadAnimation(context, R.anim.push_top_in);

		pushIn.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub
				mRubbishBoxView.setVisibility(View.INVISIBLE);
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

		});
		pushOut = AnimationUtils.loadAnimation(context, R.anim.push_top_out);

		pushOut.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

				mRubbishBoxView.setVisibility(View.VISIBLE);
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

		});

	}

	@Override
	public void onDragStart(DragSource source, boolean index0Changer) {
		CustomFrameLayout.isCityViewDraging = true;
//		if (index0Changer) {
//			mMicImg.setVisibility(View.VISIBLE);
//
//		}
//		((ImageView) findViewById(R.id.small_mic)).setImageResource(R.drawable.small_mic2);
//#ifndef WITHOUT_RECOMMEND
		findViewById(R.id.recommend).setVisibility(View.INVISIBLE);
//#endif
		mRubbishBoxView.startAnimation(pushOut);
		mRubbishBoxView.initViewState(mDragLayer.isOnlyOneCity());
		setBackgroundColor(getResources().getColor(R.color.bg_9));
	}

	@Override
	public void onDragEnd(boolean index0Changer) {
		CustomFrameLayout.isCityViewDraging = false;
		mRubbishBoxView.startAnimation(pushIn);
//		((ImageView) findViewById(R.id.small_mic)).setImageResource(R.drawable.small_mic);
//		mMicImg.setVisibility(View.VISIBLE);
		//changed by Maojianwei 更改语音播报城市
//		if (index0Changer) {
//			SPUtility.putSPString(context, R.string.str_alarm_tts_city_code, mDragLayer.getDefauldCityCode());
//			SPUtility.userActionCounterIncreaseOne(context, R.string.int_times_of_setting_alarm_city_at_citymanager);
//			Toast.makeText(context, "定时播报城市设置成功", Toast.LENGTH_SHORT).show();
//		}
		setBackgroundColor(0);
//#ifndef WITHOUT_RECOMMEND
		findViewById(R.id.recommend).setVisibility(View.VISIBLE);
//#endif
	}

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void finishAnim() {
		// TODO Auto-generated method stub

	}

	public void changeSkin(int skin) {
		// 根据城市的背景天气设置9宫格文字的颜色
		mDragLayer.setColor(skin);
	}

	private TianQiTongService mService = null;

	@Override
	public void updateUI(TianQiTongService service, String cityName, WeatherInfo fi, boolean noAnim, int skin) {
		this.mService = service;

		changeSkin(skin);

		mDragLayer.cleanDateList();
		String[] citycodeArray = service.getCityCodes();
		String currenCiytCoid = SPUtility.getSPString(context, R.string.str_current_city_code);

		int i = 0;
		for (String c : citycodeArray) {
			if (i >= 9) {
				continue;
			}

			WeatherInfo wi = service.getWeatherInfo(c);

			CityWeathInfo cwi = new CityWeathInfo();
			cwi.cityCode = c;
			cwi.cityName = service.getCityName(c);
			if (currenCiytCoid.equals(c)) {
				cwi.isCurrentCity = true;
			}

			int ycode = 0;
			ForeCast[] fcs = wi.getForecastsForCurrent(2);
			if (fcs[0] == ForeCast.EMPTY) {
				ycode = WeatherInfo.INVALID_YCODE;
			} else {
				if (wi.isDay() && fcs[0].getType() == ForeCast.TYPE_ALL_DAY) {
					ycode = fcs[0].getYcode();
					cwi.icon = WeatherInfo.getWeatherIconFromYahooCode(ycode, WeatherInfo.ICON_TYPE_FORECAST, getResources());
					cwi.weahter = fcs[0].getDayText();
					cwi.heightTem = fcs[0].getHigh();
					cwi.lowTem = fcs[0].getLow();
					cwi.isDay = true;
				} else {
					ycode = fcs[0].getYcode2();
					cwi.icon = WeatherInfo.getWeatherIconFromYahooCode(ycode, WeatherInfo.ICON_TYPE_FORECAST, getResources());
					cwi.weahter = fcs[0].getNightText();
					cwi.heightTem = fcs[0].getLow();
					cwi.lowTem = fcs[1].getHigh();
					cwi.isDay = false;
				}

			}

			mDragLayer.addCityWeathInfo(cwi, i);
			i++;
		}
		mDragLayer.setAddViewOnclick();

	}

	@Override
	public void onDeleteCity(String cityCode) {
		if (mService != null) {
			// mService
			mService.deleteWeatherData(cityCode);
			mService.deleteWarningData(cityCode);
			if (WarningCache.cache.containsKey(cityCode)) {
				WarningCache.remove(cityCode);
			}
		}
	}

	public void notifyTTsCityChanger() {
		String str = SPUtility.getSPString(context, R.string.str_alarm_tts_city_code);
	}
}
