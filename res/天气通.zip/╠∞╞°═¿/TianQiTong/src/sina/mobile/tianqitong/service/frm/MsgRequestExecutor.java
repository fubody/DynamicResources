package sina.mobile.tianqitong.service.frm;

import android.os.Message;

/**
 * 跟MsgUtility配合
 * 
 * @author 黄恪
 * 
 */
public interface MsgRequestExecutor {
	void execute(Message msg);
}
