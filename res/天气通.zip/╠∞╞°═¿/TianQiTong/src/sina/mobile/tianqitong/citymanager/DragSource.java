package sina.mobile.tianqitong.citymanager;

import android.view.View;

/**
 * Interface defining an object where drag operations originate.
 * 
 */
public interface DragSource {
	void setDragController(DragController dragger);

	void onDropCompleted(View target, boolean success);

	/**
	 * 在判断长按移动的过程中到9宫格的哪个位置了，如果不在九宫格的某个格子上，返回 -1
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	int containsIn9Grid(int x, int y);

	boolean addCityWeathInfo(CityWeathInfo cwi, int index);

	void tradeCityWeathInfo(int one, int other);

	void deleteCityWeathInfo(int index);

	boolean isOnlyOneCity();
}
