package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_URL;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.StringTokenizer;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.SinaRecommendManager;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.frm.HandlerObserver;
import sina.mobile.tianqitong.service.frm.MsgRequestExecutorHelper;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.model.DownloadItem;
import sina.mobile.tianqitong.service.model.SinaSoftWareListItemInfo;
import sina.mobile.tianqitong.service.model.SinaWebSiteListItemInfo;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.ListActivity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class SinaWebSiteActivity extends ListActivity {

	private SinaRecommendManager mSinaRecommendManager;
	private List<SinaWebSiteListItemInfo> mListItemInfo = new ArrayList<SinaWebSiteListItemInfo>();
	private SoftWareListAdapter mAdapter = null;
	private TianQiTongDownloadManger mTianQiTongDownloadManger = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mSinaRecommendManager = SinaRecommendManager.getInstance(null);
		HandlerObserver.registerObserver(mHandler, null);

		mSinaRecommendManager.refreshRecommendList(null);

		mTianQiTongDownloadManger = TianQiTongDownloadManger.getInstance(null);


		mAdapter = new SoftWareListAdapter(this);
		setListAdapter(mAdapter);
		buildData();
		mAdapter.setData(mListItemInfo);

	}

	private Handler mHandler = new Handler() {

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerObserver.NTY2HANDLER_MSG_WHAT_SINA_RECOMMEND_LIST_UPDATED: {
				buildData();
			}
				break;
			case HandlerObserver.NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_PROGRESS_UPDATED: {

				String url = msg.getData().getString(MSG_DATA_KEY_STR_URL);
				int type = mTianQiTongDownloadManger.getDownloadItem(url).getType();

				if (type == DownloadItem.TYPE_SINA_WEBSITE_ICON && msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP) == 100) {
					SinaWebSiteListItemInfo itemInfo = mUrlKeyHashMap.get(url);
					if (itemInfo != null)
						itemInfo.refreshFile(url);
					mAdapter.notifyDataSetChanged();
				}

			}
				break;

			}
		};
	};

	private String mSdDir = null;
	private String mFilePath = null;
	private HashMap<String, SinaWebSiteListItemInfo> mUrlKeyHashMap = new HashMap();

	private void buildData() {
		SinaWebSiteListItemInfo[] recommendInfos = (SinaWebSiteListItemInfo[]) mSinaRecommendManager.getRecommendInfos(SinaSoftWareListItemInfo.TYPE_WEBSITE);
		HashSet iconSet = new HashSet();
		mSdDir = getSDPath();
		mListItemInfo.clear();
		if (recommendInfos != null) {
			for (int i = 0; i < recommendInfos.length; i++) {
				mListItemInfo.add(recommendInfos[i]);

				if (recommendInfos[i].getIconFile() == null && recommendInfos[i].getIconHttpUrl() != null) {
					iconSet.add(recommendInfos[i].getIconHttpUrl());
					mUrlKeyHashMap.put(recommendInfos[i].getIconHttpUrl(), recommendInfos[i]);
				}

			}

		}

		mAdapter.notifyDataSetChanged();
		if (mSdDir != null) {
			mFilePath = mSdDir + "/TianQiTong/SinaRecommend/";
		} else {
			return;
		}

		if (iconSet.size() != 0) {
			String[] urls = new String[iconSet.size()];
			iconSet.toArray(urls);
			int[] types = new int[iconSet.size()];
			String[] filePaths = new String[iconSet.size()];
			for (int i = 0; i < iconSet.size(); i++) {
				types[i] = DownloadItem.TYPE_SINA_WEBSITE_ICON;
				filePaths[i] = mFilePath + getNameFromUrl(urls[i]);
			}

			mTianQiTongDownloadManger.downloadAll(urls, types, filePaths, true);
		}

	}

	private String getNameFromUrl(String str) {
		return str.substring(str.lastIndexOf("/") + 1, str.length());
	}

	private String getSDPath() {
		File sdDir = null;

		if (Utility.sdAvailiable()) {
			sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
		}
		if (sdDir != null) {
			return sdDir.toString();
		} else {
			return null;
		}

	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		SinaWebSiteListItemInfo itemInfo = (SinaWebSiteListItemInfo) getListView().getAdapter().getItem(position);
		String websiteUrl = itemInfo.getWebSiteHttpUrl();
		openUrlAfter(SinaWebSiteActivity.this, websiteUrl, itemInfo.getId());
	}

	private static void openUrlAfter(Context ctx, String url, String id ) {
		/**
		 * 默认使用UC打开URL
		 */
		PackageInfo info;
		String versionName;
		int count = 2;
		try {
			info = ctx.getPackageManager().getPackageInfo("com.uc.browser", PackageManager.GET_ACTIVITIES);
			versionName = info.versionName.trim();

			StringTokenizer token = new StringTokenizer(versionName, ".");
			StringBuilder sb = new StringBuilder();
			while (token.hasMoreTokens() && count > 0) {
				if (count == 1) {
					sb.append(token.nextToken());
				} else {
					sb.append(token.nextToken()).append(".");
				}
				count--;
			}
			sb.append("0");
			double versionCode = Double.parseDouble(sb.toString());

			/**
			 * UC 7.9 版本以后，支持公有接口的调用方式
			 */

			if (versionCode > 7.8) {
				openUrlByUcBrowser(ctx, url, id);
				return;
			} else {
				openUrlByDefaultBrowser(ctx, url, id);
				return;
			}
		} catch (NameNotFoundException e) {
			openUrlByDefaultBrowser(ctx, url, id);
			return;
		} catch (Exception e) {
			openUrlByDefaultBrowser(ctx, url, id);
			return;
		}

	}

	private static void openUrlByUcBrowser(Context ctx, String url, String id) {
		try {
			Intent i = new Intent("com.uc.browser.intent.action.LOADURL");
			i.putExtra("recall_action", "com.test.openintenttouc");
			String enCodeUrl = "http://forecast.sina.cn/app/redirect.php?id=0-2-1-" + id + "&ourl=" + URLEncoder.encode(url , "utf-8");
			i.putExtra("UC_LOADURL", "ext:webkit:" + enCodeUrl);
			i.putExtra("time_stamp", System.currentTimeMillis());
			ctx.startActivity(i);
		} catch (ActivityNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	private static void openUrlByDefaultBrowser(Context ctx, String url, String id) {
		try {
			Intent i = new Intent(Intent.ACTION_VIEW);
			if (url != null && !url.startsWith("http://") && !url.startsWith("https://")) {
				url = "http://" + url;
			}
			url = "http://forecast.sina.cn/app/redirect.php?id=0-2-1-" + id + "&ourl=" + URLEncoder.encode(url , "utf-8");
			Uri uri = Uri.parse(url);
			i.setData(uri);
			ctx.startActivity(i);
		} catch (ActivityNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	private class SoftWareListAdapter extends BaseAdapter {

		private LayoutInflater mInflater;
		List<SinaWebSiteListItemInfo> mListData = new ArrayList<SinaWebSiteListItemInfo>();

		public void setData(List<SinaWebSiteListItemInfo> listData) {
			mListData = listData;
		}

		public SoftWareListAdapter(Context context) {
			mInflater = LayoutInflater.from(context);
		}

		@Override
		public int getCount() {
			return mListData.size();
		}

		@Override
		public Object getItem(int arg0) {
			return mListData.get(arg0);
		}

		@Override
		public long getItemId(int arg0) {
			return arg0;
		}

		@Override
		public View getView(int arg0, View arg1, ViewGroup arg2) {
			ViewHolder holder = null;
			if (arg1 == null) {
				holder = new ViewHolder();
				arg1 = mInflater.inflate(R.layout.website_list_item, null);
				holder.init(arg1);
				arg1.setTag(holder);

			} else {
				holder = (ViewHolder) arg1.getTag();
			}
			holder.update(arg0);

			return arg1;
		}

		private class ViewHolder {
			public ImageView mIcon;
			public TextView mName;
			public TextView mBrief;

			private void init(View arg1) {
				mIcon = (ImageView) arg1.findViewById(R.id.icon);
				mName = (TextView) arg1.findViewById(R.id.name);
				mBrief = (TextView) arg1.findViewById(R.id.brief);
			}

			private void update(int position) {
				SinaWebSiteListItemInfo itemInfo = mListData.get(position);
				mName.setText(itemInfo.getName());
				mBrief.setText(itemInfo.getBrief());
				itemInfo.setIcon(mIcon);
			}

		}

	}

}