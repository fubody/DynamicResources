package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE;

import java.lang.ref.WeakReference;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.MsgResponseHandler;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SendSuggestion extends Activity implements ServiceConnection, MsgResponseHandler {

	private TianQiTongService _service;
	private EditText _etSuggestion;
	private EditText _etContact;
	private CheckBox _cbSaveContact;

	private String _config_file, _configure;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.send_suggestion);

		bindService(new Intent(this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

		_etSuggestion = (EditText) findViewById(R.id.suggestion);

		_etContact = (EditText) findViewById(R.id.contact);

		_cbSaveContact = (CheckBox) findViewById(R.id.save_contact);

		String contact = SPUtility.getSPString(this, R.string.str_contact);
		if (contact.length() != 0) {
			_etContact.setText(contact);
			_cbSaveContact.setChecked(true);
		} else {
			_cbSaveContact.setChecked(false);
		}

		_config_file = SPUtility.getConfigure(this);

		String ver = getString(R.string.ver);
		String device = android.os.Build.MODEL + "/" + android.os.Build.VERSION.RELEASE;

		_configure = ver + "/" + device;

		findViewById(R.id.send).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (_service != null) {
					String suggestion = _etSuggestion.getText().toString();
					String contact = _etContact.getText().toString();

					if (_cbSaveContact.isChecked()) {
						SPUtility.putSPString(SendSuggestion.this, R.string.str_contact, contact);
					} else {
						SPUtility.putSPString(SendSuggestion.this, R.string.str_contact, "");
					}

					if (suggestion.length() == 0) {
						Toast.makeText(SendSuggestion.this, "请输入文字", Toast.LENGTH_SHORT).show();
					} else {
						// 提交前加入判断
						if (Utility.isAirplaneModeOn(getApplicationContext())) {
							Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, SendSuggestion.this);
							dg.show();
							return;
						}

						if (!Utility.getAvailableNetWork(getApplicationContext())) {
							Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, SendSuggestion.this);
							dg.show();
							return;
						}
						// 结束
						showDialog(DIALOG_ID_PLEASE_WAIT);
						_service.sendSuggestion2TQT(new WeakReference<MsgResponseHandler>(SendSuggestion.this), suggestion, _configure, _config_file, contact, TianQiTongService.SEND_FROM_SUGGESTION);

					}

				}
			}
		});
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		unbindService(this);
	}

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		_service = ((TianQiTongService.TianQiTongBinder) service).getService();
//
// String ver = getString(R.string.ver);
// String citys = Arrays.toString(_service.getCityNames());
// String device = android.os.Build.MODEL + "/" + android.os.Build.VERSION.RELEASE;
//
// String tmp = ver + "/" + device + "/" + citys;
// _etSuggestion.setText(tmp);
// _etSuggestion.setSelection(tmp.length());

		String[] citynames = _service.getCityNames();
		StringBuilder citynamesb = new StringBuilder();
		citynamesb.append("/[");
		for (String cn : citynames) {
			citynamesb.append(cn);
			citynamesb.append(",");
		}
		citynamesb.append("]");
		_configure = _configure + citynamesb.toString();
		// #ifdef DEBUG
// @ _etSuggestion.setFilters(new android.text.InputFilter[] {});
// @ _etSuggestion.setText(_configure + "\n" + SPUtility.getSPStringsContentOfUserAction(this));
// #endif
	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		_service = null;

	}

	private static final int DIALOG_ID_NETWORK_DOWN = 0;
	private static final int DIALOG_ID_PLEASE_WAIT = 1;
	private static final int DIALOG_ID_SENT = 2;

	public Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_NETWORK_DOWN: {
			AlertDialog.Builder b = new Builder(this);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setTitle("天气通提示");
			b.setMessage("抱歉！连接网络失败，请您查看您的网络设置，WLAN用户请检查您是否获得访问权限。").setCancelable(true).setPositiveButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
// break;
		case DIALOG_ID_PLEASE_WAIT: {
			ProgressDialog dialog = new ProgressDialog(this);
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			dialog.setCancelable(false);
			dialog.setMessage("正在发送，请稍等......");
			return dialog;
		}
// break;
		case DIALOG_ID_SENT: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setCancelable(true);
			b.setMessage("发送成功");
			b.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			});
			return b.create();
		}
// break;
		default: {
			return null;
		}
		}
	}

	@Override
	public void handle(Message msg) {
		switch (msg.arg2) {
		case MsgUtility.MSG_ARG2_SEND_SUGGESION_2_TQT:
		case MsgUtility.MSG_ARG2_SEND_SUGGESION_2_WEIBO: {

			Bundle datas = msg.getData();
			int responseCode = datas.getInt(MSG_DATA_KEY_INT_RESPONSE_CODE);

			switch (responseCode) {
			case MsgUtility.RESPONSE_CODE_SUCCESSFUL: {
				removeDialog(DIALOG_ID_PLEASE_WAIT);
				showDialog(DIALOG_ID_SENT);
			}
				break;
			case MsgUtility.RESPONSE_CODE_NETWORK_DOWN:
			case MsgUtility.RESPONSE_CODE_SERVER_DOWN:
			case MsgUtility.RESPONSE_CODE_BAD_XML: {
				removeDialog(DIALOG_ID_PLEASE_WAIT);
				showDialog(DIALOG_ID_NETWORK_DOWN);
			}
			break;
//			case MsgUtility.RESPONSE_CODE_NETWORK_DOWN: {
//				removeDialog(DIALOG_ID_PLEASE_WAIT);
//				showDialog(DIALOG_ID_NETWORK_DOWN);
//			}
//				break;
			default: {
				Toast.makeText(_service, "发送失败", Toast.LENGTH_SHORT).show();
			}
			}

		}
		}

	}

}
