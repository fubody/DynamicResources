package sina.mobile.tianqitong.service.model;

import sina.mobile.tianqitong.main.SinaSoftWareActivity.SoftwareViewHolder;

public class SinaRecommendModel {
	public SinaSoftWareListItemInfo mItemInfo = null;
	public SoftwareViewHolder mHodler = null;

	public SinaRecommendModel(SinaSoftWareListItemInfo iteminfo, SoftwareViewHolder hodler) {
		mItemInfo = iteminfo;
		mHodler = hodler;
	}
}