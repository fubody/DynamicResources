package sina.mobile.tianqitong.appwidgetskinpkg;

import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.BOTTOM;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.HCENTER;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.H_MASK;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.LEFT;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.RIGHT;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.TOP;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.VCENTER;
import static sina.mobile.tianqitong.appwidgetskinpkg.AbstractSkinLayoutUnit.V_MASK;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_PLAY_OR_STOP_PLAY_TTS;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_SWITCH_WIDGET_CITY;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL;
import static sina.mobile.tianqitong.service.IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS;
import static sina.mobile.tianqitong.service.IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS_PLAYORSTOPTTS_FROM_APPWIDGET;
import static sina.mobile.tianqitong.service.IntentActionConstants.EXTRA_KEY_START_SERVICE_OTHER_PARAMS_UPDATEWEATHERS_SHOW_TOAST;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import sina.mobile.tianqitong.contentprovider.TqtContentProvider;
import sina.mobile.tianqitong.diyappwidget.PendingIntentUtil;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.TianQiTongTTS;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.Utility;
import sina.mobile.tianqitong.setting.TTSSetting;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.RemoteViews;

final public class AppWidgetSkin {

	public static final int TYPE_4X2 = 0;
	public static final int TYPE_4X1 = 1;
	int mType;

	public static final String CACHE_4X2BMP_PREFIX = "appwidgetskin_";
	public static final String CACHE_4X1BMP_PREFIX = "appwidgetskin4x1_";

	File mCacheDir;
	AbstractSkinLayoutUnit[] mLayoutUntis = null;
	boolean mIsPortrait = true;
	Uri mAppWidgetBmpUri = null;

	private boolean mHasClock = false;

	public boolean hasClock() {
		return mHasClock;
	}

	private AppWidgetSkin(Boolean isPortrait, int type) {
		mIsPortrait = isPortrait;
		mType = type;
		if (type == TYPE_4X2) {
			mCacheDir = AppWidgetSkinUtility.get4x2AppWidgetSkinCacheDir();
		} else if (type == TYPE_4X1) {
			mCacheDir = AppWidgetSkinUtility.get4x1AppWidgetSkinCacheDir();
		}
	}

	static final AppWidgetSkin[] getAppWidgetSkins(int type) {
		return new AppWidgetSkin[] { new AppWidgetSkin(true, type), new AppWidgetSkin(false, type) };
	}

	// TODO

	void setBtnOnRemoteViews(Context context, RemoteViews views) {

		AbstractSkinLayoutUnit[] alsus = mLayoutUntis;
		if (alsus == null) {
			return;
		}
		int[] pos = null;
		if (mIsPortrait) {
			pos = TianQiTongAppWidgetSkinManager.gPort4x1And4x2BtnPos;
		} else {
			pos = TianQiTongAppWidgetSkinManager.gLand4x1And4x2BtnPos;
		}

		for (AbstractSkinLayoutUnit aslu : alsus) {
			if (aslu instanceof Button) {

				Button btn = (Button) aslu;
				String functionId = btn.getFuncitonId();
				if (functionId != null) {

					PendingIntent pi = null;

					if (functionId.equals("app")) {
						String pkgName = btn.getPkgName();
						String activityName = btn.getActivityName();
						String intoClock = btn.getIntoClock();
						if("intoClock".equals(intoClock)){
							String[] name = PendingIntentUtil.getClockName(context);
							if(!name[0].equals("") && !name[1].equals("")){
								pkgName = name[0];
								activityName = name[1];
							}
						}
						
						Intent intent = new Intent();
						intent.setClassName(pkgName, activityName);
						intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.putExtra(IntentActionConstants.INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET, true);
						pi = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

					} else if (functionId.equals("play_tts")) {
						Intent i0 = new Intent(ACTION_START_SERVICE_PLAY_OR_STOP_PLAY_TTS);
						i0.putExtra(EXTRA_KEY_START_SERVICE_OTHER_PARAMS, EXTRA_KEY_START_SERVICE_OTHER_PARAMS_PLAYORSTOPTTS_FROM_APPWIDGET);

						pi = PendingIntent.getService(context, -1, i0, PendingIntent.FLAG_UPDATE_CURRENT);
					} else if (functionId.equals("set_tts")) {
						Intent i1 = new Intent(context, TTSSetting.class);
						if (i1.getExtras() != null) {
							i1.getExtras().clear();
						}
						i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						pi = PendingIntent.getActivity(context, 0, i1, PendingIntent.FLAG_UPDATE_CURRENT);
					} else if (functionId.equals("update")) {
						Intent i2 = new Intent(ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL);
						i2.putExtra(EXTRA_KEY_START_SERVICE_OTHER_PARAMS, EXTRA_KEY_START_SERVICE_OTHER_PARAMS_UPDATEWEATHERS_SHOW_TOAST);
						pi = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
					} else if (functionId.equals("change_city")) {
						Intent i2 = new Intent(ACTION_START_SERVICE_SWITCH_WIDGET_CITY);
						pi = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
					}

					if (pi != null) {
						int idx = btn.getIdx();
						views.setViewVisibility(pos[idx], View.VISIBLE);
						views.setOnClickPendingIntent(pos[idx], pi);

						String strSrc = null;
						if (functionId.equals("play_tts") && TianQiTongTTS.getInstance(null).isPlaying()) {
							strSrc = btn.getStopPlayingSrc();
						}
						if (strSrc == null || strSrc.length() == 0) {
							strSrc = btn.getSrc();
						}

						Bitmap src = null;
						if (strSrc != null) {
							try {
								src = getAppWidgetImageUnit(strSrc);
							} catch (FileNotFoundException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}

						// 这段代码打开后，会在有功能的区域点一个红点。
// {
// Bitmap emptybmp = null;
// if (src == null) {
// emptybmp = Bitmap.createBitmap(5, 5, Config.RGB_565);
// Canvas c = new Canvas(emptybmp);
// c.drawColor(Color.RED);
// } else {
// emptybmp = Bitmap.createBitmap(src.getWidth(), src.getHeight(), src.getConfig());
// Canvas c = new Canvas(emptybmp);
// c.drawBitmap(src, 0, 0, null);
// int tx = src.getWidth() / 2;
// int ty = src.getHeight() / 2;
// Paint paint = new Paint();
// paint.setColor(Color.RED);
// c.drawRect(tx - 2, ty - 2, tx + 2, ty + 2, paint);
// }
// src = emptybmp;
// }

						if (src != null) {
							views.setImageViewBitmap(pos[idx], src);
						}

					}
				}

			}
		}

		return;
	}

	void parseLayoutXml() throws XmlPullParserException, IOException {

		ArrayList<AbstractSkinLayoutUnit> out = new ArrayList<AbstractSkinLayoutUnit>();

		File layoutFile = null;
		{
			File cacheDir = mCacheDir;
			File portLayout = new File(cacheDir, "layout-port.xml");
			File landLayout = new File(cacheDir, "layout-land.xml");
			layoutFile = mIsPortrait ? portLayout : landLayout;
			if ((!layoutFile.exists())) {
				out.clear();
				return;
			}
		}

		BufferedInputStream bis = null;
		try {
			bis = new BufferedInputStream(new FileInputStream(layoutFile));
			XmlPullParserFactory factory;
			XmlPullParser xpp;

			factory = XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			xpp = factory.newPullParser();
			xpp.setInput(bis, null);
			int eventType = xpp.getEventType();

			while (eventType != XmlPullParser.END_DOCUMENT) {

				switch (eventType) {
				case XmlPullParser.START_TAG: {

					AbstractSkinLayoutUnit aslu = null;

					if (xpp.getName().equals("LayoutUnit")) {
						aslu = new LayoutUnit(this);
					} else if (xpp.getName().equals("Image")) {
						aslu = new Image(this);
					} else if (xpp.getName().equals("Text")) {
						aslu = new Text(this);
					} else if (xpp.getName().equals("TextArea")) {
						aslu = new TextArea(this);
					} else if (xpp.getName().equals("Button")) {
						aslu = new Button(this);
					} else if (xpp.getName().equals("Layout")) {
						eventType = xpp.next();
						continue;
					}
					if (aslu == null) {
						continue;
					}

					for (int i = 0; i < xpp.getAttributeCount(); i++) {
						String attrName = xpp.getAttributeName(i);
						String attrValue = xpp.getAttributeValue(i);
						if (!aslu.setValue(attrName, attrValue)) {
							continue;
						}
					}

					if (aslu.isClockUnit()) {
						mHasClock = true;
					}

					out.add(aslu);

				}
				}

				eventType = xpp.next();

			}

			mLayoutUntis = new AbstractSkinLayoutUnit[out.size()];
			out.toArray(mLayoutUntis);

			return;
		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (Exception e) {

				}
			}
		}

	}

	private void layout(WeatherInfo wi, Context context) {

		if (mLayoutUntis == null) {
			return;
		}

		float density = AppWidgetSkinUtility.mDensity;

		// 用来保存排版过程中的layoutId以及对应的排版单元。
		HashMap<String, AbstractSkinLayoutUnit> layoutId2UnitMap = new HashMap<String, AbstractSkinLayoutUnit>();

		// 当没有相对id的时候，使用这个作为相对对象。
		Rect bgRect = null;
		if (mType == TYPE_4X2) {
			if (mIsPortrait) {
				bgRect = new Rect(0, 0, (int) (320d * density), (int) (240d * density));
			} else {
				bgRect = new Rect(0, 0, (int) (480d * density), (int) (160d * density));
			}
		} else if (mType == TYPE_4X1) {
			if (mIsPortrait) {
				bgRect = new Rect(0, 0, (int) (320d * density), (int) (120d * density));
			} else {
				bgRect = new Rect(0, 0, (int) (480d * density), (int) (80d * density));
			}
		}

		// 按照顺序，对每个单元重算尺寸，然后计算位置。
		for (AbstractSkinLayoutUnit skinLayoutUnit : mLayoutUntis) {

			skinLayoutUnit.setWeatherInfo(wi);

			if (!skinLayoutUnit.measureDrawRectWAndH()) {
				continue;
			}
			// 此时mDrawRect中真正的宽高已经有了。top和left是0。

			if (skinLayoutUnit.LayoutId != null && skinLayoutUnit.LayoutId.length() != 0) {
				// 如果layoutId不为空，说明可能会被后面的单元引用。
				layoutId2UnitMap.put(skinLayoutUnit.LayoutId, skinLayoutUnit);
			}

			// 待排版单元的宽高。
			final int width = skinLayoutUnit.mDrawRect.right;
			final int height = skinLayoutUnit.mDrawRect.bottom;

			// 待排版单元上的基准点与之对齐的位置。
			int tx = 0;
			int ty = 0;

			// 计算出横向对齐基准线。
			{
				if (skinLayoutUnit.x != Integer.MIN_VALUE) {
					tx = skinLayoutUnit.x;
				} else {
					// 需要从这个rect里找需要对齐的位置。
					Rect relativeRect = null;
					if (skinLayoutUnit.DatumHLineLayoutId == null) {
						relativeRect = bgRect;
					} else {
						AbstractSkinLayoutUnit aslu = layoutId2UnitMap.get(skinLayoutUnit.DatumHLineLayoutId);
						if (aslu == null) {
							relativeRect = bgRect;
						} else {
							relativeRect = aslu.mDrawRect;
						}
					}
					if (relativeRect == null) {
						throw new IllegalStateException();
					}

					// 找需要对齐的位置。
					switch (skinLayoutUnit.DatumHLine) {
					case 0:
					case LEFT: {
						tx = relativeRect.left;
					}
						break;
					case HCENTER: {
						tx = relativeRect.left + (relativeRect.right - relativeRect.left) / 2;
					}
						break;
					case RIGHT: {
						tx = relativeRect.right;
					}
						break;
					default: {
						throw new IllegalStateException();
					}
					}
				}
			}

			// 计算出纵向对齐基准线
			{
				if (skinLayoutUnit.y != Integer.MIN_VALUE) {
					ty = skinLayoutUnit.y;
				} else {
					// 需要从这个rect里找需要对齐的位置。
					Rect relativeRect = null;
					if (skinLayoutUnit.DatumVLineLayoutId == null) {
						relativeRect = bgRect;
					} else {
						AbstractSkinLayoutUnit aslu = layoutId2UnitMap.get(skinLayoutUnit.DatumVLineLayoutId);
						if (aslu == null) {
							relativeRect = bgRect;
						} else {
							relativeRect = aslu.mDrawRect;
						}
					}
					if (relativeRect == null) {
						throw new IllegalStateException();
					}

					// 找需要对齐的位置。
					switch (skinLayoutUnit.DatumVLine) {
					case 0:
					case TOP: {
						ty = relativeRect.top;
					}
						break;
					case VCENTER: {
						ty = relativeRect.top + (relativeRect.bottom - relativeRect.top) / 2;
					}
						break;
					case BOTTOM: {
						ty = relativeRect.bottom;
					}
						break;
					default: {
						throw new IllegalStateException();
					}
					}
				}
			}

			// 此时需要对齐的位置已经找到了，下面要把待排版单元的基准点跟这个位置对齐。

			// 待排版单元mDrawRect的top和left。
			int ttx, tty;

			// 下面需要按照DatumPoint，对齐(tx,ty)
			{
				int t = skinLayoutUnit.DatumPoint & H_MASK;

				switch (t) {
				case 0:
				case LEFT: {
					ttx = tx;
				}
					break;
				case HCENTER: {
					ttx = tx - width / 2;
				}
					break;
				case RIGHT: {
					ttx = tx - width;
				}
					break;
				default: {
					throw new IllegalStateException();
				}
				}
			}
			{
				int t = skinLayoutUnit.DatumPoint & V_MASK;

				switch (t) {
				case 0:
				case TOP: {
					tty = ty;
				}
					break;
				case VCENTER: {
					tty = ty - height / 2;
				}
					break;
				case BOTTOM: {
					tty = ty - height;
				}
					break;
				default: {
					throw new IllegalStateException();
				}
				}
			}
			skinLayoutUnit.mDrawRect.offset(ttx, tty);

			// 此时待排版单元的基准点已经对正了。

			{
				int dx = 0;
				int dy = 0;
				if (skinLayoutUnit.OffsetX != Integer.MIN_VALUE) {
					dx = skinLayoutUnit.OffsetX;
				}
				if (skinLayoutUnit.OffsetY != Integer.MIN_VALUE) {
					dy = skinLayoutUnit.OffsetY;
				}
				skinLayoutUnit.mDrawRect.offset(dx, dy);
			}
			// 此时mDrawRect已经应用了偏移值，现在mDrawRect处于正确位置了。

		}

	}

	void draw(WeatherInfo wi, Context context) throws FileNotFoundException {

		if (mLayoutUntis == null) {
			return;
		}
		layout(wi, context);

		mAppWidgetBmpUri = null;

		if (mLayoutUntis != null) {

			long curtimemillis = System.currentTimeMillis();

			String prefix = "";
			if (mType == TYPE_4X2) {
				prefix = CACHE_4X2BMP_PREFIX;
			} else if (mType == TYPE_4X1) {
				prefix = CACHE_4X1BMP_PREFIX;
			}

			String fn = prefix + (mIsPortrait ? "port" : "land") + "_" + curtimemillis + ".png";

			FileOutputStream fos;

			fos = context.openFileOutput(fn, Context.MODE_WORLD_READABLE);

// {
// File f=new File(Utility.getTianQiTongDir("temp"),fn);
// fos=new FileOutputStream(f);
// }

			BufferedOutputStream bos = null;
			try {
				bos = new BufferedOutputStream(fos);
				Bitmap bmp = null;

				float density = AppWidgetSkinUtility.mDensity;
				if (mType == TYPE_4X2) {
					if (mIsPortrait) {
						bmp = Bitmap.createBitmap((int) (320d * density), (int) (240d * density), Config.ARGB_8888);
					} else {
						bmp = Bitmap.createBitmap((int) (480d * density), (int) (160d * density), Config.ARGB_8888);
					}
				} else if (mType == TYPE_4X1) {
					if (mIsPortrait) {
						bmp = Bitmap.createBitmap((int) (320d * density), (int) (120d * density), Config.ARGB_8888);
					} else {
						bmp = Bitmap.createBitmap((int) (480d * density), (int) (80d * density), Config.ARGB_8888);
					}
				}

				Canvas c = new Canvas(bmp);

				for (AbstractSkinLayoutUnit aslu : mLayoutUntis) {
					if (aslu.mDrawRect == null) {
						continue;
					}
					aslu.draw(c);
				}

				bmp.compress(CompressFormat.PNG, 100, bos);

			} finally {
				if (bos != null) {
					try {
						bos.close();
					} catch (Exception e) {

					}
				}

			}

			mAppWidgetBmpUri = TqtContentProvider.getImageFileUri(prefix + (mIsPortrait ? "port" : "land") + "_" + curtimemillis + ".png");
		}

	}

	/**
	 * 在有缓存文件的前提下，检查需要的文件，在特定的横纵条件下，是否存在。
	 * 
	 * @param zipSkin
	 * @param filename
	 * @param isPortrait
	 * @return
	 * @throws FileNotFoundException
	 *             ,IOException
	 */
	boolean checkImage(String filename) throws FileNotFoundException, IOException {
		File cacheDir = mCacheDir;
		File tqtbmp = null;
		{
			// 选择缓存图片目录。
			File drawableDir = null;
			if (mIsPortrait) {
				drawableDir = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_PORT_DRAWABLE_DIRNAME);
			} else {
				drawableDir = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_LAND_DRAWABLE_DIRNAME);
			}
			if (!drawableDir.exists()) {
				drawableDir.mkdirs();
			}

			String tqtbmpfn = filename.substring(0, filename.length() - ".png".length()) + ".png";
			tqtbmp = new File(drawableDir, tqtbmpfn);
		}

		if (tqtbmp.isFile() && tqtbmp.exists()) {
			return true;
		} else {
			// 删掉存在的同名目录
			if (tqtbmp.exists()) {
				tqtbmp.delete();
			}

			// 按照横纵屏找到已经生成的ZipEntryName的缓存文件
			File cacheFile = null;
			if (mIsPortrait) {
				cacheFile = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_PORT_DRAWABLE_CACHE_FILENAME);
			} else {
				cacheFile = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_LAND_DRAWABLE_CACHE_FILENAME);
			}
			if (cacheFile.isDirectory() || (!cacheFile.exists())) {
				// 没有缓存文件。
				return false;
			}

			// 遍历文件，找到需要的ZipEntryName
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(cacheFile));
				String zipEntryName = br.readLine();
				while (zipEntryName != null) {
					String[] tmp = Utility.split(zipEntryName, '/');
					if (tmp[1].equals(filename)) {
						br.close();
						return true;
					}
					zipEntryName = br.readLine();
				}

			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (Exception e) {

					}
				}
			}

			return false;
		}
	}

	/**
	 * 在有缓存文件的前提下，在特定的横纵条件下，取需要的文件。
	 * 
	 * @param zipSkin
	 * @param filename
	 * @param isPortrait
	 * @param density
	 * @param justWH
	 * @return
	 * @throws IOException
	 */
	Bitmap getAppWidgetImageUnit(String filename) throws FileNotFoundException, IOException {
		return (Bitmap) getAppWidgetImageUnitMaybeWH(filename, false);
	}

	int[] getAppWidgetImageUnitWH(String filename) throws FileNotFoundException, IOException {
		return (int[]) getAppWidgetImageUnitMaybeWH(filename, true);
	}

	private Object getAppWidgetImageUnitMaybeWH(String filename, boolean justWH) throws FileNotFoundException, IOException {

		File cacheDir = mCacheDir;

		// 建立对缓存图片的引用，这个文件可能不存在。
		File tqtbmp = null;
		{
			// 选择缓存图片目录。
			File drawableDir = null;
			if (mIsPortrait) {
				drawableDir = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_PORT_DRAWABLE_DIRNAME);
			} else {
				drawableDir = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_LAND_DRAWABLE_DIRNAME);
			}
			if (!drawableDir.exists()) {
				drawableDir.mkdirs();
			}

			String tqtbmpfn = filename.substring(0, filename.length() - ".png".length()) + ".png";
			tqtbmp = new File(drawableDir, tqtbmpfn);
		}

		if (tqtbmp.isFile() && tqtbmp.exists()) {

			if (justWH) {
				return TqtBmpUtility.getTqtBmpFileWH(tqtbmp, AppWidgetSkinUtility.mDensityDpi);
			} else {
				return TqtBmpUtility.loadTqtBmpFile(tqtbmp, AppWidgetSkinUtility.mDensityDpi);
			}

		} else {

			// 按照横纵屏找到已经生成的ZipEntryName的缓存文件
			File cacheFile = null;
			if (mIsPortrait) {
				cacheFile = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_PORT_DRAWABLE_CACHE_FILENAME);
			} else {
				cacheFile = new File(cacheDir, AppWidgetSkinUtility.APPWIDGETSKIN_LAND_DRAWABLE_CACHE_FILENAME);
			}
			if (cacheFile.isDirectory() || (!cacheFile.exists())) {
				if (justWH) {
					return new int[] { 0, 0 };
				} else {
					return null;
				}
			}

			// 遍历文件，找到需要的ZipEntryName
			BufferedReader br = null;
			String zipEntryName = null;
			String dir = null;
			try {
				br = new BufferedReader(new FileReader(cacheFile));
				zipEntryName = br.readLine();

				while (zipEntryName != null) {
					String[] tmp = Utility.split(zipEntryName, '/');
					if (tmp[1].equals(filename)) {
						dir = tmp[0];
						break;
					}
					zipEntryName = br.readLine();
				}

			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

			}

			if (zipEntryName == null) {
				if (justWH) {
					return new int[] { 0, 0 };
				} else {
					return null;
				}
			}

			// 解压找到的文件，decode，然后保存成tqtbmp，最后返回创建好的bmp。

			InputStream pngis = null;
			Bitmap bmp = null;

			try {
				File mZipSkinFile = null;
				if (mType == TYPE_4X2) {
					mZipSkinFile = TianQiTongAppWidgetSkinManager.m4x2ZipSkinFile;
				} else if (mType == TYPE_4X1) {
					mZipSkinFile = TianQiTongAppWidgetSkinManager.m4x1ZipSkinFile;
				} else {
					throw new IllegalStateException();
				}
				ZipFile zf = new ZipFile(mZipSkinFile);
				ZipEntry ze = zf.getEntry(zipEntryName);
				pngis = new BufferedInputStream(zf.getInputStream(ze));

				bmp = null;

				bmp = BitmapFactory.decodeStream(pngis);

			} finally {
				if (pngis != null) {
					try {
						pngis.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

			}

			int dstWidth = -1;
			int dstHeight = -1;

			dstHeight = bmp.getHeight();
			dstWidth = bmp.getWidth();

			float s;
			if (dir.contains("hdpi")) {
				s = ((float) AppWidgetSkinUtility.mDensityDpi) / ((float) DisplayMetrics.DENSITY_HIGH);
			} else if (dir.contains("mdpi")) {
				s = ((float) AppWidgetSkinUtility.mDensityDpi) / ((float) DisplayMetrics.DENSITY_MEDIUM);
			} else if (dir.contains("ldpi")) {
				s = ((float) AppWidgetSkinUtility.mDensityDpi) / ((float) DisplayMetrics.DENSITY_LOW);
			} else {
				s = ((float) AppWidgetSkinUtility.mDensityDpi) / ((float) DisplayMetrics.DENSITY_DEFAULT);
			}

			dstWidth = (int) (((float) dstWidth) * s);
			dstHeight = (int) (((float) dstHeight) * s);

			if (justWH) {
				return new int[] { dstWidth, dstHeight };
			} else {
				bmp = Bitmap.createScaledBitmap(bmp, dstWidth, dstHeight, false);
				// 删掉存在的同名目录
				if (tqtbmp.exists()) {
					tqtbmp.delete();
				}
				// 建立文件
				try {
					tqtbmp.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
					return null;
				}
				TqtBmpUtility.storeAsTqtBmpFile(tqtbmp, bmp);

				return bmp;
			}

		}

	}

}
