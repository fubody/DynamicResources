package sina.mobile.tianqitong.main;

import java.util.Calendar;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.PastWeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class WeatherGraphView extends RelativeLayout implements WeatherViewInterface {

	private TextView mTvcurrentPageTitle = null;
	private Context context;

	public WeatherGraphView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
		this.context = context;
	}

	public WeatherGraphView(Context context) {
		super(context);
		init(context);
		this.context = context;
	}

	private void init(final Context context) {
		RelativeLayout.LayoutParams lllp = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);

		setLayoutParams(lllp);
		// lllp.gravity = Gravity.CENTER_HORIZONTAL;

		DisplayMetrics dm = getResources().getDisplayMetrics();
		int height = dm.heightPixels;
		int width = dm.widthPixels;
		float proportion = (float) height / (float) width;
		if (proportion < 1.4) {
			if (480 == width && 640 == height) {// 适配480X640分辨率 added by Maojianwei
				LayoutInflater.from(context).inflate(R.layout.weather_graph_small_480x640, this, true);
			} else {
				LayoutInflater.from(context).inflate(R.layout.weather_graph_small, this, true);
			}
		} else {
			if (240 == width && 400 == height) {
				LayoutInflater.from(context).inflate(R.layout.weather_graph_small, this, true);
			} else {
				LayoutInflater.from(context).inflate(R.layout.weather_graph, this, true);
			}
		}

		View date = findViewById(R.id.date);

		mTvcurrentPageTitle = (TextView) findViewById(R.id.currentpage_title_1);
		/*
		 * _tvCurrentCityName.setOnClickListener(new OnClickListener(){
		 * 
		 * @Override public void onClick(View v) { SPUtility.userActionCounterIncreaseOne(context, R.string.int_times_of_clicking_cityname_at_mainactivity); context.startActivity(new Intent(context,
		 * CityManager.class)); }
		 * 
		 * });
		 */
		// date.setBackgroundResource(R.drawable.weather_graph_datebg);

// _tvCurrentCityName = (TextView) findViewById(R.id.current_city_name);
	}

	@Override
	public void updateUI(TianQiTongService service, String cityName, WeatherInfo wi, boolean noAnim, int skin) {

		changeSkin(skin);

		WeatherGraph wg = (WeatherGraph) findViewById(R.id.weather_graph);
		wg.updateUI(cityName, wi, service.getCurrentCityPastWeatherInfo(), noAnim);

		boolean isUseHistoryWeather = !SPUtility.getSPBoolean(context, R.string.boolean_use_history_weather_check);
		ForeCast[] fcs = null;
		if (isUseHistoryWeather) {
			fcs = PastWeatherInfo.getYeasterdayAndForecast(wi, service.getCurrentCityPastWeatherInfo());
		} else {
			fcs = wi.getForecasts();
		}

		// 更新日期
		{
			Calendar c = Calendar.getInstance();
			c.setTimeInMillis(System.currentTimeMillis());

			int[] ids = new int[] { R.id.day_0, R.id.day_1, R.id.day_2, R.id.day_3, R.id.day_4 };
			if (fcs.length == 0) {
				View date = findViewById(R.id.date);
				for (int i = 0; i < ids.length; i++) {
					TextView day = (TextView) date.findViewById(ids[i]);
					day.setText("");
				}
				date = findViewById(R.id.days_of_week);
				for (int i = 0; i < ids.length; i++) {
					TextView day = (TextView) date.findViewById(ids[i]);
					day.setText("");
				}
			} else {
				View date = findViewById(R.id.date);
				for (int i = 0; i < ids.length; i++) {
					TextView day = (TextView) date.findViewById(ids[i]);
					day.setText(fcs[i].getDateMonthNum() + "." + fcs[i].getDateDayNum());
				}

				String[] daysOfWeek = getResources().getStringArray(R.array.days_of_week_simple);
				date = findViewById(R.id.days_of_week);

				Calendar today = Calendar.getInstance();
				today.setTimeInMillis(System.currentTimeMillis());

				int[] realForecastIdxes = getRealForcastIdxs(fcs, System.currentTimeMillis());

				int todayIdx = -1;
				if (realForecastIdxes.length != 0) {
					todayIdx = realForecastIdxes[0];
				}

				for (int i = 0; i < ids.length; i++) {
					TextView day = (TextView) date.findViewById(ids[i]);
					c.set(fcs[i].getDateYearNum(), fcs[i].getDateMonthNum() - 1, fcs[i].getDateDayNum());
					String dayOfWeek = daysOfWeek[c.get(Calendar.DAY_OF_WEEK) - 1];

					if (i == todayIdx) {
						day.setText("今天");
					} else if (i == todayIdx - 1) {
						day.setText("昨天");
					} else {
						day.setText(dayOfWeek);
					}

				}
			}

		}

		{
			String[] t = Utility.split(cityName, '.');
			cityName = t[t.length - 1];
			mTvcurrentPageTitle.setText(cityName + " · 温度曲线");
			/*
			 * String cityCode = SPUtility.getSPString(service, R.string.str_current_city_code); if (cityCode.startsWith(Constants.AUTO_LOCATE_CITYCODE_PREFIX)) { ((ImageView)
			 * findViewById(R.id.gps_icon)).setVisibility(View.VISIBLE); } else { ((ImageView) findViewById(R.id.gps_icon)).setVisibility(View.GONE); }
			 */
		}

		// 更新天气图标
		{
			View windsView = findViewById(R.id.winds_of_week);
			int[] ids = { R.id.wind_0, R.id.wind_1, R.id.wind_2, R.id.wind_3, R.id.wind_4 };

			for (int i = 0; i < ids.length; i++) {
				ForeCast foreC = fcs[i];
				WindIcon windText = (WindIcon) windsView.findViewById(ids[i]);

				String[] windArray = foreC.getWind().split("转");
				String[] windInfo = windArray[0].split("风");
				String windDirection = windInfo[0];

				String highWindLevet = "2";
				if (windInfo.length == 2) {
					String[] windLevelText = windInfo[1].split("-");
					String highWindText = windLevelText[1];
					highWindLevet = highWindText.substring(0, highWindText.length() - 1);
				}

				windText.setDegreeAndWindText(getWindDegreeByText(windDirection), highWindLevet);
			}
		}

// {
// // String cityName = null;
// String[] t = Utility.split(cityName, '.');
// cityName = t[t.length - 1];
// _tvCurrentCityName.setText(cityName);
// }

	}

	/**
	 * 通过风力的方向来返回 图标旋转的度数 add by 骆灿
	 * 
	 * @param windDirection
	 *            风的方向 ，微风就是微 ，东南，西北，诸如此类。
	 * @return
	 */
	private static int getWindDegreeByText(String windDirection) {
		if (windDirection.equals("北")) {
			return -180;
		} else if (windDirection.equals("南")) {
			return 0;
		} else if (windDirection.equals("东")) {
			return -90;
		} else if (windDirection.equals("西")) {
			return 90;
		} else if (windDirection.equals("西北")) {
			return 135;
		} else if (windDirection.equals("东北")) {
			return -135;
		} else if (windDirection.equals("西南")) {
			return 45;
		} else if (windDirection.equals("东南")) {
			return -45;
		} else { // 微风
			return 0;
		}
	}

	private int[] getRealForcastIdxs(ForeCast[] fcs, long milliseconds) {
		int todayIdx = -1;
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(milliseconds);

		for (int i = 0; i < fcs.length; i++) {
			if (fcs[i].getDateYearNum() == c.get(Calendar.YEAR) && fcs[i].getDateDayNum() == c.get(Calendar.DAY_OF_MONTH) && fcs[i].getDateMonthNum() == c.get(Calendar.MONTH) + 1) {
				todayIdx = i;
				break;
			}
		}
		if (todayIdx != -1) {
			int[] r = new int[fcs.length - todayIdx];
			for (int i = 0; i < r.length; i++) {
				r[i] = todayIdx + i;
			}
			return r;
		}
		return new int[] {};
	}

	public void finishAnim() {
		WeatherGraph wg = (WeatherGraph) findViewById(R.id.weather_graph);
		wg.finishAnim();
	}

	// private static final int[] _wgbg = new int[] { R.drawable.weather_graph_bg_1, R.drawable.weather_graph_bg_2, R.drawable.weather_graph_bg_1 };
	private static final int[] _daysOfWeekColor = new int[] { 0xff1379c1, 0xff7bcdf7, 0xff673b0c, 0xff40738e, 0xffd2d0ce, 0xff1e99c6, 0xffffffff, 0xffffffff, 0xffffffff };
	private static final int[] _daysOfDateColor = new int[] { 0xffffffff, 0xffffffff, 0xffffffff, 0xff496594, 0xff7c7381, 0xff388cc6, 0xffc6f5ff, 0xff2f2f2f, 0xffffffff };
	private static final int[] _titleColors = new int[] { 0xffffffff, 0xff1d6fa3, 0xff784213, 0xff48a2d2, 0xff6b5e75, 0xffffffff, 0xff18bcf9, 0xff3d3d3d, 0xffc4d6ee };

	public void changeSkin(int skin) {
		int wp = skin;
		WeatherGraph wg = (WeatherGraph) findViewById(R.id.weather_graph);
// wg.setBackgroundResource(R.drawable.weather_moji_bg);

		View week = findViewById(R.id.days_of_week);
		View date = findViewById(R.id.date);
		int[] ids = new int[] { R.id.day_0, R.id.day_1, R.id.day_2, R.id.day_3, R.id.day_4 };
		for (int i = 0; i < ids.length; i++) {
			TextView day = (TextView) week.findViewById(ids[i]);
			day.setTextColor(_daysOfWeekColor[wp]);
			TextView dateDay = (TextView) date.findViewById(ids[i]);
			dateDay.setTextColor(_daysOfDateColor[wp]);
		}

		mTvcurrentPageTitle.setTextColor(_titleColors[wp]);
		ImageView wgbg = (ImageView) findViewById(R.id.weather_graph_bg);

		// 适配480X640分辨率 added by Maojianwei
		DisplayMetrics dm = getResources().getDisplayMetrics();
		if (480 == dm.widthPixels && 640 == dm.heightPixels) {
			wgbg.setImageResource(R.drawable.weather_graph_bg_480x640);
		} else {
			wgbg.setImageResource(R.drawable.weather_graph_bg_1);
		}

		wg.changeSkin(skin);
	}

}
