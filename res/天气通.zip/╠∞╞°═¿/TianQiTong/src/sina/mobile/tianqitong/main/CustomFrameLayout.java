package sina.mobile.tianqitong.main;

import java.util.ArrayList;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.utility.BitmapCache;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

public class CustomFrameLayout extends FrameLayout {

	public CustomFrameLayout(Context context) {
		super(context);
		init(context, null);
	}

	public CustomFrameLayout(Context context, AttributeSet attrs) {
		super(context, attrs, 0);
		init(context, attrs);
	}

	public CustomFrameLayout(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context, attrs);
	}

	public void loadBg() {
		super.onAttachedToWindow();
//		System.out.println("Attached");
		mBg = BitmapCache.getBitmap(mBgId, getResources());
	}

	public void releaseBg() {
		super.onDetachedFromWindow();
//		System.out.println("Detached");
		mBGFadeInFadeOutState = BG_FADE_STATE_REST;
		mBg = null;
		mNewBg = null;
	}

	private static int gSXAnimationVelocity = 0;

	private int _currentChildIdx = 0;

	private static int gMinimumFlingVelocity;

	private int mTouchSlop;

	private int mBgId;
	private int mNewBgId;
	private Bitmap mBg = null;

	private Bitmap mNewBg = null;

	private int mBGFadeInFadeOutState = 0;
	private static final int BG_FADE_STATE_REST = 0;
	private static final int BG_FADE_STATE_FADEOUT = 1;
	private static final int BG_FADE_STATE_FADEIN = 2;

	private static final int gS = 1024;

	private static final int BG_FADE_S_STEP = 255 * gS / 10;
	private int mCurrentBGAlpha = 255;

	private int mSXAnimationVelocity = 0;

	private int mState = STATE_REST;
	private static final int STATE_BEING_DRAGGED = 0;
	private static final int STATE_GOING = 1;
	private static final int STATE_OUTBOUND = 2;
	private static final int STATE_REBOUNDING = 3;
	private static final int STATE_REST = 4;

	private float mLastMotionX;
	private float mLastMotionY;

	private VelocityTracker mVelocityTracker;

	private boolean mIsCircular = true;
	private boolean mShouldRebound = false;

	private void init(Context context, AttributeSet attrs) {

		gSXAnimationVelocity = ViewConfiguration.getMinimumFlingVelocity() * gS * 3 / 5;

		ViewConfiguration vc = ViewConfiguration.get(getContext());

		gMinimumFlingVelocity = ViewConfiguration.getMinimumFlingVelocity();

		mTouchSlop = vc.getScaledTouchSlop();

		if (attrs != null) {
			TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CustomFrameLayout, 0, 0);

			if (a != null) {
				final int N = a.getIndexCount();
				for (int i = 0; i < N; i++) {
					int attr = a.getIndex(i);
					switch (attr) {
					case R.styleable.CustomFrameLayout_big_background: {
						int id = a.getResourceId(attr, -1);
						if (id != -1) {
							mBgId = id;
							mBg = BitmapCache.getBitmap(id, getResources());
						}
					}
						break;
					case R.styleable.CustomFrameLayout_isCircular: {
						mIsCircular = a.getBoolean(attr, true);
					}
						break;
					case R.styleable.CustomFrameLayout_shouldRebound: {
						mShouldRebound = a.getBoolean(attr, true);
					}
						break;
					}
				}
				a.recycle();
			}

		}

		setFocusable(true);

	}

	private final int mFadeBgSampleSize = 2;

	public void setBigBG(int id) {
		if (mBg != null) {
			if (mNewBgId != id) {
				if (mNewBgId != Integer.MIN_VALUE) {
					mBgId = mNewBgId;
				}

				mBg = null;
				mNewBg = null;
				System.gc();

				mBg = BitmapCache.getSampleBitmap(mBgId, getResources(), mFadeBgSampleSize);

				mNewBgId = id;
				mNewBg = BitmapCache.getSampleBitmap(mNewBgId, getResources(), mFadeBgSampleSize);

				setChildrenDrawnWithCacheEnabled(true);

				mBGFadeInFadeOutState = BG_FADE_STATE_FADEOUT;
				mCurrentBGAlpha = 255;
				invalidate();
			}
		} else {
			if (mBgId != id) {
				mBg = null;
				mNewBg = null;
				mNewBgId = Integer.MIN_VALUE;
				mBg = BitmapCache.getBitmap(id, getResources());
				mBgId = id;
			}
		}

	}

	private boolean countCurrentChildIdx() {

		boolean re = false;

		Rect pr = new Rect();
		getDrawingRect(pr);

		int count = getChildCount();
		int width = pr.right - pr.left;
		int halfWidth = width / 2;

		Rect r = null;

		for (int i = 0; i < count; i++) {
			View child = getChildAt(i);

			if (child.getVisibility() != View.GONE) {
				r = new Rect();
				child.getDrawingRect(r);
				offsetDescendantRectToMyCoords(child, r);

				if (r.left < pr.left && r.right > pr.left && r.right < pr.right && r.right - pr.left > halfWidth) {
					if (_currentChildIdx != i) {
						re = true;
					}
					_currentChildIdx = i;
					break;
				}
				if (r.right > pr.right && r.left < pr.right && r.left > pr.left && pr.right - r.left > halfWidth) {
					if (_currentChildIdx != i) {
						re = true;
					}
					_currentChildIdx = i;
					break;
				}
			}
		}
		return re;
	}

	public int getCurrentChild() {
		return _currentChildIdx;
	}

	private void doLayout() {

		for (int idx = 0; idx < getChildCount(); idx++) {

			View child = getChildAt(idx);

			int currentLeft = child.getLeft();

			int targetLeft = (idx - _currentChildIdx) * getMeasuredWidth();

			int offset = targetLeft - currentLeft;

			child.offsetLeftAndRight(offset);

		}
	}

	public boolean setDisplayedChild(int idx) {

		if (idx == _currentChildIdx) {
			return false;
		}
		_currentChildIdx = idx;

		View viewToSetCurrent = getChildAt(idx);
		if (viewToSetCurrent.getVisibility() == View.GONE) {
			return false;
		}

		doLayout();
		return true;
	}

	@Override
	protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
		super.onLayout(changed, left, top, right, bottom);
		doLayout();
		setChildrenDrawingCacheEnabled(true);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}

	private void makeSAndDRect(Rect s, Rect d, int tmp, int bgWidth, int width, int height, int bgHeight) {

		int sleft = 0;
		int sright = 0;
		int dleft = 0;
		int dright = getWidth();

		if (tmp > 0) {
			sleft = 0;
			sright = getWidth() - tmp;
			dleft = tmp;
			dright = getWidth();
		} else {
			sleft = -tmp;
			if (tmp + bgWidth < getWidth()) {
				sright = bgWidth;
				dleft = 0;
				dright = bgWidth + tmp;
			} else {
				sright = sleft + getWidth();
				dleft = 0;
				dright = getWidth();
			}
		}
		s.set(sleft, 0, sright, bgHeight);
		d.set(dleft, 0, dright, height);

//		System.out.println(s + "->" + d);

		if (mBGFadeInFadeOutState == BG_FADE_STATE_FADEOUT) {
			s.right = (s.right * gS / mFadeBgSampleSize) / gS;
			s.left = (s.left * gS / mFadeBgSampleSize) / gS;
			s.bottom = (s.bottom * gS / mFadeBgSampleSize) / gS;
		}

//		System.out.println("--" + s + "->" + d);

	}

	private void drawBigBGTemp(Bitmap bg, Canvas canvas, int alpha, boolean byIdx) {

//		System.out.println("a-" + alpha);

		Paint p = new Paint();
		p.setAlpha(alpha);
		if (bg != null) {

			View currentView = getChildAt(_currentChildIdx);

			int measuredWidth = getWidth();
			int vLeftOfFirstChild = currentView.getLeft() - _currentChildIdx * measuredWidth;
			int currentLeft = currentView.getLeft();
			int currentRight = currentView.getRight();

			int offset = 0;
			int offset2 = currentRight;
			if (byIdx) {
				offset = currentLeft;
				offset2 = currentView.getWidth();
			}

			canvas.clipRect(new Rect(0, 0, getWidth(), getHeight()));

			int realBgWidth = bg.getWidth();
			int realBgHeight = bg.getHeight();

			int scaledBgWidth = realBgWidth;
			int scaledBgHeight = realBgHeight;

			if (mBGFadeInFadeOutState == BG_FADE_STATE_FADEOUT) {
				scaledBgWidth = realBgWidth * mFadeBgSampleSize;
				scaledBgHeight = realBgHeight * mFadeBgSampleSize;
			}

			if (_currentChildIdx == 0 && currentLeft > 0) {

				int tmp = vLeftOfFirstChild - offset;
				Rect s = new Rect();
				Rect d = new Rect();
				makeSAndDRect(s, d, tmp, scaledBgWidth, getWidth(), getHeight(), scaledBgHeight);
				canvas.drawBitmap(bg, s, d, p);

				tmp = vLeftOfFirstChild - scaledBgWidth + 1 - offset;
				s = new Rect();
				d = new Rect();
				makeSAndDRect(s, d, tmp, scaledBgWidth, getWidth(), getHeight(), scaledBgHeight);

				canvas.drawBitmap(bg, s, d, p);

			} else if (_currentChildIdx == getChildCount() - 1 && currentLeft < 0) {

				int tmp = offset2;
				Rect s = new Rect();
				Rect d = new Rect();
				makeSAndDRect(s, d, tmp, scaledBgWidth, getWidth(), getHeight(), scaledBgHeight);
				canvas.drawBitmap(bg, s, d, p);

				tmp = -scaledBgWidth + offset2;
				s = new Rect();
				d = new Rect();
				makeSAndDRect(s, d, tmp, scaledBgWidth, getWidth(), getHeight(), scaledBgHeight);
				canvas.drawBitmap(bg, s, d, p);
			} else {
				int bgoffset = 0;
				if (getChildCount() != 1) {
					bgoffset = ((scaledBgWidth - measuredWidth) * (vLeftOfFirstChild - offset)) / (measuredWidth * (getChildCount() - 1));
				}

				int tmp = bgoffset;
				Rect s = new Rect();
				Rect d = new Rect();
				makeSAndDRect(s, d, tmp, scaledBgWidth, getWidth(), getHeight(), scaledBgHeight);
				canvas.drawBitmap(bg, s, d, p);
			}

		}

	}

	private void drawBigBackgroundByIdx(Bitmap bg, Canvas canvas, int alpha) {
		drawBigBGTemp(bg, canvas, alpha, true);

	}

	private void drawBigBackground(Bitmap bg, Canvas canvas, int alpha) {
		drawBigBGTemp(bg, canvas, alpha, false);

	}

	private boolean mBackgroundRebound = false;

	public void setBackgroundRebound(boolean rebound) {
		mBackgroundRebound = rebound;
	}

	protected void dispatchDraw(Canvas canvas) {

		View currentView = getChildAt(_currentChildIdx);

		int a = gSXAnimationVelocity * 3 / 5;
		if (mState == STATE_REBOUNDING) {
			a = gSXAnimationVelocity / 13;
		}

		if (mState == STATE_GOING || mState == STATE_OUTBOUND) {
			if (mShouldRebound) {
				int leftOfCurrentView = currentView.getLeft();
				if (mSXAnimationVelocity < 0) {
					if (leftOfCurrentView <= 0) {
						mState = STATE_OUTBOUND;
					}
					if (mSXAnimationVelocity >= 0) {
						mState = STATE_REBOUNDING;
					} else {

					}
				} else {
					if (leftOfCurrentView >= 0) {
						mState = STATE_OUTBOUND;
					}
					if (mSXAnimationVelocity <= 0) {
						mState = STATE_REBOUNDING;
					} else {

					}
				}
			}
		}

		switch (mBGFadeInFadeOutState) {
		case BG_FADE_STATE_FADEOUT: {
			if (mCurrentBGAlpha <= 0) {
				mBGFadeInFadeOutState = BG_FADE_STATE_REST;
				mCurrentBGAlpha = 0;
				mBgId = mNewBgId;
				mBg = null;
				mNewBg = null;
				System.gc();

				mBg = BitmapCache.getBitmap(mBgId, getResources());
				mNewBgId = Integer.MIN_VALUE;

				if (mBackgroundRebound) {
					drawBigBackground(mBg, canvas, 255);
				} else {
					if (mState == STATE_GOING || mState == STATE_BEING_DRAGGED) {
						drawBigBackground(mBg, canvas, 255);
					} else if (mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
						drawBigBackgroundByIdx(mBg, canvas, 255);
					} else {
						drawBigBackground(mBg, canvas, 255);
					}
				}

			} else {

				if (mBackgroundRebound) {
					drawBigBackground(mBg, canvas, 255);
				} else {
					if (mState == STATE_GOING || mState == STATE_BEING_DRAGGED) {
						drawBigBackground(mBg, canvas, 255);
					} else if (mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
						drawBigBackgroundByIdx(mBg, canvas, 255);
					} else {
						drawBigBackground(mBg, canvas, 255);
					}
				}

				if (mBackgroundRebound) {
					drawBigBackground(mNewBg, canvas, 255 - mCurrentBGAlpha);
				} else {
					if (mState == STATE_GOING || mState == STATE_BEING_DRAGGED) {
						drawBigBackground(mNewBg, canvas, 255 - mCurrentBGAlpha);
					} else if (mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
						drawBigBackgroundByIdx(mNewBg, canvas, 255 - mCurrentBGAlpha);
					} else {
						drawBigBackground(mNewBg, canvas, 255 - mCurrentBGAlpha);
					}
				}

				mCurrentBGAlpha = (mCurrentBGAlpha * gS - BG_FADE_S_STEP) / gS;
			}
		}
			break;
		case BG_FADE_STATE_FADEIN: {
			if (mCurrentBGAlpha >= 255) {
				mBGFadeInFadeOutState = BG_FADE_STATE_REST;
				setChildrenDrawnWithCacheEnabled(false);
				mCurrentBGAlpha = 255;
				if (mBackgroundRebound) {
					drawBigBackground(mBg, canvas, 255);
				} else {
					if (mState == STATE_GOING || mState == STATE_BEING_DRAGGED) {
						drawBigBackground(mBg, canvas, 255);
					} else if (mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
						drawBigBackgroundByIdx(mBg, canvas, 255);
					} else {
						drawBigBackground(mBg, canvas, 255);
					}
				}
			} else {
				if (mBackgroundRebound) {
					drawBigBackground(mBg, canvas, mCurrentBGAlpha);
				} else {
					if (mState == STATE_GOING || mState == STATE_BEING_DRAGGED) {
						drawBigBackground(mBg, canvas, mCurrentBGAlpha);
					} else if (mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
						drawBigBackgroundByIdx(mBg, canvas, mCurrentBGAlpha);
					} else {
						drawBigBackground(mBg, canvas, mCurrentBGAlpha);
					}
				}

				mCurrentBGAlpha = (mCurrentBGAlpha * gS + BG_FADE_S_STEP) / gS;
			}
		}
			break;
		case BG_FADE_STATE_REST: {
			if (mBackgroundRebound) {
				drawBigBackground(mBg, canvas, 255);
			} else {
				if (mState == STATE_GOING || mState == STATE_BEING_DRAGGED) {
					drawBigBackground(mBg, canvas, 255);
				} else if (mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
					drawBigBackgroundByIdx(mBg, canvas, 255);
				} else {
					drawBigBackground(mBg, canvas, 255);
				}
			}
		}
			break;
		}

		long drawingTime = getDrawingTime();
		if (mState == STATE_REST || mState == STATE_REBOUNDING || mState == STATE_OUTBOUND) {
			drawChild(canvas, getChildAt(_currentChildIdx), drawingTime);
		} else {
			for (int i = 0; i < getChildCount(); i++) {
				drawChild(canvas, getChildAt(i), drawingTime);
			}
		}

		if (mState == STATE_GOING || mState == STATE_OUTBOUND) {

			if (mShouldRebound) {

				int leftOfCurrentView = currentView.getLeft();

				if (mSXAnimationVelocity < 0) {
					if (leftOfCurrentView <= 0) {
						mState = STATE_OUTBOUND;
						mSXAnimationVelocity += a;
					}
					if (mSXAnimationVelocity >= 0) {
						mSXAnimationVelocity = 0;
						mState = STATE_REBOUNDING;
						invalidate();
						return;

					} else {

					}
				} else {
					if (leftOfCurrentView >= 0) {
						mState = STATE_OUTBOUND;
						mSXAnimationVelocity -= a;
					}
					if (mSXAnimationVelocity <= 0) {
						mSXAnimationVelocity = 0;
						mState = STATE_REBOUNDING;
						invalidate();
						return;
					} else {

					}
				}
			} else {
				int leftOfCurrentView = currentView.getLeft();
				if (mSXAnimationVelocity < 0) {
					if (leftOfCurrentView + mSXAnimationVelocity / gS <= 0) {
						doLayout();
						if (mOnCustomFrameOperationListener != null) {
							mOnCustomFrameOperationListener.onCurrentChildChanged(_currentChildIdx);
						}
						mState = STATE_REST;
						invalidate();
						return;

					} else {

					}
				} else {
					if (leftOfCurrentView + mSXAnimationVelocity / gS >= 0) {
						doLayout();
						if (mOnCustomFrameOperationListener != null) {
							mOnCustomFrameOperationListener.onCurrentChildChanged(_currentChildIdx);
						}
						mState = STATE_REST;
						invalidate();
						return;
					} else {

					}
				}
			}

			for (int i = 0; i < getChildCount(); i++) {
				final View child = getChildAt(i);
				child.offsetLeftAndRight(mSXAnimationVelocity / gS);
			}
		} else if (mState == STATE_REBOUNDING) {

			int leftOfCurrentView = currentView.getLeft();

			if (leftOfCurrentView > 0) {
				mSXAnimationVelocity -= a;
				if (leftOfCurrentView + mSXAnimationVelocity / gS <= 0) {
					doLayout();
					if (mOnCustomFrameOperationListener != null) {
						mOnCustomFrameOperationListener.onCurrentChildChanged(_currentChildIdx);
					}
					mState = STATE_REST;
					invalidate();
					return;

				} else {

				}
			} else {
				mSXAnimationVelocity += a;
				if (leftOfCurrentView + mSXAnimationVelocity / gS >= 0) {
					doLayout();
					if (mOnCustomFrameOperationListener != null) {
						mOnCustomFrameOperationListener.onCurrentChildChanged(_currentChildIdx);
					}
					mState = STATE_REST;
					invalidate();
					return;
				} else {

				}
			}

			for (int i = 0; i < getChildCount(); i++) {
				final View child = getChildAt(i);
				child.offsetLeftAndRight(mSXAnimationVelocity / gS);
			}
		}

		if (mBGFadeInFadeOutState == BG_FADE_STATE_FADEOUT || mBGFadeInFadeOutState == BG_FADE_STATE_FADEIN) {
			invalidate();
		} else if (mState == STATE_GOING || mState == STATE_OUTBOUND) {
			invalidate();
		} else if (mState == STATE_REBOUNDING) {
			invalidate();
		}

		if (mOnCustomFrameOperationListener != null) {

			ArrayList<Rect> alRects = new ArrayList<Rect>();
			for (int i = 0; i < getChildCount(); i++) {
				View v = getChildAt(i);
				Rect r = new Rect();
				v.getDrawingRect(r);
				offsetDescendantRectToMyCoords(v, r);
				alRects.add(r);
			}
			Rect[] notGoneChildrenRect = new Rect[alRects.size()];
			alRects.toArray(notGoneChildrenRect);

			Rect customFrameLayoutRect = new Rect();
			getDrawingRect(customFrameLayoutRect);

			mOnCustomFrameOperationListener.onChildrenMoving(notGoneChildrenRect, customFrameLayoutRect);
		}

		if (!isInTouchMode()) {
			if (!isFocused()) {
				Paint p = new Paint();
				p.setColor(Color.BLACK);
				p.setAlpha(100);
				canvas.drawRect(0, 0, getWidth(), getHeight(), p);
			}
		}

	}

	public static boolean isCityViewDraging = false;

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {

		if (mOnCustomFrameOperationListener != null) {
			mOnCustomFrameOperationListener.onInterceptTouchEvent();
		}

		if (isCityViewDraging) {
			return false;
		}

		final int action = ev.getAction();

		boolean r;

		switch (mState) {
		case STATE_REST: {

			final float x = ev.getX();
			final float y = ev.getY();

			switch (action) {
			case MotionEvent.ACTION_DOWN: {

				mLastMotionX = x;
				mLastMotionY = y;

				r = false;
			}
				break;
			case MotionEvent.ACTION_MOVE: {

				final int xDiff = (int) Math.abs(x - mLastMotionX);
				final int yDiff = (int) Math.abs(y - mLastMotionY);

				boolean xMoved = xDiff > mTouchSlop;

				if (xMoved && yDiff < xDiff) {
					mState = STATE_BEING_DRAGGED;
					r = true;
				} else {
					r = false;
				}
			}

				break;

			case MotionEvent.ACTION_CANCEL:
			case MotionEvent.ACTION_UP: {
				mState = STATE_REST;
				r = false;
			}

				break;
			default: {
				r = false;
			}
			}
		}
			break;
		default: {
			r = false;
		}
		}

		return r;
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {

		boolean rr;

		if (mVelocityTracker == null) {
			mVelocityTracker = VelocityTracker.obtain();
		}

		mVelocityTracker.addMovement(ev);

		final int action = ev.getAction();

		switch (action & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN: {

			mState = STATE_BEING_DRAGGED;

			rr = true;
		}
			break;
		case MotionEvent.ACTION_MOVE: {
			if (mState == STATE_BEING_DRAGGED) {

				setChildrenDrawnWithCacheEnabled(true);

				final float x = ev.getX();

				int deltaX = (int) (x - mLastMotionX);

				if (mIsCircular) {

					View currentChild = getChildAt(_currentChildIdx);
					Rect r = new Rect();
					currentChild.getDrawingRect(r);
					offsetDescendantRectToMyCoords(currentChild, r);

					if (_currentChildIdx == 0) {
						if (r.left > 0) {
							View child = getChildAt(getChildCount() - 1);
							makeSureAisPlacedToTheLeftOfB(child, r);
						} else {
							if (getChildCount() > 1) {
								View child = getChildAt(1);
								makeSureAisPlacedToTheRightOfB(child, r);
							}

						}
					} else if (_currentChildIdx == getChildCount() - 1) {
						if (r.right < getMeasuredWidth() - 1) {
							View child = getChildAt(0);
							makeSureAisPlacedToTheRightOfB(child, r);
						} else {
							if (getChildCount() > 1) {
								View child = getChildAt(getChildCount() - 2);
								makeSureAisPlacedToTheLeftOfB(child, r);
							}
						}
					}
				}

				for (int i = 0; i < getChildCount(); i++) {
					View child = getChildAt(i);
					child.offsetLeftAndRight(deltaX);
				}
				invalidate();
				mLastMotionX = x;

				rr = true;
			} else {
				rr = false;
			}

		}

			break;
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_CANCEL: {

			setChildrenDrawnWithCacheEnabled(false);

			final VelocityTracker velocityTracker = mVelocityTracker;
			velocityTracker.computeCurrentVelocity(100);
			float xVelocity = velocityTracker.getXVelocity();

			if (mState == STATE_BEING_DRAGGED) {

				if (Math.abs(xVelocity) < gMinimumFlingVelocity) {

					countCurrentChildIdx();
					View currentChild = getChildAt(_currentChildIdx);

					mSXAnimationVelocity = (currentChild.getLeft() < 0 ? 1 : -1) * gSXAnimationVelocity;
				} else {

					View currentChild = getChildAt(_currentChildIdx);
					Rect r = new Rect();
					currentChild.getDrawingRect(r);
					offsetDescendantRectToMyCoords(currentChild, r);

					if (mIsCircular) {
						if (_currentChildIdx == 0) {
							if (xVelocity > 0) {
								// 向右拨动后退
								View previousChild = getChildAt(getChildCount() - 1);
								makeSureAisPlacedToTheLeftOfB(previousChild, r);

							} else {
								// 前进
								if (getChildCount() > 1) {
									View nextChild = getChildAt(1);
									makeSureAisPlacedToTheRightOfB(nextChild, r);
								}
							}
						} else if (_currentChildIdx == getChildCount() - 1) {
							if (xVelocity > 0) {
								// 后退
								if (getChildCount() > 1) {
									View previousChild = getChildAt(getChildCount() - 2);
									makeSureAisPlacedToTheLeftOfB(previousChild, r);
								}
							} else {
								// 前进
								View nextChild = getChildAt(0);
								makeSureAisPlacedToTheRightOfB(nextChild, r);
							}
						}
					}

					if (xVelocity < 0) {

						View v = getChildAt(_currentChildIdx);

						if (v.getLeft() > 0) {

						} else {
							int tmpidx = getNextChildIdx();
							if (tmpidx == -1) {

							} else {
								_currentChildIdx = tmpidx;
							}
						}

					} else {
						View v = getChildAt(_currentChildIdx);

						if (v.getLeft() < 0) {

						} else {
							int tmpidx = getPreviousChildIdx();
							if (tmpidx == -1) {

							} else {
								_currentChildIdx = tmpidx;
							}
						}

					}

					mSXAnimationVelocity = (xVelocity > 0 ? 1 : -1) * gSXAnimationVelocity;

				}

				mState = STATE_GOING;

				invalidate();

			}

			rr = true;

		}
			break;
		default: {
			rr = true;
		}
		}

		return rr;
	}

	private void makeSureAisPlacedToTheLeftOfB(View viewA, Rect rectB) {

		Rect rectA = new Rect();
		viewA.getDrawingRect(rectA);
		offsetDescendantRectToMyCoords(viewA, rectA);

		if (rectA.left > rectB.left) {
			int targetLeft = rectB.left - getMeasuredWidth() + 1;

			int offset = targetLeft - rectA.left;

			viewA.offsetLeftAndRight(offset);
		}

	}

	private void makeSureAisPlacedToTheRightOfB(View viewA, Rect rectB) {

		Rect rectA = new Rect();
		viewA.getDrawingRect(rectA);
		offsetDescendantRectToMyCoords(viewA, rectA);

		if (rectA.left < rectB.left) {
			int targetLeft = rectB.left + getMeasuredWidth() - 1;

			int offset = targetLeft - rectA.left;

			viewA.offsetLeftAndRight(offset);
		}
	}

	private int getPreviousChildIdx() {
		int lastChildIdx = -1;
		for (int i = getChildCount() - 1; i >= 0; i--) {

			if (lastChildIdx == -1) {
				lastChildIdx = i;
			}
			if (i < _currentChildIdx) {
				return i;
			}

		}
		if (mIsCircular) {
			return lastChildIdx;
		} else {
			return -1;
		}
	}

	private int getNextChildIdx() {
		int firstChildIdx = -1;
		for (int i = 0; i < getChildCount(); i++) {

			if (firstChildIdx == -1) {
				firstChildIdx = i;
			}
			if (i > _currentChildIdx) {
				return i;
			}

		}
		if (mIsCircular) {
			return firstChildIdx;
		} else {
			return -1;
		}
	}

	public void toPrevious() {

		int tmpidx = getPreviousChildIdx();
		if (tmpidx == -1) {
			return;
		} else {
			if (mIsCircular) {
				if (tmpidx > _currentChildIdx) {

					View currentChild = getChildAt(_currentChildIdx);
					Rect r = new Rect();
					currentChild.getDrawingRect(r);
					offsetDescendantRectToMyCoords(currentChild, r);

					View previousChild = getChildAt(tmpidx);
					makeSureAisPlacedToTheLeftOfB(previousChild, r);

					_currentChildIdx = tmpidx;
				}
			}
		}

		_currentChildIdx = tmpidx;

		mSXAnimationVelocity = gSXAnimationVelocity;
		mState = STATE_GOING;
		invalidate();
	}

	public void toNext() {
		int tmpidx = getNextChildIdx();
		if (tmpidx == -1) {
			return;
		} else {
			if (mIsCircular) {
				if (tmpidx < _currentChildIdx) {

					View currentChild = getChildAt(_currentChildIdx);
					Rect r = new Rect();
					currentChild.getDrawingRect(r);
					offsetDescendantRectToMyCoords(currentChild, r);

					View nextChild = getChildAt(tmpidx);
					makeSureAisPlacedToTheRightOfB(nextChild, r);
				}
			}
		}
		_currentChildIdx = tmpidx;

		mSXAnimationVelocity = -gSXAnimationVelocity;
		mState = STATE_GOING;
		invalidate();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {

		case KeyEvent.KEYCODE_DPAD_LEFT: {
			toPrevious();
			return true;
		}

		case KeyEvent.KEYCODE_DPAD_RIGHT: {
			toNext();
			return true;
		}

		}

		return super.onKeyDown(keyCode, event);
	}

	private onCustomFrameOperationListener mOnCustomFrameOperationListener = null;

	public void setOnCustomFrameOperationListener(onCustomFrameOperationListener listener) {
		mOnCustomFrameOperationListener = listener;
	}

	public static interface onCustomFrameOperationListener {
		public void onChildrenMoving(Rect[] childrenRect, Rect customFrameLayoutRect);

		public void onInterceptTouchEvent();

		public void onCurrentChildChanged(int idx);

		public void onBGFadeDone();
	}

}
