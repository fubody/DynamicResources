package sina.mobile.tianqitong.appwidget;

import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_SWITCH_WIDGET_CITY;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_4x1WIDGET;
import static sina.mobile.tianqitong.service.utility.SPUtility.getSPStringArray;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Calendar;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.contentprovider.TqtContentProvider;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.main.MainActivity;
import sina.mobile.tianqitong.main.TianQiTongReciever;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;

/**
 * 4x1天气通插件的Provider
 * 
 * @author 黄恪
 * 
 */
public class Widget4x1Provider extends AppWidgetProvider {

	/**
	 * 第一个格显示城市名，第二个显示明天，后面的三个才需要显示星期几
	 */
	private static final int[] _week_day_ids = new int[] { R.id._3ed_week_day_1, R.id._4th_week_day_1, R.id._5th_week_day_1 };

	/**
	 * 
	 */
	private static final int[] _icon_ids = new int[] { R.id._1st_icon, R.id._2nd_icon, R.id._3ed_icon, R.id._4th_icon, R.id._5th_icon };
	private static final int[] _temp_ids = new int[] { R.id._1st_temperature, R.id._2nd_temperature, R.id._3ed_temperature, R.id._4th_temperature, R.id._5th_temperature };
	private static final int[] _city_name_chars = new int[] { R.id.cityname_1st_char, R.id.cityname_2nd_char, R.id.cityname_3ed_char, R.id.cityname_4th_char };
	private static final int[] _week_ids = new int[] { R.id._2ed_week_day, R.id._2ed_week_day_1, R.id._3ed_week_day, R.id._3ed_week_day_1, R.id._4th_week_day, R.id._4th_week_day_1,
			R.id._5th_week_day, R.id._5th_week_day_1 };

	public static final void make4x1Values(WeatherInfo wi, String cityName, Context context, int[] icons, String[] texts, String[] temps) {

		if (icons == null || icons.length != 5) {
			throw new IllegalArgumentException();
		}
		if (texts == null || texts.length != 5) {
			throw new IllegalArgumentException();
		}
		if (temps == null || temps.length != 5) {
			throw new IllegalArgumentException();
		}

		String[] daysOfWeek = context.getResources().getStringArray(R.array.brief_days_of_week);

		String[] tmp = Utility.split(cityName, '.');
		cityName = tmp[tmp.length - 1];

		if (cityName.length() > 4) {
			cityName = cityName.substring(0, 3) + "..";
		}

		texts[0] = cityName;
		texts[1] = "明天";

		ForeCast[] fcs = wi.getForecastsForCurrent(5);
		Calendar calendar = Calendar.getInstance();

		long currentMillis = System.currentTimeMillis();

		for (int i = 0; i < 5; i++) {
			if (fcs[i] == ForeCast.EMPTY) {
				icons[i] = R.drawable.weathericon_forecast_17;
				temps[i] = "";
			} else {
				int ycode = fcs[i].getYcode();
				if (ycode == WeatherInfo.INVALID_YCODE) {
					ycode = fcs[i].getYcode2();
				}

				icons[i] = WeatherInfo.getWeatherIconFromYahooCode(ycode, WeatherInfo.ICON_TYPE_FORECAST, context.getResources());

				int h = fcs[i].getHigh();
				int l = fcs[i].getLow();
				String temp = l + (h == WeatherInfo.INVALID_TEMPERATURE ? "" : ("/" + h)) + "°";
				temps[i] = temp;
			}
			if (i >= 2) {
				calendar.setTimeInMillis(currentMillis);
				String dayOfWeek = daysOfWeek[calendar.get(Calendar.DAY_OF_WEEK) - 1];
				texts[i] = dayOfWeek;
			}
			currentMillis += 24L * 1000L * 3600L;
		}

	}

	synchronized public static RemoteViews updateAppWidget(Context context, TianQiTongService service) {

		TianQiTongLog.addNormalLog("updateAppWidget");

		RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.appwidget_4x1);
		Bitmap src = BitmapFactory.decodeResource(context.getResources(), R.drawable.widget_bg_4x1);
		views.setImageViewUri(R.id.widget_bg_color, getBackgroundImageColor(context, src));
		views.setImageViewUri(R.id.widget_bg, getBackgroundImage(context, src));

		boolean remoteSetBackgroundResource = false;
		try {
			Method[] ms = View.class.getMethods();
			for (Method m : ms) {
				if (m.getName().equals("setBackgroundResource")) {
					Annotation[] as = m.getAnnotations();
					for (Annotation a : as) {
						if (a.toString().contains("RemotableViewMethod")) {
							remoteSetBackgroundResource = true;
							break;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (remoteSetBackgroundResource) {
			if (backgroundImageAlpha < 10) {
				views.setInt(R.id.cityname, "setBackgroundResource", R.drawable.widget_4x1_cityname_bg_no_color);
			} else {
				views.setInt(R.id.cityname, "setBackgroundResource", R.drawable.widget_4x1_cityname_bg);
			}
		}

		String[] cityCodes = getSPStringArray(context, R.string.strs_cached_citys, ',');
		String[] daysOfWeek = context.getResources().getStringArray(R.array.brief_days_of_week);

		if (cityCodes.length != 0) {

			String[] texts = new String[5];
			String[] temps = new String[5];
			int[] icons = new int[5];

			String cityCode = SPUtility.getSPString(context, R.string.str_widget_city_code);
			WeatherInfo wi = service.getWeatherInfo(cityCode);
			String cityName = service.getCityName(cityCode);

			Widget4x1Provider.make4x1Values(wi, cityName, context, icons, texts, temps);

			String[] tmp = Utility.split(cityName, '.');// TODO 从onstartcommand里过来的更新，有时候这里的cityName会是null，为什么呢......
			cityName = tmp[tmp.length - 1];

			if (cityName.length() <= 4) {
				int i = 0;
				for (; i < cityName.length(); i++) {
					views.setTextViewText(_city_name_chars[i], cityName.charAt(i) + "");
				}
				for (; i < _city_name_chars.length; i++) {
					views.setTextViewText(_city_name_chars[i], "");
				}
			} else {
				for (int i = 0; i < 3; i++) {
					views.setTextViewText(_city_name_chars[i], cityName.charAt(i) + "");
				}
				views.setTextViewText(R.id.cityname_4th_char, "..");
			}

			for (int viewIdx = 0; viewIdx < 5; viewIdx++) {
				views.setImageViewResource(_icon_ids[viewIdx], icons[viewIdx]);
				views.setTextViewText(_temp_ids[viewIdx], temps[viewIdx]);
				if (viewIdx >= 2) {
					views.setTextViewText(_week_day_ids[viewIdx - 2], texts[viewIdx]);
				}
			}

			Intent i2 = new Intent(ACTION_START_SERVICE_SWITCH_WIDGET_CITY);
			PendingIntent pi2 = PendingIntent.getService(context, -1, i2, PendingIntent.FLAG_UPDATE_CURRENT);
			for (int i = 0; i < _city_name_chars.length; i++) {
				views.setOnClickPendingIntent(_city_name_chars[i], pi2);
			}
			views.setOnClickPendingIntent(_icon_ids[0], pi2);
			views.setOnClickPendingIntent(_temp_ids[0], pi2);

		} else {

			for (int i = 0; i < 5; i++) {
				views.setImageViewResource(_icon_ids[i], R.drawable.weathericon_forecast_17);
				views.setTextViewText(_temp_ids[i], "无数据");
			}

			for (int i = 2; i < 5; i++) {
				String dayOfWeek = daysOfWeek[i + 1];
				views.setTextViewText(_week_day_ids[i - 2], dayOfWeek);
			}

			Intent i1 = new Intent(context, MainActivity.class);
			i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
			i1.putExtra(IntentActionConstants.INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET, true);
			PendingIntent pi1 = PendingIntent.getActivity(context, 0, i1, PendingIntent.FLAG_UPDATE_CURRENT);
			views.setOnClickPendingIntent(_icon_ids[0], pi1);
			views.setOnClickPendingIntent(_temp_ids[0], pi1);
		}

		{
			Intent i1 = new Intent(context, MainActivity.class);
			i1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
			i1.putExtra(IntentActionConstants.INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET, true);
			PendingIntent pi1 = PendingIntent.getActivity(context, 0, i1, PendingIntent.FLAG_UPDATE_CURRENT);

			for (int i = 1; i < 5; i++) {
				views.setOnClickPendingIntent(_icon_ids[i], pi1);
				views.setOnClickPendingIntent(_temp_ids[i], pi1);
			}
		}

		// 设置字体的颜色

		for (int i = 0; i < _temp_ids.length; i++) {
			views.setTextColor(_temp_ids[i], getTextColor(context));
		}
		for (int i = 0; i < _city_name_chars.length; i++) {
			views.setTextColor(_city_name_chars[i], getTextColor(context));
		}
		for (int i = 0; i < _week_ids.length; i++) {
			views.setTextColor(_week_ids[i], getTextColor(context));
		}

		return views;

	}

	private static int getTextColor(Context context) {

		return DiyAppWidgetAttrUtil.getTextColor(context, AWType._1ST_4X1, FileGettable.CURRENT);
	}

	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {

		TianQiTongLog.addNormalLog("update4x1AppWidget");
		Intent i = new Intent(ACTION_START_SERVICE_UPDATE_4x1WIDGET);
		context.startService(i);

	}

	private static int backgroundImageAlpha = 255;

	/**
	 * 获得背景的透明度
	 * 
	 * @return
	 */
	public static int getBackgroundImageAlpha() {
		return backgroundImageAlpha;
	}

	/**
	 * 获得背景的颜色
	 * 
	 * @return
	 */
	public static void getBackgroundImageColor(Context context, Canvas canvas) {
		int colorInt = DiyAppWidgetAttrUtil.getBgColor(context, AWType._1ST_4X1, FileGettable.CURRENT);

		int backgroundAlpha = Color.alpha(colorInt);
		if (backgroundAlpha < 10) {
			backgroundImageAlpha = backgroundAlpha;
		} else {
			backgroundImageAlpha = 255;
		}
		canvas.drawARGB(backgroundAlpha, Color.red(colorInt), Color.green(colorInt), Color.blue(colorInt));

	}

	/**
	 * 获取背景图片
	 * 
	 * @param context
	 * @param src
	 * @return
	 */
	public static Uri getBackgroundImage(Context context, Bitmap src) {

		Bitmap bitmap = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);
		Paint paint = new Paint();
		paint.setAlpha(getBackgroundImageAlpha());
		Matrix matrix = new Matrix();
		canvas.drawBitmap(src, matrix, paint);

		long millisecond = System.currentTimeMillis();
		final String pngPrefix = "portskinBg4x1";
		File dir = context.getFilesDir();
		File[] fs = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(pngPrefix) && name.endsWith(".png")) {
					return true;
				}
				return false;
			}
		});
		for (File f : fs) {
			f.delete();
		}

		Uri uri1 = null;
		{
			FileOutputStream fos = null;
			try {
				fos = context.openFileOutput(pngPrefix + millisecond + ".png", Context.MODE_WORLD_READABLE);
			} catch (FileNotFoundException e) {
			}

			File f = new File(dir, pngPrefix + millisecond + ".png");
			bitmap.compress(CompressFormat.PNG, 100, fos);

			uri1 = TqtContentProvider.getImageFileUri(f.getName());

// uri1 = Uri.fromFile(f);
		}
		return uri1;

	}

	/**
	 * 获取背景图片的颜色
	 * 
	 * @param context
	 * @param src
	 * @return
	 */
	public static Uri getBackgroundImageColor(Context context, Bitmap src) {

		Bitmap bitmap = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);
		getBackgroundImageColor(context, canvas);
		bitmap = getRoundedCornerBitmap(bitmap, 13);

		long millisecond = System.currentTimeMillis();
		final String pngPrefix = "portskincolor4x1";
		File dir = context.getFilesDir();
		File[] fs = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(pngPrefix) && name.endsWith(".png")) {
					return true;
				}
				return false;
			}
		});
		for (File f : fs) {
			f.delete();
		}

		Uri uri1 = null;
		{
			FileOutputStream fos = null;
			try {
				fos = context.openFileOutput(pngPrefix + millisecond + ".png", Context.MODE_WORLD_READABLE);
			} catch (FileNotFoundException e) {
			}

			File f = new File(dir, pngPrefix + millisecond + ".png");
			bitmap.compress(CompressFormat.PNG, 100, fos);

			uri1 = TqtContentProvider.getImageFileUri(f.getName());

		}
		return uri1;

	}

	// 获得圆角图片的方法

	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, float roundPx) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final int color = 0xff424242;

		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

		final RectF rectF = new RectF(rect);
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);

		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}

	public void onEnabled(Context context) {
			TianQiTongReciever.applyTickAlarm(context, System.currentTimeMillis());
		}

	public void onDisabled(Context context) {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
		int[] appWidget4x2Ids = appWidgetManager.getAppWidgetIds(new ComponentName(context, WidgetProvider.class));
		if (appWidget4x2Ids.length == 0) {
			Intent i = new Intent(IntentActionConstants.ACTION_BC_UPDATE_WIDGET_CLOCK);
			PendingIntent sender = PendingIntent.getBroadcast(context, 0, i, PendingIntent.FLAG_UPDATE_CURRENT);
			AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
			am.cancel(sender);
		}

	}

}
