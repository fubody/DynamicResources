package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.repaintPreview;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

/**
 * 可diy单元的抽象父类。
 * 
 * @author 黄恪
 * 
 * @param <E>
 */
abstract class AbstractDiyableUnit {

	/**
	 * @param type
	 *            属于哪个插件
	 */
	public AbstractDiyableUnit(AWType type) {
		mType = type;
	}

	/**
	 * 
	 * @param x
	 *            位置，像素
	 * @param y
	 *            位置，像素
	 * @param anchorFlag
	 *            对齐方式
	 */
	void measureDrawRect(int x, int y, int anchorFlag) {
		mX = x;
		mY = y;
		mAnchorFlag = anchorFlag;
		mDrawBounds = doMeasureDrawRect();
	}

	/**
	 * x坐标，像素值。
	 */
	private int mX;

	/**
	 * y坐标，像素值。
	 */
	private int mY;

	/**
	 * 横向靠左。
	 */
	static final int ANCHOR_FLAG_LEFT = 0x01;// 0001
	/**
	 * 横向居中。
	 */
	static final int ANCHOR_FLAG_HCENTER = 0x01 << 1;// 0010
	/**
	 * 横向靠右。
	 */
	static final int ANCHOR_FLAG_RIGHT = 0x01 << 2;// 0100

	/**
	 * 横向mask。
	 */
	private static final int ANCHOR_H_MASK = 0x7;// 0000 0111

	/**
	 * 纵向靠上。
	 */
	static final int ANCHOR_FLAG_TOP = 0x1 << 3;// 1000
	/**
	 * 纵向居中。
	 */
	static final int ANCHOR_FLAG_VCENTER = 0x01 << 4;// 0001 0000
	/**
	 * 纵向靠下。
	 */
	static final int ANCHOR_FLAG_BOTTOM = 0x1 << 5;// 0010 0000

	/**
	 * 纵向mask。
	 */
	private static final int ANCHOR_V_MASK = 0x38;// 0011 1000

	/**
	 * mX和mY标志的是DrawBounds的哪个位置。
	 */
	private int mAnchorFlag;

	/**
	 * 绘制区域的外框。
	 */
	private Rect mDrawBounds;

	/**
	 * 计算绘制区域外框。父类构造器调用， 子类实现。
	 * 
	 * @return
	 */
	protected abstract Rect doMeasureDrawRect();

	/**
	 * 取绘制外框。
	 * 
	 * @return
	 */
	final Rect getDrawBounds() {
		return new Rect(mDrawBounds);
	}

	/**
	 * 取点击区域。
	 * 
	 * @return
	 */
	public abstract Rect getTouchableBounds();

	/**
	 * 把左上不是(0,0)的Rect，主要是文字的，整理成左上(0,0)。<br>
	 * 可以static。
	 * 
	 * @param r
	 */
	protected static final void offsetTextRect2Zero(Rect r) {
		// 这两个if应该都是进不去的。保险起见吧。
		if (r.bottom < r.top) {
			int i = r.bottom;
			r.bottom = r.top;
			r.top = i;
		}
		if (r.right < r.left) {
			int i = r.right;
			r.right = r.left;
			r.left = i;
		}

		r.bottom = r.bottom - r.top;
		r.top = 0;

		r.right = r.right - r.left;
		r.left = 0;

	}

	/**
	 * 把只有宽高有效的rect，按照mX，mY，mAnchorFlag，移动到正确的绘制位置。
	 * 
	 * @param r
	 */
	protected final void offsetRect(Rect r) {

		offsetTextRect2Zero(r);

		int t = mAnchorFlag & ANCHOR_H_MASK;

		switch (t) {
		case ANCHOR_FLAG_LEFT: {
			r.left = mX;

		}
			break;
		case ANCHOR_FLAG_HCENTER: {
			r.left = mX - r.right / 2;
		}
			break;
		case ANCHOR_FLAG_RIGHT: {
			r.left = mX - r.right;
		}
			break;
		default: {

		}
		}
		r.right = r.left + r.right;

		t = mAnchorFlag & ANCHOR_V_MASK;

		switch (t) {
		case ANCHOR_FLAG_TOP: {
			r.top = mY;
		}
			break;
		case ANCHOR_FLAG_VCENTER: {
			r.top = mY - r.bottom / 2;
		}
			break;
		case ANCHOR_FLAG_BOTTOM: {
			r.top = mY - r.bottom;
		}
			break;
		default: {

		}
		}
		r.bottom = r.top + r.bottom;
	}

	/**
	 * 在c上面画。
	 * 
	 * @param c
	 */
	public abstract void drawOnCanvas(Canvas c);

	/**
	 * 本单元属于哪种插件。
	 */
	private AWType mType;

	/**
	 * 取插件类型。
	 * 
	 * @return
	 */
	protected final AWType getType() {
		return mType;
	}

	/**
	 * 菜单项。在第一次get的时候生成，然后不可修改。
	 */
	private View[] mOptions;

	/**
	 * 重新生成菜单项。
	 * 
	 * @return
	 */
	protected abstract View[] makeOptions();

	public abstract String getOptionsTitle();

	/**
	 * 取菜单项。
	 * 
	 * @return
	 */
// final View[] getOptions() {
// return getOptions(false);
// }

	final View[] getOptions(boolean remake, boolean prepare) {
		if (!(getActivity() instanceof AppWidgetDiyTool)) {
			throw new IllegalStateException();
		}
		if (mOptions == null || remake) {
			mOptions = makeOptions();
		}
		if (prepare) {
			prepareOptions(mOptions);
		}
		return mOptions;
	}

	/**
	 * 准备菜单项。
	 * 
	 * @param options
	 */
	protected abstract void prepareOptions(View[] options);

	/**
	 * 从SharedPreference和WeatherInfo里拿数据更新当前的内容。
	 */
	protected abstract void remakeParams();

	abstract void onOkPressed();

	abstract void onCancelPressed();

	protected final void refresh() {
		remakeParams();
		repaintPreview(mType);
	}

}
