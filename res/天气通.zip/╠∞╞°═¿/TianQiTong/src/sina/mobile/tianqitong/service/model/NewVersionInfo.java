package sina.mobile.tianqitong.service.model;

import java.io.Serializable;

public class NewVersionInfo implements Serializable {
	public int _response = 0;
	public String _address = "";
	public String _message = "";
	public String _version = "0";
}
