package sina.mobile.tianqitong.appwidget;

import static sina.mobile.tianqitong.service.utility.SPUtility.getSPInteger;
import static sina.mobile.tianqitong.service.utility.SPUtility.getSPStringArray;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Calendar;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.contentprovider.TqtContentProvider;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.ButtonFunction;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.CitynameMode;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyButton;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyText;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.TextContent;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.WeatherIconMode;
import sina.mobile.tianqitong.diyappwidget.PendingIntentUtil;
import sina.mobile.tianqitong.main.TianQiTongReciever;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.ChineseCalendarUtility;
import sina.mobile.tianqitong.service.utility.ChineseDate;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.text.format.DateFormat;
import android.text.format.Time;
import android.view.View;
import android.widget.RemoteViews;

public class WidgetProvider extends AppWidgetProvider {
	private static final int[] _numberDrawableIds = new int[] { R.drawable.clock_0, R.drawable.clock_1, R.drawable.clock_2, R.drawable.clock_3, R.drawable.clock_4, R.drawable.clock_5,
			R.drawable.clock_6, R.drawable.clock_7, R.drawable.clock_8, R.drawable.clock_9, };
	private static AWType whichInsert = null;

	/**
	 * 获得是哪种插件
	 * 
	 * @return
	 */
	public static AWType getwhichInsert(Context context) {
		// 设置时哪个插件
		whichInsert = AWType.getAWType(getSPInteger(context, R.string.strint_which_default_4x2));
		return whichInsert;
	}

	/**
	 * 获取是模式情况
	 * 
	 * @param context
	 * @return
	 */
	static WeatherIconMode getwhichWeatherIconMode(Context context) {
		return DiyAppWidgetAttrUtil.getWeatherIconMode(context, whichInsert, FileGettable.CURRENT);
	}

	public static ButtonFunction getButtonFunction(Context context, DiyButton which) {
		return DiyAppWidgetAttrUtil.getButtonValue(context, whichInsert, FileGettable.CURRENT, which);
	}

	/**
	 * 从左到右从上到下第一个文字的内容
	 * 
	 * @return
	 */
	public static TextContent getText_1_Function(Context context) {
		return DiyAppWidgetAttrUtil.getTextValue(context, whichInsert, FileGettable.CURRENT, DiyText._1ST_TEXT);
	}

	/**
	 * 从左到右从上到下第二个文字的内容
	 * 
	 * @return
	 */
	public static TextContent getText_2_Function(Context context) {

		return DiyAppWidgetAttrUtil.getTextValue(context, whichInsert, FileGettable.CURRENT, DiyText._2ND_TEXT);
	}

	/**
	 * 城市的位置
	 * 
	 * @return
	 */
	public static CitynameMode getCityname_Function(Context context) {
		return DiyAppWidgetAttrUtil.getCitynameMode(context, whichInsert, FileGettable.CURRENT);
	}

	/**
	 * 字体的颜色
	 * 
	 * @return
	 */
	public static int getTextColor(Context context) {
		return DiyAppWidgetAttrUtil.getTextColor(context, whichInsert, FileGettable.CURRENT);
	}

	private static int backgroundImageAlpha = 255;

	/**
	 * 获得背景的透明度
	 * 
	 * @return
	 */
	public static int getBackgroundImageAlpha(Context context) {
		return backgroundImageAlpha;
	}

	/**
	 * 获得背景的颜色
	 * 
	 * @return
	 */
// public static void getBackgroundImageColor(Context context, Canvas canvas) {
// int colorInt = DiyAppWidgetAttrUtil.getBgColor(context, whichInsert, FileGettable.CURRENT);
// int backgroundAlpha = Color.alpha(colorInt);
// if (backgroundAlpha < 10) {
// backgroundImageAlpha = backgroundAlpha;
// } else {
// backgroundImageAlpha = 255;
// }
// canvas.drawARGB(backgroundAlpha, Color.red(colorInt), Color.green(colorInt), Color.blue(colorInt));
//
// }

	/**
	 * 根据功能设置图标和需要的跳转
	 * 
	 * @param views
	 */
	public static void accordingFunctionGoAndSetImage(RemoteViews views, Context context, TianQiTongService service, AWType type) {

		int[] btns = new int[] { R.id.button_1, R.id.button_2 };
		DiyButton[] whichs = new DiyButton[] { DiyButton._1ST_BUTTON, DiyButton._2ND_BUTTON };

		for (int i = 0; i < 2; i++) {

			int buttonId = btns[i];
			DiyButton which = whichs[i];
			ButtonFunction function = getButtonFunction(context, which);

			views.setInt(buttonId, "setVisibility", View.VISIBLE);

			switch (function) {
			case NULL: {// 设置为没有
				views.setInt(buttonId, "setVisibility", View.INVISIBLE);
			}
				break;
			case TTS_SETTING: {// 设置定时语音播报
				views.setImageViewResource(buttonId, R.drawable.widget_setalarm);
				views.setOnClickPendingIntent(buttonId, PendingIntentUtil.getSetingAlam(context));
			}

				break;
			case PLAY_TTS: {// 播报语音的功能
				views.setImageViewResource(buttonId, R.drawable.widget_play_tts_button);
				views.setOnClickPendingIntent(buttonId, PendingIntentUtil.getTTSPlaying(context));
				if (service.isTTSPlaying()) {
					views.setImageViewResource(buttonId, R.drawable.widget_stop_playing_tts_button);
				} else {
					views.setImageViewResource(buttonId, R.drawable.widget_play_tts_button);
				}
			}
				break;

			case UPDATE_DATA: {

				views.setImageViewResource(buttonId, R.drawable.widget_update);
				views.setOnClickPendingIntent(buttonId, PendingIntentUtil.getUpdateWeatherDate(context));
			}
				break;
			case WEIBO: {
				views.setImageViewResource(buttonId, R.drawable.widget_weibo);
				PendingIntent p = PendingIntentUtil.getRunWeibo(context);
				views.setOnClickPendingIntent(buttonId, p);

			}
				break;
			case APP: {
				PackageManager pm = context.getPackageManager();
				String pkgname = DiyAppWidgetAttrUtil.getAppPackageName(context, type, FileGettable.CURRENT, which);
				String clsname = DiyAppWidgetAttrUtil.getAppActivityName(context, type, FileGettable.CURRENT, which);

				views.setImageViewResource(buttonId, R.drawable.widget_app);
				PendingIntent p = PendingIntentUtil.getOtherApp(context, pkgname, clsname, which);
				views.setOnClickPendingIntent(buttonId, p);
			}
				break;

			default:
				break;
			}

		}

	}

	/**
	 * 关于日期的返回串
	 * 
	 * @param mTextContent
	 * @param context
	 * @return
	 */
	public static String getContentUserDefinedAboutDate(TextContent mTextContent, Context context) {

		// 日期
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(System.currentTimeMillis());
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		// 星期
		String[] daysOfWeek = context.getResources().getStringArray(R.array.days_of_week_simple);
		String dayOfWeek = daysOfWeek[calendar.get(Calendar.DAY_OF_WEEK) - 1];

		ChineseDate cd = ChineseCalendarUtility.getChineseDate(calendar);
		String cdate = "";
		if (cd != null) {
			cdate = ChineseCalendarUtility.toString(context.getResources(), cd, ChineseCalendarUtility.DATE_FORMAT_20110323_APPWIDGET);
		}

		StringBuilder str = new StringBuilder();

		switch (mTextContent) {
		case CHN_YMD: {
			// [辛卯] 二月廿八（有节气时候，节气提换辛卯）；

			str.append(cdate);
		}
			break;
		case YMDW: {
			// 2011.3.11/周五；
			str.append(year);
			str.append(".");
			str.append(month);
			str.append(".");
			str.append(day);
			str.append("/");
			str.append(dayOfWeek);

		}
			break;
		case LongMDW: {
			// 3月11日 周五 ；
			str.append(month);
			str.append("月");
			str.append(day);
			str.append("日 ");
			str.append(dayOfWeek);

		}
			break;
		case MDW: {
			// 3.11/五

			str.append(month);
			str.append(".");
			str.append(day);
			str.append("/");
			str.append(dayOfWeek);
		}
			break;
		case YMDW_CHN_MD: {
			str.append(year);
			str.append(".");
			str.append(month);
			str.append(".");
			str.append(day);
			str.append("/");
			str.append(dayOfWeek);
			str.append("/");
			str.append(cdate);
		}
			break;
		}

		return str.toString();
	}

	/**
	 * 关于天气的需要返回的字符串
	 * 
	 * @param mTextContent
	 * @param context
	 * @return
	 */

	public static String getContentUserDefinedAboutWeather(TextContent mTextContent, Context context, WeatherInfo wi, boolean longMode) {

		// 温度
		if (wi == null) {
			return "";
		}

		StringBuilder str = new StringBuilder();
		switch (mTextContent) {
		case WEATHER: {
			if (!Utility.isOut(wi)) {
				String weather = WeatherInfo.getWeatherStrFromYahooCode(wi.getYCodeUsingSunRiseAndSet(), context.getResources());
				str.append(weather);
			}
		}
			break;
		case TEMPERATURE: {

			ForeCast[] fcs = wi.getForecastsForCurrent(2);
			ForeCast tomorrowForecast = fcs[1];
			ForeCast todayForecast = fcs[0];

			// 更新最低最高温

			if (fcs[0] != ForeCast.EMPTY) {
				// 有今天的预报数据
				todayForecast = fcs[0];
			}
			if (fcs[1] != ForeCast.EMPTY) {
				// 有明天的预报数据
				tomorrowForecast = fcs[1];
			}
			if (fcs[0] != ForeCast.EMPTY) {
				str.append(todayForecast.getLow());
				if (todayForecast.getHigh() != WeatherInfo.INVALID_TEMPERATURE) {
					str.append(" ~ ");
					str.append(todayForecast.getHigh());
				} else {
					if (tomorrowForecast != null) {
						str.append(" ~ ");
						str.append(tomorrowForecast.getHigh());
					}
				}
				str.append("℃");
			}

		}
			break;
		case HUMIDITY: {
			if (!Utility.isOut(wi)) {
				int humidity = wi.getCondition().getHumidity();

				if (humidity != WeatherInfo.INVALID_HUMIDITY) {
					str.append("湿度：" + humidity + "%");
				}

			}
		}
			break;
		case UV: {

			String uv = wi.getLifdex().getUv();
			if (uv != null && uv.length() != 0) {
				str.append("紫外线：" + uv);
			}

		}
			break;
		case CWASH: {
			String cwash = wi.getLifdex().getCwash();
			if (cwash != null && cwash.length() != 0) {
				str.append("洗车" + (longMode ? "指数" : "") + "：" + cwash);
			}

		}
			break;
		case COLD: {
			String cold = wi.getLifdex().getCold();
			if (cold != null && cold.length() != 0) {
				str.append("感冒" + (longMode ? "指数" : "") + "：" + cold);
			}

		}
			break;
		case COMFORT: {
			String comfort = wi.getLifdex().getComfort();
			if (comfort != null && comfort.length() != 0) {
				str.append((longMode ? "舒适指数：" : "") + comfort);
			}
		}
			break;
		}
		return str.toString();

	}

	public static String getContentUserDefinedAboutWeather(TextContent mTextContent, Context context, WeatherInfo wi) {
		return getContentUserDefinedAboutWeather(mTextContent, context, wi, false);
	}

	/**
	 * 获得widget上的城市名字
	 * 
	 * @param context
	 * @param service
	 * @return
	 */
	public static String getCityName(Context context, TianQiTongService service) {
		String cityName = "";
		String[] cityCodes = new String[0];
		cityCodes = getSPStringArray(context, R.string.strs_cached_citys, ',');
		if (cityCodes.length != 0) {
			String cityCode = SPUtility.getSPString(context, R.string.str_widget_city_code);
			// 更新城市名
			cityName = service.getCityName(cityCode);
			String[] tmp = Utility.split(cityName, '.');
			cityName = tmp[tmp.length - 1];
			if (cityName.length() > 4) {
				cityName = cityName.substring(0, 3) + "...";
			}
		}
		return cityName;
	}

	/**
	 * 设置文字和天气图标
	 * 
	 * @param views
	 * @param context
	 * @param service
	 */
	private static void accordingFunctionSetTextAndIcon(RemoteViews views, Context context, TianQiTongService service) {

		// 城市的名字
		String[] cityCodes = new String[0];
		cityCodes = getSPStringArray(context, R.string.strs_cached_citys, ',');

		// 天气图标
		int iconId = R.drawable.weathericon_appwidget_17;
		WeatherInfo wi = null;
		int ycode = WeatherInfo.INVALID_YCODE;

		String temperature = "(预报已过期)";
		if (cityCodes.length != 0) {
			String cityCode = SPUtility.getSPString(context, R.string.str_widget_city_code);
			wi = service.getWeatherInfo(cityCode);
			// 这里调用这个方法是为了初始化todayForecast
			temperature = getContentUserDefinedAboutWeather(TextContent.TEMPERATURE, context, wi);
			// 更新天气图标
			// int updateType = SPUtility.getSPStringInteger(service, R.string.strint_update_type);
			// 改为了从diy中获取是实况还是预报模式
			switch (getwhichWeatherIconMode(context)) {
			case FORECAST: {

				ForeCast todayForecast = wi.getForecastsForCurrent(1)[0];

				views.setTextViewText(R.id.condition_tem, "");
				// 按次数，预报模式
				if (todayForecast != ForeCast.EMPTY) {
					ycode = todayForecast.getYcode();
					if (todayForecast.getYcode() == WeatherInfo.INVALID_YCODE) {
						ycode = todayForecast.getYcode2();

					}
				}
				break;
			}
			case CONDITION: {
				// 按间隔，实况模式
				ycode = wi.getYCodeUsingSunRiseAndSet();
				if (wi.getCondition().getTemperature() == -274)
					break;

				String tem = wi.getCondition().getTemperature() + "℃";
				if (getwhichInsert(context) == AWType._2ND_4X2) {
					tem += "(实况)";
					views.setViewVisibility(R.id.condition_tem, View.VISIBLE);
				}
				views.setTextViewText(R.id.condition_tem, tem);
				views.setTextColor(R.id.condition_tem, getTextColor(context));
				break;
			}
			default: {
				throw new IllegalStateException();
			}
			}

			int temIconId = WeatherInfo.getWeatherIconFromYahooCode(ycode, WeatherInfo.ICON_TYPE_APPWIDGET, service.getResources());
			if (temIconId != -1) {
				iconId = temIconId;
			}
		}

		// 设置字体的颜色

		int[] textViewId = { R.id.city_name, R.id.text_1, R.id.text_2 };
		for (int i = 0; i < textViewId.length; i++) {
			views.setTextColor(textViewId[i], getTextColor(context));
		}

		int text_1 = R.id.text_1;
		switch (getText_1_Function(context)) {

		case NULL: {
			views.setInt(text_1, "setVisibility", View.GONE);
		}
			break;
		case CHN_YMD: {
			views.setTextViewText(text_1, getContentUserDefinedAboutDate(TextContent.CHN_YMD, context));
		}
			break;
		case YMDW: {
			views.setTextViewText(text_1, getContentUserDefinedAboutDate(TextContent.YMDW, context));
		}
			break;
		case LongMDW: {
			views.setTextViewText(text_1, getContentUserDefinedAboutDate(TextContent.LongMDW, context));
		}
			break;
		case MDW: {
			views.setTextViewText(text_1, getContentUserDefinedAboutDate(TextContent.MDW, context));
		}
			break;
		case YMDW_CHN_MD: {
			views.setTextViewText(text_1, getContentUserDefinedAboutDate(TextContent.YMDW_CHN_MD, context));
		}
			break;
		case WEATHER: {
			views.setTextViewText(text_1, getContentUserDefinedAboutWeather(TextContent.WEATHER, context, wi));
		}
			break;
		case TEMPERATURE: {
			views.setTextViewText(text_1, temperature);
		}
			break;
		case HUMIDITY: {
			views.setTextViewText(text_1, getContentUserDefinedAboutWeather(TextContent.HUMIDITY, context, wi));
		}
			break;
		case UV: {
			views.setTextViewText(text_1, getContentUserDefinedAboutWeather(TextContent.UV, context, wi));
		}
			break;
		case CWASH: {
			views.setTextViewText(text_1, getContentUserDefinedAboutWeather(TextContent.CWASH, context, wi));
		}
			break;
		case COLD: {
			views.setTextViewText(text_1, getContentUserDefinedAboutWeather(TextContent.COLD, context, wi));
		}
			break;
		case COMFORT: {
			views.setTextViewText(text_1, getContentUserDefinedAboutWeather(TextContent.COMFORT, context, wi));
		}
			break;
		}

		int text_2 = R.id.text_2;
		switch (getText_2_Function(context)) {

		case NULL: {
			views.setInt(text_2, "setVisibility", View.GONE);
		}
			break;
		case CHN_YMD: {
			views.setTextViewText(text_2, getContentUserDefinedAboutDate(TextContent.CHN_YMD, context));
		}
			break;
		case YMDW: {
			views.setTextViewText(text_2, getContentUserDefinedAboutDate(TextContent.YMDW, context));
		}
			break;
		case LongMDW: {
			views.setTextViewText(text_2, getContentUserDefinedAboutDate(TextContent.LongMDW, context));
		}
			break;
		case MDW: {
			views.setTextViewText(text_2, getContentUserDefinedAboutDate(TextContent.MDW, context));
		}
			break;
		case YMDW_CHN_MD: {
			views.setTextViewText(text_2, getContentUserDefinedAboutDate(TextContent.YMDW_CHN_MD, context));
		}
			break;
		case WEATHER: {
			views.setTextViewText(text_2, getContentUserDefinedAboutWeather(TextContent.WEATHER, context, wi));
		}
			break;
		case TEMPERATURE: {
			views.setTextViewText(text_2, temperature);
		}
			break;
		case HUMIDITY: {
			views.setTextViewText(text_2, getContentUserDefinedAboutWeather(TextContent.HUMIDITY, context, wi));
		}
			break;
		case UV: {
			views.setTextViewText(text_2, getContentUserDefinedAboutWeather(TextContent.UV, context, wi));
		}
			break;
		case CWASH: {
			views.setTextViewText(text_2, getContentUserDefinedAboutWeather(TextContent.CWASH, context, wi));
		}
			break;
		case COLD: {
			views.setTextViewText(text_2, getContentUserDefinedAboutWeather(TextContent.COLD, context, wi));
		}
			break;
		case COMFORT: {
			views.setTextViewText(text_2, getContentUserDefinedAboutWeather(TextContent.COMFORT, context, wi));
		}
			break;
		}

		boolean remoteSetBackgroundResource = false;
		try {
			Method[] ms = View.class.getMethods();
			for (Method m : ms) {
				if (m.getName().equals("setBackgroundResource")) {
					Annotation[] as = m.getAnnotations();
					for (Annotation a : as) {
						if (a.toString().contains("RemotableViewMethod")) {
							remoteSetBackgroundResource = true;
							break;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 城市名字的位置
		switch (getCityname_Function(context)) {

		case NULL: {// 没有按钮。
			views.setInt(R.id.city_name, "setVisibility", View.GONE);
		}
			break;
		case SHOW: {// 显示按钮
			views.setInt(R.id.city_name, "setVisibility", View.VISIBLE);
			views.setTextViewText(R.id.city_name, getCityName(context, service));
			if (remoteSetBackgroundResource) {
				views.setInt(R.id.city_name, "setBackgroundResource", R.drawable.appwidget_change_city_button);
			}
			views.setOnClickPendingIntent(R.id.city_name, PendingIntentUtil.getChangeCiteName(context));

		}
			break;
		case ONLY_TEXT: {// 仅显示文字
			views.setInt(R.id.city_name, "setVisibility", View.VISIBLE);
			views.setTextViewText(R.id.city_name, getCityName(context, service));
			if (remoteSetBackgroundResource) {
				views.setInt(R.id.city_name, "setBackgroundResource", 0);
			}
			views.setOnClickPendingIntent(R.id.city_name, PendingIntentUtil.getChangeCiteName(context));

		}
			break;
		}

		// 设置天气图标
		if (ycode != WeatherInfo.INVALID_YCODE) {
			if (getwhichInsert(context) == AWType._2ND_4X2) {// 如果是新的4x2插件对天气图标进行了放大的出来
				Bitmap src = BitmapFactory.decodeResource(context.getResources(), iconId);
				final int width = src.getWidth();
				final int height = src.getHeight();
				Matrix m = new Matrix();
				m.setScale(1.32f, 1.32f);
				Bitmap b = Bitmap.createBitmap(src, 0, 0, width, height, m, true); //
				views.setImageViewBitmap(R.id.icon, b);
			} else {
				views.setImageViewResource(R.id.icon, iconId);
			}
		}

	}

	// 获得圆角图片的方法

// public static void getRoundedCornerBitmap(Bitmap bitmap, float roundPx) {
// Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
// Canvas canvas = new Canvas(bitmap);
//
// final int color = 0xff424242;
//
// final Paint paint = new Paint();
// final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
//
// final RectF rectF = new RectF(rect);
// paint.setAntiAlias(true);
// canvas.drawARGB(0, 0, 0, 0);
//
// paint.setColor(color);
// canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
// paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
// canvas.drawBitmap(bitmap, rect, rect, paint); // return
//
// }

	/**
	 * 获取背景图片
	 * 
	 * @param context
	 * @param src
	 * @return //
	 */
// public static Uri getBackgroundImage(Context context, int width, int height) {
//
// long millisecond = System.currentTimeMillis();
// final String pngPrefix = "portskinBg4x2";
//
// Bitmap bitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
// Canvas canvas = new Canvas(bitmap);
// Paint paint = new Paint();
// paint.setAlpha(getBackgroundImageAlpha(context));
// Matrix matrix = new Matrix();
//
// Bitmap src = BitmapFactory.decodeResource(context.getResources(), R.drawable.widget_bg);
//
// canvas.drawBitmap(src, matrix, paint);
// // 已经绘制了就做回收处理
// src.recycle();
//
// File dir = context.getFilesDir();
// File[] fs = dir.listFiles(new FilenameFilter() {
//
// Override
// public boolean accept(File dir, String name) {
// if (name.startsWith(pngPrefix) && name.endsWith(".png")) {
// return true;
// }
// return false;
// }
// });
// for (File f : fs) {
// f.delete();
// }
//
// Uri uri1 = null;
// {
// FileOutputStream fos = null;
// try {
// fos = context.openFileOutput(pngPrefix + millisecond + ".png", Context.MODE_WORLD_READABLE);
// } catch (FileNotFoundException e) {
// }
// File f = new File(dir, pngPrefix + millisecond + ".png");
// bitmap.compress(CompressFormat.PNG, 100, fos);
//
// uri1 = TqtContentProvider.getImageFileUri(f.getName());
//
// }
// // 保持到硬盘后作回收处理
// bitmap.recycle();
// return uri1;
//
// }

	/**
	 * 获取背景图片的颜色
	 * 
	 * @param context
	 * @param src
	 * @return
	 */
	public static Uri getBackgroundImage(Context context, int width, int height, AWType awt) {

		Bitmap bitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
		Canvas canvas = new Canvas(bitmap);

		int colorInt = DiyAppWidgetAttrUtil.getBgColor(context, whichInsert, FileGettable.CURRENT);
		int backgroundAlpha = Color.alpha(colorInt);
		if (backgroundAlpha < 10) {
			backgroundImageAlpha = backgroundAlpha;
		} else {
			backgroundImageAlpha = 255;
		}
		{
			int offint = 5;
			canvas.save();
			final Paint paint = new Paint();
			paint.setARGB(backgroundAlpha, Color.red(colorInt), Color.green(colorInt), Color.blue(colorInt));
			final Rect rect = new Rect(0 + offint, 0 + offint, width - offint, height - offint);
			final RectF rectF = new RectF(rect);
			paint.setAntiAlias(true);
			canvas.drawRoundRect(rectF, 15, 15, paint);
			paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
			canvas.drawBitmap(bitmap, rect, rect, paint);
			canvas.restore();
		}
		if (awt == AWType._1ST_4X2) {

			Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setAlpha(getBackgroundImageAlpha(context));
			Matrix matrix = new Matrix();

			Bitmap src = BitmapFactory.decodeResource(context.getResources(), R.drawable.widget_bg);

			// 获得图片的宽高
			int widthOld = src.getWidth();
			int heightOld = src.getHeight();
			// 计算缩放比例
			float scaleWidth = ((float) width) / widthOld;
			float scaleHeight = ((float) height) / heightOld;
			// 取得想要缩放的matrix参数
			matrix.postScale(scaleWidth, scaleHeight);
			canvas.drawBitmap(src, matrix, paint);
			src.recycle();
		}

		long millisecond = System.currentTimeMillis();
		final String pngPrefix = "portskincolor4x2";

		File dir = context.getFilesDir();
		File[] fs = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				if (name.startsWith(pngPrefix) && name.endsWith(".png")) {
					return true;
				}
				return false;
			}
		});
		for (File f : fs) {
			f.delete();
		}

		Uri uri1 = null;
		{
			FileOutputStream fos = null;
			try {
				fos = context.openFileOutput(pngPrefix + millisecond + ".png", Context.MODE_WORLD_READABLE);
			} catch (FileNotFoundException e) {
			}

			File f = new File(dir, pngPrefix + millisecond + ".png");
			bitmap.compress(CompressFormat.PNG, 100, fos);

			uri1 = TqtContentProvider.getImageFileUri(f.getName());

		}
		bitmap.recycle();
		return uri1;

	}

	synchronized public static RemoteViews updateAppWidget(Context context, TianQiTongService service) {

		// 更新时间
		Time _time = new Time();
		_time.setToNow();

		int hour = _time.hour;
		if (!DateFormat.is24HourFormat(context)) {
			if (hour > 12) {
				hour -= 12;
			}
		}

		int hour0 = hour / 10;
		int hour1 = hour % 10;
		int minute0 = _time.minute / 10;
		int minute1 = _time.minute % 10;

		RemoteViews views = null;

		BitmapFactory.Options opts = new BitmapFactory.Options();
		opts.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(context.getResources(), R.drawable.widget_bg, opts);

		switch (getwhichInsert(context)) {
		case _1ST_4X2: {

			views = new RemoteViews(context.getPackageName(), R.layout.appwidget);

			// views.setImageViewUri(R.id.widget_bg_color, getBackgroundImageColor(context, opts.outWidth, opts.outHeight));
			views.setImageViewUri(R.id.widget_bg, getBackgroundImage(context, opts.outWidth, opts.outHeight, AWType._1ST_4X2));

			views.setImageViewResource(R.id.widget_hour_0, _numberDrawableIds[hour0]);
			views.setImageViewResource(R.id.widget_hour_1, _numberDrawableIds[hour1]);
			views.setImageViewResource(R.id.widget_minute_0, _numberDrawableIds[minute0]);
			views.setImageViewResource(R.id.widget_minute_1, _numberDrawableIds[minute1]);
			views.setImageViewResource(R.id.icon, R.drawable.weathericon_appwidget_17);

			// 设置天气图标和钟得背景点击跳转到主程序
			views.setOnClickPendingIntent(R.id.icon, PendingIntentUtil.getTianQiTong(context));
			views.setOnClickPendingIntent(R.id.clock_bg, PendingIntentUtil.getClock(context));

			accordingFunctionGoAndSetImage(views, context, service, AWType._1ST_4X2);

			accordingFunctionSetTextAndIcon(views, context, service);

			return views;

		}

		case _2ND_4X2: {
			views = new RemoteViews(context.getPackageName(), R.layout.appwidget_2nd);
			StringBuilder timeStringBuilder = new StringBuilder();
			timeStringBuilder.append(hour0);
			timeStringBuilder.append(hour1);
			timeStringBuilder.append(":");
			timeStringBuilder.append(minute0);
			timeStringBuilder.append(minute1);
			views.setImageViewUri(R.id.widget_bg_color, getBackgroundImage(context, opts.outWidth, opts.outHeight, AWType._2ND_4X2));
			views.setTextViewText(R.id.time, timeStringBuilder.toString());
			views.setTextColor(R.id.time, getTextColor(context));

			views.setImageViewResource(R.id.icon, R.drawable.weathericon_appwidget_17);

			// 设置天气图标和钟得背景点击跳转到主程序
			views.setOnClickPendingIntent(R.id.icon, PendingIntentUtil.getTianQiTong(context));
			views.setOnClickPendingIntent(R.id.time, PendingIntentUtil.getClock(context));
			accordingFunctionGoAndSetImage(views, context, service, AWType._2ND_4X2);
			accordingFunctionSetTextAndIcon(views, context, service);
			return views;
		}
		}
		return views;
	}

	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {

		TianQiTongLog.addNormalLog("update4x2AppWidget");
		Intent i = new Intent(IntentActionConstants.ACTION_START_SERVICE_UPDATE_4x2WIDGET);
		context.startService(i);

	}

	public void onEnabled(Context context) {
		TianQiTongReciever.applyTickAlarm(context, System.currentTimeMillis());
	}

	public void onDisabled(Context context) {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
		int[] appWidget4x1Ids = appWidgetManager.getAppWidgetIds(new ComponentName(context, Widget4x1Provider.class));
		if (appWidget4x1Ids.length == 0) {
			Intent i = new Intent(IntentActionConstants.ACTION_BC_UPDATE_WIDGET_CLOCK);
			PendingIntent sender = PendingIntent.getBroadcast(context, 0, i, PendingIntent.FLAG_UPDATE_CURRENT);
			AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
			am.cancel(sender);
		}

	}

}
