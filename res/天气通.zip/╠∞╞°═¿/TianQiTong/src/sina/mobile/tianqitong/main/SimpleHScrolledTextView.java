package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Message;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

/**
 * 这个View是一个极度简化的TextView，目的是实现文字在没有焦点的情况下的卷动效果。<br>
 * 内容很简单，没啥说的。
 * 
 * @author 黄恪
 * 
 */
public class SimpleHScrolledTextView extends View {

	private TextPaint _tp = null;
	private String _text = "";

	public SimpleHScrolledTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);

		TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.SimpleHScrolledTextView);
		if (ta != null) {
			int n = ta.getIndexCount();
			for (int i = 0; i < n; i++) {
				int attr = ta.getIndex(i);

				switch (attr) {
				case R.styleable.SimpleHScrolledTextView_text: {
					_text = ta.getString(attr);
				}

					break;
				case R.styleable.SimpleHScrolledTextView_textColor: {
					_tp.setColor(ta.getColor(attr, 0xffffffff));
				}

					break;
				case R.styleable.SimpleHScrolledTextView_textSize: {
					_tp.setTextSize(ta.getDimensionPixelSize(attr, 15));
				}

					break;
				}
			}
			ta.recycle();
		}

	}

	public SimpleHScrolledTextView(Context context) {
		super(context);
		init(context);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);
		int heightSize = MeasureSpec.getSize(heightMeasureSpec);

		int width = 0;
		int height = 0;

		switch (widthMode) {
		case MeasureSpec.EXACTLY: {
			width = widthSize;
		}
			break;
		case MeasureSpec.UNSPECIFIED: {
			width = (int) _tp.measureText(_text);
		}
			break;
		case MeasureSpec.AT_MOST: {
			width = Math.min((int) _tp.measureText(_text), widthSize);
		}
			break;
		}

		switch (heightMode) {
		case MeasureSpec.EXACTLY: {
			height = heightSize;
		}
			break;
		case MeasureSpec.UNSPECIFIED: {
			height = (int) _tp.getTextSize();
		}
			break;
		case MeasureSpec.AT_MOST: {
			height = Math.min((int) _tp.getTextSize(), heightSize);
		}
			break;
		}
		setMeasuredDimension(width, height);
		_animStep = 0;
		_sCurrentOffsetX = 0L;
		_currentTimeMillis = 0L;
	}

	/*
	 * 当前文字的绘制位置，由onDraw来控制。
	 */
	private long _sCurrentOffsetX = 0L;

	/*
	 * 写死的每帧位移，位移值是这个变量除以_s
	 */
	private final static long _sOffsetX = 2000L;

	/*
	 * 为了算术保留精度用的系数
	 */
	private final static long _s = 1000L;

	/**
	 * 当前动画的阶段。公有了。想不清楚的时候别动这个！
	 */
	public int _animStep = -1;

	/*
	 * 简单动画，帧率写死。
	 */
	private static final long FRAMES_PER_SECOND = 30;

	private boolean mAnimFlag = true;

	/*
	 * 控制帧率用的时间，
	 */
	private long _currentTimeMillis = 0L;

	private static final int MSG_WHAT_0_1 = 0;
	private static final int MSG_WHAT_RE = 1;
	private static final int MSG_WHAT_2_0 = 2;

	private Handler _handler = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == MSG_WHAT_0_1) {
				_animStep = 1;
				invalidate();
				_currentTimeMillis = System.currentTimeMillis();
			} else if (msg.what == MSG_WHAT_RE) {
				invalidate();
				_currentTimeMillis = System.currentTimeMillis();
			} else if (msg.what == MSG_WHAT_2_0) {
				_animStep = 0;
				invalidate();
				_currentTimeMillis = System.currentTimeMillis();
			}

		}
	};

	@Override
	protected void onDraw(Canvas canvas) {

		if (_tp.measureText(_text) > getMeasuredWidth()) {

			// 这里的动画没有停止。
			// 动画依赖的是主线程的looper，而这个looper在应用关闭的时候，会被阻塞住。

			switch (_animStep) {
			case 0: {
				// 静止状态
				_sCurrentOffsetX = 0L;
				canvas.drawText(_text, 0, getMeasuredHeight() - 1, _tp);
				if (mAnimFlag) {
					_handler.sendEmptyMessageDelayed(MSG_WHAT_0_1, 2000L);
				}

			}
				break;
			case 1: {
				// 从静止状态向左移动
				_sCurrentOffsetX -= _sOffsetX;
				canvas.drawText(_text, _sCurrentOffsetX / _s, getMeasuredHeight() - 1, _tp);

				if (_sCurrentOffsetX / _s + _tp.measureText(_text) <= getMeasuredWidth() - _tp.getTextSize()) {
					_animStep = 2;
					invalidate();
				} else {
					if ((_currentTimeMillis - System.currentTimeMillis()) * _s > (1000L * _s / FRAMES_PER_SECOND)) {
						invalidate();
						_currentTimeMillis = System.currentTimeMillis();
					} else {
						long a = 1000L * _s / FRAMES_PER_SECOND;
						long b = _currentTimeMillis - System.currentTimeMillis();
						_handler.sendEmptyMessageDelayed(MSG_WHAT_RE, (a - b) / _s);

					}
				}

			}
				break;
			case 2: {
				// 静止状态
				canvas.drawText(_text, _sCurrentOffsetX / _s, getMeasuredHeight() - 1, _tp);

				if (_shstvs != null) {
					boolean all2 = true;
					for (SimpleHScrolledTextView v : _shstvs) {
						if (v._tp.measureText(v._text) > v.getMeasuredWidth()) {
							if (v._animStep != 2) {
								all2 = false;
								break;
							}
						} else {
							if (v._animStep != 0) {
								all2 = false;
								break;
							}
						}

					}
					if (all2) {
						for (SimpleHScrolledTextView v : _shstvs) {
							if (v._tp.measureText(v._text) > v.getMeasuredWidth()) {
								v._handler.removeMessages(MSG_WHAT_2_0);
								v._handler.sendEmptyMessageDelayed(MSG_WHAT_2_0, 2000L);
							}

						}
					}
				}
			}
			}
		} else {
			canvas.drawText(_text, 0, getMeasuredHeight() - 1, _tp);
		}
	}

	public void setText(String text) {
		_text = text;
		requestLayout();
	}

	public void setTextColor(int color) {
		_tp.setColor(color);
		invalidate();
	}

	private void init(Context context) {
		_tp = new TextPaint();
		_tp.setTextSize(15);
		_tp.setColor(0xffffffff);
		_tp.setAntiAlias(true);
	}

	public String toString() {
		return (_tp.measureText(_text) > getMeasuredWidth()) + _text;
	}

	/**
	 * 为了统一动画的一个全局数据。<br>
	 * 用的时候想清楚！
	 */
	public static SimpleHScrolledTextView[] _shstvs = null;

	public void setAnimFlag(boolean flag) {
		mAnimFlag = flag;
	}

	public boolean getAnimFlag() {
		return mAnimFlag;
	}

}
