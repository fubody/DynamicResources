package sina.mobile.tianqitong.service;

public interface Constants {
	public static final String CITY_SUFFIX = ".city";
	public static final String HISTORY_SUFFIX = ".history";
	public static final String WARNING_SUFFIX = ".warning";
	public static final String DOWNLOAD_SUFFIX = ".tqtdownload";
	public static final String NEW_VERSION_INFO_FILENAME = "newVersionInfo.xml";
	public static final String DOWNLOAD_ITEMS_FILENAME = "downloadlist.xml";
	public static final String SOUNDLIST_FILENAME = "soundList.xml";
	public static final String APPWIDGETSKIN4X1_LIST_FILENAME = "appwidget_skin_4x1.xml";
	public static final String APPWIDGETSKIN4X2_LIST_FILENAME = "appwidget_skin_4x2.xml";
	public static final String SINA_RECOMMEND_LIST_FILENAME = "sina_recommend.xml";
	public static final String ADLIST_FILENAME = "adList.xml";
	public static final String WEEK_RECOMMEND_LIST_FILENAME = "week_recommend.xml";
	public static final String UPDATE_PAST_WEATHER_DYAS = "7";
	/**
	 * 特殊的cityCode前缀。这个cityCode在向服务器取天气信息，和向城市数据取城市名称的时候，会被换成真正的cityCode。<br>
	 * 这个做法，使应用的其它位置几乎并不知道有这么一个特殊cityCode。<br>
	 * 但是也使得本来应该在上层完成的功能，渗透到了底层。
	 */
	public static final String AUTO_LOCATE_CITYCODE_PREFIX = "AUTO_LOCATE_";

	public static final String DIR_TIANQITONG = "TianQiTong";
	public static final String DIR_LOG = "Logs";
	public static final String DIR_DOWNLOAD = "Downloads";
	public static final String DIR_APPWIDGET = "AppWidgetSkin";
	public static final String DIR_APPWIDGET4x1 = "AppWidgetSkin4x1";
	public static final String DIR_TTS = "TTS";
	public static final String DIR_AD = "AD";
	public static final String DIR_CACHEBACKUP = "CACHEBACKUP";
	public static final String DIR_RECOMMEND = "SinaRecommend";
	public static final String DIR_WEEK_RECOMMEND = "WeekRecommend";

	public static final int UPDATE_TYPE_FORECAST = 0;
	public static final int UPDATE_TYPE_CONDITION = 1;
}
