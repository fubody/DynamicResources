package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getBgColor;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.putTempBgColor;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.putTempTextColor;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getTempOrCurrent;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.repaintPreview;

import java.util.HashMap;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.SeekBar;
import android.widget.TextView;

class DiyableBG extends AbstractDiyableUnit implements SeekBar.OnSeekBarChangeListener, OnClickListener {

	private int mTempTextColor = 0xff000000;

	private int mResId;

	private boolean mHasBGBitmap = false;

	private int mWidth;
	private int mHeight;

	public DiyableBG(AWType type, int w, int h) {
		super(type);
		mWidth = w;
		mHeight = h;
		mHasBGBitmap = false;
		remakeParams();
	}

	public DiyableBG(AWType type, int resId) {
		super(type);
		mResId = resId;
		mHasBGBitmap = true;
		remakeParams();
	}

	public int getTextColor() {
		return mTempTextColor;
	}

	@Override
	public void drawOnCanvas(Canvas c) {

		RectF mBGRect = new RectF(getDrawBounds());

		if (mHasBGBitmap) {
			Bitmap bg = null;
			bg = getBitmap(getActivity().getResources(), mResId);// BitmapFactory.decodeResource(getActivity().getResources(), mResId);

			int[] argbs = new int[bg.getWidth() * bg.getHeight()];
			bg.getPixels(argbs, 0, bg.getWidth(), 0, 0, bg.getWidth(), bg.getHeight());

			int minAlpha = 0x50;

			int width = bg.getWidth();

			for (int y = 0; y < bg.getHeight(); y++) {

				int left = -1;
				int right = width;

				for (int x = 0; x < bg.getWidth(); x++) {
					int cc = argbs[y * width + x];
					if (Color.alpha(cc) > minAlpha) {
						if (left == -1) {
							left = x;
						}
						right = x;
					}
				}

				if (left != -1) {
					for (int x = left; x <= right; x++) {
						argbs[y * width + x] = makeColor();
					}
				}

			}

			Bitmap tbg = Bitmap.createBitmap(bg.getWidth(), bg.getHeight(), Config.ARGB_8888);
			Canvas canvas = new Canvas(tbg);

			canvas.drawBitmap(argbs, 0, bg.getWidth(), 0, 0, bg.getWidth(), bg.getHeight(), true, null);
			argbs = null;
			canvas.drawBitmap(bg, 0, 0, null);
			bg = null;
			Paint p = new Paint();
			if (mAlpha <= 10) {
				p.setAlpha(mAlpha);
			}
			c.drawBitmap(tbg, mBGRect.left, mBGRect.top, p);
		} else {
			Paint p = new Paint();
			p.setColor(makeColor());
			p.setAntiAlias(true);
			c.drawRoundRect(mBGRect, 5f * getDensity(), 5f * getDensity(), p);
		}

	}

	@Override
	public Rect getTouchableBounds() {
		return getDrawBounds();
	}

	@Override
	protected Rect doMeasureDrawRect() {
		Rect mBGRect;
		if (mHasBGBitmap) {
			Options opts = new Options();
			opts.inJustDecodeBounds = true;
			BitmapFactory.decodeResource(getActivity().getResources(), mResId, opts);
			mBGRect = new Rect(0, 0, opts.outWidth * opts.inTargetDensity / opts.inDensity, opts.outHeight * opts.inTargetDensity / opts.inDensity);
		} else {
			mBGRect = new Rect(0, 0, mWidth, mHeight);
		}
		offsetRect(mBGRect);
		return mBGRect;
	}

	@Override
	protected void remakeParams() {
		int color = getBgColor(getActivity(), getType(), getTempOrCurrent());
		makeAHSV(color);
		mTempTextColor = DiyAppWidgetAttrUtil.getTextColor(getActivity(), getType(), getTempOrCurrent());
	}

	/**
	 * ok键按下了。需要把mTempValue存下，然后清空mTempValue。<br>
	 * 刷新内容。
	 */
	void onOkPressed() {

		if (!(getActivity() instanceof AppWidgetDiyTool)) {
			throw new IllegalStateException();
		}

		putTempBgColor(getActivity(), getType(), makeColor());
		putTempTextColor(getActivity(), getType(), mTempTextColor);

		repaintPreview(getType());
	}

	/**
	 * cancel键按下了。把清空mTempValue。<br>
	 * 刷新内容。
	 */
	void onCancelPressed() {
		if (!(getActivity() instanceof AppWidgetDiyTool)) {
			throw new IllegalStateException();
		}
		int color = getBgColor(getActivity(), getType(), getTempOrCurrent());
		makeAHSV(color);
		mTempTextColor = DiyAppWidgetAttrUtil.getTextColor(getActivity(), getType(), getTempOrCurrent());

		repaintPreview(getType());
	}

	private final AlphaDrawable mAlphaDrawable = new AlphaDrawable();
	private final HueDrawable mHueDrawable = new HueDrawable();
	private final SaturationDrawable mSaturationDrawable = new SaturationDrawable();
	private final ValueDrawable mValueDrawable = new ValueDrawable();

	private SeekBar mAlphaSeekBar;

// private SeekBar mHueSeekBar;
// private SeekBar mSaturationSeekBar;
// private SeekBar mValueSeekBar;

	@Override
	public View[] makeOptions() {

		DisplayMetrics dm = new DisplayMetrics();
		getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
		final float density = dm.density;

		View[] r = new View[6];

		{
			LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
			TextView tv = new TextView(getActivity());
			tv.setText("背景颜色");
			tv.setLayoutParams(lllp);
			r[0] = tv;
		}

		{

			LayoutInflater li = getActivity().getLayoutInflater();

			View item = li.inflate(R.layout.awdt_bgclr_selector, null);
			int[] ids = new int[] { R.id.bgbtn00, R.id.bgbtn01, R.id.bgbtn02, R.id.bgbtn03, R.id.bgbtn04, R.id.bgbtn05, R.id.bgbtn06, R.id.bgbtn07, R.id.bgbtn08, R.id.bgbtn09, R.id.bgbtn10,
					R.id.bgbtn11 };
			for (int id : ids) {
				View v = item.findViewById(id);
				v.setOnClickListener(this);
			}
			LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
			item.setLayoutParams(lllp);
			r[1] = item;

		}

		{
			LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
			TextView tv = new TextView(getActivity());
			tv.setText("背景透明度");
			tv.setLayoutParams(lllp);
			r[2] = tv;
		}

		{
			mAlphaSeekBar = new SeekBar(getActivity());
			mAlphaSeekBar.setMax(100);
			mAlphaSeekBar.setProgressDrawable(mAlphaDrawable);
			mAlphaSeekBar.setOnSeekBarChangeListener(this);

			LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams((int) (density * 200f), LayoutParams.WRAP_CONTENT);
			lllp.gravity = Gravity.CENTER;
			mAlphaSeekBar.setLayoutParams(lllp);
			r[3] = mAlphaSeekBar;
		}

// {
// LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
// lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
// TextView tv = new TextView(getActivity());
// tv.setText("背景色相");
// tv.setLayoutParams(lllp);
// r[2] = tv;
// }
//
// {
// mHueSeekBar = new SeekBar(getActivity());
// mHueSeekBar.setMax(360);
//
// mHueSeekBar.setProgressDrawable(mHueDrawable);
//
// mHueSeekBar.setOnSeekBarChangeListener(this);
//
// LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams((int) (density * 200f), LayoutParams.WRAP_CONTENT);
// lllp.gravity = Gravity.CENTER;
// mHueSeekBar.setLayoutParams(lllp);
// r[3] = mHueSeekBar;
// }
//
// {
// LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
// lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
// TextView tv = new TextView(getActivity());
// tv.setText("背景饱和度");
// tv.setLayoutParams(lllp);
// r[4] = tv;
// }
//
// {
// mSaturationSeekBar = new SeekBar(getActivity());
// mSaturationSeekBar.setMax(100);
//
// mSaturationSeekBar.setProgressDrawable(mSaturationDrawable);
//
// mSaturationSeekBar.setOnSeekBarChangeListener(this);
//
// LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams((int) (density * 200f), LayoutParams.WRAP_CONTENT);
// lllp.gravity = Gravity.CENTER;
// mSaturationSeekBar.setLayoutParams(lllp);
// r[5] = mSaturationSeekBar;
// }
//
// {
// LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
// lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
// TextView tv = new TextView(getActivity());
// tv.setText("背景明亮度");
// tv.setLayoutParams(lllp);
// r[6] = tv;
// }
//
// {
// mValueSeekBar = new SeekBar(getActivity());
// mValueSeekBar.setMax(100);
//
// mValueSeekBar.setProgressDrawable(mValueDrawable);
//
// mValueSeekBar.setOnSeekBarChangeListener(this);
//
// LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams((int) (density * 200f), LayoutParams.WRAP_CONTENT);
// lllp.gravity = Gravity.CENTER;
// mValueSeekBar.setLayoutParams(lllp);
// r[7] = mValueSeekBar;
// }

		{
			LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
			TextView tv = new TextView(getActivity());
			tv.setText("文字颜色");
			tv.setLayoutParams(lllp);
			r[4] = tv;
		}

		{

			LayoutInflater li = getActivity().getLayoutInflater();
			View item = li.inflate(R.layout.awdt_txtclr_selector, null);
			int[] ids = new int[] { R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5, R.id.btn6 };
			for (int id : ids) {
				View v = item.findViewById(id);
				v.setOnClickListener(this);
			}
			LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			lllp.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
			item.setLayoutParams(lllp);
			r[5] = item;

		}

		return r;
	}

	@Override
	protected void prepareOptions(View[] options) {

// float hsv[] = new float[3];
// Color.colorToHSV(mTempColor, hsv);
// mAlpha = Color.alpha(mTempColor);
//
// mHue = hsv[0];
// mSaturation = hsv[1];
// mValue = hsv[2];

		mAlphaSeekBar.setProgress(mAlpha * 100 / 255);
// mHueSeekBar.setProgress((int) mHue);
// mSaturationSeekBar.setProgress((int) (mSaturation * 100f));
// mValueSeekBar.setProgress((int) (mValue * 100f));

	}

	float mHue, mSaturation, mValue;
	int mAlpha;

	class HueDrawable extends Drawable {

		@Override
		public void draw(Canvas canvas) {

			float d = (float) canvas.getDensity() / 160f;
			int h = (int) (10f * d);
			int y = (getBounds().bottom - getBounds().top - h) / 2 + getBounds().top;

			canvas.clipRect(new Rect(getBounds().left, y, getBounds().right, y + h));

			int w = getBounds().right - getBounds().left;

			int tw = (int) (mHue * (float) w / 360f);
			Paint p = new Paint();
			p.setColor(Color.HSVToColor(0xff, new float[] { mHue, mSaturation, mValue }));
			canvas.drawRect(new Rect(getBounds().left, getBounds().top, getBounds().left + tw, getBounds().bottom), p);

			for (int x = getBounds().left + tw; x < getBounds().right; x++) {

				float hue = (360f * (float) (x - getBounds().left)) / (float) (getBounds().right - getBounds().left);
				p = new Paint();
				p.setColor(Color.HSVToColor(0xff, new float[] { hue, mSaturation, mValue }));
				canvas.drawLine(x, y, x, y + h, p);

			}

			canvas.clipRect(getBounds());

		}

		@Override
		public void setAlpha(int alpha) {

		}

		@Override
		public void setColorFilter(ColorFilter cf) {

		}

		@Override
		public int getOpacity() {
			return 0;
		}

	}

	class SaturationDrawable extends Drawable {

		@Override
		public void draw(Canvas canvas) {

			float d = (float) canvas.getDensity() / 160f;
			int h = (int) (10f * d);
			int y = (getBounds().bottom - getBounds().top - h) / 2 + getBounds().top;

			canvas.clipRect(new Rect(getBounds().left, y, getBounds().right, y + h));

			int w = getBounds().right - getBounds().left;

			int tw = (int) (mSaturation * (float) w);
			Paint p = new Paint();
			p.setColor(Color.HSVToColor(0xff, new float[] { mHue, mSaturation, mValue }));
			canvas.drawRect(new Rect(getBounds().left, getBounds().top, getBounds().left + tw, getBounds().bottom), p);

			for (int x = getBounds().left + tw; x < getBounds().right; x++) {

				float saturation = (float) (x - getBounds().left) / (float) (getBounds().right - getBounds().left);
				p = new Paint();
				p.setColor(Color.HSVToColor(0xff, new float[] { mHue, saturation, mValue }));
				canvas.drawLine(x, y, x, y + h, p);

			}

			canvas.clipRect(getBounds());

		}

		@Override
		public void setAlpha(int alpha) {

		}

		@Override
		public void setColorFilter(ColorFilter cf) {

		}

		@Override
		public int getOpacity() {
			return 0;
		}

	}

	class ValueDrawable extends Drawable {

		@Override
		public void draw(Canvas canvas) {

			float d = (float) canvas.getDensity() / 160f;
			int h = (int) (10f * d);
			int y = (getBounds().bottom - getBounds().top - h) / 2 + getBounds().top;

			canvas.clipRect(new Rect(getBounds().left, y, getBounds().right, y + h));

			int w = getBounds().right - getBounds().left;

			int tw = (int) (mValue * (float) w);
			Paint p = new Paint();
			p.setColor(Color.HSVToColor(0xff, new float[] { mHue, mSaturation, mValue }));
			canvas.drawRect(new Rect(getBounds().left, getBounds().top, getBounds().left + tw, getBounds().bottom), p);

			for (int x = getBounds().left + tw; x < getBounds().right; x++) {

				float value = (float) (x - getBounds().left) / (float) (getBounds().right - getBounds().left);
				p = new Paint();
				p.setColor(Color.HSVToColor(0xff, new float[] { mHue, mSaturation, value }));
				canvas.drawLine(x, y, x, y + h, p);

			}

			canvas.clipRect(getBounds());

		}

		@Override
		public void setAlpha(int alpha) {

		}

		@Override
		public void setColorFilter(ColorFilter cf) {

		}

		@Override
		public int getOpacity() {
			return 0;
		}

	}

	class AlphaDrawable extends Drawable {

		@Override
		public void draw(Canvas canvas) {

			float d = (float) canvas.getDensity() / 160f;
			int h = (int) (10f * d);
			int y = (getBounds().bottom - getBounds().top - h) / 2 + getBounds().top;

			int boxw = (int) (10f * d);

			int w = getBounds().right - getBounds().left;

			canvas.clipRect(new Rect(getBounds().left, y, getBounds().right, y + h));

			for (int tx = getBounds().left; tx < getBounds().right + boxw; tx += boxw) {
				for (int ty = y; ty < y + h + boxw; ty += boxw) {
					boolean x2 = (tx / boxw) % 2 == 0;
					boolean y2 = (ty / boxw) % 2 == 0;
					Rect rect = new Rect(tx, ty, tx + boxw, ty + boxw);
					Paint p = new Paint();
					p.setStyle(Style.FILL_AND_STROKE);
					if (x2 && y2) {
						p.setColor(Color.GRAY);
					} else if ((!x2) && (!y2)) {
						p.setColor(Color.GRAY);
					} else {
						p.setColor(Color.WHITE);
					}
					canvas.drawRect(rect, p);
				}
			}

			Paint p = new Paint();
			p.setStyle(Style.FILL_AND_STROKE);

			p.setColor(makeColor());
			p.setAlpha(mAlpha);

			float alpha = ((float) mAlpha) / 255f;

			Rect rect = new Rect(getBounds().left, getBounds().top, getBounds().left + (int) (alpha * (float) w), getBounds().bottom);
			canvas.drawRect(rect, p);

			canvas.clipRect(getBounds());

		}

		@Override
		public void setAlpha(int alpha) {

		}

		@Override
		public void setColorFilter(ColorFilter cf) {

		}

		@Override
		public int getOpacity() {
			return 0;
		}

	}

	private int makeColor() {
		return Color.HSVToColor(mAlpha, new float[] { mHue, mSaturation, mValue });
	}

	private void makeAHSV(int color) {

		mAlpha = Color.alpha(color);
		makeHSVWithoutA(color);
	}

	private void makeHSVWithoutA(int color) {
		float hsv[] = new float[3];
		Color.colorToHSV(color, hsv);

		mHue = hsv[0];
		mSaturation = hsv[1];
		mValue = hsv[2];
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		if (fromUser) {
			if (seekBar == mAlphaSeekBar) {
				mAlpha = progress * 255 / 100;
// } else if (seekBar == mHueSeekBar) {
// mHue = (float) progress;
// } else if (seekBar == mSaturationSeekBar) {
// mSaturation = (float) progress / 100f;
// } else if (seekBar == mValueSeekBar) {
// mValue = (float) progress / 100f;
			}
			mHueDrawable.invalidateSelf();
			mSaturationDrawable.invalidateSelf();
			mValueDrawable.invalidateSelf();
			mAlphaDrawable.invalidateSelf();
		}

	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
// mTempColor = makeColor();
		repaintPreview(getType());

	}

	@Override
	public String getOptionsTitle() {
		return "设置背景颜色和文字颜色";
	}

	private HashMap<Integer, Integer> mTxtId2ClrMap;
	private HashMap<Integer, Integer> mBgId2ClrMap;

	private HashMap<Integer, Integer> getTxtId2ClrMap() {
		if (mTxtId2ClrMap == null) {
			mTxtId2ClrMap = new HashMap<Integer, Integer>();
			int[] txtids = new int[] { R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4, R.id.btn5, R.id.btn6 };
			int[] txtclrs = new int[] { 0xff000000, 0xfffffffe, 0xfffed998, 0xff81f5ff, 0xff9fffce, 0xff5e360b, 0xffca9fff };// 0xffffffff是-1，会导致错误
			for (int i = 0; i < txtids.length; i++) {
				mTxtId2ClrMap.put(txtids[i], txtclrs[i]);
			}
		}
		return mTxtId2ClrMap;
	}

	private HashMap<Integer, Integer> getBgId2ClrMap() {
		if (mBgId2ClrMap == null) {
			mBgId2ClrMap = new HashMap<Integer, Integer>();
			int[] bgids = new int[] { R.id.bgbtn00, R.id.bgbtn01, R.id.bgbtn02, R.id.bgbtn03, R.id.bgbtn04, R.id.bgbtn05, R.id.bgbtn06, R.id.bgbtn07, R.id.bgbtn08, R.id.bgbtn09, R.id.bgbtn10,
					R.id.bgbtn11 };
			int[] bgclrs = new int[] { 0xff34c3ff, 0xff50ceb6, 0xff98f217, 0xfff0ca1c, 0xfff88d00, 0xff888888, 0xff3f4ccf, 0xff9832d3, 0xfffe97aa, 0xffe72a0c, 0xff52072e, 0xff272727 };
			for (int i = 0; i < bgids.length; i++) {
				mBgId2ClrMap.put(bgids[i], bgclrs[i]);
			}
		}
		return mBgId2ClrMap;
	}

	@Override
	public void onClick(View v) {

		Integer clr = getTxtId2ClrMap().get(v.getId());
		if (clr != null) {
			mTempTextColor = clr.intValue();
		}

		clr = getBgId2ClrMap().get(v.getId());
		if (clr != null) {
			int color = clr.intValue();
			makeHSVWithoutA(color);
		}

		mAlphaDrawable.invalidateSelf();

		repaintPreview(getType());
	}

}
