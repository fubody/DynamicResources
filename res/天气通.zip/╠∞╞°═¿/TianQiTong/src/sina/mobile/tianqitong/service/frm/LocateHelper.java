package sina.mobile.tianqitong.service.frm;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_GET_CITYCODE_VIA_NAUTICA;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_CITYCODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_CITYNAME;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_FAILED_CAN_NOT_DO_IT_AGAIN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_LOCATE_TIME_OUT;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_NO_LOCATION_PROVIDER;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SUCCESSFUL;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_USER_CANCELED;
import static sina.mobile.tianqitong.service.frm.MsgUtility.sendResponse;

import java.lang.ref.WeakReference;
import java.util.HashSet;

import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.TianQiTongNetwork;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.utility.CityUtil;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

/**
 * 定位模块，可以执行MSG_ARG2_GET_CITYCODE_VIA_NAUTICA事件。<br>
 * 再定位过程中再次定位会直接返回RESPONSE_CODE_FAILED_CAN_NOT_DO_IT_AGAIN。<br>
 * 定位超时时间10s，超时之后，没有缓存城市，返回RESPONSE_CODE_COMMON_FAILED，<br>
 * 有缓存城市，返回RESPONSE_CODE_LOCATE_TIME_OUT并带回缓存的城市号。<br>
 * 没有设备，返回RESPONSE_CODE_NO_LOCATION_PROVIDER。<br>
 * 成功，返回成功，并带回城市号。<br>
 * 
 * @author 黄恪
 * 
 */
public class LocateHelper extends MsgRequestExecutorHelper {

	private static LocateHelper gInstance;

	private WeakReference<TianQiTongService> mWrService;

	private LocationListener mNetworkListener = null;
	private LocationListener mGpsListener = null;

	private LocateHelper(TianQiTongService service) {
		mWrService = new WeakReference<TianQiTongService>(service);
		mNetworkListener = new NetworkListener();
		mGpsListener = new GpsListener();
	}

	public static final LocateHelper getInstance(TianQiTongService service) {
		boolean invalidInstance = gInstance == null || gInstance.mWrService.get() == null;
		if (invalidInstance) {
			if (service == null) {
				throw new IllegalStateException();
			} else {
				gInstance = new LocateHelper(service);
			}
		}
		return gInstance;
	}

	public static final void clearInstance() {
		gInstance = null;
	}

	private int mCurrentLocatingRequestNum = -1;

	@Override
	public void executeRequest(int event, final int requestNum, Bundle args) {
		switch (event) {
		case MSG_ARG2_GET_CITYCODE_VIA_NAUTICA: {

			if (mCurrentLocatingRequestNum != -1) {
				// 定位中，不允许再定位
				Bundle b = new Bundle();
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_FAILED_CAN_NOT_DO_IT_AGAIN);
				sendResponse(requestNum, b);
				return;
			}

			mCanceled = false;

			mCurrentLocatingRequestNum = requestNum;

			

			if (mCanceled) {
				stopLocate();
				Bundle b = new Bundle();
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
				sendResponse(mCurrentLocatingRequestNum, b);
				mCurrentLocatingRequestNum = -1;
				return;
			}

			LocationManager locationManager = (LocationManager) mWrService.get().getSystemService(Context.LOCATION_SERVICE);

			
			if (mCanceled) {
				stopLocate();
				Bundle b = new Bundle();
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
				sendResponse(mCurrentLocatingRequestNum, b);
				mCurrentLocatingRequestNum = -1;
				return;
			}

			boolean networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
			boolean gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
			

			if (!networkEnabled && !gpsEnabled) {

				if (mCanceled) {
					stopLocate();
					Bundle b = new Bundle();
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
					sendResponse(mCurrentLocatingRequestNum, b);
					mCurrentLocatingRequestNum = -1;
					return;
				}

				// 没找到设备
				Bundle b = new Bundle();
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NO_LOCATION_PROVIDER);
				sendResponse(requestNum, b);
				mCurrentLocatingRequestNum = -1;
				return;
			} else if (!networkEnabled && gpsEnabled) {
				updateLocation(locationManager, LocationManager.GPS_PROVIDER, mTimeOutRunnable, mGpsListener);

			} else if (networkEnabled && !gpsEnabled) {
				updateLocation(locationManager, LocationManager.NETWORK_PROVIDER, mTimeOutRunnable, mNetworkListener);
			} else {
				updateLocation(locationManager, LocationManager.GPS_PROVIDER, mNetworkLocation, mGpsListener);
			}
			break;
		}
		}

	}

	// #ifdef DEBUG_LOCATE
// @ private static int gIdxOfMockNatica = 0;
// @ private static double[][] gMockNautica = new double[][] { { 39.904214, 116.407413 },// 北京，CHXX0008
// @ { 39.909965, 116.656437 },// WMXX1307,通州
// @ { 39.909965, 116.656437 },// WMXX1307,通州
// @ { 39.630476, 118.180407 },// CHXX0131,唐山
// @ { 39.630476, 118.180407 },// CHXX0131,唐山
// @ { 39.935377, 119.600492 },// WMXX1038,秦皇岛
// @ { 39.8345965, 119.4845224 } // WMXX1689,秦皇岛.北戴河
// @
// @ };
	// #endif

	private void updateLocation(LocationManager locationManager, String provider, Runnable locationRunnable, LocationListener listener) {

		if (mCanceled) {
			stopLocate();
			Bundle b = new Bundle();
			b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
			sendResponse(mCurrentLocatingRequestNum, b);
			mCurrentLocatingRequestNum = -1;
			return;
		}

		locationManager.removeUpdates(mNetworkListener);
		locationManager.removeUpdates(mGpsListener);
		locationManager.requestLocationUpdates(provider, 0, 0, listener);
		_handler.postDelayed(locationRunnable, 6L * 1000L);
	}

	private class NetworkListener implements LocationListener {

		@Override
		public void onLocationChanged(final Location location) {
			if (mCurrentLocatingRequestNum != -1) {
				_handler.removeCallbacks(mTimeOutRunnable);
				_handler.post(new Runnable() {

					@Override
					public void run() {
						getLocation(location);
					}

				});
			} else {
				throw new IllegalStateException();
			}
		}

		@Override
		public void onProviderDisabled(String provider) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

	}

	private class GpsListener implements LocationListener {

		@Override
		public void onLocationChanged(final Location location) {
			if (mCurrentLocatingRequestNum != -1) {
				_handler.removeCallbacks(mNetworkLocation);
				_handler.removeCallbacks(mTimeOutRunnable);
				_handler.post(new Runnable() {

					@Override
					public void run() {
						getLocation(location);

					}

				});
			} else {
				throw new IllegalStateException();
			}
		}

		@Override
		public void onProviderDisabled(String provider) {
		}

		@Override
		public void onProviderEnabled(String provider) {
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
		}

	}

	private void getLocation(Location location) {

		if (mCanceled) {
			stopLocate();
			Bundle b = new Bundle();
			b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
			sendResponse(mCurrentLocatingRequestNum, b);
			mCurrentLocatingRequestNum = -1;
			return;
		}

		String[] temp = new String[2];
		temp[0] = location.getLatitude() + "";
		temp[1] = location.getLongitude() + "";
		stopLocate();

		String cityCode = CityUtil.getCityCodeViaNautica(mWrService.get().getResources(), Double.parseDouble(temp[0]), Double.parseDouble(temp[1]));

		cityCode = Constants.AUTO_LOCATE_CITYCODE_PREFIX + cityCode;

		Bundle b = new Bundle();
		b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_SUCCESSFUL);
		b.putString(MSG_DATA_KEY_STR_CITYCODE, cityCode);
		sendResponse(mCurrentLocatingRequestNum, b);
		mCurrentLocatingRequestNum = -1;
		return;
	}

	private Runnable mNetworkLocation = new Runnable() {

		@Override
		public void run() {
			if (mCurrentLocatingRequestNum != -1) {
				LocationManager locationManager = (LocationManager) mWrService.get().getSystemService(Context.LOCATION_SERVICE);
				updateLocation(locationManager, LocationManager.NETWORK_PROVIDER, mTimeOutRunnable, mNetworkListener);
			} else {
				throw new IllegalStateException();
			}
		}

	};

	private Runnable mTimeOutRunnable = new Runnable() {
		@Override
		public void run() {
			if (mCurrentLocatingRequestNum != -1) {

				if (mCanceled) {
					stopLocate();
					Bundle b = new Bundle();
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
					sendResponse(mCurrentLocatingRequestNum, b);
					mCurrentLocatingRequestNum = -1;
					return;
				}

				Location lastKnownLocation = null;
				{
					LocationManager locationManager = (LocationManager) mWrService.get().getSystemService(Context.LOCATION_SERVICE);
					Location lastKnownNetLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
					Location lastKnownGpsLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
					if (lastKnownNetLocation == null) {
						if (lastKnownGpsLocation == null) {
							lastKnownLocation = null;
						} else {
							lastKnownLocation = lastKnownGpsLocation;
						}
					} else {
						if (lastKnownGpsLocation == null) {
							lastKnownLocation = lastKnownNetLocation;
						} else {
							lastKnownLocation = isBetterLocation(lastKnownNetLocation, lastKnownGpsLocation) ? lastKnownNetLocation : lastKnownGpsLocation;
						}
					}
				}

				stopLocate();
				if (lastKnownLocation == null) {
					Bundle b = new Bundle();
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_LOCATE_TIME_OUT);
					sendResponse(mCurrentLocatingRequestNum, b);
					mCurrentLocatingRequestNum = -1;
					return;
				} else {
					String[] temp = new String[2];
					temp[0] = lastKnownLocation.getLatitude() + "";
					temp[1] = lastKnownLocation.getLongitude() + "";
					stopLocate();

					String cityCode = CityUtil.getCityCodeViaNautica(mWrService.get().getResources(), Double.parseDouble(temp[0]), Double.parseDouble(temp[1]));
					String cityName = CityUtil.getSubCityName(mWrService.get().getResources(), cityCode);

					Bundle b = new Bundle();
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_LOCATE_TIME_OUT);
					b.putString(MSG_DATA_KEY_STR_CITYCODE, Constants.AUTO_LOCATE_CITYCODE_PREFIX + cityCode);
					b.putString(MSG_DATA_KEY_STR_CITYNAME, cityName);
					sendResponse(mCurrentLocatingRequestNum, b);
					mCurrentLocatingRequestNum = -1;
					return;
				}
			} else {
				throw new IllegalStateException();
			}

		}
	};

	@Override
	public int[] getValidEvents() {
		return new int[] { MSG_ARG2_GET_CITYCODE_VIA_NAUTICA };
	}

	private void stopLocate() {
		_handler.removeCallbacks(mTimeOutRunnable);
		_handler.removeCallbacks(mNetworkLocation);
		LocationManager locationManager = (LocationManager) mWrService.get().getSystemService(Context.LOCATION_SERVICE);
		locationManager.removeUpdates(mNetworkListener);
		locationManager.removeUpdates(mGpsListener);
	}

	private boolean mCanceled = false;

	public void cancelLocate() {
		if (mCurrentLocatingRequestNum != -1) {
			mCanceled = true;
		}
	}

	public void stopLocateAndSendResponseTimeOut() {
		if (mCurrentLocatingRequestNum != -1) {
			stopLocate();
			Bundle b = new Bundle();
			b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_LOCATE_TIME_OUT);
			sendResponse(mCurrentLocatingRequestNum, b);
			mCurrentLocatingRequestNum = -1;
		}
	}

	private static final int TWO_MINUTES = 1000 * 60 * 2;

	/**
	 * Determines whether one Location reading is better than the current Location fix
	 * 
	 * @param location
	 *            The new Location that you want to evaluate
	 * @param currentBestLocation
	 *            The current Location fix, to which you want to compare the new one
	 */
	private static boolean isBetterLocation(Location location, Location currentBestLocation) {
		if (currentBestLocation == null) {
			// A new location is always better than no location
			return true;
		}

		// Check whether the new location fix is newer or older
		long timeDelta = location.getTime() - currentBestLocation.getTime();
		boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
		boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
		boolean isNewer = timeDelta > 0;

		// If it's been more than two minutes since the current location, use the new location
		// because the user has likely moved
		if (isSignificantlyNewer) {
			return true;
			// If the new location is more than two minutes older, it must be worse
		} else if (isSignificantlyOlder) {
			return false;
		}

		// Check whether the new location fix is more or less accurate
		int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
		boolean isLessAccurate = accuracyDelta > 0;
		boolean isMoreAccurate = accuracyDelta < 0;
		boolean isSignificantlyLessAccurate = accuracyDelta > 200;

		// Check if the old and new location are from the same provider
		boolean isFromSameProvider = isSameProvider(location.getProvider(), currentBestLocation.getProvider());

		// Determine location quality using a combination of timeliness and accuracy
		if (isMoreAccurate) {
			return true;
		} else if (isNewer && !isLessAccurate) {
			return true;
		} else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
			return true;
		}
		return false;
	}

	/** Checks whether two providers are the same */
	private static boolean isSameProvider(String provider1, String provider2) {
		if (provider1 == null) {
			return provider2 == null;
		}
		return provider1.equals(provider2);
	}

}
