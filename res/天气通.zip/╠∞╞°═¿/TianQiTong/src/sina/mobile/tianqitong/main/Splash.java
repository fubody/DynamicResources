package sina.mobile.tianqitong.main;

import java.lang.ref.WeakReference;
import java.util.Timer;
import java.util.TimerTask;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.citymanager.CitySelector;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.MsgResponseHandler;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import cn.sina.mobileads.Ad;
import cn.sina.mobileads.AdListener;
import cn.sina.mobileads.AdRequest;
import cn.sina.mobileads.AdRequest.ErrorCode;
import cn.sina.mobileads.SinaADSDK;
import cn.sina.mobileads.view.FlashAd;

public class Splash extends Activity implements ServiceConnection, AdListener, MsgResponseHandler {

	private FlashAd mFlashAd = null;
	private int mDismissFlashAd = 0;
	private int mDismissInFlash = 0;
	private boolean mIsCitySelector = false;
	private Handler mHandler;
	private Timer mTimer;
	private boolean mFlag = true;
	private TianQiTongService mService = null;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (mFlag) {
			SinaADSDK sdk = SinaADSDK.getInstance();
	        sdk.initSDK(Splash.this);

			mHandler = new Handler() {

				@Override
				public void handleMessage(Message msg) {
					switch (msg.what) {
					case 1:
						mDismissFlashAd++;
						if (mDismissFlashAd == 2) {
							if (mIsCitySelector) {
								String suggestion = checkCompatible();
								if(suggestion.equals("")){
									Intent i = new Intent(Splash.this, CitySelector.class);
									startActivityForResult(i, 0);
									overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
								}else{
									//不支持的分辨率
									showSupportNotDialog(suggestion);
									
								}
								
							} else {
								String suggestion = checkCompatible();
								if(suggestion.equals("")){
									startActivity(new Intent(Splash.this, MainActivity.class));
									overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
									finish();
								}else{
									//不支持的分辨率
									showSupportNotDialog(suggestion);
									
								}
								
							}
						}
						break;
					}
					super.handleMessage(msg);
				}

			};
			mTimer = new Timer();
			
			requestWindowFeature(Window.FEATURE_NO_TITLE);
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

		}
		
		setContentView(R.layout.splash);
		findViewById(R.id.splash_layout).setDrawingCacheEnabled(true);

		if (mFlag) {
			// 直接绑定
			Intent i = new Intent(Splash.this, TianQiTongService.class);
			bindService(i, Splash.this, BIND_AUTO_CREATE);
			
		}else{
			new Thread() {
				public void run() {
					try {
						Thread.sleep(1000L);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					// 直接绑定
					Intent i = new Intent(Splash.this, TianQiTongService.class);
					bindService(i, Splash.this, BIND_AUTO_CREATE);
				}
			}.start();
		}
		

	}

	public void onDestroy() {
		if (mFlag) {
			mFlashAd.destroy();
			SinaADSDK.getInstance().releaseSDK();
		}
		super.onDestroy();
		String[] cityCodes = SPUtility.getSPStringArray(Splash.this, R.string.strs_cached_citys, ',');
		if (cityCodes.length == 0) {
			try {
				unbindService(this);
			} catch (Exception e) {

			}

			stopService(new Intent(this, TianQiTongService.class));
		} else {
			unbindService(this);
		}
	}

	public void onActivityResult(int requestCode, int responseCode, Intent data) {
		switch (responseCode) {
		case Activity.RESULT_OK: {
			Intent i = new Intent(this, MainActivity.class);
			i.putExtra(IntentActionConstants.INTENT_EXTRA_FIRST_RUN, true);
			startActivity(i);
		}
		}
		finish();

	}

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		mService = ((TianQiTongService.TianQiTongBinder) service).getService();
		{
			// 维持这个Service不会因为解绑被干掉。
			Intent i = new Intent(this, TianQiTongService.class);
			startService(i);
		}

		String[] cityCodes = mService.getCityCodes();
		if (cityCodes.length == 0) {
			if (mFlag) {
				mDismissFlashAd++;
				mDismissInFlash++;
				mIsCitySelector = true;
				if (mDismissFlashAd == 2 || mDismissFlashAd == 2) {
					String suggestion = checkCompatible();
					if(suggestion.equals("")){
						Intent i = new Intent(Splash.this, CitySelector.class);
						startActivityForResult(i, 0);
						overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
					}else{
						//不支持的分辨率
						showSupportNotDialog(suggestion);
						
					}
					
				}
			} else {
				String suggestion = checkCompatible();
				if(suggestion.equals("")){
					Intent i = new Intent(Splash.this, CitySelector.class);
					startActivityForResult(i, 0);
					overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
				}else{
					//不支持的分辨率
					showSupportNotDialog(suggestion);
					
				}
			}

		} else {
			if (mFlag) {
				mDismissFlashAd++;
				mDismissInFlash++;
				mIsCitySelector = false;
				if (mDismissFlashAd == 2 || mDismissFlashAd == 2) {
					String suggestion = checkCompatible();
					if(suggestion.equals("")){
						startActivity(new Intent(Splash.this, MainActivity.class));
						overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
						finish();
					}else{
						//不支持的分辨率
						showSupportNotDialog(suggestion);
						
					}
				}
			} else {
				String suggestion = checkCompatible();
				if(suggestion.equals("")){
					startActivity(new Intent(Splash.this, MainActivity.class));
					overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
					finish();
				}else{
					//不支持的分辨率
					showSupportNotDialog(suggestion);
					
				}
				
			}

		}

	}

	@Override
	public void onServiceDisconnected(ComponentName name) {

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onStart() {
		if (mFlag) {
			final String posid = "pos4ef01951626bc"; // 广告位id
			// final String posid = "pos4e783f3a630e3"; // 广告位id
			mFlashAd = new FlashAd(Splash.this, posid);
			AdRequest adRequest = new AdRequest();
			mFlashAd.setAdListener(Splash.this);
			mFlashAd.loadAd(adRequest);
		}

		super.onStart();
	}

	@Override
	public void onDismissScreen(Ad arg0) {
		if (mFlag) {
			mDismissInFlash++;
			if (mDismissInFlash == 2) {
				if (mIsCitySelector) {
					String suggestion = checkCompatible();
					if(suggestion.equals("")){
						Intent i = new Intent(Splash.this, CitySelector.class);
						startActivityForResult(i, 0);
						overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
					}else{
						//不支持的分辨率
						showSupportNotDialog(suggestion);
						
					}
					
				} else {
					String suggestion = checkCompatible();
					if(suggestion.equals("")){
						startActivity(new Intent(Splash.this, MainActivity.class));
						overridePendingTransition(R.anim.fade_in, R.anim.scale_2_small);
						finish();
					}else{
						//不支持的分辨率
						showSupportNotDialog(suggestion);
						
					}
				}
			}

		}
	}

	@Override
	public void onFailedToReceiveAd(Ad arg0, ErrorCode arg1) {
		if (mFlag) {
			mTimer.schedule(new TimerTask() {

				@Override
				public void run() {
					Message message = new Message();
					message.what = 1;
					mHandler.sendMessage(message);

				}

			}, 1000);

		}

	}

	@Override
	public void onHideBanner(Ad arg0) {

	}

	@Override
	public void onLeaveApplication(Ad arg0) {

	}

	@Override
	public void onPresentScreen(Ad arg0) {

	}

	@Override
	public void onReceiveAd(Ad arg0) {
		if (mFlag) {
			mFlashAd.show();
		}
	}
	
	private String checkCompatible(){
		String size = Splash.this.getString(R.string.size);
		boolean isCompatible = false;
		DisplayMetrics dm = getResources().getDisplayMetrics();
		int height = dm.heightPixels;
		int width = dm.widthPixels;
		if("large".equals(size)){
			if(width == 800 && height == 1280){
				return "";
			}else{
				//不支持
				String dpi = Splash.this.getString(R.string.dpi);
				String aspect = Splash.this.getString(R.string.aspect);
				return size + "-" + aspect + "-" + dpi;
			}
			
		}else{
			String resolution = width + "x" + height;
			//"640x960", "480x640" added by Maojianwei
			String []metrics = new String[]{"480x800","320x480","540x960","480x854","240x320","720x1280", "640x960", "480x640","720x1184","800x1280","240x400"};

			for(int i = 0; i < metrics.length; i ++){
				if(resolution.equals(metrics[i])){
					isCompatible = true;
					break;
				}else{
					isCompatible = false;
				}
			}
			if(isCompatible){
				return "";
			}else{
				return "分辨率：" + resolution;
			}
		}
	}
	
	private void showSupportNotDialog(final String suggestion){
		View view = View.inflate(Splash.this, R.layout.support_not_dialog_view, null);
		final CheckBox checkbox = (CheckBox)view.findViewById(R.id.send_message);
		//checkbox.setChecked(true);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
		builder.setTitle("天气通兼容性检测");
		builder.setMessage("谢谢您对天气通的信赖，我们暂不支持您的机型分辨率！");
		builder.setView(view);
		builder.setCancelable(false);
		builder.setNeutralButton("退出", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				//发送反馈给后台
				if(checkbox.isChecked()){
					String configFile = SPUtility.getConfigure(Splash.this);
					String ver = getString(R.string.ver);
					String device = android.os.Build.MODEL + "/" + android.os.Build.VERSION.RELEASE;
					String configure = ver + "/" + device;
					mService.sendSuggestion2TQT(new WeakReference<MsgResponseHandler>(Splash.this), suggestion, configure, configFile, "", TianQiTongService.SEND_FROM_COMPATIBILITY);
				}
				dialog.dismiss();
				finish();
			}
		});
		builder.show();
	}

	@Override
	public void handle(Message msg) {
		
	}

	@Override
	public void onADClicked(Ad arg0, String arg1) {
		
	}
	
}
