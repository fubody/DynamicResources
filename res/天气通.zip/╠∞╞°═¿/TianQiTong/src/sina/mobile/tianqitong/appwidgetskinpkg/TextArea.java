package sina.mobile.tianqitong.appwidgetskinpkg;

import java.util.ArrayList;

import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.Utility;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.TextPaint;

public class TextArea extends AbstractSkinLayoutUnit {

	private String Text = null;
	private int TextColor = 0xff000000;
	private int TextSize = 0;
	private int LineGap = 0;
	private String Suffix = "...";

	private int w = Integer.MIN_VALUE;
	private int h = Integer.MIN_VALUE;

	private String[] mLines = null;
	private int mRealWidth;
	private int mRealHeight;

	protected TextArea(AppWidgetSkin aws) {
		super(aws);
	}

	@Override
	protected Rect doMeasureDrawRectWAndH() {
		if (mLines == null) {
			return null;
		}
		return new Rect(0, 0, mRealWidth, mRealHeight);
	}

	@Override
	protected boolean setSubValue(String attrName, String attrValue) {
		if (attrName.equals("Text")) {
			Text = attrValue;
		} else if (attrName.equals("TextColor")) {

			String intu = attrValue.substring(0, 4);
			String intl = attrValue.substring(4);

			int int0 = Integer.parseInt(intu.toUpperCase(), 16);
			int int1 = Integer.parseInt(intl.toUpperCase(), 16);

			TextColor = (int0 << 16) | int1;
		} else if (attrName.equals("TextSize")) {
			TextSize = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("LineGap")) {
			LineGap = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("w")) {
			w = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("h")) {
			h = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("Suffix")) {
			Suffix = attrValue;
		} else {
			return false;
		}
		return true;
	}

	@Override
	void draw(Canvas c) {
		TextPaint tp = new TextPaint();
		tp.setAntiAlias(true);
		tp.setColor(TextColor);
		tp.setTextSize(TextSize);

		int ty = mDrawRect.top + TextSize + LineGap;

		for (String line : mLines) {
			c.drawText(line, mDrawRect.left, ty, tp);
			ty += TextSize + LineGap;
		}

	}

	@Override
	void setWeatherInfo(WeatherInfo wi) {

		if (Text == null || Text.length() == 0) {
			mLines = new String[] {};
			if (w != Integer.MIN_VALUE) {
				mRealWidth = w;
			} else {
				mRealWidth = 0;
			}
			if (h != Integer.MIN_VALUE) {
				mRealHeight = h;
			} else {
				mRealHeight = 0;
			}
			return;
		}

		String allText = "";
		// 先把functionid替换成字符串，有了一个总的真正的字符串，才好进行后面的排版。
		{
			StringBuilder allTextSb = new StringBuilder();
			StringBuilder functionId = new StringBuilder();
			boolean isFunctionId = false;
			for (int i = 0; i < Text.length(); i++) {
				char c = Text.charAt(i);
				if (isFunctionId) {
					if (c != '}') {
						functionId.append(c);
					} else {
						isFunctionId = false;
						String[] tmp = Utility.split(functionId.toString(), ':');
						String functionid = tmp[0];
						String offsettime = null;
						if (tmp.length > 1) {
							offsettime = tmp[1];
						}
						allTextSb.append(sina.mobile.tianqitong.appwidgetskinpkg.Text.getTextByFunctionIdAndTimeOffset(wi, functionid, offsettime));
						functionId = new StringBuilder();
					}
				} else {
					if (c == '{') {
						isFunctionId = true;
					} else {
						allTextSb.append(c);
					}
				}
			}
			allText = allTextSb.toString();
		}

		int lineHeight = TextSize + LineGap;

		TextPaint tp = new TextPaint();
		tp.setTextSize(TextSize);

		// 快速判断一下区域能不能放下字符串
		if (w != Integer.MIN_VALUE) {
			mRealWidth = w;
			char c = allText.charAt(0);
			if (w <= (int) tp.measureText(c + "")) {
				// 如果定死的宽度连第一个字符都放不下，返回。
				mLines = new String[] {};
				if (h != Integer.MIN_VALUE) {
					mRealHeight = h;
				} else {
					mRealHeight = 0;
				}
				return;
			}
		}
		if (h != Integer.MIN_VALUE) {
			mRealHeight = h;
			if (h <= lineHeight) {
				// 如果定死的高度连第一个行都放不下，返回。
				mLines = new String[] {};
				if (w != Integer.MIN_VALUE) {
					mRealWidth = w;
				} else {
					mRealWidth = 0;
				}
				return;
			}
		}

		// 计算宽高，计算换行和行尾省略号，整理出mLines来。
		{
			if (w != Integer.MIN_VALUE) {
				mRealWidth = w;
				if (h != Integer.MIN_VALUE) {
					// 有宽高限制，需要计算换行和省略符。
					mRealHeight = h;

					StringBuilder currentLineSb = new StringBuilder();
					ArrayList<String> linesList = new ArrayList<String>();

					int countHeight = lineHeight;
					for (int i = 0; i < allText.length(); i++) {

						char currentChar = allText.charAt(i);
						int currentCharWidth = (int) tp.measureText(currentChar + "");
						int currentLineWidth = (int) tp.measureText(currentLineSb.toString());
						currentLineWidth += currentCharWidth;

						if (currentLineWidth >= w) {
							if (countHeight + lineHeight >= h) {
								// 超过高度，不能换行
								CharSequence sub = currentLineSb.subSequence(0, currentLineSb.length() - 1);
								currentLineSb = new StringBuilder();
								currentLineSb.append(sub);
								currentLineSb.append(Suffix);
								linesList.add(currentLineSb.toString());
								// 这里其实不是很准确，因为不能换行的情况下，去掉本行最后一个字符，换成后缀，...一类的，
								// 这个后缀仍然可能超出边界。
								// 不过这个太细节了，暂时算了。
								currentLineSb = new StringBuilder();
								break;
							} else {
								// 换行
								linesList.add(currentLineSb.toString());
								currentLineSb = new StringBuilder();
								countHeight += lineHeight;
								currentLineSb.append(currentChar);
							}

						} else {
							currentLineSb.append(currentChar);
						}

					}

					if (currentLineSb.length() != 0) {
						linesList.add(currentLineSb.toString());
						countHeight += lineHeight;
					}

					mLines = new String[linesList.size()];
					linesList.toArray(mLines);

				} else {
					// 有宽限制，没有高限制，需要计算换行。
					StringBuilder currentLineSb = new StringBuilder();
					ArrayList<String> linesList = new ArrayList<String>();

					mRealHeight = lineHeight;
					for (int i = 0; i < allText.length(); i++) {

						char currentChar = allText.charAt(i);
						int currentCharWidth = (int) tp.measureText(currentChar + "");
						int currentLineWidth = (int) tp.measureText(currentLineSb.toString());
						currentLineWidth += currentCharWidth;

						if (currentLineWidth >= w) {
							// 换行
							linesList.add(currentLineSb.toString());
							currentLineSb = new StringBuilder();
							mRealHeight += lineHeight;
						}
						currentLineSb.append(currentChar);
					}
					linesList.add(currentLineSb.toString());
					mRealHeight += lineHeight;
					mLines = new String[linesList.size()];
					linesList.toArray(mLines);
				}
			} else {
				if (h != Integer.MIN_VALUE) {
					// 有高限制，没有宽限制，是无限长度的单行。
					mRealHeight = h;
					if (h < lineHeight) {
						mLines = new String[] {};
						mRealWidth = 0;
					} else {
						mRealWidth = (int) tp.measureText(allText.toString());
						mLines = new String[] { allText };
					}
				} else {
					// 宽高都没有限制，是无限程度的单行。
					mRealHeight = lineHeight;
					mRealWidth = (int) tp.measureText(allText.toString());
					mLines = new String[] { allText };
				}
			}
		}

	}

	@Override
	boolean isClockUnit() {
		// TODO Auto-generated method stub
		return false;
	}
}
