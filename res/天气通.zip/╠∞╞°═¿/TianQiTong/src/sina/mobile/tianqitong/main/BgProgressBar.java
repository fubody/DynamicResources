package sina.mobile.tianqitong.main;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class BgProgressBar extends View {
	Paint mPaint;
	private int mMax = 100;
	private int mMaxWidth;;
	private int width;

	public BgProgressBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		mPaint = new Paint();
		mPaint.setARGB(100, 126, 191, 210);
	}

	public BgProgressBar(Context context) {
		super(context);
		mPaint = new Paint();
	}

	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		int wspecMode = MeasureSpec.getMode(widthMeasureSpec);
		int wspecSize = MeasureSpec.getSize(widthMeasureSpec);

		int hspecMode = MeasureSpec.getMode(heightMeasureSpec);
		int hspecSize = MeasureSpec.getSize(heightMeasureSpec);
		mMaxWidth = wspecSize;
		setMeasuredDimension(wspecSize, hspecSize);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		mPaint.setStrokeWidth(4);
		canvas.drawRect(0, 0, width, 200, mPaint);
	}

	/**
	 * progress最大是100
	 * 
	 * @param progress
	 */
	public void setProgress(int progress) {

		width = (mMaxWidth * progress) / mMax;
		invalidate();
	}

}
