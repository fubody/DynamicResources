package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCityName;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getWeatherInfo;
import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidget.Widget4x1Provider;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;

public class _1st4x1DiyableAppWidget extends AbstractDiyableAppWidget {

	static final int IDX_WIDGET_BG = 0;

	_1st4x1DiyableAppWidget() {
		super((int) (320f * getDensity()), (int) (120f * getDensity()), AWType._1ST_4X1);
	}

	@Override
	protected void doDraw(Canvas canvas, AbstractDiyableUnit[] diyableUnits) {
		float density = getDensity();
		int width = getWidthPixels();
		Resources res = getActivity().getResources();

		int bgWidth = width;

		{
			diyableUnits[IDX_WIDGET_BG].drawOnCanvas(canvas);
		}

		int textSize = (int) (13 * density);
		{

			int widgetBgWidth = diyableUnits[IDX_WIDGET_BG].getDrawBounds().right - diyableUnits[IDX_WIDGET_BG].getDrawBounds().left;
			int bgHeight = diyableUnits[IDX_WIDGET_BG].getDrawBounds().bottom - diyableUnits[IDX_WIDGET_BG].getDrawBounds().top;

			int yOfText = (int) (25d * density);
			int gapBetweenTextAndSide = (int) (3d * density);

			String[] texts = new String[5];
			String[] temps = new String[5];
			int[] icons = new int[5];

			Widget4x1Provider.make4x1Values(getWeatherInfo(), getCityName(), getActivity(), icons, texts, temps);

			int tx = (bgWidth - widgetBgWidth) / 2;

			Paint p = new Paint();
			p.setColor(((DiyableBG) diyableUnits[IDX_WIDGET_BG]).getTextColor());
			p.setTextSize(textSize);
			p.setAntiAlias(true);

			int widthOfcell = widgetBgWidth * 3 / 11;

			for (int i = 0; i < 5; i++) {

				Bitmap icon = getBitmap(res, icons[i]);// BitmapFactory.decodeResource(res, icons[i]);
				if (texts[i].length() == 1) {
					texts[i] = "周" + texts[i];
				}

				int xOfText = tx + (widthOfcell - (int) p.measureText(texts[i])) / 2;
				int xOfTemp = tx + (widthOfcell - (int) p.measureText(temps[i])) / 2;
				int xOfIcon = tx + (widthOfcell - icon.getWidth()) / 2;

				if (i == 0) {
					RectF rectf = new RectF(tx + (int) (8d * density), yOfText + (int) (3d * density), tx + widthOfcell - (int) (8d * density), yOfText + textSize + (int) (8d * density));

					Paint paint = new Paint();
					paint.setColor(Color.BLACK);
					paint.setStyle(Style.FILL);
					paint.setAlpha(0x66);
					paint.setAntiAlias(true);
					canvas.drawRoundRect(rectf, 6 * density, 6 * density, paint);

					paint = new Paint();
					paint.setColor(0xff464646);
					paint.setStyle(Style.STROKE);
					paint.setStrokeWidth(1);
					paint.setAntiAlias(true);
					canvas.drawRoundRect(rectf, 6 * density, 6 * density, paint);
				}

				tx = tx + widthOfcell;
				widthOfcell = widgetBgWidth * 8 / 44;

				canvas.drawText(texts[i], xOfText, yOfText + textSize + gapBetweenTextAndSide, p);

				canvas.drawText(temps[i], xOfTemp, yOfText + bgHeight - textSize - gapBetweenTextAndSide, p);

				Matrix m = new Matrix();
				m.postTranslate(xOfIcon, yOfText + textSize + gapBetweenTextAndSide);
				canvas.drawBitmap(icon, m, null);

			}

		}

	}

	@Override
	protected void doLayout(AbstractDiyableUnit[] diyableUnits) {

		float density = getDensity();
		int width = getWidthPixels();

		int yOfBg = (int) (20d * density);

		{
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_HCENTER | AbstractDiyableUnit.ANCHOR_FLAG_TOP;
			diyableUnits[IDX_WIDGET_BG].measureDrawRect(width / 2, yOfBg, anchorFlag);
		}
	}

	@Override
	protected AbstractDiyableUnit[] newDiyableUnits() {

		AbstractDiyableUnit[] rr = new AbstractDiyableUnit[1];

		{
			rr[IDX_WIDGET_BG] = new DiyableBG(AWType._1ST_4X1, R.drawable.widget_bg_4x1);
		}

		return rr;

	}

}
