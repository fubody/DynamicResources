package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getClockNumbers;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;

import java.util.EnumMap;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.ButtonFunction;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyButton;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyText;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.WeatherIconMode;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.TextPaint;

public class _2nd4x2DiyableAppWidget extends AbstractDiyableAppWidget {

	static final int IDX_WIDGET_BG = 0;
	static final int IDX_WEATHERICON = 1;
	static final int IDX_1ST_TEXT = 2;
	static final int IDX_2ND_TEXT = 3;
	static final int IDX_CITYNAME = 4;
	static final int IDX_1ST_BUTTON = 5;
	static final int IDX_2ND_BUTTON = 6;

	_2nd4x2DiyableAppWidget() {
		super((int) (320f * getDensity()), (int) (240f * getDensity()), AWType._2ND_4X2);
	}

	@Override
	protected void doDraw(Canvas canvas, AbstractDiyableUnit[] diyableUnits) {

		Resources res = getActivity().getResources();
		int width = getWidthPixels();
		float density = getDensity();

		int bgWidth = width;
		int bgHeight = (int) (160f * density);
		int gapBetweenBgAndTop = (int) (40f * density);

		{
			diyableUnits[IDX_WIDGET_BG].drawOnCanvas(canvas);
		}

		{
			diyableUnits[IDX_WEATHERICON].drawOnCanvas(canvas);
		}

		{
			int gapBetweenClockAndTop = (int) (5f * density);
			int gapBetweenClockAndRight = (int) (10f * density);
			int clockTextSize = (int) (70f * density);
			int[] clockNums = getClockNumbers();
			StringBuilder clockText = new StringBuilder();
			clockText.append(clockNums[0]);
			clockText.append(clockNums[1]);
			clockText.append(":");
			clockText.append(clockNums[2]);
			clockText.append(clockNums[3]);
			String text = clockText.toString();
			Paint paint = new Paint();
			paint.setColor(((DiyableBG) diyableUnits[IDX_WIDGET_BG]).getTextColor());
			paint.setAntiAlias(true);
			paint.setTextSize(clockTextSize);
			Rect textBounds = new Rect();
			paint.getTextBounds(text, 0, text.length(), textBounds);
			int w = (int) paint.measureText(text);
			canvas.drawText(text, bgWidth - gapBetweenClockAndRight - w, gapBetweenClockAndTop + clockTextSize + gapBetweenBgAndTop, paint);
		}

		{
			diyableUnits[IDX_1ST_TEXT].drawOnCanvas(canvas);
		}

		{
			int gapBetweenLineAndBottom = (int) (5d * density);
			Bitmap line = getBitmap(res, R.drawable.line_for_2nd);// BitmapFactory.decodeResource(res, R.drawable.line_for_2nd);
			Matrix m = new Matrix();
			m.postTranslate(bgWidth - line.getWidth(), bgHeight - gapBetweenLineAndBottom - line.getHeight() + gapBetweenBgAndTop);
			canvas.drawBitmap(line, m, null);
			diyableUnits[IDX_2ND_BUTTON].drawOnCanvas(canvas);
			m = new Matrix();
			m.postTranslate(bgWidth - line.getWidth(), diyableUnits[IDX_2ND_BUTTON].getDrawBounds().top - line.getHeight());
			canvas.drawBitmap(line, m, null);
			line = null;
		}

		{
			diyableUnits[IDX_1ST_BUTTON].drawOnCanvas(canvas);
		}

		{
			diyableUnits[IDX_2ND_TEXT].drawOnCanvas(canvas);
		}

		{
			if (conditionTempRect != null) {
				TextPaint mTp;
				mTp = new TextPaint();
				mTp.setColor(((DiyableBG) diyableUnits[IDX_WIDGET_BG]).getTextColor());
				int textSize = (int) (17f * density);
				mTp.setTextSize(textSize);
				mTp.setAntiAlias(true);
				String mText = DiyableAppWidgetPreviewManager.getWeatherInfo().getCondition().getTemperature() + "℃(实况)";
				canvas.drawText(mText, conditionTempRect.left, conditionTempRect.bottom, mTp);
			}
		}

		{
			diyableUnits[IDX_CITYNAME].drawOnCanvas(canvas);
		}

	}

	Rect conditionTempRect = null;

	@Override
	protected void doLayout(AbstractDiyableUnit[] diyableUnits) {

		Resources res = getActivity().getResources();
		int width = getWidthPixels();
		float density = getDensity();

		int bgWidth = width;
		int bgHeight = (int) (160f * density);
		int gapBetweenBgAndTop = (int) (40f * density);

		{
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_LEFT | AbstractDiyableUnit.ANCHOR_FLAG_TOP;
			diyableUnits[IDX_WIDGET_BG].measureDrawRect(0, gapBetweenBgAndTop, anchorFlag);
		}

		{
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_LEFT | AbstractDiyableUnit.ANCHOR_FLAG_TOP;
			diyableUnits[IDX_WEATHERICON].measureDrawRect(0, gapBetweenBgAndTop, anchorFlag);
		}

		int clockBottom = 0;

		{
			int gapBetweenClockAndTop = (int) (5f * density);
			int clockTextSize = (int) (70f * density);
			clockBottom = gapBetweenClockAndTop + clockTextSize;
		}

		{
			int gapBetweenClockAndText = (int) (10f * density);
			int gapBetweenTextAndRight = (int) (20f * density);
			int tx = bgWidth - gapBetweenTextAndRight;
			int ty = gapBetweenClockAndText + clockBottom + gapBetweenBgAndTop;
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_RIGHT | AbstractDiyableUnit.ANCHOR_FLAG_TOP;
			diyableUnits[IDX_1ST_TEXT].measureDrawRect(tx, ty, anchorFlag);
		}

		int tx;
		int ty;
		{
			int gapBetweenLineAndBottom = (int) (5d * density);
			int gapBetweenBottomAndRight = (int) (0d * density);
			Options opts = new Options();
			opts.inJustDecodeBounds = true;
			BitmapFactory.decodeResource(res, R.drawable.line_for_2nd, opts);
			tx = bgWidth - gapBetweenBottomAndRight;
			ty = bgHeight - gapBetweenLineAndBottom - opts.outHeight * opts.inTargetDensity / opts.inDensity + gapBetweenBgAndTop;
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_RIGHT | AbstractDiyableUnit.ANCHOR_FLAG_BOTTOM;
			diyableUnits[IDX_2ND_BUTTON].measureDrawRect(tx, ty, anchorFlag);
		}

		{
			tx = diyableUnits[IDX_2ND_BUTTON].getDrawBounds().left;
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_RIGHT | AbstractDiyableUnit.ANCHOR_FLAG_BOTTOM;
			diyableUnits[IDX_1ST_BUTTON].measureDrawRect(tx, ty, anchorFlag);
		}

		{
			int gapBetweenTextAndLine = (int) (10d * density);
			int gapBetweenTextAndButton = 0;
			tx = diyableUnits[IDX_1ST_BUTTON].getDrawBounds().left - gapBetweenTextAndButton;
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_RIGHT | AbstractDiyableUnit.ANCHOR_FLAG_BOTTOM;
			diyableUnits[IDX_2ND_TEXT].measureDrawRect(tx, ty - gapBetweenTextAndLine, anchorFlag);
		}

		{

			if (((DiyableWeatherIcon) diyableUnits[IDX_WEATHERICON]).getTempValue() == WeatherIconMode.CONDITION) {

				int gapBetweenTextAndLine = (int) (10d * density);
				int gapBetweenTextAndButton = (int) (10d * density);
				tx = diyableUnits[IDX_2ND_TEXT].getDrawBounds().left - gapBetweenTextAndButton;

				conditionTempRect = new Rect();

				TextPaint mTp;
				mTp = new TextPaint();
				mTp.setColor(((DiyableBG) diyableUnits[IDX_WIDGET_BG]).getTextColor());
				int textSize = (int) (17f * density);
				mTp.setTextSize(textSize);
				mTp.setAntiAlias(true);

				String mText = DiyableAppWidgetPreviewManager.getWeatherInfo().getCondition().getTemperature() + "℃(实况)";
				mTp.getTextBounds(mText, 0, mText.length(), conditionTempRect);
				{
					if (conditionTempRect.bottom < conditionTempRect.top) {
						int i = conditionTempRect.bottom;
						conditionTempRect.bottom = conditionTempRect.top;
						conditionTempRect.top = i;
					}
					if (conditionTempRect.right < conditionTempRect.left) {
						int i = conditionTempRect.right;
						conditionTempRect.right = conditionTempRect.left;
						conditionTempRect.left = i;
					}

					conditionTempRect.bottom = conditionTempRect.bottom - conditionTempRect.top;
					conditionTempRect.top = 0;

					conditionTempRect.right = conditionTempRect.right - conditionTempRect.left;
					conditionTempRect.left = 0;

					conditionTempRect.left = tx - conditionTempRect.right;
					conditionTempRect.right = conditionTempRect.left + conditionTempRect.right;

					conditionTempRect.top = ty - conditionTempRect.bottom - gapBetweenTextAndLine;
					conditionTempRect.bottom = conditionTempRect.top + conditionTempRect.bottom;
				}

			} else {
				conditionTempRect = null;
			}

		}

		{

			int gapBetweenTextAndButton = (int) (10d * density);
			if (conditionTempRect == null) {
				tx = diyableUnits[IDX_2ND_TEXT].getDrawBounds().left - gapBetweenTextAndButton;
			} else {
				tx = conditionTempRect.left - gapBetweenTextAndButton;
			}
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_RIGHT | AbstractDiyableUnit.ANCHOR_FLAG_BOTTOM;
			diyableUnits[IDX_CITYNAME].measureDrawRect(tx, ty, anchorFlag);

		}

	}

	@Override
	protected AbstractDiyableUnit[] newDiyableUnits() {

		int width = getWidthPixels();
		float density = getDensity();
		AWType type = AWType._2ND_4X2;

		int bgWidth = width;
		int bgHeight = (int) (160f * density);

		AbstractDiyableUnit[] r = new AbstractDiyableUnit[7];

		r[IDX_WIDGET_BG] = new DiyableBG(type, bgWidth, bgHeight);

		r[IDX_WEATHERICON] = new DiyableWeatherIcon(type, 1.2f, false, (DiyableBG) r[IDX_WIDGET_BG]);

		int textSize = (int) (15f * density);
		r[IDX_1ST_TEXT] = new DiyableText(type, textSize, DiyText._1ST_TEXT, (DiyableBG) r[IDX_WIDGET_BG], true);

		EnumMap<ButtonFunction, Integer> function2ResidMap = new EnumMap<DiyAppWidgetAttrUtil.ButtonFunction, Integer>(ButtonFunction.class);
		{
			function2ResidMap.put(ButtonFunction.PLAY_TTS, R.drawable.widget_play_tts);
			function2ResidMap.put(ButtonFunction.TTS_SETTING, R.drawable.widget_setalarm);
			function2ResidMap.put(ButtonFunction.WEIBO, R.drawable.widget_weibo);
			function2ResidMap.put(ButtonFunction.UPDATE_DATA, R.drawable.widget_update);
			function2ResidMap.put(ButtonFunction.APP, R.drawable.widget_app);
		}
		r[IDX_2ND_BUTTON] = new DiyableButton(type, DiyButton._2ND_BUTTON, function2ResidMap);
		r[IDX_1ST_BUTTON] = new DiyableButton(type, DiyButton._1ST_BUTTON, function2ResidMap);

		textSize = (int) (17f * density);
		r[IDX_2ND_TEXT] = new DiyableText(type, textSize, DiyText._2ND_TEXT, (DiyableBG) r[IDX_WIDGET_BG], false);

		int cityNameTextSize = (int) (17d * density);
		r[IDX_CITYNAME] = new DiyableCityname(type, cityNameTextSize, (DiyableBG) r[IDX_WIDGET_BG]);

		return r;

	}

}
