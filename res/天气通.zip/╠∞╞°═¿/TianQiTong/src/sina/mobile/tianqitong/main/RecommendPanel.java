package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_URL;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.WeekRecommendManager;
import sina.mobile.tianqitong.service.frm.HandlerObserver;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.model.DownloadItem;
import sina.mobile.tianqitong.service.model.WeekRecommendListInfo;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Bitmap.Config;
import android.location.GpsStatus.Listener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.AdapterView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class RecommendPanel extends Activity implements OnClickListener {
	private TianQiTongService mService;
	private RelativeLayout mLayoutAll;
	private LinearLayout recommendAllLayout, topLayout;
	private ScrollView scrollview;
	private ImageView mBack;

	private HorizontalScrollView logoView;
// Listener mListener;
	private WeekRecommendManager mWeekRecommendManager;
	private List<WeekRecommendListInfo> mSoftWareListItemInfo = new ArrayList<WeekRecommendListInfo>();
	private List<WeekRecommendListInfo> mGoogleMarketListItemInfo = new ArrayList<WeekRecommendListInfo>();
	private List<WeekRecommendListInfo> mWebsiteListItemInfo = new ArrayList<WeekRecommendListInfo>();
	private TianQiTongDownloadManger mTianQiTongDownloadManger = null;
	private ArrayList<ImageView> res = new ArrayList<ImageView>();

	private TableRow mTableRow;
	private Bitmap mStar;
	private Bitmap mStarNo;
	private View itemView, introview;
	private ImageView itemLogo, downloadBtn;
	private static final int DIALOG_ID_DOWNLOADING = 1;
	ImageView imageView;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.recommend_panel);

		mStar = BitmapFactory.decodeResource(getResources(), R.drawable.recommend_star);
		mStarNo = BitmapFactory.decodeResource(getResources(), R.drawable.recommend_star_no);

		mWeekRecommendManager = WeekRecommendManager.getInstance(null);
		HandlerObserver.registerObserver(mHandler, null);

		mTianQiTongDownloadManger = TianQiTongDownloadManger.getInstance(null);
		scrollview = (ScrollView) findViewById(R.id.scroll_view);
		mLayoutAll = (RelativeLayout) findViewById(R.id.recommend_layout_all);
		mBack = (ImageView) findViewById(R.id.back);
		mBack.setOnClickListener(this);

		recommendAllLayout = (LinearLayout) findViewById(R.id.recommend_layout);
		topLayout = (LinearLayout) findViewById(R.id.top_pannel);
		logoView = (HorizontalScrollView) this.findViewById(R.id.logo_view);
		logoView.setHorizontalScrollBarEnabled(false);
		mTableRow = (TableRow) logoView.findViewById(R.id.row);

		String timeStamp = SPUtility.getSPString(this, R.string.recommend_time_stamp);
		if (timeStamp.trim().equals("0")) {
			mWeekRecommendManager.refreshRecommendList(null);
			scrollview.setVisibility(View.GONE);
			topLayout.setVisibility(View.GONE);
		} else {
			initCommentList();
		}

	}

// public Dialog onCreateDialog(int id) {
// switch (id) {
// case DIALOG_ID_DOWNLOADING: {
// ProgressDialog dialog = new ProgressDialog(this);
// dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
// dialog.setCancelable(false);
// dialog.setMessage("正在加载...");
// return dialog;
// }
// }
// return null;
// }
// public void stopDialog(int id) {
// try {
// dismissDialog(id);
// } catch (IllegalArgumentException iae) {
//
// }
// }

	private void putClickBoolean() {
		SPUtility.putSPBoolean(this, R.string.if_new_recommend_click, false);
	}

	private void initCommentList() {
		buildData();
		if (mSoftWareListItemInfo == null || mGoogleMarketListItemInfo == null) {

		} else {

// DisplayMetrics m = new DisplayMetrics();
// this.getWindowManager().getDefaultDisplay().getMetrics(m);
// final GalleryWidgetAdapterView work = new GalleryWidgetAdapterView(this);
// work.setLayoutParams(new ViewGroup.LayoutParams(m.widthPixels, 80));
//
// if (mGoogleMarketListItemInfo != null && mGoogleMarketListItemInfo.size() > 0) {
// for (int i = 0; i < mGoogleMarketListItemInfo.size(); i++) {
// logoView = new ImageView(this);
// logoView.setTag(mGoogleMarketListItemInfo.get(i).getIconHttpUrl());
// mGoogleMarketListItemInfo.get(i).setIcon(logoView);
// res.add(logoView);
// }
// }
//
// work.setOnClickListener(new GalleryWidgetAdapterView.OnItemClickListener() {
//
// Override
// public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
// // TODO Auto-generated method stub
// openUriOrDownload(mGoogleMarketListItemInfo.get(position).getWeekRecommendHttpUrl(), mGoogleMarketListItemInfo.get(position).getId(), mGoogleMarketListItemInfo.get(position)
// .getType());
// }
//
// });
// marketLayout.addView(work, 0);
//
// final Adapter adapter = new Adapter(this, res);
// work.setAdapter(adapter);

			if (mGoogleMarketListItemInfo != null && mGoogleMarketListItemInfo.size() > 0) {
				for (int i = 0; i < mGoogleMarketListItemInfo.size(); i++) {
					final int id = i;
					ImageView imageView = new ImageView(this);
					imageView.setBackgroundResource(R.drawable.week_recommend_bg);
					res.add(imageView);
					imageView.setTag(mGoogleMarketListItemInfo.get(i).getIconHttpUrl());
					imageView.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							openUriOrDownload(mGoogleMarketListItemInfo.get(id).getWeekRecommendHttpUrl(), mGoogleMarketListItemInfo.get(id).getId(), mGoogleMarketListItemInfo.get(id).getType());

						}

					});
					mGoogleMarketListItemInfo.get(i).setIcon(imageView);

					DisplayMetrics dm = getResources().getDisplayMetrics();
					float d = dm.density;
					int dip = 100;
					int px = (int) (((float) dip) * d);
					//int py = imageView.getDrawable().getIntrinsicHeight();
					int py = (int) (((float) 82) * d);

					TableRow.LayoutParams params = new TableRow.LayoutParams(px, py);

					dip = 10;
					px = (int) (((float) dip) * d);
					params.rightMargin = px;
					params.bottomMargin = 0;
					mTableRow.addView(imageView, i, params);
				}
			}

			for (int i = 0; i < mSoftWareListItemInfo.size(); i++) {

				WeekRecommendListInfo recommendItem = mSoftWareListItemInfo.get(i);
				itemView = getRecommendItemView(recommendItem);
				introview = getItemIntroView(recommendItem);
				if (i == 0) {
					itemView.setBackgroundResource(R.drawable.recommend_light_list);
				} else if (i == 1) {
					itemView.setBackgroundResource(R.drawable.recommend_dark_list);
				} else {
					if (i % 2 == 0) {
						itemView.setBackgroundResource(R.drawable.recommend_light_list);
					} else {
						itemView.setBackgroundResource(R.drawable.recommend_dark_list);
					}
				}

				downloadBtn = new ImageView(this);
				downloadBtn = (ImageView) itemView.findViewById(R.id.button);
				downloadBtn.setBackgroundResource(R.drawable.recommend_download);

				downloadBtn.setClickable(true);
				downloadBtn.setFocusable(true);
				downloadBtn.setTag(i);

				itemLogo = new ImageView(this);
				itemLogo = (ImageView) itemView.findViewById(R.id.image);
				recommendItem.setIcon(itemLogo);
				itemLogo.setTag(mSoftWareListItemInfo.get(i).getIconHttpUrl());
				itemView.setTag(i * 2);

				itemView.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {

						int index = (Integer) v.getTag();
						for (int i = 0; i < mSoftWareListItemInfo.size(); i++) {
							if (index != i * 2 || recommendAllLayout.getChildAt(i * 2 + 1).getVisibility() == 0) {
								recommendAllLayout.getChildAt(i * 2 + 1).setVisibility(View.GONE);
							} else {
								recommendAllLayout.getChildAt(index + 1).setVisibility(View.VISIBLE);
								scrollview.requestChildFocus(recommendAllLayout, recommendAllLayout.getChildAt(index + 1));
							}

						}

					}

				});

				downloadBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {

						int position = (Integer) (v.getTag());
						openUriOrDownload(mSoftWareListItemInfo.get(position).getWeekRecommendHttpUrl(), mSoftWareListItemInfo.get(position).getId(), mSoftWareListItemInfo.get(position).getType());

					}

				});

				recommendAllLayout.addView(itemView, i * 2);
				recommendAllLayout.addView(introview, i * 2 + 1);
				recommendAllLayout.getChildAt(i * 2 + 1).setVisibility(View.GONE);
			}

		}
		scrollview.setVisibility(View.VISIBLE);
		topLayout.setVisibility(View.VISIBLE);
	}

	private Handler mHandler = new Handler() {

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case HandlerObserver.NTY2HANDLER_MSG_WHAT_WEEK_RECOMMEND_LIST_UPDATED: {
				initCommentList();
				putClickBoolean();
			}
				break;
			case HandlerObserver.NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_PROGRESS_UPDATED: {

				String url = msg.getData().getString(MSG_DATA_KEY_STR_URL);
				int type = mTianQiTongDownloadManger.getDownloadItem(url).getType();

				if (type == DownloadItem.TYPE_WEEK_RECOMMEND_ICON && msg.getData().getInt(MsgUtility.MSG_DATA_KEY_INT_STEP) == 100) {
					WeekRecommendListInfo itemInfo = mUrlKeyHashMap.get(url);
					if (itemInfo != null)
						itemInfo.refreshFile(url);

					if (mGoogleMarketListItemInfo != null && mGoogleMarketListItemInfo.size() > 0 && mGoogleMarketListItemInfo.contains(itemInfo)) {
						for (int i = 0; i < mGoogleMarketListItemInfo.size(); i++) {
							ImageView imageView = (ImageView) res.get(i);
							if (url.equals(imageView.getTag())) {
								itemInfo.setIcon(imageView);
								imageView.invalidate();
								
							}
						}

					}

					if (mSoftWareListItemInfo != null && mSoftWareListItemInfo.size() > 0 && mSoftWareListItemInfo.contains(itemInfo)) {
						for (int i = 0; i < mSoftWareListItemInfo.size(); i++) {
							if (url.equals(recommendAllLayout.getChildAt(i * 2).findViewById(R.id.image).getTag())) {
								itemLogo = (ImageView) recommendAllLayout.getChildAt(i * 2).findViewById(R.id.image);
								itemInfo.setIcon(itemLogo);
								itemLogo.invalidate();

							}
						}

					}

				}

			}
				break;

			}
		};
	};

	private String mSdDir = null;
	private String mFilePath = null;
	private HashMap<String, WeekRecommendListInfo> mUrlKeyHashMap = new HashMap();

	private void buildData() {
		WeekRecommendListInfo[] recommendInfos = (WeekRecommendListInfo[]) mWeekRecommendManager.getRecommendInfos();
		HashSet iconSet = new HashSet();
		mSdDir = getSDPath();

		mSoftWareListItemInfo.clear();
		mGoogleMarketListItemInfo.clear();
		mWebsiteListItemInfo.clear();

		if (recommendInfos != null) {
			int type = -1;
			for (int i = 0; i < recommendInfos.length; i++) {
				type = recommendInfos[i].getType();
				if (type == WeekRecommendListInfo.TYPE_GOOGLE_MARKET_WEBSITE || type == WeekRecommendListInfo.TYPE_WEBSITE) {
					mSoftWareListItemInfo.add(recommendInfos[i]);
				} else if (type == WeekRecommendListInfo.TYPE_SOFTWARE) {
					mGoogleMarketListItemInfo.add(recommendInfos[i]);
				} else {
					mWebsiteListItemInfo.add(recommendInfos[i]);
				}

				if (recommendInfos[i].getIconFile() == null && recommendInfos[i].getIconHttpUrl() != null) {
					iconSet.add(recommendInfos[i].getIconHttpUrl());
					mUrlKeyHashMap.put(recommendInfos[i].getIconHttpUrl(), recommendInfos[i]);
				}

				/*
				 * if (recommendInfos[i].getSinaRecommendApkFile() == null && recommendInfos[i].getSinaRecommendApkHttpUrl() != null) {
				 * mUrlKeyHashMap.put(recommendInfos[i].getSinaRecommendApkHttpUrl(), recommendInfos[i]); }
				 */
				mUrlKeyHashMap.put(recommendInfos[i].getWeekRecommendHttpUrl(), recommendInfos[i]);

			}

		}

// mMoreLayout = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.click_more_btn, null);
// Button moreBtn = (Button)mMoreLayout.findViewById(R.id.more_btn);
		if (mSdDir != null) {
			mFilePath = mSdDir + "/TianQiTong/WeekRecommend/";
		} else {
			return;
		}

		if (iconSet.size() != 0) {
			String[] urls = new String[iconSet.size()];
			iconSet.toArray(urls);
			int[] types = new int[iconSet.size()];
			String[] filePaths = new String[iconSet.size()];
			for (int i = 0; i < iconSet.size(); i++) {
				types[i] = DownloadItem.TYPE_WEEK_RECOMMEND_ICON;
				filePaths[i] = mFilePath + getNameFromUrl(urls[i]);
			}

			mTianQiTongDownloadManger.downloadAll(urls, types, filePaths, true);
		}

	}

	private String getNameFromUrl(String str) {
		return str.substring(str.lastIndexOf("/") + 1, str.length());
	}

	private String getSDPath() {
		File sdDir = null;

		if (Utility.sdAvailiable()) {
			sdDir = Environment.getExternalStorageDirectory();// 获取根目录
		}
		if (sdDir != null) {
			return sdDir.toString();
		} else {
			return null;
		}

	}

	private View getRecommendItemView(WeekRecommendListInfo itemInfo) {
		LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View convertView = layoutInflater.inflate(R.layout.list_item_layout, null);
		downloadBtn = (ImageView) convertView.findViewById(R.id.button);
		itemLogo = (ImageView) convertView.findViewById(R.id.image);
		TextView name = (TextView) convertView.findViewById(R.id.name);
		name.setText(itemInfo.getName());
		TextView introduction = (TextView) convertView.findViewById(R.id.introduction);
		introduction.setText(itemInfo.getBrief());
		return convertView;
	}

	private View getItemIntroView(WeekRecommendListInfo itemInfo) {
		LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View convertView = layoutInflater.inflate(R.layout.item, null);
		TextView detailTextView = (TextView) convertView.findViewById(R.id.info);
		TextView versionTextView = (TextView) convertView.findViewById(R.id.version);
		TextView sizeTextView = (TextView) convertView.findViewById(R.id.size);
		TextView downloadTextView = (TextView) convertView.findViewById(R.id.download);
		ImageView starTextView = (ImageView) convertView.findViewById(R.id.star);
		detailTextView.setText(itemInfo.getDetails());
		versionTextView.setText(itemInfo.getVersion());
		sizeTextView.setText(itemInfo.getSize());
		downloadTextView.setText(itemInfo.getDownLoadCount());
		starTextView.setImageBitmap(getStartsBitmap(itemInfo.getScore()));

		return convertView;
	}

	private HashMap<Integer, Bitmap> mStarCache = new HashMap<Integer, Bitmap>();

	protected Bitmap getStartsBitmap(int score) {

		if (mStarCache.get(score) == null) {
			int width = mStar.getWidth();
			int height = mStar.getHeight();

			if (score > 5 || score < 2) {
				return mStar;
			}

			Bitmap output = Bitmap.createBitmap(width * 5, height, Config.ARGB_4444);
			Canvas canvas = new Canvas(output);
			for (int j = 0; j <= score - 1; j++) {
				canvas.drawBitmap(mStar, j * width, 0, null);
			}
			for (int z = score - 1 + 1; z < 5; z++) {
				canvas.drawBitmap(mStarNo, z * width, 0, null);
			}

			mStarCache.put(score, output);

		}
		return mStarCache.get(score);

	}

	public final void onServiceConnected(ComponentName name, IBinder service) {
		mService = ((TianQiTongService.TianQiTongBinder) service).getService();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.back:
			finish();

			break;

		/*
		 * case R.id.jifeng: if (mWebsiteListItemInfo != null && mWebsiteListItemInfo.size() == 3) { openUriOrDownload(mWebsiteListItemInfo.get(0).getWeekRecommendHttpUrl(),
		 * mWebsiteListItemInfo.get(0).getId()); } break; case R.id.qq: if (mWebsiteListItemInfo != null && mWebsiteListItemInfo.size() == 3) {
		 * openUriOrDownload(mWebsiteListItemInfo.get(1).getWeekRecommendHttpUrl(), mWebsiteListItemInfo.get(1).getId()); } break; case R.id.sina: if (mWebsiteListItemInfo != null &&
		 * mWebsiteListItemInfo.size() == 3) { openUriOrDownload(mWebsiteListItemInfo.get(2).getWeekRecommendHttpUrl(), mWebsiteListItemInfo.get(2).getId()); } break;
		 */
		}
	}

	private void openUriOrDownload(String url, String id, int type) {
		try {
			Intent intent = new Intent();
			intent.setAction(Intent.ACTION_VIEW);
			String encodeUrl = "";
			if (type == 0) {
				encodeUrl = "http://forecast.sina.cn/app/redirect.php?id=0-4-2-" + id + "&ourl=" + URLEncoder.encode(url, "utf-8");
			} else if (type == 1) {
				encodeUrl = "http://forecast.sina.cn/app/redirect.php?id=0-4-0-" + id + "&ourl=" + URLEncoder.encode(url, "utf-8");
			} else if (type == 2) {
				encodeUrl = "http://forecast.sina.cn/app/redirect.php?id=0-4-1-" + id + "&ourl=" + URLEncoder.encode(url, "utf-8");
			}

			Uri uri = Uri.parse(encodeUrl);
			intent.setData(uri);
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

}
