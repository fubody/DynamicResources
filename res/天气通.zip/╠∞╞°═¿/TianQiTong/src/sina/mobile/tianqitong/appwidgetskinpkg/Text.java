package sina.mobile.tianqitong.appwidgetskinpkg;

import java.util.Calendar;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.ChineseCalendarUtility;
import sina.mobile.tianqitong.service.utility.ChineseDate;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.TextPaint;

public class Text extends AbstractSkinLayoutUnit {

	private String Text = null;
	private int TextColor = 0xff000000;
	private int TextSize = 0;
	private boolean HasShadow = false;
	private String FunctionId = null;
	private String OffsetTime = null;

	protected String mText = null;

	protected Text(AppWidgetSkin aws) {
		super(aws);
	}

	@Override
	protected boolean setSubValue(String attrName, String attrValue) {
		if (attrName.equals("FunctionId")) {
			FunctionId = attrValue;
		} else if (attrName.equals("Text")) {
			Text = attrValue;
		} else if (attrName.equals("TextColor")) {

			String intu = attrValue.substring(0, 4);
			String intl = attrValue.substring(4);

			int int0 = Integer.parseInt(intu.toUpperCase(), 16);
			int int1 = Integer.parseInt(intl.toUpperCase(), 16);

			TextColor = (int0 << 16) | int1;

		} else if (attrName.equals("TextSize")) {
			TextSize = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("HasShadow")) {
			HasShadow = Boolean.parseBoolean(attrValue);
		} else if (attrName.equals("OffsetTime")) {
			OffsetTime = attrValue;
		} else {
			return false;
		}
		return true;
	}

	@Override
	protected Rect doMeasureDrawRectWAndH() {

		if (mText == null) {
			return null;
		}

		TextPaint tp = new TextPaint();
		tp.setTextSize(TextSize);
		int w = (int) tp.measureText(mText);
		return new Rect(0, 0, w, TextSize);
	}

	@Override
	public void setWeatherInfo(WeatherInfo wi) {
		if (Text != null) {
			mText = Text;
		} else {
			mText = getTextByFunctionIdAndTimeOffset(wi, FunctionId, OffsetTime);
		}
	}

	public static String getTextByFunctionIdAndTimeOffset(WeatherInfo wi, String FunctionId, String OffsetTime) {
		String mText = null;

		int offsetDay = 0;
		int daySign = 1;
		if (OffsetTime != null) {
			if (OffsetTime.startsWith("-")) {
				daySign = -1;
				OffsetTime = OffsetTime.substring(1);
			} else if (OffsetTime.startsWith("+")) {
				daySign = 1;
				OffsetTime = OffsetTime.substring(1);
			} else {
				daySign = 1;
				OffsetTime = OffsetTime.substring(0);
			}
			if (OffsetTime.endsWith("d")) {
				offsetDay = daySign * Integer.parseInt(OffsetTime.substring(0, OffsetTime.length() - 1));
			}
		}

		Context context = TianQiTongAppWidgetSkinManager.getInstance(null)._wrService.get();
		if (context == null) {
			return mText;
		}

		if (FunctionId.equals("city_name")) {

			String cityName = wi.getLocation();
			int idx = wi.getLocation().indexOf('.');

			if (idx != -1) {
				mText = cityName.substring(idx + 1, cityName.length());
			} else {
				mText = cityName;
			}

			return mText;
		}

		if (FunctionId.equals("c_weather")) {
			int ycode = wi.getYCodeUsingSunRiseAndSet();
			mText = WeatherInfo.getWeatherStrFromYahooCode(ycode, context.getResources());
		} else if (FunctionId.equals("wind")) {
			mText = wi.getCondition().getWind();
			if (mText == WeatherInfo.INVALID_WIND) {
				mText = "";
			}
		} else if (FunctionId.equals("temperature")) {
			int temp = wi.getCondition().getTemperature();
			if (temp == WeatherInfo.INVALID_TEMPERATURE) {
				mText = "";
			} else {
				mText = temp + "";
			}
		} else if (FunctionId.equals("humidity")) {
			int humidity = wi.getCondition().getHumidity();
			if (humidity == WeatherInfo.INVALID_HUMIDITY) {
				mText = "";
			} else {
				mText = humidity + "";
			}
		} else if (FunctionId.equals("uv")) {
			mText = wi.getLifdex().getUv();
		} else if (FunctionId.equals("cwash")) {
			mText = wi.getLifdex().getCwash();
		} else if (FunctionId.equals("cold")) {
			mText = wi.getLifdex().getCold();
		} else if (FunctionId.equals("comfort")) {
			mText = wi.getLifdex().getComfort();
		} else if (FunctionId.equals("cloth")) {
			mText = wi.getLifdex().getCloth();
		} else if (FunctionId.equals("umbrella")) {
			mText = wi.getLifdex().getUmbrella();
		} else if (FunctionId.equals("insolate")) {
			mText = wi.getLifdex().getInsolate();
		} else if (FunctionId.equals("sport")) {
			mText = wi.getLifdex().getSport();
		} else if (FunctionId.equals("sun_rise")) {
			mText = wi.getSunRiseStrForLocal();
		} else if (FunctionId.equals("sun_set")) {
			mText = wi.getSunSetStrForLocal();
		}

		if (mText != null) {
			return mText;
		}

		ForeCast careForecast = null;
		ForeCast careTomorrowForecast = null;

		ForeCast[] fcs = wi.getForecastsForCurrent(5);
		{
			careForecast = fcs[offsetDay];
			if (careForecast == ForeCast.EMPTY) {
				careForecast = null;
			}
			if (offsetDay + 1 >= fcs.length) {
				careTomorrowForecast = null;
			} else {
				careTomorrowForecast = fcs[offsetDay + 1];
				if (careTomorrowForecast == ForeCast.EMPTY) {
					careTomorrowForecast = null;
				}
			}

		}

		if (FunctionId.equals("day_weather")) {
			if (careForecast != null) {
				int ycode = careForecast.getYcode();
				mText = WeatherInfo.getWeatherStrFromYahooCode(ycode, context.getResources());
			} else {
				mText = "";
			}
		} else if (FunctionId.equals("night_weather")) {
			if (careForecast != null) {
				int ycode = careForecast.getYcode2();
				mText = WeatherInfo.getWeatherStrFromYahooCode(ycode, context.getResources());
			} else {
				mText = "";
			}
		} else if (FunctionId.equals("hltemperature")) {

			StringBuilder str = new StringBuilder();

			// 更新最低最高温
			if (careForecast != null) {
				str.append(careForecast.getLow());
				if (careForecast.getHigh() != WeatherInfo.INVALID_TEMPERATURE) {
					str.append("/");
					str.append(careForecast.getHigh());
				} else {
					if (careTomorrowForecast != ForeCast.EMPTY) {
						str.append("/");
						str.append(careTomorrowForecast.getHigh());
					}
				}
			}
			mText = str.toString();
		}

		careTomorrowForecast = null;
		careForecast = null;

		if (mText != null) {
			return mText;
		}

		Calendar calendar = Calendar.getInstance();

		long curtime = System.currentTimeMillis();
		curtime = curtime + ((long) offsetDay) * 3600000L * 24L;
		calendar.setTimeInMillis(curtime);

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int week = calendar.get(Calendar.DAY_OF_WEEK);

		if (FunctionId.equals("yyyy")) {
			mText = year + "";
		} else if (FunctionId.equals("yy")) {
			mText = (year + "").substring(2);
		} else if (FunctionId.equals("mm")) {
			mText = AppWidgetSkinUtility.num(month + 1);
		} else if (FunctionId.equals("m")) {
			mText = (month + 1) + "";
		} else if (FunctionId.equals("dd")) {
			mText = AppWidgetSkinUtility.num(day);
		} else if (FunctionId.equals("d")) {
			mText = day + "";
		} else if (FunctionId.equals("w0")) {
			mText = context.getResources().getStringArray(R.array.days_of_week)[week - 1];
		} else if (FunctionId.equals("w1")) {
			mText = context.getResources().getStringArray(R.array.days_of_week_simple)[week - 1];
		} else if (FunctionId.equals("w2")) {
			mText = context.getResources().getStringArray(R.array.brief_days_of_week)[week - 1];
		}

		if (mText != null) {
			return mText;
		}

		ChineseDate cd = ChineseCalendarUtility.getChineseDate(calendar);

		String term = "";
		String chny = "";
		String chnm = "";
		String chnd = "";
		if (cd != null) {
			if (cd.isSolarTerm()) {
				term = ChineseCalendarUtility.getSorlarTermStr(context.getResources(), cd);
			}

			chny = ChineseCalendarUtility.getYearStr(context.getResources(), cd);
			chnm = ChineseCalendarUtility.getMonthStr(context.getResources(), cd);
			chnd = ChineseCalendarUtility.getDayStr(context.getResources(), cd);
		}

		if (FunctionId.equals("chn_solar_term")) {
			mText = term;
		} else if (FunctionId.equals("chn_y")) {
			mText = chny;
		} else if (FunctionId.equals("chn_m")) {
			mText = chnm;
		} else if (FunctionId.equals("chn_d")) {
			mText = chnd;
		}

		return mText;

	}

	@Override
	public void draw(Canvas c) {

		if (HasShadow) {
			TextPaint tp = new TextPaint();
			tp.setAntiAlias(true);
			tp.setColor(0x88000000);
			tp.setTextSize(TextSize);
			c.drawText(mText, mDrawRect.left + 3, mDrawRect.bottom + 3, tp);
		}

		TextPaint tp = new TextPaint();
		tp.setAntiAlias(true);
		tp.setColor(TextColor);
		tp.setTextSize(TextSize);
		c.drawText(mText, mDrawRect.left, mDrawRect.bottom, tp);

	}

	boolean isClockUnit() {
		return FunctionId != null && FunctionId.contains("clock");
	}

}
