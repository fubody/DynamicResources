package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.IntentActionConstants;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainGuideActivity extends Activity implements OnClickListener {
	private RelativeLayout mTotalLayout;
	private ImageView mImageViewGuideContent;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_guide_layout);
		mTotalLayout = (RelativeLayout) findViewById(R.id.guide_layout);
		mImageViewGuideContent = (ImageView) findViewById(R.id.guide_image);

		Intent i = getIntent();
		String guideType = i.getStringExtra(IntentActionConstants.BUNDLE_GUIDE_TYPE);
		try{
			if (guideType != null && guideType.equals(IntentActionConstants.BUNDLE_GUIDE_TYPE_VALUE_MAIN)) {
				mImageViewGuideContent.setImageResource(R.drawable.guide_main);
			} else if (guideType != null && guideType.equals(IntentActionConstants.BUNDLE_GUIDE_TYPE_VALUE_CITYDRAG)) {
				mImageViewGuideContent.setImageResource(R.drawable.guide_city_drag);
			}
		}catch(OutOfMemoryError ex){
			finish();
		}
		
		mTotalLayout.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		finish();
		overridePendingTransition(R.anim.fade_in, R.anim.fade_out_guide);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			overridePendingTransition(R.anim.fade_in, R.anim.fade_out_guide);
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
