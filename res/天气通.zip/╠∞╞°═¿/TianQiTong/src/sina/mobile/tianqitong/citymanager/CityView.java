package sina.mobile.tianqitong.citymanager;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class CityView extends RelativeLayout {
	private CityWeathInfo cityWeathInfo = null;
	TextView cityName;
	TextView temH, temL;
	private ImageView mAddView;
	LinearLayout mWeatherIcon = null;
	ImageView icon = null;
	// ImageView mLicon = null;
	ImageView mCurrent = null;
	ImageView mDiverof9city = null;
	ImageView mIsGps = null;
	private ImageView mIsTTS = null;
	TextView mWeacher = null;
	TextView mTemDiv = null;
	Context context;
	boolean isDay = true;

	public CityView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		RelativeLayout.LayoutParams lllp = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		setLayoutParams(lllp);
		LayoutInflater.from(context).inflate(R.layout.city_view, this, true);

		cityName = (TextView) findViewById(R.id.cityName);
		temH = (TextView) findViewById(R.id.tem_h);
		temL = (TextView) findViewById(R.id.tem_l);
		mAddView = (ImageView) findViewById(R.id.add_view);
		mWeatherIcon = (LinearLayout) findViewById(R.id.h_b_icon);
		icon = (ImageView) mWeatherIcon.findViewById(R.id.w_icon_h);
		// mLicon = (ImageView) mWeatherIcon.findViewById(R.id.w_icon_l);
		mCurrent = (ImageView) findViewById(R.id.current_city_view);
		mDiverof9city = (ImageView) findViewById(R.id.diverof9city);
		mWeacher = (TextView) findViewById(R.id.weacher);
		mTemDiv = (TextView) findViewById(R.id.tem_div);
		mIsGps = (ImageView) findViewById(R.id.is_gps);
		mIsTTS = (ImageView) findViewById(R.id.is_tts);
		
	}

	public CityWeathInfo getCityWeathInfo() {
		return this.cityWeathInfo;
	}
	
	public void setCityWeathInfo(CityWeathInfo cityWeathInfo) {
		changViewVisibility(true);
		String[] tmps = Utility.split(cityWeathInfo.cityName, '.');
		String shortCityName = tmps[tmps.length - 1];
		cityName.setText(shortCityName);
		if (cityWeathInfo.heightTem != -274) {
			temH.setText(cityWeathInfo.heightTem + "°");
		}
		if (cityWeathInfo.lowTem != -274) {
			temL.setText(cityWeathInfo.lowTem + "°");
		}
		if (cityWeathInfo.icon != -100) {
			icon.setImageResource(cityWeathInfo.icon);
		}
		mWeacher.setText(cityWeathInfo.weahter);

		if (cityWeathInfo.cityCode.startsWith(Constants.AUTO_LOCATE_CITYCODE_PREFIX)) {
			mIsGps.setVisibility(View.VISIBLE);
		} else {
			mIsGps.setVisibility(View.GONE);
		}
		
		setTTSCity(cityWeathInfo);//added by Maojianwei
		
		isDay = cityWeathInfo.isDay;
// if (cityWeathInfo.nightIcon != -1) {
// mLicon.setVisibility(View.VISIBLE);
// mLicon.setImageResource(cityWeathInfo.nightIcon);
// } else {
// mLicon.setVisibility(View.GONE);
// }

		if (cityWeathInfo.isCurrentCity) {
			mCurrent.setVisibility(View.VISIBLE);
		} else {
			mCurrent.setVisibility(View.GONE);
		}

		this.cityWeathInfo = cityWeathInfo;
	}

	/**
	 * 设置播报城市图标
	 * 
	 * @param cityWeathInfo
	 * @author MaoJianWei
	 */
	private void setTTSCity(CityWeathInfo cityWeathInfo) {
		mIsTTS.setVisibility(SPUtility.getSPBoolean(context, R.string.boolean_use_tts, false) && 
				cityWeathInfo.cityCode.equals(SPUtility.getSPString(context, 
				R.string.str_alarm_tts_city_code)) ? View.VISIBLE : View.GONE);
	}

	public void setWeathViewVisibility(int i) {
		cityName.setVisibility(i);
		// tem.setVisibility(i);
		mWeatherIcon.setVisibility(i);
	}

	public void setAddViewVisibility(int i) {
		mAddView.setVisibility(i);
	}

	/**
	 * true + 号消失， 天气出来
	 * 
	 * @param b
	 */
	public void changViewVisibility(boolean b) {
		setVisibility(View.VISIBLE);
		if (b) {
			cityName.setVisibility(View.VISIBLE);
			mWeatherIcon.setVisibility(View.VISIBLE);
			mDiverof9city.setVisibility(View.VISIBLE);
			mAddView.setVisibility(View.INVISIBLE);
			mWeacher.setVisibility(View.VISIBLE);
		} else {
			cityName.setVisibility(View.INVISIBLE);
			mWeatherIcon.setVisibility(View.INVISIBLE);
			mWeacher.setVisibility(View.INVISIBLE);
			mCurrent.setVisibility(View.INVISIBLE);
			mAddView.setOnClickListener(null);
			mAddView.setVisibility(View.VISIBLE);
			mIsGps.setVisibility(View.INVISIBLE);
			mIsTTS.setVisibility(View.INVISIBLE);// added by Maojianwei
			mDiverof9city.setVisibility(View.INVISIBLE);
		}
	}

	public void onlyHasBg() {
		cityName.setVisibility(View.INVISIBLE);
		mWeatherIcon.setVisibility(View.INVISIBLE);
		mAddView.setVisibility(View.INVISIBLE);
		mCurrent.setVisibility(View.INVISIBLE);
		mDiverof9city.setVisibility(View.INVISIBLE);
		mWeacher.setVisibility(View.INVISIBLE);
	}

	public boolean isAddViewVisibility() {
		if (mAddView.getVisibility() == View.VISIBLE) {
			return true;
		} else {
			return false;
		}
	}
}
