package sina.mobile.tianqitong.citymanager;

public class CityModel implements Comparable<CityModel> {

	private String mainName;
	private String subName;
	private String subMainName;
	private int type = 0;//type 0 临汾.山西 type1 洪洞.临汾 
	public static final int TYPE_KEY_2_PART = 0;
	public static final int TYPE_KEY_1_PART = 1;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getSubMainName() {
		if(subName.indexOf(".") != -1){
			subMainName = subName.substring(subName.lastIndexOf(".") + 1);
		}
		if (subMainName == null) {
			subMainName = mainName;
		}
		if(subMainName.equals(subName)){
			return null;
		}
		return subMainName;
	}

	public void setSubMainName(String subMainName) {
		this.subMainName = subMainName;
	}

	private String cityCode;

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	private int weight = 0;

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getMainName() {
		return mainName;
	}

	public void setMainName(String mainName) {
		this.mainName = mainName;
	}

	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	@Override
	public int compareTo(CityModel another) {
		// TODO Auto-generated method stub
		if (this.weight > another.weight) {
			return -1;
		} else if (this.weight == another.weight) {
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	public String toString() {
		return null;

	}

	public String getSubCityNameForSearch() {
		if (subName.indexOf(".") != -1) {
			return subName;
		} else {
			return subName + "." + mainName;
		}

	}

	public String getSubCityNameForSearchNew() {
		if (subName.indexOf(".") != -1) {			
			return subName.substring(0, subName.indexOf("."));
		} else {
			return subName;
		}

	}

}
