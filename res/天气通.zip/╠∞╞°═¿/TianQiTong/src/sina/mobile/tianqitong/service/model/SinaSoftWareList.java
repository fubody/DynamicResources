package sina.mobile.tianqitong.service.model;

import java.io.Serializable;

public class SinaSoftWareList implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public SinaSoftWareListItemInfo[] mSinaSoftWareListItemInfo;
	public SinaWebSiteListItemInfo[] mSinaWebSiteListItemInfo;
	public String mTimeStamp = null;
}