package sina.mobile.tianqitong.main;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TianQiTongReceiver_boot extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		
		boolean hasCity = true;
		if (SPUtility
				.getSPStringArray(context, R.string.strs_cached_citys, ',').length == 0) {
			hasCity = false;
		}

		String action = intent.getAction();
		if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {
			// lyang changed 开机启动 暂时
			// boolean start = SPUtility.getSPBoolean(context,
			// R.string.boolean_auto_start_after_booting);
			// boolean start = true;
			if (hasCity) {
				// 用户新安装天气通，没启动，然后重启电脑，会导致问题
				Intent i = new Intent(context, TianQiTongService.class);
				context.startService(i);
			}
		}
	}

}
