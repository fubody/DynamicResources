package sina.mobile.tianqitong.main;

import org.apache.http.util.EncodingUtils;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongService;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

/**
 * 这个类主要跳转点击的广告，并且向服务器以post的方式传入点击广告的参数
 * 
 * @author zhangxi
 * 
 */
public class AdWebActivity extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent i = getIntent();
		String clickUrl = i.getStringExtra("clickUrl");
		if (clickUrl != null) {

			String aspect = getString(R.string.aspect);
			String device = android.os.Build.MODEL + "/" + android.os.Build.VERSION.RELEASE;// 设备名
			String pt = "1";
			String ver = getString(R.string.ver);
			String uid = TianQiTongService.getIMEI(this);
			String pd = "0";
			String pid = "free";

			String urlParam = "url=" + clickUrl + "&device=" + device + "&pid=" + pid + "&pt=" + pt + "&ver=" + ver + "&uid=" + uid + "&pd=" + pd;
			WebView webview = new WebView(this);
			setContentView(webview);
			byte[] post = EncodingUtils.getBytes(urlParam, "UTF-8");
			webview.postUrl("http://202.108.5.62/admin/tianqitong/api/goto.php", post);
		}
		// 在点击返回键的时候会出现一个空的webview于是这里在发送完请求以后直接做关闭处理。
		finish();

	}

}
