package sina.mobile.tianqitong.main;

import java.util.Calendar;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.model.WeatherInfo.Lifedex;
import sina.mobile.tianqitong.service.utility.ChineseCalendarUtility;
import sina.mobile.tianqitong.service.utility.ChineseDate;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class WeatherInfoView extends RelativeLayout implements WeatherViewInterface {

	TextView _tvCurHumidity = null;
	TextView _tvCurWeather = null;
	TextView _tvCurWind = null;
	TextView _tvCurTemperature = null;
	TextView _tvDate = null;
	TextView _tvCurrentCityName = null;
	Button mLifeButton = null;
	Button mForecastButton = null;
	RelativeLayout mWeatherAll = null;
	RelativeLayout mLifeIndex = null;
	private int mPosition = -1;
	View[] mSunrise;
	View[] mSunset;
	View[] mLifeIndexView = new View[8];

// View _vFirst = null;
// View _vSecond = null;

	View[] _vsToday1st;
	View[] _vsToday2nd;
	private static final int IDX_TODAY_TEXT = 0;
	private static final int IDX_TODAY_ICON = 1;
	private static final int IDX_TODAY_TEMP = 2;
	private static final int IDX_TODAY_WEATHER = 3;
	private static final int IDX_TODAY_WIND = 4;
	private static final int IDX_SUN_ICON = 0;
	private static final int IDX_SUN_TEXT = 1;
	private static final int IDX_SUN_TIME = 2;

	View[] _vForecasts = new View[4];

	public WeatherInfoView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public WeatherInfoView(Context context) {
		super(context);
		init(context);
	}

	private void init(final Context context) {
		RelativeLayout.LayoutParams lllp = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		setLayoutParams(lllp);
		DisplayMetrics dm = getResources().getDisplayMetrics();
		int height = dm.heightPixels;
		int width = dm.widthPixels;
		float proportion = (float) height / (float) width;
		if(480 == width && 640 == height) {//适配480X640的分辨率
			LayoutInflater.from(context).inflate(R.layout.weather_info_small_480x640, this, true);
		} else if((720 == width && 1184 == height) || (800 == width && 1280 == height)){
			LayoutInflater.from(context).inflate(R.layout.weather_info_1_6, this, true);
		} else {
			if (proportion > 1.7) {
				if (width == 480) {
					View view = LayoutInflater.from(context).inflate(R.layout.weather_info, this, true);
				} else {
					LayoutInflater.from(context).inflate(R.layout.weather_info_big, this, true);
				}
			} else if (proportion < 1.4) {
				LayoutInflater.from(context).inflate(R.layout.weather_info_small, this, true);
			} else {
				View view = LayoutInflater.from(context).inflate(R.layout.weather_info, this, true);
			}
		}
		_tvCurWeather = (TextView) findViewById(R.id.current_weahter);
		_tvCurHumidity = (TextView) findViewById(R.id.current_humidity);
		_tvCurWind = (TextView) findViewById(R.id.current_wind);
		_tvDate = (TextView) findViewById(R.id.date);
		_tvCurTemperature = (TextView) findViewById(R.id.current_temperature);
		_tvCurrentCityName = (TextView) findViewById(R.id.current_city_name);
		/*
		 * _tvCurrentCityName.setOnClickListener(new OnClickListener(){
		 * 
		 * @Override public void onClick(View v) { SPUtility.userActionCounterIncreaseOne(context, R.string.int_times_of_clicking_cityname_at_mainactivity); context.startActivity(new Intent(context,
		 * CityManager.class)); }
		 * 
		 * });
		 */
		mLifeButton = (Button) findViewById(R.id.index_btn);
		mLifeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				/*
				 * if(isViewVisible(mWeatherAll)){ applyRotation(0, 0, 90); }else if(isViewVisible(mLifeIndex)){ applyRotation(1, 0, 90); }
				 */
				applyRotation(0, 0, 90);

			}

		});

		mForecastButton = (Button) findViewById(R.id.forecast_btn);
		mForecastButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				/*
				 * if(isViewVisible(mWeatherAll)){ applyRotation(0, 0, 90); }else if(isViewVisible(mLifeIndex)){ applyRotation(1, 0, 90); }
				 */
				applyRotation(1, 0, 90);

			}

		});
		mWeatherAll = (RelativeLayout) findViewById(R.id.weather_all);
		mLifeIndex = (RelativeLayout) findViewById(R.id.life_index);

// _vFirst = findViewById(R.id.today_first);
// _vSecond = findViewById(R.id.today_second);

		TypedArray ta = getResources().obtainTypedArray(R.array.forecasts);
		for (int i = 0; i < 4; i++) {
			_vForecasts[i] = findViewById(ta.getResourceId(i, R.id.forecast_0));
		}

// SimpleHScrolledTextView._shstvs = new SimpleHScrolledTextView[8];

		ta.recycle();

		_vsToday1st = new View[] { findViewById(R.id.today_1st_text), findViewById(R.id.today_1st_icon), findViewById(R.id.today_1st_temp), findViewById(R.id.today_1st_weather),
				findViewById(R.id.today_1st_wind), };
		_vsToday2nd = new View[] { findViewById(R.id.today_2nd_text), findViewById(R.id.today_2nd_icon), findViewById(R.id.today_2nd_temp), findViewById(R.id.today_2nd_weather),
				findViewById(R.id.today_2nd_wind), };

		TypedArray lifeIndexArray = getResources().obtainTypedArray(R.array.lifeindex);
		for (int i = 0; i < 8; i++) {
			mLifeIndexView[i] = findViewById(ta.getResourceId(i, R.id.lifeindex_0));
		}

		lifeIndexArray.recycle();

		mSunrise = new View[] { findViewById(R.id.sunrise_icon), findViewById(R.id.sunrise_text), findViewById(R.id.sunrise_time), };
		mSunset = new View[] { findViewById(R.id.sunset_icon), findViewById(R.id.sunset_text), findViewById(R.id.sunset_time), };

	}

	private void updateToday(View[] vs, ForeCast fc, boolean today, boolean daynight, int skin) {

		if (fc == ForeCast.EMPTY) {
			for (View v : vs) {
				v.setVisibility(View.INVISIBLE);
			}
			return;
		} else {
			for (View v : vs) {
				v.setVisibility(View.VISIBLE);
			}
		}

		TextView tvText = (TextView) vs[IDX_TODAY_TEXT];
		ImageView ivIcon = (ImageView) vs[IDX_TODAY_ICON];
		TextView tvTemperature = (TextView) vs[IDX_TODAY_TEMP];
		TextView tvWeather = (TextView) vs[IDX_TODAY_WEATHER];
		TextView tvWind = (TextView) vs[IDX_TODAY_WIND];

		int wp = skin;

		if (today) {
			if (daynight) {
				tvText.setText("今天白天");
				tvTemperature.setText(fc.getHigh() + "°");
				tvTemperature.setTextColor(_oranges[wp]);

				tvWeather.setText(fc.getDayText());
				String wind = fc.getDayWind();
				if (wind == WeatherInfo.INVALID_WIND) {
					wind = "";
				}
				tvWind.setText(wind);
				int id = WeatherInfo.getWeatherIconFromYahooCode(fc.getYcode(), WeatherInfo.ICON_TYPE_FORECAST, getResources());
				ivIcon.setImageResource(id);
			} else {
				tvText.setText("今天夜间");
				tvTemperature.setText(fc.getLow() + "°");
				tvTemperature.setTextColor(_blues[wp]);
				tvWeather.setText(fc.getNightText());
				String wind = fc.getNightWind();
				if (wind == WeatherInfo.INVALID_WIND) {
					wind = "";
				}
				tvWind.setText(wind);
				int id = WeatherInfo.getWeatherIconFromYahooCode(fc.getYcode2(), WeatherInfo.ICON_TYPE_FORECAST, getResources());
				ivIcon.setImageResource(id);
			}
		} else {
			if (daynight) {
				tvText.setText("明天白天");
				tvTemperature.setText(fc.getHigh() + "°");
				tvTemperature.setTextColor(_oranges[wp]);
				tvWeather.setText(fc.getDayText());
				String wind = fc.getDayWind();
				if (wind == WeatherInfo.INVALID_WIND) {
					wind = "";
				}
				tvWind.setText(wind);
				int id = WeatherInfo.getWeatherIconFromYahooCode(fc.getYcode(), WeatherInfo.ICON_TYPE_FORECAST, getResources());
				ivIcon.setImageResource(id);
			} else {
				// tvText.setText("明天夜间");
				// tvTemperature.setText(fc.getLow()+"℃");
				// tvTemperature.setTextColor(R.color.blue);
				// tvWeather.setText(weathers.length > 1 ? weathers[1]
				// : weathers[0]);
				// tvWind.setText(winds.length > 1 ? winds[1] : winds[0]);
			}
		}
	}

	private void updateForecast(View v, ForeCast fc) {
		TextView tvText = (TextView) v.findViewById(R.id.text);
		ImageView ivIcon = (ImageView) v.findViewById(R.id.icon);
		TextView tvHighTemperature = (TextView) v.findViewById(R.id.high_temp);
		TextView tvLowTemperature = (TextView) v.findViewById(R.id.low_temp);
		TextView tvWeather = (TextView) v.findViewById(R.id.weather);

		if (fc == ForeCast.EMPTY) {
			tvText.setVisibility(View.INVISIBLE);
			ivIcon.setVisibility(View.INVISIBLE);
			tvHighTemperature.setVisibility(View.INVISIBLE);
			tvLowTemperature.setVisibility(View.INVISIBLE);
			tvWeather.setVisibility(View.INVISIBLE);
			return;
		} else {
			tvText.setVisibility(View.VISIBLE);
			ivIcon.setVisibility(View.VISIBLE);
			tvHighTemperature.setVisibility(View.VISIBLE);
			tvLowTemperature.setVisibility(View.VISIBLE);
			tvWeather.setVisibility(View.VISIBLE);
			// tvWind.setVisibility(View.VISIBLE);
		}

		Calendar _calendar = Calendar.getInstance();
		_calendar.setTimeInMillis(System.currentTimeMillis());
		_calendar.set(Calendar.YEAR, fc.getDateYearNum());
		_calendar.set(Calendar.MONTH, fc.getDateMonthNum() - 1);
		_calendar.set(Calendar.DAY_OF_MONTH, fc.getDateDayNum());

		int dayNumOfWeek = _calendar.get(Calendar.DAY_OF_WEEK);
		tvText.setText(getResources().getStringArray(R.array.days_of_week)[dayNumOfWeek - 1]);

		tvHighTemperature.setText(fc.getHigh() + "°");
		tvLowTemperature.setText(fc.getLow() + "°");

		String weather = fc.getDayText();
		if (weather.length() > 4) {
			weather = weather.substring(0, 4);
		}

		tvWeather.setText(weather);

		String fcwind = fc.getWind();
		if (fcwind == WeatherInfo.INVALID_WIND) {
			// tvWind.setText("");
		} else {
			// tvWind.setText(fc.getWind());
		}

		int id = WeatherInfo.getWeatherIconFromYahooCode(fc.getYcode(), WeatherInfo.ICON_TYPE_FORECAST, getResources());
		ivIcon.setImageResource(id);
	}

	@Override
	public void updateUI(TianQiTongService service, String cityName, final WeatherInfo wi, boolean noAnim, int skin) {

		changeSkin(skin);

		Calendar _calendar = Calendar.getInstance();
		_calendar.setTimeInMillis(System.currentTimeMillis());
		StringBuilder sb = new StringBuilder();
		sb.append(_calendar.get(Calendar.YEAR));
		sb.append("/");
		sb.append(Utility.getStrMD(_calendar));
		sb.append("  ");
		int dayOfWeek = _calendar.get(Calendar.DAY_OF_WEEK);
		String dayOfWeekStr = getResources().getStringArray(R.array.days_of_week)[dayOfWeek - 1];
		sb.append(dayOfWeekStr);
		sb.append("  ");
		ChineseDate cd = ChineseCalendarUtility.getChineseDate(_calendar);

		if (cd != null) {
			sb.append(ChineseCalendarUtility.toString(getResources(), cd, ChineseCalendarUtility.DATE_FORMAT_DEFAULT));

		}

		_tvDate.setText(sb.toString());

		if (Utility.isOut(wi)) {
			_tvCurHumidity.setText("湿度过时");
			_tvCurTemperature.setText("温度过时");
			_tvCurWind.setText("风力风向过时");
			_tvCurWeather.setText("实况天气过时");

		} else {
			int temp = wi.getCondition().getTemperature();
			String tmp = temp == -274 ? "" : (temp + "c");
			_tvCurTemperature.setText(makeCentigradeImgStr(tmp, service));

			int humidity = wi.getCondition().getHumidity();
			String strHumidity = (humidity == WeatherInfo.INVALID_HUMIDITY ? "" : ("湿度：" + humidity + "%"));
			_tvCurHumidity.setText(strHumidity);

			String wind = wi.getCondition().getWind();
			if (wind == WeatherInfo.INVALID_WIND) {
				_tvCurWind.setText("");
			} else {
				_tvCurWind.setText(wind);
			}

			_tvCurWeather.setText(WeatherInfo.getWeatherStrFromYahooCode(wi.getYCodeUsingSunRiseAndSet(), getResources()));
		}

		{
			ForeCast[] fcs = wi.getForecastsForCurrent(5);

			if (fcs[0].getType() == ForeCast.TYPE_NIGHT) {
				updateToday(_vsToday1st, fcs[0], true, false, skin);// 今天夜间
				updateToday(_vsToday2nd, fcs[1], false, true, skin);// 明天白天
				_firstIsDay = false;
			} else {
				updateToday(_vsToday1st, fcs[0], true, true, skin);// 今天白天
				updateToday(_vsToday2nd, fcs[0], true, false, skin);// 今天夜间
				_firstIsDay = true;
			}
			for (int i = 0; i < _vForecasts.length; i++) {
				updateForecast(_vForecasts[i], fcs[i + 1]);
			}
		}

		{
			String[] t = Utility.split(cityName, '.');
			cityName = t[t.length - 1];
			_tvCurrentCityName.setText(cityName);
			String cityCode = SPUtility.getSPString(service, R.string.str_current_city_code);
			if (cityCode.startsWith(Constants.AUTO_LOCATE_CITYCODE_PREFIX)) {
				((ImageView) findViewById(R.id.gps_icon)).setVisibility(View.VISIBLE);
			} else {
				((ImageView) findViewById(R.id.gps_icon)).setVisibility(View.GONE);
			}
		}

		updateSunTime(mSunrise, wi, 0);
		updateSunTime(mSunset, wi, 1);
		updateLifeIndexForecast(mLifeIndexView, wi);
	}

	private static char[] centigradeCharactors = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'c', '-', '.' };

	private static int[] centigradeImageIds = new int[] { R.drawable.centigrade_0, R.drawable.centigrade_1, R.drawable.centigrade_2, R.drawable.centigrade_3, R.drawable.centigrade_4,
			R.drawable.centigrade_5, R.drawable.centigrade_6, R.drawable.centigrade_7, R.drawable.centigrade_8, R.drawable.centigrade_9, R.drawable.centigrade, R.drawable.centigrade_belowzero,
			R.drawable.centigrade_point };

	private SpannableString makeCentigradeImgStr(String str, Context context) {
		SpannableString ss = new SpannableString(str);
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			for (int j = 0; j < centigradeCharactors.length; j++) {
				if (centigradeCharactors[j] == c) {
					ss.setSpan(new ImageSpan(context, centigradeImageIds[j]), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
			}
		}
		return ss;
	}

	public void finishAnim() {

	}

	private static final int[] _middleBgs = new int[] { R.drawable.weather_info_middle_bg_1, R.drawable.weather_info_middle_bg_1, R.drawable.weather_info_middle_bg_1 };
	// private static final int[] _bottomBgs = new int[] { R.drawable.weather_info_bottom_bg_1, R.drawable.weather_info_bottom_bg_2, R.drawable.weather_info_bottom_bg_1 };
	private static final int[] _lifeMiddleBgs = new int[] { R.drawable.weather_life_middle_bg_1, R.drawable.weather_life_middle_bg_1, R.drawable.weather_life_middle_bg_1 };
	private static final int[] _dateTextColor = new int[] { 0xffffffff, 0xffb7d7fc, 0xffa57021, 0xff367cad, 0xff756c82, 0xffffffff, 0xffc5dff0, 0xff6d6d6d, 0xffc4d6ee };
	private static final int[] _curWeatherColor = new int[] { 0xffffffff, 0xffffffff, 0xff683e0e, 0xff21629d, 0xff474458, 0xffffffff, 0xffffffff, 0xff5f5e5c, 0xffffffff };
	private static final int[] _curHumidityColor = new int[] { 0xffffffff, 0xffffffff, 0xff683e0e, 0xff367cad, 0xff756c82, 0xffffffff, 0xffffffff, 0xff5f5e5c, 0xffffffff };

	private static final int[] _todayTextColor = new int[] { 0xff0f5586, 0xff35beff, 0xff71471f, 0xff266998, 0xff534a60, 0xff0f5586, 0xff0881d0, 0xff3b3b3b, 0xff44434b };
	private static final int[] _todayWeatherColor = new int[] { 0xff1b90cd, 0xffffffff, 0xffffffff, 0xff1697e3, 0xff816f98, 0xff2aa5e4, 0xffffffff, 0xff424246, 0xffffffff };
	private static final int[] _todayWindColor = new int[] { 0xff1b90cd, 0xffffffff, 0xffffffff, 0xff1697e3, 0xff816f98, 0xff2aa5e4, 0xffc2d8ff, 0xff424246, 0xffbac3cd };

	private static final int[] _forecastTextColor = new int[] { 0xff0f5586, 0xff35beff, 0xff71471f, 0xff0f86c3, 0xff493f5c, 0xff0f5586, 0xff0881d0, 0xff3b3b3b, 0xff44434b };
	private static final int[] _forecastWeatherColor = new int[] { 0xff1b90cd, 0xffffffff, 0xffffffff, 0xff2f94d5, 0xffd3c3ed, 0xff3a95dc, 0xffc2d8ff, 0xffc5cfd2, 0xffc5cfd2 };
	private static final int[] _forecastWindColor = new int[] { 0xffffffff, 0xffffffff, 0xffffffff, 0xffc5cfd2, 0xffe6d5f9, 0xff42a9f8, 0xffc2d8ff, 0xffc5cfd2, 0xffc5cfd2 };

	private static final int[] _forecastHighColor = new int[] { 0xfffd933e, 0xfffdb834, 0xfffdb834, 0xffd0941d, 0xfff7d01a, 0xfffd933d, 0xfffdb834, 0xfffdb834, 0xfffdb834 };
	private static final int[] _forecastLowColor = new int[] { 0xff2f7eac, 0xff10c3ec, 0xff82dded, 0xff56b5c6, 0xff1d4766, 0xff52a1de, 0xff82dded, 0xff82dded, 0xff82dded };

	private static final int[] _oranges = new int[] { 0xfffd933e, 0xfffdb834, 0xffbc7427, 0xffe88321, 0xfff7d01a, 0xfffd933d, 0xfffdb834, 0xffe08d21, 0xfffdb834 };
	private static final int[] _blues = new int[] { 0xff2f7eac, 0xff10c3ec, 0xff56abe1, 0xff0f8eaa, 0xff298fa5, 0xff52a1de, 0xff0881d0, 0xff4c95c3, 0xff18d1ff };

	private static final int[] _lifeTextColor = new int[] { 0xff2f8fcc, 0xffffffff, 0xffffffff, 0xff2b8895, 0xffa9f0fd, 0xff2b8fa8, 0xffa8eafa, 0xffa8eafa, 0xff69d6f1 };
	private static final int[] _lifeIndexColor = new int[] { 0xff204e78, 0xffdd9045, 0xff301c02, 0xff609cdb, 0xff393056, 0xff3e4e66, 0xffffffff, 0xffffffff, 0xffffffff };

	private static final int[] _SunTextColor = new int[] { 0xff3b87ce, 0xffffffff, 0xff71471f, 0xff2d6fa6, 0xff514762, 0xff3b87ce, 0xffffffff, 0xff2e2e2e, 0xffffffff };

	private static final int[] lifeIndexId = { R.drawable.life_index_1, R.drawable.life_index_2, R.drawable.life_index_3, R.drawable.life_index_4, R.drawable.life_index_5, R.drawable.life_index_6,
			R.drawable.life_index_7, R.drawable.life_index_8 };

	private boolean _firstIsDay = true;

	public void changeSkin(int skin) {
		int wp = skin;
		ImageView middle = (ImageView) findViewById(R.id.weather_info_middle);
		// 指数背景
		ImageView indexMiddle = (ImageView) findViewById(R.id.lifeindex_info_middle);
		
		//适配480X640分辨率        added by Maojianwei 
		DisplayMetrics dm = getResources().getDisplayMetrics();
		if(480 == dm.widthPixels && 640 == dm.heightPixels) {
			middle.setImageResource(R.drawable.weather_info_middle_bg_480x640);
			indexMiddle.setImageResource(R.drawable.weather_life_middle_bg_480x640);
		} else if(720 == dm.widthPixels && 1184 == dm.heightPixels){
			middle.setImageResource(R.drawable.weather_info_middle_bg_720x1184);
			indexMiddle.setImageResource(R.drawable.weather_life_middle_bg_720x1184);
		} else if(800 == dm.widthPixels && 1280 == dm.heightPixels){
			middle.setImageResource(R.drawable.weather_info_middle_bg_800x1280);
			indexMiddle.setImageResource(R.drawable.weather_life_middle_bg_800x1280);
		} else {
			middle.setImageResource(R.drawable.weather_info_middle_bg_1);
			indexMiddle.setImageResource(R.drawable.weather_life_middle_bg_1);
		}
		
// middle.setBackgroundResource(R.drawable.weather_moji_bg);

		/*
		 * ImageView bottom = (ImageView) findViewById(R.id.weather_info_bottom); bottom.setImageResource(_bottomBgs[wp]);
		 */

		/*
		 * ImageView indexBottom = (ImageView) findViewById(R.id.lifeindex_info_bottom); indexBottom.setImageResource(_bottomBgs[wp]);
		 */

		_tvDate.setTextColor(_curHumidityColor[wp]);
		_tvCurHumidity.setTextColor(_curHumidityColor[wp]);
		_tvCurWeather.setTextColor(_curWeatherColor[wp]);
		_tvCurWind.setTextColor(_curHumidityColor[wp]);

		int _orange, _blue;
		_orange = _oranges[wp];
		_blue = _blues[wp];

		View[][] tmps = new View[][] { _vsToday1st, _vsToday2nd };
		for (View[] vs : tmps) {
			((TextView) (vs[IDX_TODAY_TEXT])).setTextColor(_todayTextColor[wp]);
			((TextView) (vs[IDX_TODAY_WEATHER])).setTextColor(_todayWeatherColor[wp]);
			((TextView) (vs[IDX_TODAY_WIND])).setTextColor(_todayWindColor[wp]);
		}
		if (_firstIsDay) {
			((TextView) _vsToday1st[IDX_TODAY_TEMP]).setTextColor(_orange);
			((TextView) _vsToday2nd[IDX_TODAY_TEMP]).setTextColor(_blue);
		} else {
			((TextView) _vsToday1st[IDX_TODAY_TEMP]).setTextColor(_blue);
			((TextView) _vsToday2nd[IDX_TODAY_TEMP]).setTextColor(_orange);
		}

		for (int i = 0; i < _vForecasts.length; i++) {
			((TextView) (_vForecasts[i].findViewById(R.id.text))).setTextColor(_forecastTextColor[wp]);
			((TextView) (_vForecasts[i].findViewById(R.id.weather))).setTextColor(_forecastWeatherColor[wp]);
			// ((SimpleHScrolledTextView) (_vForecasts[i].findViewById(R.id.wind))).setTextColor(_forecastWindColor[wp]);
			((TextView) (_vForecasts[i].findViewById(R.id.high_temp))).setTextColor(_forecastHighColor[wp]);
			((TextView) (_vForecasts[i].findViewById(R.id.low_temp))).setTextColor(_forecastLowColor[wp]);
		}

		((TextView) mSunrise[IDX_SUN_TEXT]).setTextColor(_SunTextColor[wp]);
		((TextView) mSunrise[IDX_SUN_TIME]).setTextColor(_SunTextColor[wp]);
		((TextView) mSunset[IDX_SUN_TEXT]).setTextColor(_SunTextColor[wp]);
		((TextView) mSunset[IDX_SUN_TIME]).setTextColor(_SunTextColor[wp]);

		for (int i = 0; i < 8; i++) {
			((TextView) mLifeIndexView[i].findViewById(R.id.life_text)).setTextColor(_lifeTextColor[wp]);
			((TextView) mLifeIndexView[i].findViewById(R.id.life_index)).setTextColor(_lifeIndexColor[wp]);
		}

	}

	private boolean isViewVisible(View view) {
		if (view != null) {
			return view.getVisibility() == View.VISIBLE;
		} else {
			return false;
		}
	}

	private void applyRotation(int position, float start, float end) {
		// 找旋转中心点
		float centerX = mWeatherAll.getWidth() / 2.0f;
		float centerY = mWeatherAll.getHeight() / 2.0f;

		// 新建动画
		final RotateAnim rotation = new RotateAnim(start, end, centerX, centerY, 310.0f, true);
		rotation.setDuration(300);
		rotation.setFillAfter(true);
		rotation.setInterpolator(new AccelerateInterpolator());
		rotation.setAnimationListener(new DisplayNextView(position));

		mWeatherAll.setDrawingCacheEnabled(true);
		mWeatherAll.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_AUTO);
		mLifeIndex.setDrawingCacheEnabled(true);
		mLifeIndex.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_AUTO);
		if (position == 0) {
			mWeatherAll.startAnimation(rotation);
		} else {
			mLifeIndex.startAnimation(rotation);
		}

		// mPosition = -mPosition;
	}

	/**
	 * 用于监听动画完成的listener
	 */
	private final class DisplayNextView implements Animation.AnimationListener {
		private final int mDisplayPosition;

		private DisplayNextView(int position) {
			mDisplayPosition = position;
		}

		public void onAnimationStart(Animation animation) {
		}

		public void onAnimationEnd(Animation animation) {
			if (mDisplayPosition == 0) {
				mLifeButton.setVisibility(View.GONE);
				mForecastButton.setVisibility(View.VISIBLE);
				mWeatherAll.post(new SwapViews(mDisplayPosition));
			} else {
				mForecastButton.setVisibility(View.GONE);
				mLifeButton.setVisibility(View.VISIBLE);
				mLifeIndex.post(new SwapViews(mDisplayPosition));
			}

		}

		public void onAnimationRepeat(Animation animation) {
		}
	}

	/**
	 * 用于做第二个动画
	 */
	private final class SwapViews implements Runnable {
		private final int mPosition;

		public SwapViews(int position) {
			mPosition = position;
		}

		public void run() {
			float centerX = mWeatherAll.getWidth() / 2.0f;
			float centerY = mWeatherAll.getHeight() / 2.0f;

			RotateAnim rotation = new RotateAnim(-90, 0, centerX, centerY, 310.0f, false);
			rotation.setDuration(300);
			rotation.setFillAfter(true);
			rotation.setInterpolator(new DecelerateInterpolator());
			rotation.setAnimationListener(new AnimationListener() {

				@Override
				public void onAnimationStart(Animation animation) {
					// TODO Auto-generated method stub

				}

				@Override
				public void onAnimationRepeat(Animation animation) {
					// TODO Auto-generated method stub

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					mLifeIndex.setDrawingCacheEnabled(false);
					mWeatherAll.setDrawingCacheEnabled(false);
				}
			});

			if (mPosition == 0) {
				mLifeIndex.setVisibility(View.VISIBLE);
				mWeatherAll.setVisibility(View.GONE);
				mLifeIndex.startAnimation(rotation);
			} else {
				mWeatherAll.setVisibility(View.VISIBLE);
				mLifeIndex.setVisibility(View.GONE);
				mWeatherAll.startAnimation(rotation);
			}

		}
	}

	private void updateSunTime(View[] views, WeatherInfo wi, int i) {
		TextView tvText = (TextView) views[IDX_SUN_TEXT];
		ImageView ivIcon = (ImageView) views[IDX_SUN_ICON];
		TextView tvTime = (TextView) views[IDX_SUN_TIME];

		if (i == 0) {
			tvTime.setText(wi.getSunRiseStrForLocal());
			tvText.setText("日出时间：");
			ivIcon.setImageResource(R.drawable.sun_rise_icon);
		} else {

			tvTime.setText(wi.getSunSetStrForLocal());
			tvText.setText("日落时间：");
			ivIcon.setImageResource(R.drawable.sun_set_icon);
		}

	}

	/**
	 * 更新生活指数预报
	 */
	private void updateLifeIndexForecast(View[] v, WeatherInfo wi) {
		TextView indexName = null;
		ImageView indexIcon = null;
		TextView lifeIndex = null;
		if (!Utility.isOut(wi)) {
			Lifedex lifeIndexs = wi.getLifdex();
			for (int i = 0; i < 8; i++) {
				indexName = (TextView) v[i].findViewById(R.id.life_text);
				indexIcon = (ImageView) v[i].findViewById(R.id.life_icon);
				lifeIndex = (TextView) v[i].findViewById(R.id.life_index);
				indexName.setText(getResources().getStringArray(R.array.text_of_life_index)[i]);
				indexIcon.setImageResource(lifeIndexId[i]);
				switch (i) {
				case 0:
					lifeIndex.setText(lifeIndexs.getUv());
					break;
				case 1:
					lifeIndex.setText(lifeIndexs.getCloth());
					break;
				case 2:
					lifeIndex.setText(lifeIndexs.getComfort());
					break;
				case 3:
					lifeIndex.setText(lifeIndexs.getCold());
					break;
				case 4:
					lifeIndex.setText(lifeIndexs.getCwash());
					break;
				case 5:
					lifeIndex.setText(lifeIndexs.getInsolate());
					break;
				case 6:
					lifeIndex.setText(lifeIndexs.getSport());
					break;
				case 7:
					lifeIndex.setText(lifeIndexs.getUmbrella());
					break;

				}
			}

		}
	}
}
