package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getTempOrCurrent;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.repaintPreview;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;

abstract class AbstractDiyableUnitWithItsOptionItemsAreRadioButtons<E extends Enum> extends AbstractDiyableUnit implements OnCheckedChangeListener {

	/**
	 * @param type
	 *            属于哪个插件
	 */
	public AbstractDiyableUnitWithItsOptionItemsAreRadioButtons(AWType type) {
		super(type);
	}

	/**
	 * 有大量的菜单项是RadioButton构成的。
	 * 
	 * @param values
	 * @param labels
	 * @return
	 */
	protected final RadioButton[] makeRadioOptions(E[] values, String[] labels) {
		if (getTempOrCurrent() == FileGettable.CURRENT && mTempValue != null) {
			throw new IllegalStateException();
		}

		RadioButton[] rs = new RadioButton[values.length];

		for (int i = 0; i < values.length; i++) {
			String optionText = labels[i];
			RadioButton rb = new RadioButton(getActivity());
			rb.setText(optionText);
			rb.setOnCheckedChangeListener(this);
			rb.setTag(values[i]);

			rs[i] = rb;
		}

		return rs;

	}

	protected void prepareOptions(View[] options) {

		for (View v : options) {
			RadioButton rbtn = (RadioButton) v;
			E ee = (E) v.getTag();
			if (ee == getTempValue()) {
				if (!rbtn.isChecked()) {
					rbtn.setChecked(true);
				}

			}
		}
	}

	/**
	 * 编辑中的内容，还没按ok。
	 */
	private E mTempValue;

	/**
	 * 取得编辑中的内容。
	 * 
	 * @return
	 */
	final E getTempValue() {
		return mTempValue;
	}

	@Override
	protected void remakeParams() {
		mTempValue = getValueFromTempSPFile();

	}

	protected abstract E getValueFromTempSPFile();

	/**
	 * 把数据存到TempSharedPreference里去。
	 * 
	 * @param tempValue
	 */
	protected abstract void putTempValue(E tempValue);

	/**
	 * ok键按下了。需要把mTempValue存下，然后清空mTempValue。<br>
	 * 刷新内容。
	 */
	void onOkPressed() {
		if (getTempOrCurrent() == FileGettable.CURRENT && mTempValue != null) {
			throw new IllegalStateException();
		}
		if (!(getActivity() instanceof AppWidgetDiyTool)) {
			throw new IllegalStateException();
		}
		if (mTempValue != null) {
			putTempValue(mTempValue);
			repaintPreview(getType());
		}
	}

	/**
	 * cancel键按下了。把清空mTempValue。<br>
	 * 刷新内容。
	 */
	void onCancelPressed() {
		if (getTempOrCurrent() == FileGettable.CURRENT && mTempValue != null) {
			throw new IllegalStateException();
		}
		if (!(getActivity() instanceof AppWidgetDiyTool)) {
			throw new IllegalStateException();
		}
		mTempValue = getValueFromTempSPFile();
		repaintPreview(getType());
	}

	/**
	 * 有大量的菜单项是RadioButton构成的。<br>
	 * 点击一个之后，需要把其它的取消选中。<br>
	 * 然后设置mTempValue，然后刷新内容。
	 */
	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (getTempOrCurrent() == FileGettable.CURRENT && mTempValue != null) {
			throw new IllegalStateException();
		}
		if (!(getActivity() instanceof AppWidgetDiyTool)) {
			throw new IllegalStateException();
		}
		if (isChecked) {
			mTempValue = (E) buttonView.getTag();
			View[] options = getOptions(false, false);
			for (int i = 0; i < options.length; i++) {
				if (options[i] instanceof RadioButton) {
					RadioButton v = (RadioButton) options[i];
					if (buttonView != v) {
						v.setChecked(false);
					}
				}
			}
			repaintPreview(getType());
		}

	}

}
