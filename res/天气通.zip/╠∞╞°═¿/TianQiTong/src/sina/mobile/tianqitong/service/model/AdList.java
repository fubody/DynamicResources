package sina.mobile.tianqitong.service.model;

import java.io.File;

import sina.mobile.tianqitong.service.simplelistdata.TQTListDataList;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataListItem;
import sina.mobile.tianqitong.service.utility.BitmapCache;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.ImageView;

public class AdList extends TQTListDataList {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String mTimeStamp;

	public AdList(String timeStamp) {
		mTimeStamp = timeStamp;
	}

	public String getTimeStamp() {
		return mTimeStamp;
	}

	public static class AdEntity extends TQTListDataListItem {

		private String mTxt = null;

		public static final int POS_BANNER = 1;

		public static final int ACT_LINK = 1;
		public static final int ACT_DOWNLOAD = 2;

		private int mPos = 1;
		private int mAct = 1;

		private String mId = "";

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public AdEntity(String imageUrl, String clickUrl, String txt, int pos, int act, String id) {
			super(DownloadItem.TYPE_AD_DOWNLOAD);
			setMainUrl(clickUrl);
			mId = id;
			mTxt = txt;
			mPos = pos;
			mAct = act;
			putAutoDownloadHttpUrl(DownloadItem.TYPE_AD_ICON, imageUrl);
		}

		public void setAdImage(ImageView iv) {
			File mIconFile = new File(getAutoDownloadSDFileAbsolutePath(DownloadItem.TYPE_AD_ICON));
			if (mIconFile.exists() && mIconFile.isFile()) {
				iv.setVisibility(View.VISIBLE);
				Bitmap bitmap = null;
				String key = mIconFile.getAbsolutePath();
				if (BitmapCache.getCustomBitmap(key) != null) {
					bitmap = BitmapCache.getCustomBitmap(key);
				} else {
					bitmap = BitmapFactory.decodeFile(mIconFile.getAbsolutePath());
					BitmapCache.putCustomBitmap(key, bitmap);
				}

				bitmap.setDensity(android.util.DisplayMetrics.DENSITY_HIGH);
				iv.setScaleType(ImageView.ScaleType.FIT_XY);
				iv.setImageBitmap(bitmap);
			} else {
				iv.setVisibility(View.GONE);
			}
		}

		public String getTxt() {
			return mTxt;
		}
		
		public String getId() {
			return mId;
		}

		public int getPos() {
			return mPos;
		}

		public int getAct() {
			return mAct;
		}
	}
}
