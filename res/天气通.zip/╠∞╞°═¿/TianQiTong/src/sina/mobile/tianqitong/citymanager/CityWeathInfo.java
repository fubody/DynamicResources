package sina.mobile.tianqitong.citymanager;

public class CityWeathInfo {
	public String cityCode = "";
	public String cityName = "";
	public boolean isDefaultCity;
	public boolean isBrodcastCity;
	public boolean isCurrentCity;
	public int icon = -100;
	// public int incon=-100;
	public int heightTem = -274;
	public int lowTem = -274;
	public String weahter = "";
	public boolean isDay=true;

// public static CityWeathInfo copyCityWeathInfo(CityWeathInfo c) {
// if (c == null)
// return null;
// CityWeathInfo tem = new CityWeathInfo();
// tem.cityCode = c.cityCode;
// tem.cityName = c.cityName;
// tem.isDefaultCity = c.isDefaultCity;
// tem.isBrodcastCity = c.isBrodcastCity;
// tem.dayIcon = c.dayIcon;
// tem.nightIcon = c.nightIcon;
// tem.heightTem = c.heightTem;
// tem.lowTem = c.lowTem;
// tem.isCurrentCity=c.isCurrentCity;
// return tem;
// }
}
