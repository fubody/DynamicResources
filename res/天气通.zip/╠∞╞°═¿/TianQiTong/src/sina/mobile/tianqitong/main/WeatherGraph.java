package sina.mobile.tianqitong.main;

import java.util.Arrays;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.model.PastWeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.BitmapCache;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.WeathIconUtil;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

/**
 * 这个类是天气曲线，继承于View。负责绘制曲线、图标、温度，以及播放曲线动画。
 * 
 * @author 黄恪
 * 
 */
public class WeatherGraph extends View {

	private Context context;

	/** 用来绘制当前天气状况的 */
	private ForeCast[] mWheatherInfo;

	private boolean isDrawPastWeather;

	public WeatherGraph(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.context = context;
		init(context);
	}

	public WeatherGraph(Context context) {
		super(context);
		this.context = context;
		init(context);
	}

	private float mDensity = 1;

	/**
	 * 初始化，缓存所有的静态图片加速绘制。
	 * 
	 * @param c
	 */
	private void init(Context c) {

		WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		mDensity = dm.density;

	}

	private int dipTopx(int dipInt) {
		return (int) (((float) dipInt) * mDensity);
	}

	/**
	 * 对应的天气数据
	 */
	private WeatherInfo _wi = null;

	/**
	 * 标记是否set了新的weatherInfo
	 */
// private boolean _dataChanged = true;

	/**
	 * 标记是否正在动画
	 */
	private boolean _animStarting = false;

	/**
	 * 用新的WeatherInfo更新界面。真正的更新操作会在onMeasure里做。
	 * 
	 * @param cityName
	 *            目前城市名显示在CustomFrameLayout里，所以这个参数目前没用。
	 * @param wi
	 *            新的WeatherInfo
	 */
	public void updateUI(String cityName, WeatherInfo wi, PastWeatherInfo pwi, boolean noAnim) {
		if (wi == null) {
			return;
		}
		if (_wi != null) {
			if (pwi == null && wi.getCityCode().equals(_wi.getCityCode()) && wi.getPubdateStr().equals(_wi.getPubdateStr())) {
				return;
			}
		}
		finishAnim();

		_wi = wi;

		if (noAnim) {
			_g = null;
		} else {
			invalidate();
		}

		isDrawPastWeather = !SPUtility.getSPBoolean(context, R.string.boolean_use_history_weather_check);
		if (isDrawPastWeather) {
			mWheatherInfo = PastWeatherInfo.getYeasterdayAndForecast(wi, pwi);
		} else {
			mWheatherInfo = _wi.getForecasts();
		}

		initGraph();

	}

	/**
	 * 当前画在屏幕上的图
	 */
	private Graph _g = null;

	/**
	 * 用更新来的WeatherInfo构建的图，不画，_g会改变内容慢慢向这个靠近，以形成动画。
	 */
	private Graph _newG = null;

	public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int wspecMode = MeasureSpec.getMode(widthMeasureSpec);
		int wspecSize = MeasureSpec.getSize(widthMeasureSpec);

		int hspecMode = MeasureSpec.getMode(heightMeasureSpec);
		int hspecSize = MeasureSpec.getSize(heightMeasureSpec);

		int w = 0, h = 0;

		switch (wspecMode) {
		case MeasureSpec.UNSPECIFIED:
			throw new IllegalArgumentException();
		case MeasureSpec.AT_MOST:
		case MeasureSpec.EXACTLY:
			w = wspecSize;
			break;
		}

		switch (hspecMode) {
		case MeasureSpec.UNSPECIFIED:
			throw new IllegalArgumentException();
		case MeasureSpec.AT_MOST:
		case MeasureSpec.EXACTLY:
			h = hspecSize;
			break;
		}
		setMeasuredDimension(w, h);

		initGraph();

	}

	private void initGraph() {
		// 尺寸计算完毕。下面开始进行曲线各个值的计算。

		// 去掉之后会有问题
		if (_g != null) {
			_g._height = getMeasuredHeight();
			_g._width = getMeasuredWidth();

			_g.makeConst();
// _g.makeYOfZero();
// _g.makeRamp();
			_g.makeGraph();
		}

// if (!_dataChanged) {
// return;
// }

		if (_wi == null || mWheatherInfo.length == 0) {
			return;
		}

		if (_g == null) {
			_g = new Graph();
			_g._wi = _wi;
			_g._height = getMeasuredHeight();
			_g._width = getMeasuredWidth();

			_g.makeConst();
// _g.makeYOfZero();
// _g.makeRamp();
			_g.makeGraph();
		} else {
			if (_wi == _g._wi) {
				return;
			}
			_newG = new Graph();
			_newG._wi = _wi;
			_newG._height = getMeasuredHeight();
			_newG._width = getMeasuredWidth();

			_newG.makeConst();
// _newG.makeYOfZero();
// _newG.makeRamp();
			_newG.makeGraph();

			_sYofZero = _g._yOfZero * _s;

			makeSteps();

			_sYOfHighTemperatures = new int[5];
			_sYOfLowTemperatures = new int[5];
			for (int i = 0; i < _g._yOfHighTemperatures.length; i++) {
				_sYOfHighTemperatures[i] = _g._yOfHighTemperatures[i] * _s;
				_sYOfLowTemperatures[i] = _g._yOfLowTemperatures[i] * _s;
			}
			_currentMillisecond = 0L;
			_animStarting = true;
		}

	}

	/**
	 * 强制结束动画
	 */
	public void finishAnim() {
		if (_newG == null) {
			return;
		}

		// isOtherAm = true;
		// _h.sendEmptyMessage(1);
		// thermometerScope = 0;
		_g = _newG;
		_newG = null;
		_animStarting = false;
// _sYHighStep = null;
// _sYLowStep = null;
		_sYOfHighTemperatures = null;
		_sYOfLowTemperatures = null;
		_currentMillisecond = 0L;
		_animStarting = false;
		_savedMillisecond = 0L;
	}

	private int _sYZeroStep = 0;
	private int[] _sYHighStep = null;
	private int[] _sYLowStep = null;

	private int _sYofZero = 0;
	private int[] _sYOfHighTemperatures = null;
	private int[] _sYOfLowTemperatures = null;

	private void makeSteps() {
		try {
			int sframes = (int) ((_animDurationMillsecond - _currentMillisecond) * _s / _millisecondPerFrame);

			_sYZeroStep = (_newG._yOfZero - _g._yOfZero) * _ss / sframes;// TODO 这里会抛除零异常？！

			if (_sYHighStep == null) {
				_sYHighStep = new int[5];
				_sYLowStep = new int[5];
			}

			for (int i = 0; i < _g._yOfHighTemperatures.length; i++) {
				_sYHighStep[i] = ((_newG._yOfHighTemperatures[i] - _g._yOfHighTemperatures[i]) * _ss) / sframes;
				_sYLowStep[i] = ((_newG._yOfLowTemperatures[i] - _g._yOfLowTemperatures[i]) * _ss) / sframes;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 初始认为帧率是20帧每秒。在画的时候会动态计算这个。
	private static int MAX_FRAME_PER_SECOND = 25;
	private static long _millisecondPerFrame = 1000L / MAX_FRAME_PER_SECOND;
	private static long _animDurationMillsecond = 500L;
	private long _currentMillisecond = 0L;
	private long _savedMillisecond = 0L;

	public void onDraw(Canvas canvas) {

		if (_wi == null || mWheatherInfo.length == 0) {
			return;
		}

		if (!_animStarting) {
			if (_g != null) {
				// _g.drawRamp(canvas);
				// _g.drawBoxes(canvas);
				// _g.drawZero(canvas);
				_g.drawGraph(canvas);
				_g.drawIconAndText(canvas);

			}
		} else {

			if (_savedMillisecond == 0L) {
				_savedMillisecond = System.currentTimeMillis();

			} else {
				_millisecondPerFrame = System.currentTimeMillis() - _savedMillisecond;
				_currentMillisecond += _millisecondPerFrame;

				_savedMillisecond = System.currentTimeMillis();
			}
			if (_g != null) {

				if (_currentMillisecond >= _animDurationMillsecond) {
					finishAnim();

					// _g.drawRamp(canvas);
					// _g.drawBoxes(canvas);
					// _g.drawZero(canvas);
					_g.drawGraph(canvas);
					_g.drawIconAndText(canvas);

				} else {
					_sYofZero = _sYofZero + _sYZeroStep;
					_g.setYOfZero(_sYofZero / _s);
					// _g.makeRamp();
					// _g.drawRamp(canvas);
					// _g.drawBoxes(canvas);
					// _g.drawZero(canvas);

					for (int i = 0; i < _g._yOfHighTemperatures.length; i++) {
						_sYOfHighTemperatures[i] = (_sYOfHighTemperatures[i] + _sYHighStep[i]);
						_sYOfLowTemperatures[i] = (_sYOfLowTemperatures[i] + _sYLowStep[i]);
						_g._yOfHighTemperatures[i] = _sYOfHighTemperatures[i] / _s;
						_g._yOfLowTemperatures[i] = _sYOfLowTemperatures[i] / _s;
						if (_newG != null) {
							if (_newG._yOfHighTemperatures[i] == -1) {
								_g._yOfHighTemperatures[i] = -1;
							}
							if (_newG._yOfLowTemperatures[i] == -1) {
								_g._yOfLowTemperatures[i] = -1;
							}
						}
						if (_newG != null) {
							if (_sYHighStep[i] < 0) {
								if (_g._yOfHighTemperatures[i] < _newG._yOfHighTemperatures[i]) {
									_g._yOfHighTemperatures[i] = _newG._yOfHighTemperatures[i];
								}
							} else {
								if (_g._yOfHighTemperatures[i] > _newG._yOfHighTemperatures[i]) {
									_g._yOfHighTemperatures[i] = _newG._yOfHighTemperatures[i];
								}
							}
							if (_sYLowStep[i] < 0) {
								if (_g._yOfLowTemperatures[i] < _newG._yOfLowTemperatures[i]) {
									_g._yOfLowTemperatures[i] = _newG._yOfLowTemperatures[i];
								}
							} else {
								if (_g._yOfLowTemperatures[i] > _newG._yOfLowTemperatures[i]) {
									_g._yOfLowTemperatures[i] = _newG._yOfLowTemperatures[i];
								}
							}

						}
					}

					_g.drawGraph(canvas);

					if (_millisecondPerFrame >= 1000L / MAX_FRAME_PER_SECOND) {
						_h.sendEmptyMessage(0);
					} else {
						_h.sendEmptyMessageDelayed(0, 1000L / MAX_FRAME_PER_SECOND - _millisecondPerFrame);

					}

				}

			}

		}
	}

	Handler _h = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == 0) {
				invalidate();
				makeSteps();
			}

		}
	};

	/**
	 * 整型乘除用来保证精度用的
	 */
	private static final int _s = 256;
	private static final int _ss = 256 * 256;

	private class Graph {

		private static final int _amountOfBoxes = 20;
		private static final int _amountOfTopBoxes = 5;
		private static final int _amountOfBottomBoxes = 5;

		private WeatherInfo _wi = null;

		private static final int _nOfRamp = 100;
		private static final int _rampTopColor = 0x55ffa000;
		private static final int _rampZeroColor = 0x00000000;
		private static final int _rampBottomColor = 0x3300deff;

		private static final int _dashedHighLineColor = 0xffc39e73;
		private static final int _dashedLowLineColor = 0xff9fd1d7;
		private static final int _darkLineColor = 0x26000000;
		public int[] _rampInts = null;
		int _yOfZero = -1;

		private int _yOfHighestTemperature;
		private int _sPixelsPerCentigrade;
		private int _highestTemperature;
		private int _lowestTemperature;

		int[] _yOfHighTemperatures = null;
		int[] _yOfLowTemperatures = null;
		int sPixelsPerBox;

		public void makeConst() {
			_highestTemperature = Integer.MIN_VALUE;
			_lowestTemperature = Integer.MAX_VALUE;
			ForeCast[] fcs = mWheatherInfo;

			// 屏幕上只显示5天的曲线，最高温度位置和最低温度位置尤其必须要在5天里找而不是6天。
			for (int i = 0; i < 5; i++) {
				ForeCast fc = fcs[i];
				if (fc.getHigh() > _highestTemperature && fc.getHigh() != -274) {
					_highestTemperature = fc.getHigh();
				}
				if (fc.getLow() < _lowestTemperature && fc.getLow() != -274) {
					_lowestTemperature = fc.getLow();
				}
			}
			sPixelsPerBox = getMeasuredHeight() * _s / _amountOfBoxes;
			_sPixelsPerCentigrade = getMeasuredHeight() * (_amountOfBoxes - _amountOfBottomBoxes - _amountOfTopBoxes) * _s / ((_highestTemperature - _lowestTemperature) * _amountOfBoxes);
			_yOfHighestTemperature = (sPixelsPerBox * (_amountOfTopBoxes)) / _s;

			_sLeftSpace = _width * _s / 8;
			_sRightSpace = _width * _s / 8;
			_sWidthOfOneDay = (_width * _s - _sLeftSpace - _sRightSpace) / 4;

			_distanceBetweenPointAndIcon = dipTopx(_width / 43);
			_distanceBetweenIconAndText = _distanceBetweenPointAndIcon;
		}

		public void makeYOfZero() {
			_yOfZero = _yOfHighestTemperature + _highestTemperature * _sPixelsPerCentigrade / _s;
			setYOfZero(_yOfZero);
		}

		public void setYOfZero(int yOfZero) {
			_yOfZero = yOfZero;
			if (_yOfZero <= 0) {
				_yOfZero = 0;
			}
			if (_yOfZero >= _height) {
				_yOfZero = _height;
			}
		}

		public void makeRamp() {
			_rampInts = new int[_nOfRamp];
			int zeroPoint = _yOfZero * _nOfRamp / _height;
			if (zeroPoint > 0 && zeroPoint < _nOfRamp - 1) {
				makeRamp(_rampTopColor, _rampZeroColor, _rampInts, 0, zeroPoint);
				makeRamp(_rampBottomColor, _rampZeroColor, _rampInts, zeroPoint, _nOfRamp - 1);
			} else if (zeroPoint <= 0) {
				makeRamp(_rampBottomColor, _rampZeroColor, _rampInts, 0, _nOfRamp - 1);
			} else if (zeroPoint >= _nOfRamp - 1) {
				makeRamp(_rampTopColor, _rampZeroColor, _rampInts, 0, _nOfRamp - 1);
			}
		}

		public void drawRamp(Canvas canvas) {
			Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setStyle(Style.FILL_AND_STROKE);

			int th = _height * _s;
			int tstep = th / _rampInts.length;
			int ty = 0;
			for (int i = 0; i < _rampInts.length; i++) {
				paint.setColor(_rampInts[i]);
				canvas.drawRect(0, ty / _s, _width, (ty + tstep) / _s, paint);
				ty = ty + tstep;
			}
		}

		public void drawBoxes(Canvas canvas) {
			Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setColor(0xffffffff);
			paint.setStyle(Style.STROKE);
			paint.setStrokeWidth(2);
			int sPixelsPerBox = _height * _s / _amountOfBoxes;
			int tx = 0, ty = 0;
			for (int i = 0; i < _amountOfBoxes; i++) {
				canvas.drawLine(0, ty / _s, _width, ty / _s, paint);
				canvas.drawLine(tx / _s, 0, tx / _s, _height, paint);
				tx += sPixelsPerBox;
				ty += sPixelsPerBox;
			}
			canvas.drawRect(0, 0, _width - 1, _height - 1, paint);

		}

		public void drawZero(Canvas canvas) {
			if (_yOfZero > 0 && _yOfZero < _height) {
				Paint paint = new Paint();
				paint.setAntiAlias(true);
				paint.setColor(0xffffffff);
				paint.setStyle(Style.STROKE);
				paint.setStrokeWidth(4);
				canvas.drawLine(0, _yOfZero, _width, _yOfZero, paint);
			}
		}

		public void makeGraph() {
			_yOfHighTemperatures = new int[5];
			_yOfLowTemperatures = new int[5];
			Arrays.fill(_yOfHighTemperatures, -274);
			Arrays.fill(_yOfLowTemperatures, -274);

			ForeCast[] fcs = mWheatherInfo;

			for (int i = 0; i < _yOfHighTemperatures.length; i++) {
				if (fcs[i].getHigh() == -274) {
					_yOfHighTemperatures[i] = -1;
				} else {
					_yOfHighTemperatures[i] = _yOfHighestTemperature + (_highestTemperature - fcs[i].getHigh()) * _sPixelsPerCentigrade / _s;
				}
				if (fcs[i].getLow() == -274) {
					_yOfLowTemperatures[i] = -1;
				} else {
					_yOfLowTemperatures[i] = _yOfHighestTemperature + (_highestTemperature - fcs[i].getLow()) * _sPixelsPerCentigrade / _s;
				}
			}
		}

		private int _width, _height;
		private int _sLeftSpace, _sRightSpace, _sWidthOfOneDay;
		private int _distanceBetweenPointAndIcon;
		private int _distanceBetweenIconAndText;

		private void drawGraphLine(Canvas canvas, int width, int color, int xOffset, int yOffset) {
			drawGraphLine(canvas, width, color, color, xOffset, yOffset);
		}

		private void drawGraphLine(Canvas canvas, float density, int highColor, int lowColor, int xOffset, int yOffset) {

			Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setStyle(Style.FILL_AND_STROKE);

			int shadedWidth = (int) (4f * density);
			int normalWidth = (int) (3.3f * density);

			int x = _sLeftSpace;
			for (int i = 0; i < 5; i++) {
				int tx0 = x / _s;
				int tx1 = (x - _sWidthOfOneDay) / _s;

				if (_yOfHighTemperatures[i] != -1) {
					if (i != 0 && _yOfHighTemperatures[i - 1] != -1) {
						if (isDrawPastWeather && i == 1) {
							drawDashedLine(canvas, normalWidth, _dashedHighLineColor, tx1, _yOfHighTemperatures[i - 1], tx0, _yOfHighTemperatures[i]);
							drawDashedLine(canvas, shadedWidth, _darkLineColor, tx1, _yOfHighTemperatures[i - 1] + yOffset, tx0, _yOfHighTemperatures[i] + yOffset);
						} else {
							paint.setColor(highColor);
							paint.setStrokeWidth(normalWidth);
							canvas.drawLine(tx1, _yOfHighTemperatures[i - 1], tx0, _yOfHighTemperatures[i], paint);

							paint.setColor(_darkLineColor);
							paint.setStrokeWidth(shadedWidth);
							canvas.drawLine(tx1 + xOffset, _yOfHighTemperatures[i - 1] + yOffset, tx0 + xOffset, _yOfHighTemperatures[i] + yOffset, paint);
						}
					}
				}
				if (_yOfLowTemperatures[i] != -1) {
					if (i != 0 && _yOfLowTemperatures[i - 1] != -1) {
						if (isDrawPastWeather && i == 1) {
							drawDashedLine(canvas, normalWidth, _dashedLowLineColor, tx1, _yOfLowTemperatures[i - 1], tx0, _yOfLowTemperatures[i]);
							drawDashedLine(canvas, shadedWidth, _darkLineColor, tx1, _yOfLowTemperatures[i - 1] + yOffset, tx0, _yOfLowTemperatures[i] + yOffset);
						} else {
							paint.setColor(lowColor);
							paint.setStrokeWidth(normalWidth);
							canvas.drawLine(tx1, _yOfLowTemperatures[i - 1], tx0, _yOfLowTemperatures[i], paint);

							paint.setColor(_darkLineColor);
							paint.setStrokeWidth(shadedWidth);
							canvas.drawLine(tx1 + xOffset, _yOfLowTemperatures[i - 1] + yOffset, tx0 + xOffset, _yOfLowTemperatures[i] + yOffset, paint);

						}
					}
				}

				x = x + _sWidthOfOneDay;
			}
		}

		public void drawDashedLine(Canvas canvas, int width, int color, float startX, float startY, float stopX, float stopY) {
			Paint paint = new Paint();
			paint.setAntiAlias(true);
			paint.setStyle(Style.FILL_AND_STROKE);
			paint.setStrokeWidth(width);
			paint.setColor(color);

			PathEffect effects = new DashPathEffect(new float[] { 12, 7 }, 0);
			paint.setPathEffect(effects);

			canvas.drawLine(startX, startY, stopX, stopY, paint);
		}

		public void drawGraph(Canvas canvas) {

			int hotColor = Color.argb(0xff, Color.red(_rampTopColor), Color.green(_rampTopColor), Color.blue(_rampTopColor));
			int coldColor = Color.argb(0xff, Color.red(_rampBottomColor), Color.green(_rampBottomColor), Color.blue(_rampBottomColor));

			DisplayMetrics dm = new DisplayMetrics();
			((Activity) getContext()).getWindowManager().getDefaultDisplay().getMetrics(dm);
			float d = dm.density;

			// 画阴影和线
			int tmpoffset = (int) (2f * d);
// drawGraphLine(canvas, (int) (4f * d), 0x26000000, tmpoffset, tmpoffset);
// drawGraphLine(canvas, (int) (2.7f * d), 0x4c000000, tmpoffset, tmpoffset);
			// drawGraphLine(canvas, (int) (1.3f * d), 0x4c000000, tmpoffset, tmpoffset);
			drawGraphLine(canvas, d, hotColor, coldColor, tmpoffset, tmpoffset);

			// 画点
			int x = _sLeftSpace;
			for (int i = 0; i < 5; i++) {
				int tx0 = x / _s;
				if (_yOfHighTemperatures[i] != -1) {
					if (isDrawPastWeather && i == 0) {
						Bitmap bmp = BitmapCache.getBitmap(R.drawable.high_temp_dark_point, getResources());
						canvas.drawBitmap(bmp, tx0 - bmp.getWidth() / 2, _yOfHighTemperatures[i] - bmp.getHeight() / 2, null);
					} else {
						Bitmap bmp = BitmapCache.getBitmap(R.drawable.high_temp_point, getResources());
						canvas.drawBitmap(bmp, tx0 - bmp.getWidth() / 2, _yOfHighTemperatures[i] - bmp.getHeight() / 2, null);
					}
				}
				if (_yOfLowTemperatures[i] != -1) {
					if (isDrawPastWeather && i == 0) {
						Bitmap bmp = BitmapCache.getBitmap(R.drawable.low_temp_dark_point, getResources());
						canvas.drawBitmap(bmp, tx0 - bmp.getWidth() / 2, _yOfLowTemperatures[i] - bmp.getHeight() / 2, null);
					} else {
						Bitmap bmp = BitmapCache.getBitmap(R.drawable.low_temp_point, getResources());
						canvas.drawBitmap(bmp, tx0 - bmp.getWidth() / 2, _yOfLowTemperatures[i] - bmp.getHeight() / 2, null);
					}
				}

				x = x + _sWidthOfOneDay;
			}

		}

		// 画图标和温度
		public void drawIconAndText(Canvas canvas) {
			Paint tp = new Paint();
			tp.setAntiAlias(true);
			tp.setColor(0xffffffff);
			DisplayMetrics dm = new DisplayMetrics();
			((Activity) getContext()).getWindowManager().getDefaultDisplay().getMetrics(dm);
			float d = dm.density;
			tp.setTextSize(13.3f * d);

			int x = _sLeftSpace;
			for (int i = 0; i < 5; i++) {
				int tx0 = x / _s;
				if (_yOfHighTemperatures[i] != -1) {

					Bitmap bmp = null;
					if (isDrawPastWeather && i == 0) {
						tp.setColor(_highHistoryTempTextColor);
						bmp = WeathIconUtil.obtionBitmapByType(context, mWheatherInfo[i].getYcode(), WeathIconUtil.ICON_TYPE_HISTORY);
					} else {
						tp.setColor(_highTempTextColor);
						bmp = WeathIconUtil.obtionBitmapByType(context, mWheatherInfo[i].getYcode(), WeathIconUtil.ICON_TYPE_GRAPH);
					}

					int xx = tx0 - bmp.getWidth() / 2;
					int yy = _yOfHighTemperatures[i] - bmp.getHeight() - _distanceBetweenPointAndIcon;
					canvas.drawBitmap(bmp, xx, yy, null);

					String text = mWheatherInfo[i].getHigh() + "°";
					Rect r = new Rect();
					tp.getTextBounds(text, 0, text.length(), r);

					xx = tx0 - r.right / 2;
					yy = yy - _distanceBetweenIconAndText;

					canvas.drawText(text, xx, yy, tp);
				}
				if (_yOfLowTemperatures[i] != -1) {
					// int id = WeatherInfo.getWeatherIconFromYahooCode(_wi.getForecasts()[i].getYcode2(), WeatherInfo.ICON_TYPE_FORECAST, getResources());
					Bitmap bmp = null;
					if (isDrawPastWeather && i == 0) {
						tp.setColor(_lowHistoryTempTextColor);
						bmp = WeathIconUtil.obtionBitmapByType(context, mWheatherInfo[i].getYcode2(), WeathIconUtil.ICON_TYPE_HISTORY);
					} else {
						tp.setColor(_lowTempTextColor);
						bmp = WeathIconUtil.obtionBitmapByType(context, mWheatherInfo[i].getYcode2(), WeathIconUtil.ICON_TYPE_GRAPH);
					}

					int xx = tx0 - bmp.getWidth() / 2;
					int yy = _yOfLowTemperatures[i] + _distanceBetweenPointAndIcon;
					canvas.drawBitmap(bmp, xx, yy, null);

					String text = mWheatherInfo[i].getLow() + "°";
					Rect r = new Rect();
					tp.getTextBounds(text, 0, text.length(), r);

					xx = tx0 - r.right / 2;

					yy = yy + bmp.getHeight() + _distanceBetweenIconAndText - r.top;

					canvas.drawText(text, xx, yy, tp);
				}

				x = x + _sWidthOfOneDay;
			}
		}

		private void makeRamp(int from, int to, int[] ramp, int startIdx, int endIdx) {

			int s = _s;

			int fromA = Color.alpha(from) * s;
			int fromR = Color.red(from) * s;
			int fromG = Color.green(from) * s;
			int fromB = Color.blue(from) * s;
			int toA = Color.alpha(to) * s;
			int toR = Color.red(to) * s;
			int toG = Color.green(to) * s;
			int toB = Color.blue(to) * s;
			int tmp = endIdx - startIdx;
			int aStep = (toA - fromA) / tmp;
			int rStep = (toR - fromR) / tmp;
			int gStep = (toG - fromG) / tmp;
			int bStep = (toB - fromB) / tmp;

			for (int i = startIdx; i <= endIdx; i++) {
				ramp[i] = Color.argb(fromA / s, fromR / s, fromG / s, fromB / s);
				fromA = (fromA + aStep);
				fromR = (fromR + rStep);
				fromG = (fromG + gStep);
				fromB = (fromB + bStep);
			}

		}
	}

	private static final int[] _lowTempColor = new int[] { 0xff286192, 0xffbaecff, 0xff674f29, 0xff3b78ad, 0xff267fba, 0xff286192, 0xff80d3f8, 0xff153653, 0xff80d3f8 };
	private static final int[] _highTempColor = new int[] { 0xfff5872e, 0xfff3bc4d, 0xffffffff, 0xfff98521, 0xffde9216, 0xfff5872e, 0xfff9a732, 0xff313131, 0xfffeb45b };
	private int _highTempTextColor = 0xffffffff, _lowTempTextColor;
	private int _highHistoryTempTextColor = 0xffffffff;
	private int _lowHistoryTempTextColor = 0xffffffff;

	private static final int[] _highHistoryTempColors = new int[] { 0xff5a5a59, 0xff717171, 0xff6c6c69 };
	private static final int[] _lowHistoryTempColors = new int[] { 0xff373737, 0x787878, 0xff696969 };

	public void changeSkin(int skin) {
		int wp = skin;

		// _bmpThermometer0 = BitmapFactory.decodeResource(getResources(), _thermometer0[wp]);
		_lowTempTextColor = _lowTempColor[wp];
		_highTempTextColor = _highTempColor[wp];

		isDrawPastWeather = !SPUtility.getSPBoolean(context, R.string.boolean_use_history_weather_check);
		if (isDrawPastWeather) {
			if (wp == 1) { // 雷雨天气
				_highHistoryTempTextColor = _highHistoryTempColors[1];
				_lowHistoryTempTextColor = _lowHistoryTempColors[1];
			} else if (wp == 6) { // 夜间晴
				_highHistoryTempTextColor = _highHistoryTempColors[2];
				_lowHistoryTempTextColor = _lowHistoryTempColors[2];
			} else { // 默认颜色
				_highHistoryTempTextColor = _highHistoryTempColors[0];
				_lowHistoryTempTextColor = _lowHistoryTempColors[0];
			}
		}

	}
}
