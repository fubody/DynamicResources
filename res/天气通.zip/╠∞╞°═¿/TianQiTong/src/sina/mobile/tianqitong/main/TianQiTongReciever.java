package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_ALARM;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_ALL_UPDATED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_TTS_PLAYING;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_TTS_PLAYING_FINISHED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_UPDATE_WIDGET_CLOCK;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_WIDGET_CITY_CHANGED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WIDGET;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WIDGET_BTN;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WIDGET_CLOCK;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL_AND_PLAYTTS_MAYBE_POPUP;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_KEY_INT_ALARM_TYPE;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_KEY_LONG_ALARM_TIME;

import java.util.Calendar;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongAlarm;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

public class TianQiTongReciever extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		boolean hasCity = true;
		if (SPUtility.getSPStringArray(context, R.string.strs_cached_citys, ',').length == 0) {
			hasCity = false;
		}

		String action = intent.getAction();

		if (action.equals(ACTION_ALARM)) {
			if (!hasCity) {
				return;
			}
			int type = intent.getIntExtra(BUNDLE_KEY_INT_ALARM_TYPE, TianQiTongAlarm.RETURN_TYPE_NONE);
			long time = intent.getLongExtra(BUNDLE_KEY_LONG_ALARM_TIME, 0L);

			if (Math.abs(System.currentTimeMillis() - time) > 1000L * 10L * 60L) {
				TianQiTongAlarm.applyAlarm(context);
				return;
			}

			Intent i = null;
			switch (type) {
			case TianQiTongAlarm.RETURN_TYPE_NONE: {
				// 不应该到这里。
			}
				break;
			case TianQiTongAlarm.RETURN_TYPE_UPDATE: {
				i = new Intent(ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL);
			}
				break;
			case TianQiTongAlarm.RETURN_TYPE_TTS:
			case TianQiTongAlarm.RETURN_TYPE_BOTH: {
				// 开始更新
				i = new Intent(ACTION_START_SERVICE_WAKE_UP_AND_UPDATE_ALL_AND_PLAYTTS_MAYBE_POPUP);
			}
				break;
			}

			context.startService(i);

		} else if (action.equals(ACTION_BC_TTS_PLAYING_FINISHED) || action.equals(ACTION_BC_TTS_PLAYING)) {

			Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET_BTN);
			context.startService(i);

		} else if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {
			// lyang changed 开机启动 暂时
// boolean start = SPUtility.getSPBoolean(context, R.string.boolean_auto_start_after_booting);
// boolean start = true;
			if (hasCity) {
				// 用户新安装天气通，没启动，然后重启电脑，会导致问题
				Intent i = new Intent(context, TianQiTongService.class);
				context.startService(i);
			}
		} else if (action.equals(ACTION_BC_WIDGET_CITY_CHANGED)) {
			Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET);
			context.startService(i);
		} else if (action.equals(ACTION_BC_ALL_UPDATED)) {
			String cityCode = SPUtility.getSPString(context, R.string.str_widget_city_code);
			if (cityCode.length() != 0) {
				Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET);
				context.startService(i);
				SPUtility.putSPStringLong(context, R.string.strlong_refresh_milletime, System.currentTimeMillis());
			}
			// 当天气数据有更新就要更新天气提醒内容
			Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION);
			context.startService(i);

		} else if (ACTION_BC_UPDATE_WIDGET_CLOCK.equals(action) || Intent.ACTION_USER_PRESENT.equals(action) || Intent.ACTION_TIME_CHANGED.equals(action) || Intent.ACTION_DATE_CHANGED.equals(action)
				|| Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {

// long time = intent.getLongExtra("time", -1);
// time = time == -1 ? (System.currentTimeMillis()) : time;
// applyTickAlarm(context, time);

			Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET_CLOCK);
			context.startService(i);
		} else {
			// super.onReceive(context, intent);
		}
	}

	public static void applyTickAlarm(Context context, long curTime) {

		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(curTime + 60000L);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		long time = c.getTimeInMillis();

		Intent i = new Intent(ACTION_BC_UPDATE_WIDGET_CLOCK);
// i.putExtra("time", time);
		PendingIntent sender = PendingIntent.getBroadcast(context, 0, i, PendingIntent.FLAG_CANCEL_CURRENT);
		AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
		am.set(AlarmManager.RTC, time, sender);

	}

	/**
	 * 判断是否存在这样一个应用
	 * 
	 * @param context
	 * @param intent
	 * @return
	 */
	public static boolean isIntentAvailable(Context context, Intent intent) {
		final PackageManager packageManager = context.getPackageManager();
		List<ResolveInfo> list = packageManager.queryIntentActivities(intent, 0);
		return list.size() > 0;
	}

}
