package sina.mobile.tianqitong.service.frm;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import android.os.Handler;
import android.os.Message;

/**
 * 这个类实现了一个简单的利用handler的消息队列形式的Observer模式。<br>
 * 调用者利用一个Handler作为Observer，通过register注册进本静态类。<br>
 * 然后如果数据变化，需要控制数据的对象调用notify静态方法，通知观察者数据变化。<br>
 * 用的是弱引用，不需要unregister，但是同时，注册进来的Handler也不能是匿名内部类。
 * 
 * @author 黄恪
 * 
 */
public final class HandlerObserver {
	private HandlerObserver() {

	}

	/**
	 * 表示所有事件
	 */
	public static final int NTY2HANDLER_MSG_WHAT_ALL = -1;

	/**
	 * 桌面4x2插件皮肤包列表更新了。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_4x2APPWIDGETSKIN_LIST_UPDATED = 0;

	/**
	 * 桌面4x1插件皮肤包列表更新了。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_4x1APPWIDGETSKIN_LIST_UPDATED = 1;

	/**
	 * 语音包列表更新了。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_SOUNDENTITY_LIST_UPDATED = 2;

	/**
	 * 下载项增加了的广播事件。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_ADDED = 3;
	/**
	 * 下载项进度更新了的广播事件。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_PROGRESS_UPDATED = 4;
	/**
	 * 下载项被取消并且删除了的广播事件。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_DELETED = 5;

	/**
	 * 广告列表更新了
	 */
	public static final int NTY2HANDLER_MSG_WHAT_LIST_AD = 6;

	/**
	 * 新浪推荐列表更新了。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_SINA_RECOMMEND_LIST_UPDATED = 7;
	
	/**
	 * 一周推荐列表更新了。
	 */
	public static final int NTY2HANDLER_MSG_WHAT_WEEK_RECOMMEND_LIST_UPDATED = 8;

	/**
	 * 事件对应handler的表。
	 */
	private final static HashMap<Integer, ArrayList<WeakReference<Handler>>> mNty2RegisteredHandlersMap;
	static {
		mNty2RegisteredHandlersMap = new HashMap<Integer, ArrayList<WeakReference<Handler>>>();
	}

	private final static ReentrantReadWriteLock gLock;
	static {
		gLock = new ReentrantReadWriteLock();
	}

	/**
	 * 向Handler发布通知。<br>
	 * 公有，使用的时候一定要注意不要胡发布通知。
	 * 
	 * @param msg
	 *            msg的what就是向观察者通知的事件号。不关注这个事件的观察者不会收到这个通知。
	 */
	public static final void notifyObservers(Message msg) {

		gLock.readLock().lock();

		int[] ntys = new int[] { msg.what, NTY2HANDLER_MSG_WHAT_ALL };
		for (int nty : ntys) {
			ArrayList<WeakReference<Handler>> list = mNty2RegisteredHandlersMap.get(nty);
			if (list == null) {

			} else {
				Iterator<WeakReference<Handler>> iterator = list.iterator();
				while (iterator.hasNext()) {
					WeakReference<Handler> l = iterator.next();
					if (l.get() == null) {
						iterator.remove();
					} else {
						l.get().sendMessage(Message.obtain(msg));
					}
				}
			}
		}
		msg.recycle();

		gLock.readLock().unlock();
	}

	/**
	 * 
	 * @param h
	 *            观察者。
	 * @param ntyEvents
	 *            观察者关注的事件号。
	 */
	public static final void registerObserver(Handler h, int[] ntyEvents) {

		gLock.writeLock().lock();

		if (ntyEvents == null) {
			ntyEvents = new int[] { NTY2HANDLER_MSG_WHAT_ALL };
		}

		for (int ntyEvent : ntyEvents) {
			ArrayList<WeakReference<Handler>> list = mNty2RegisteredHandlersMap.get(ntyEvent);
			if (list == null) {
				list = new ArrayList<WeakReference<Handler>>();
				mNty2RegisteredHandlersMap.put(ntyEvent, list);
			} else {
				Iterator<WeakReference<Handler>> iterator = list.iterator();
				while (iterator.hasNext()) {
					WeakReference<Handler> l = iterator.next();
					if (l.get() == null || l.get() == h) {
						iterator.remove();
					}
				}
			}
			list.add(new WeakReference<Handler>(h));
		}
		gLock.writeLock().unlock();
	}

}
