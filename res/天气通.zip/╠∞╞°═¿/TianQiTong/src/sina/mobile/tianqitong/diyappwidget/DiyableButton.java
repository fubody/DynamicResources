package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getAppActivityName;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getAppPackageName;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getButtonValue;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.putTempButtonValue;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.*;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getTempOrCurrent;

import java.util.EnumMap;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.ButtonFunction;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyButton;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

class DiyableButton extends AbstractDiyableUnitWithItsOptionItemsAreRadioButtons<ButtonFunction> implements View.OnClickListener {

	private DiyButton mButtonType;

	private static EnumMap<ButtonFunction, Integer> mFunction2ResidMap;

	public DiyableButton(AWType type, DiyButton buttonType, EnumMap<ButtonFunction, Integer> function2ResidMap) {
		super(type);
		mButtonType = buttonType;
		mFunction2ResidMap = function2ResidMap;
		remakeParams();
	}

	@Override
	public void drawOnCanvas(Canvas c) {

		if (mFunction2ResidMap.containsKey(getTempValue())) {
			int resId = mFunction2ResidMap.get(getTempValue());

			Bitmap btn = getBitmap(getActivity().getResources(), resId);// BitmapFactory.decodeResource(getActivity().getResources(), resId);

			Rect mButtonRect = getDrawBounds();

			c.drawBitmap(btn, mButtonRect.left, mButtonRect.top, null);

			btn = null;

		}

	}

	@Override
	public View[] makeOptions() {

		ButtonFunction[] buttonFunction = new ButtonFunction[] { ButtonFunction.TTS_SETTING, ButtonFunction.UPDATE_DATA, ButtonFunction.NULL, ButtonFunction.PLAY_TTS, ButtonFunction.WEIBO,
				ButtonFunction.APP };

		String[] optionTexts = new String[buttonFunction.length];

		for (int i = 0; i < buttonFunction.length; i++) {
			optionTexts[i] = "";

			switch (buttonFunction[i]) {
			case TTS_SETTING: {
				optionTexts[i] = "天气通定时唤醒播报";
			}
				break;
			case UPDATE_DATA: {
				optionTexts[i] = "更新天气";
			}
				break;
			case NULL: {
				optionTexts[i] = "不显示";
			}
				break;
			case WEIBO: {
				optionTexts[i] = "新浪微博";
			}
				break;
			case APP: {
				String pkgname = getAppPackageName(getActivity(), getCurAWType(), FileGettable.TEMP, mButtonType);
				String clsname = getAppActivityName(getActivity(), getCurAWType(), FileGettable.TEMP, mButtonType);

				PackageManager pm = getActivity().getPackageManager();
				ActivityInfo ai = null;

				try {
					ai = pm.getActivityInfo(new ComponentName(pkgname, clsname), 0);

				} catch (NameNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (ai == null) {
					optionTexts[i] = "其它应用";
				} else {
					optionTexts[i] = "其它应用(" + ai.loadLabel(pm) + ")";
				}

			}
				break;
			case PLAY_TTS: {
				optionTexts[i] = "语音播报";
			}
				break;
			}
		}

		View[] rs = makeRadioOptions(buttonFunction, optionTexts);
		for (View v : rs) {
			ButtonFunction bf = (ButtonFunction) v.getTag();
			if (bf == ButtonFunction.APP) {
				v.setOnClickListener(this);
				break;
			}
		}
		return rs;
	}

	@Override
	public void putTempValue(ButtonFunction tempValue) {
		putTempButtonValue(getActivity(), getType(), mButtonType, tempValue);
	}

	@Override
	public Rect getTouchableBounds() {
		return getDrawBounds();
	}

	@Override
	protected Rect doMeasureDrawRect() {
		int resId;
		if (mFunction2ResidMap.containsKey(getTempValue())) {
			resId = mFunction2ResidMap.get(getTempValue());
		} else {
			resId = R.drawable.widget_play_tts;
		}

		Options opts = new Options();
		opts.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(getActivity().getResources(), resId, opts);

		Rect mButtonRect = new Rect(0, 0, opts.outWidth * opts.inTargetDensity / opts.inDensity, opts.outHeight * opts.inTargetDensity / opts.inDensity);
		offsetRect(mButtonRect);

		return mButtonRect;

	}

	@Override
	protected ButtonFunction getValueFromTempSPFile() {
		return getButtonValue(getActivity(), getType(), getTempOrCurrent(), mButtonType);
	}

	@Override
	public String getOptionsTitle() {
		return "设置按钮快捷方式";
	}

	@Override
	public void onClick(View v) {
		((AppWidgetDiyTool) getActivity()).mDiyBtn = mButtonType;
		getActivity().showDialog(AppWidgetDiyTool.DIALOG_ID_GET_APP);
	}

}
