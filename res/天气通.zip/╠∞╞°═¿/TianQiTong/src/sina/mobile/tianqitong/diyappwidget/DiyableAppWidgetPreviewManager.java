package sina.mobile.tianqitong.diyappwidget;

import java.util.EnumMap;
import java.util.HashMap;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.text.format.DateFormat;
import android.text.format.Time;
import android.util.DisplayMetrics;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public final class DiyableAppWidgetPreviewManager {

	private DiyableAppWidgetPreviewManager() {

	}

	private static Activity gActivity = null;

	private static WeatherInfo gWi = null;

	private static String gCityName = null;

	private static FileGettable gTempOrCurrent = null;

	private static float gDensity;

	private static int gWidthPixels;

	private static int gHeightPixels;

	public static void init(Activity activity, WeatherInfo wi, String cityName, FileGettable tempOrCurrent) {
		if (activity == null) {
			if (wi == null) {
				throw new IllegalArgumentException();
			}
		}
		if (wi != null) {
			gWi = wi;
		}
		if (activity != null) {
			gActivity = activity;
			DisplayMetrics dm = new DisplayMetrics();
			activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
			gDensity = dm.density;
			gWidthPixels = dm.widthPixels;
			gHeightPixels = dm.heightPixels;
		}
		if (cityName != null) {
			String[] tmp = Utility.split(cityName, '.');
			cityName = tmp[tmp.length - 1];
			gCityName = cityName;
		}
		if (tempOrCurrent != null) {

			if (tempOrCurrent != gTempOrCurrent) {
				gTempOrCurrent = tempOrCurrent;

				if (gCurAWType != null) {// 加注释，太绕。
					repaintPreview(gCurAWType);
				}
			}

		}

	}

	static Activity getActivity() {
		return gActivity;
	}

	static WeatherInfo getWeatherInfo() {
		return gWi;
	}

	static String getCityName() {
		return gCityName;
	}

	static FileGettable getTempOrCurrent() {
		return gTempOrCurrent;
	}

	static float getDensity() {
		return gDensity;
	}

	static int getWidthPixels() {
		return gWidthPixels;
	}

	static int getHeightPixels() {
		return gHeightPixels;
	}

// private static EnumMap<AWType, Bitmap> gType2AWPreviewMap = null;
// private static EnumMap<AWType, AbstractDiyableUnit[]> gType2DiyableUnitsMap = null;

	private static EnumMap<AWType, AbstractDiyableAppWidget> gType2DiyableAppWidgetsMap = null;

// static synchronized Bitmap rebuildPreview(AWType type) {
// if (gType2AWPreviewMap == null) {
// gType2AWPreviewMap = new EnumMap<AWType, Bitmap>(AWType.class);
// }
// if (gType2DiyableUnitsMap == null) {
// gType2DiyableUnitsMap = new EnumMap<AWType, AbstractDiyableUnit[]>(AWType.class);
// }
//
// gType2DiyableUnitsMap.remove(type);
// AbstractDiyableUnit[] tr = makeDiyableUnits(type);
// gType2DiyableUnitsMap.put(type, tr);
//
// gType2AWPreviewMap.remove(type);
// Bitmap r = getPreview(type);
// gType2AWPreviewMap.put(type, r);
//
// return r;
//
// }

	static synchronized void repaintPreview(AWType type) {

		if (gType2DiyableAppWidgetsMap == null) {
			// TODO 不抛异常的话会造成下面空指针。
		}
		AbstractDiyableAppWidget adaw = gType2DiyableAppWidgetsMap.get(type);
		adaw.releaseCache();
		adaw.layout();
	}

	static synchronized AbstractDiyableAppWidget makeDiyableUnits(AWType type) {

		AbstractDiyableAppWidget diyableAppWidget = null;
		if (gType2DiyableAppWidgetsMap == null) {
			gType2DiyableAppWidgetsMap = new EnumMap<AWType, AbstractDiyableAppWidget>(AWType.class);
		} else {
			diyableAppWidget = gType2DiyableAppWidgetsMap.get(type);
		}
		if (diyableAppWidget == null) {
			switch (type) {
			case _1ST_4X2: {
				diyableAppWidget = new _1st4x2DiyableAppWidget();
			}
				break;
			case _1ST_4X1: {
				diyableAppWidget = new _1st4x1DiyableAppWidget();
			}
				break;
			case _2ND_4X2: {
				diyableAppWidget = new _2nd4x2DiyableAppWidget();
			}
				break;
			}
			diyableAppWidget.layout();
			gType2DiyableAppWidgetsMap.put(type, diyableAppWidget);
		}
		return diyableAppWidget;

	}

	public static synchronized void layoutDiyableUnits(AWType type) {

		AbstractDiyableAppWidget diyableAppWidget = makeDiyableUnits(type);
		diyableAppWidget.layout();

	}

	static synchronized void getPreview(AWType type, Canvas canvas) {

		AbstractDiyableAppWidget diyableAppWidget = makeDiyableUnits(type);

		diyableAppWidget.draw(canvas);

	}

	private static Bitmap gWallpaper = null;

	private final static Bitmap gNullBmp = Bitmap.createBitmap(1, 1, Config.ARGB_8888);

	public final static Bitmap getNullBmp() {
		return gNullBmp;
	}

	static synchronized Bitmap getWallpaper() {

		if (gActivity == null) {
			return gNullBmp;
		}

		if (gWallpaper == null) {
			DisplayMetrics dm = new DisplayMetrics();
			gActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
			int width = dm.widthPixels;

			
			try{
				WallpaperManager wm = (WallpaperManager) gActivity.getSystemService(Context.WALLPAPER_SERVICE);
				Bitmap bmp = ((BitmapDrawable) wm.getDrawable()).getBitmap();
				gWallpaper = Bitmap.createBitmap(width, bmp.getHeight(), bmp.getConfig());
				Canvas c = new Canvas(gWallpaper);
				Matrix m = new Matrix();
				m.postTranslate(-(bmp.getWidth() - width) / 2, 0);
				c.drawBitmap(bmp, m, null);
				bmp = null;
				c = null;
			}catch(OutOfMemoryError oome){
				gWallpaper=Bitmap.createBitmap(width,dm.heightPixels, Bitmap.Config.RGB_565);
				Canvas c = new Canvas(gWallpaper);
				c.drawColor(Color.MAGENTA);
				c=null;
			}
			
			
		}
		return gWallpaper;
	}

// private static Bitmap gCursor = null;

// static final int RADIUS_DIP_OF_CURSOR = 15;

	static synchronized Bitmap getCursorBmp() {
		return getBitmap(getActivity().getResources(), R.drawable.awdt_cursor);
	}

	static synchronized int getCursorRadius() {
		return getCursorBmp().getWidth() / 2;
	}

// private static Bitmap gFinger = null;
//
	static synchronized Bitmap getFingerBmp() {
		return getBitmap(getActivity().getResources(), R.drawable.awpv_help_finger);
	}

	private static Animation gCursorAnimation = null;

	private static final Animation gNullAnim = new AlphaAnimation(1, 1);
	{
		gNullAnim.setDuration(10L);
	}

	static synchronized Animation getCursorAnimation() {
		if (gActivity == null) {
			return gNullAnim;
		}
		if (gCursorAnimation == null) {
			gCursorAnimation = AnimationUtils.loadAnimation(gActivity, R.anim.appwidget_diy_tools_cursor);
			gCursorAnimation.initialize(getCursorBmp().getWidth(), getCursorBmp().getHeight(), 0, 0);
		}
		return gCursorAnimation;
	}

	private static Animation gFingerPressAnimation = null;

	static synchronized Animation getFingerPressAnimation() {
		if (gActivity == null) {
			return gNullAnim;
		}
		if (gFingerPressAnimation == null) {
			gFingerPressAnimation = AnimationUtils.loadAnimation(gActivity, R.anim.appwidget_diy_tools_help_finger_press);
			gFingerPressAnimation.initialize(getFingerBmp().getWidth(), getFingerBmp().getHeight(), 0, 0);
		}
		return gFingerPressAnimation;
	}

	private static HashMap<Integer, Bitmap> gBmpCacheMap;// TODO 合并图片缓存

	static Bitmap getBitmap(Resources res, int resId) {
		if (gActivity == null) {
			return gNullBmp;
		}
		if (gBmpCacheMap == null) {
			gBmpCacheMap = new HashMap<Integer, Bitmap>();
		}
		Bitmap bmp = gBmpCacheMap.get(resId);
		if (bmp == null) {
			try {
				bmp = BitmapFactory.decodeResource(res, resId);
			} catch (OutOfMemoryError oome) {
				gBmpCacheMap.clear();
				bmp = BitmapFactory.decodeResource(res, resId);
			}
			gBmpCacheMap.put(resId, bmp);

		}
		return bmp;
	}

	static synchronized void releaseBitmapCacheAndWallpaper() {
		gBmpCacheMap = null;
		gWallpaper = null;
		System.gc();
	}

	static synchronized void releaseBitmapCache() {
		gBmpCacheMap = null;
		System.gc();
	}

	public static synchronized void releaseAll() {

		gCursorAnimation = null;
		gFingerPressAnimation = null;
// gCursor = null;
		gWallpaper = null;
// gFinger = null;

		gType2DiyableAppWidgetsMap = null;

		gActivity = null;

		gWi = null;
		gCityName = null;

		gCurAWType = null;

		gBmpCacheMap = null;
	}

	private static AWType gCurAWType = null;

	static synchronized AWType getCurAWType() {
		return gCurAWType;
	}

	public static synchronized void setCurAWType(AWType type) {

		gCurAWType = type;

		if (type == null) {
			return;
		}

		for (AWType t : gType2DiyableAppWidgetsMap.keySet()) {
			if (t != type) {
				gType2DiyableAppWidgetsMap.get(t).releaseCache();
			}
		}

	}

	static synchronized void getCurPreview(Canvas canvas) {
		if (gCurAWType == null) {
			return;
		}
		getPreview(gCurAWType, canvas);
	}

	static synchronized AbstractDiyableAppWidget getCurDiyableUnits() {
		if (gCurAWType == null) {
			throw new IllegalStateException();
		}
		return makeDiyableUnits(gCurAWType);
	}

	static final int[] getClockNumbers() {// TODO 可以跟桌面插件的方法合并？

		if (gActivity == null) {
			return new int[] { 1, 2, 3, 4 };
		}

		Time _time = new Time();
		_time.setToNow();

		int hour = _time.hour;
		if (!DateFormat.is24HourFormat(gActivity)) {
			if (hour > 12) {
				hour -= 12;
			}
		}

		int hour0 = hour / 10;
		int hour1 = hour % 10;
		int minute0 = _time.minute / 10;
		int minute1 = _time.minute % 10;

		int[] r = new int[4];

		r[0] = hour0;
		r[1] = hour1;
		r[2] = minute0;
		r[3] = minute1;

		return r;
	}

}
