package sina.mobile.tianqitong.appwidgetskinpkg;

import java.util.HashMap;

import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.Utility;
import android.graphics.Canvas;
import android.graphics.Rect;

public abstract class AbstractSkinLayoutUnit {

	/*
	 * 解析进来一律是pix而不是dip
	 */

	protected int x = Integer.MIN_VALUE;
	protected int y = Integer.MIN_VALUE;

	protected String LayoutId = null;
	protected int OffsetX = Integer.MIN_VALUE;
	protected int OffsetY = Integer.MIN_VALUE;

	public static final int LEFT = 0x1;// 1
	public static final int HCENTER = 0x1 << 1;// 2
	public static final int RIGHT = 0x1 << 2;// 4

	public static final int TOP = 0x1 << 3;// 8
	public static final int VCENTER = 0x1 << 4;// 16
	public static final int BOTTOM = 0x1 << 5;// 32

	/**
	 * 横向mask。
	 */
	static final int H_MASK = 0x7;// 0000 0111

	/**
	 * 纵向mask。
	 */
	static final int V_MASK = 0x38;// 0011 1000

	protected int DatumPoint = 0;
	protected int DatumHLine = 0;
	protected int DatumVLine = 0;
	protected String DatumHLineLayoutId = null;
	protected String DatumVLineLayoutId = null;

	protected Rect mDrawRect = null;

	protected AppWidgetSkin mAws = null;

	protected AbstractSkinLayoutUnit(AppWidgetSkin aws) {
		mAws = aws;
	}

	/**
	 * 这个方法必然会在setWeatherInfo之后才被调用。
	 * 
	 * @return
	 */
	protected abstract Rect doMeasureDrawRectWAndH();

	/**
	 * 这个方法必然会在setWeatherInfo之后才被调用。
	 * 
	 * @return
	 */
	protected boolean measureDrawRectWAndH() {
		mDrawRect = doMeasureDrawRectWAndH();
		if (mDrawRect == null) {
			return false;
		} else {
			Rect r = mDrawRect;
			// 这两个if应该都是进不去的。保险起见吧。
			if (r.bottom < r.top) {
				int i = r.bottom;
				r.bottom = r.top;
				r.top = i;
			}
			if (r.right < r.left) {
				int i = r.right;
				r.right = r.left;
				r.left = i;
			}

			r.bottom = r.bottom - r.top;
			r.top = 0;

			r.right = r.right - r.left;
			r.left = 0;
			return true;
		}
	}

	boolean setValue(String attrName, String attrValue) {
		float density = AppWidgetSkinUtility.mDensity;
		if (attrName.equals("x")) {
			x = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("y")) {
			y = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("LayoutId")) {
			LayoutId = attrValue;
		} else if (attrName.equals("OffsetX")) {
			OffsetX = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("OffsetY")) {
			OffsetY = AppWidgetSkinUtility.px(attrValue);
		} else if (attrName.equals("DatumPoint")) {
			DatumPoint = getIntDatumPoint(attrValue);
		} else if (attrName.equals("DatumHLine")) {
			DatumHLine = getIntDatumLine(attrValue);
		} else if (attrName.equals("DatumVLine")) {
			DatumVLine = getIntDatumLine(attrValue);
		} else if (attrName.equals("DatumHLineLayoutId")) {
			DatumHLineLayoutId = attrValue;
		} else if (attrName.equals("DatumVLineLayoutId")) {
			DatumVLineLayoutId = attrValue;
		} else if (!setSubValue(attrName, attrValue)) {
			return false;
		}
		return true;
	}

	protected abstract boolean setSubValue(String attrName, String attrValue);

	abstract void draw(Canvas c);

	abstract void setWeatherInfo(WeatherInfo wi);

	protected static final HashMap<String, Integer> mStrDatum2IntDatum = new HashMap<String, Integer>();
	static {
		mStrDatum2IntDatum.put("left", LEFT);
		mStrDatum2IntDatum.put("hcenter", HCENTER);
		mStrDatum2IntDatum.put("right", RIGHT);
		mStrDatum2IntDatum.put("top", TOP);
		mStrDatum2IntDatum.put("vcenter", VCENTER);
		mStrDatum2IntDatum.put("bottom", BOTTOM);
	}

	protected static final int getIntDatumPoint(String strDatumPoint) {
		String[] tmp = Utility.split(strDatumPoint, '|');
		int a = mStrDatum2IntDatum.get(tmp[0]);
		int b = mStrDatum2IntDatum.get(tmp[1]);
		return a | b;
	}

	protected static final int getIntDatumLine(String strDatumLine) {
		return mStrDatum2IntDatum.get(strDatumLine);
	}
	
	abstract boolean isClockUnit();

}