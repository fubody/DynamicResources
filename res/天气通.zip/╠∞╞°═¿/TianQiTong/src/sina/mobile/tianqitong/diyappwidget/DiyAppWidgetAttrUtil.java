package sina.mobile.tianqitong.diyappwidget;

import java.util.EnumMap;

import sina.mobile.tianqitong.service.TianQiTongDataStorage;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * 用于操作可diy桌面插件的SharedPreference的静态工具类。
 * 
 * @author 黄恪
 * 
 */
public final class DiyAppWidgetAttrUtil {

	private DiyAppWidgetAttrUtil() {

	}

	/**
	 * 可自定义AppWidget的类型
	 * 
	 * @author 黄恪
	 * 
	 */
	public static enum AWType {
		_1ST_4X2(0), _1ST_4X1(1), _2ND_4X2(2), ;

		private int mId;

		AWType(int id) {
			mId = id;
		}

		public int getId() {
			return mId;
		}

		public static AWType getAWType(int id) {
			switch (id) {
			case 0: {
				return _1ST_4X2;
			}

			case 1: {
				return _1ST_4X1;
			}

			case 2: {
				return _2ND_4X2;
			}

			}
			return _1ST_4X2;
		}
	}

	/**
	 * AppWidget类型对相关的文件名的表。
	 */
	private static final EnumMap<AWType, String[]> gType2Fn = new EnumMap<AWType, String[]>(AWType.class);
	static {
		String DEFAULT_1ST_4X2_ATTRS_FILENAME = "default_1st_4x2_attrs";
		String CURRENT_1ST_4X2_ATTRS_FILENAME = "current_1st_4x2_attrs";
		String TEMP_1ST_4X2_ATTRS_FILENAME = "temp_1st_4x2_attrs";
		String DEFAULT_1ST_4X1_ATTRS_FILENAME = "default_1st_4x1_attrs";
		String CURRENT_1ST_4X1_ATTRS_FILENAME = "current_1st_4x1_attrs";
		String TEMP_1ST_4X1_ATTRS_FILENAME = "temp_1st_4x1_attrs";
		String DEFAULT_2ND_4X2_ATTRS_FILENAME = "default_2nd_4x2_attrs";
		String CURRENT_2ND_4X2_ATTRS_FILENAME = "current_2nd_4x2_attrs";
		String TEMP_2ND_4X2_ATTRS_FILENAME = "temp_2nd_4x2_attrs";

		gType2Fn.put(AWType._1ST_4X2, new String[] { DEFAULT_1ST_4X2_ATTRS_FILENAME, CURRENT_1ST_4X2_ATTRS_FILENAME, TEMP_1ST_4X2_ATTRS_FILENAME });
		gType2Fn.put(AWType._1ST_4X1, new String[] { DEFAULT_1ST_4X1_ATTRS_FILENAME, CURRENT_1ST_4X1_ATTRS_FILENAME, TEMP_1ST_4X1_ATTRS_FILENAME });
		gType2Fn.put(AWType._2ND_4X2, new String[] { DEFAULT_2ND_4X2_ATTRS_FILENAME, CURRENT_2ND_4X2_ATTRS_FILENAME, TEMP_2ND_4X2_ATTRS_FILENAME });
	}

	/**
	 * gType2Fn的值中，默认文件名的位置。
	 */
	private static final int IDX_DEFAULT = 0;
	/**
	 * gType2Fn的值中，当前文件名的位置。
	 */
	private static final int IDX_CURRENT = 1;
	/**
	 * gType2Fn的值中，临时文件名的位置。
	 */
	private static final int IDX_TEMP = 2;

	public static enum FileGettable {

		CURRENT(IDX_CURRENT), TEMP(IDX_TEMP);

		private int mIdx;

		FileGettable(int idx) {
			mIdx = idx;
		}

		int getIdx() {
			return mIdx;
		}
	}

	/**
	 * 可diy插件上，从左到右，从上到下，第一个和第二个文字区域。
	 */
	public static enum DiyText {
		/**
		 * 可diy插件上，从左到右，从上到下，第一个文字区域。
		 */
		_1ST_TEXT("int_1st_text"),
		/**
		 * 可diy插件上，从左到右，从上到下，第二个文字区域。
		 */
		_2ND_TEXT("int_2nd_text");

		private String mSpKey;

		DiyText(String key) {
			mSpKey = key;
		}

		String getSpKey() {
			return mSpKey;
		}
	}

	/**
	 * 文字类型。
	 */
	public static enum TextContent {
		/**
		 * 无文字。
		 */
		NULL(0),
		/**
		 * 农历年月日，节气替换年。
		 */
		CHN_YMD(1),
		/**
		 * 公历年月日周。
		 */
		YMDW(2),
		/**
		 * 公历周月日。
		 */
		LongMDW(3),
		/**
		 * 公历月日周。
		 */
		MDW(4),
		/**
		 * 公历年月日周加农历月日。
		 */
		YMDW_CHN_MD(5),
		/**
		 * 实况天气。
		 */
		WEATHER(6),
		/**
		 * 最低温最高温。
		 */
		TEMPERATURE(7),
		/**
		 * 湿度。
		 */
		HUMIDITY(8),
		/**
		 * 紫外线指数。
		 */
		UV(9),
		/**
		 * 洗车指数。
		 */
		CWASH(10),
		/**
		 * 感冒指数。
		 */
		COLD(11),
		/**
		 * 舒适度指数。
		 */
		COMFORT(12);

		private int mSpValue;

		TextContent(int value) {
			mSpValue = value;
		}

		int getSpValue() {
			return mSpValue;
		}
	}

	/**
	 * 可diy插件上，从左到右，从上到下，第一个和第二个功能按钮。
	 */
	public static enum DiyButton {
		_1ST_BUTTON("int_1st_button"), _2ND_BUTTON("int_2nd_button");

		private String mSpKey;

		DiyButton(String key) {
			mSpKey = key;
		}

		String getSpKey() {
			return mSpKey;
		}
	}

	/**
	 * 按钮类型。
	 */
	public static enum ButtonFunction {
		/**
		 * 无按钮。
		 */
		NULL(0),
		/**
		 * 设置定时语音播报。
		 */
		TTS_SETTING(1),
		/**
		 * 播放语音。
		 */
		PLAY_TTS(2),
		/**
		 * 更新天气数据。
		 */
		UPDATE_DATA(3),
// /**
// * 进入系统闹钟。
// */
// SYS_ALARM(4),
		/**
		 * 进入微博。
		 */
		WEIBO(4),
// /**
// * 进入系统照相机。
// */
// SYS_CAMERA(6),
// /**
// * 进入系统设置。
// */
// SYS_SETTING(7),
// /**
// * 进入系统通讯录。
// */
// SYS_CONTACTS(8),
// /**
// * 关闭数据网络信号。
// */
// SYS_CLOSE_NET(9);
		/**
		 * 万能按钮
		 */
		APP(5);

		private int mSpValue;

		ButtonFunction(int value) {
			mSpValue = value;
		}

		int getSpValue() {
			return mSpValue;
		}

		public int getId() {
			return mSpValue;
		}

		public static ButtonFunction getBtnFunc(int id) {
			for (ButtonFunction btnf : ButtonFunction.values()) {
				if (id == btnf.getId()) {
					return btnf;
				}
			}
			throw new IllegalStateException();
		}

	}

	/**
	 * 可diy插件上，城市名按钮的key。
	 */
	private static final String INT_CITYNAME_MODE = "int_cityname_mode";

	/**
	 * 城市名按钮
	 * 
	 * @author 黄恪
	 * 
	 */
	public static enum CitynameMode {
		/**
		 * 没有按钮。
		 */
		NULL(0),
		/**
		 * 显示按钮。
		 */
		SHOW(1),
		/**
		 * 仅显示文字。
		 */
		ONLY_TEXT(2);

		private int mSpValue;

		CitynameMode(int value) {
			mSpValue = value;
		}

		int getSpValue() {
			return mSpValue;
		}

	}

	/**
	 * 可diy插件上，天气图标的key。
	 */
	private static final String INT_WEATHERICON_MODE = "int_weathericon_mode";

	public static enum WeatherIconMode {

		/**
		 * 天气图标，实况图标。
		 */
		CONDITION(0),
		/**
		 * 天气图标，预报图标。
		 */
		FORECAST(1);

		private int mSpValue;

		WeatherIconMode(int value) {
			mSpValue = value;
		}

		int getSpValue() {
			return mSpValue;
		}

	}

	/**
	 * 可diy插件上，万能按钮包名的key。
	 */
	private static final String STR_1STBTN_APP_PKG_NAME = "1st_app_pkg_name";
	private static final String STR_1STBTN_APP_ACTIVITY_NAME = "1st_app_activity_name";
	private static final String STR_2NDBTN_APP_PKG_NAME = "2nd_app_pkg_name";
	private static final String STR_2NDBTN_APP_ACTIVITY_NAME = "2nd_app_activity_name";

	/**
	 * 可diy插件上，天气图标包位置的key。空字符串表示使用默认图标包。
	 */
	private static final String STR_WEATHERICON_URI = "str_weathericon_uri";

	/**
	 * 可diy插件上，背景颜色的key。
	 */
	private static final String INT_BG_COLOR = "int_bg_color";

	/**
	 * 可diy插件上，文字颜色的key。
	 */
	private static final String INT_TEXT_COLOR = "int_text_color";

	/**
	 * 用一个sp文件内容，完全替换另一个。
	 * 
	 * @param c
	 * @param fn
	 *            被替换的。
	 * @param replacementFn
	 *            用来替换的。
	 */
	private static final void replaceSP(Context c, String fn, String replacementFn) {
		SharedPreferences replacementSp = TianQiTongDataStorage.getSP(c, replacementFn);
		SharedPreferences sp = TianQiTongDataStorage.getSP(c, fn);
		if (replacementSp.getAll().size() == 0) {
			throw new IllegalArgumentException();
		}
		Editor editor = sp.edit();
		editor.clear();
		for (String key : replacementSp.getAll().keySet()) {
			Object v = replacementSp.getAll().get(key);
			if (v instanceof Integer) {
				editor.putInt(key, ((Integer) v).intValue());
			} else if (v instanceof String) {
				editor.putString(key, ((String) v));
			} else {
				throw new IllegalStateException();
			}
		}
		editor.commit();
	}

	/**
	 * 把某类插件的属性恢复成默认状态。
	 * 
	 * @param c
	 * @param type
	 *            插件类型。
	 */
	public static final void restoreToDefault(Context c, AWType type) {
		SharedPreferences dsp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[IDX_DEFAULT]);
		if (dsp.getAll().size() == 0) {
			initDefaultValues(c);
		}
		replaceSP(c, gType2Fn.get(type)[IDX_CURRENT], gType2Fn.get(type)[IDX_DEFAULT]);
	}

	/**
	 * 把编辑好的临时配置，保存成当前配置，并清除临时配置。
	 * 
	 * @param c
	 * @param type
	 */
	public static final void saveTemp(Context c, AWType type) {
		replaceSP(c, gType2Fn.get(type)[IDX_CURRENT], gType2Fn.get(type)[IDX_TEMP]);
		SharedPreferences temp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[IDX_TEMP]);
		temp.edit().clear().commit();
	}

	public static final void clearTemp(Context c, AWType type) {
		SharedPreferences temp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[IDX_TEMP]);
		temp.edit().clear().commit();
	}

	private static final void fix15to14BtnBug(Context c) {

		DiyButton[] btns = new DiyButton[] { DiyButton._1ST_BUTTON, DiyButton._2ND_BUTTON };

		for (AWType type : AWType.values()) {
			for (int idx = 0; idx <= 1; idx++) {
				SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[idx]);

				SharedPreferences.Editor editor = sp.edit();

				{
					String STR_APP_PKG_NAME = "app_pkg_name";
					String[] btnPkgNames = new String[] { STR_1STBTN_APP_PKG_NAME, STR_2NDBTN_APP_PKG_NAME };

					for (int i = 0; i < btnPkgNames.length; i++) {
						String btnPkgName = sp.getString(btnPkgNames[i], null);
						String pkgName = sp.getString(STR_APP_PKG_NAME, null);
						if (btnPkgName == null) {
							if (pkgName != null) {
								if (sp.getInt(btns[i].getSpKey(), -1) == ButtonFunction.APP.getSpValue()) {
									editor.putString(btnPkgNames[i], pkgName);
								} else {
									editor.putString(btnPkgNames[i], "");
								}
								editor.remove(STR_APP_PKG_NAME).commit();
							} else {
								editor.putString(btnPkgNames[i], "");
								if (sp.getInt(btns[i].getSpKey(), -1) == ButtonFunction.APP.getSpValue()) {
									editor.putInt(btns[i].getSpKey(), ButtonFunction.PLAY_TTS.getSpValue());
								}
							}
						}
						editor.commit();
					}
				}
				{
					String STR_APP_ACTIVITY_NAME = "app_activity_name";
					String[] btnActivityNames = new String[] { STR_1STBTN_APP_ACTIVITY_NAME, STR_2NDBTN_APP_ACTIVITY_NAME };

					for (int i = 0; i < btnActivityNames.length; i++) {
						String btnActivityName = sp.getString(btnActivityNames[i], null);
						String activityName = sp.getString(STR_APP_ACTIVITY_NAME, null);
						if (btnActivityName == null) {
							if (activityName != null) {
								if (sp.getInt(btns[i].getSpKey(), -1) == ButtonFunction.APP.getSpValue()) {
									editor.putString(btnActivityNames[i], activityName);
								} else {
									editor.putString(btnActivityNames[i], "");
								}
								editor.remove(STR_APP_ACTIVITY_NAME).commit();
							} else {
								editor.putString(btnActivityNames[i], "");
								if (sp.getInt(btns[i].getSpKey(), -1) == ButtonFunction.APP.getSpValue()) {
									editor.putInt(btns[i].getSpKey(), ButtonFunction.PLAY_TTS.getSpValue());
								}
							}
						}
						editor.commit();
					}
				}
			}
		}

	}

	/**
	 * 初始化各个默认配置。并且生成当前配置。 需要在TianQiTongService.onCreate()里运行。
	 * 
	 * @param c
	 */
	public static final void initDefaultValues(Context c) {
		{
			SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(AWType._1ST_4X2)[IDX_DEFAULT]);
			if (sp.getAll().size() == 0) {
				SharedPreferences.Editor editor = sp.edit();
				editor.putInt(DiyText._1ST_TEXT.getSpKey(), TextContent.TEMPERATURE.getSpValue());
				editor.putInt(DiyText._2ND_TEXT.getSpKey(), TextContent.LongMDW.getSpValue());
				editor.putInt(DiyButton._1ST_BUTTON.getSpKey(), ButtonFunction.TTS_SETTING.getSpValue());
				editor.putInt(DiyButton._2ND_BUTTON.getSpKey(), ButtonFunction.PLAY_TTS.getSpValue());
				editor.putInt(INT_CITYNAME_MODE, CitynameMode.SHOW.getSpValue());
				editor.putInt(INT_WEATHERICON_MODE, WeatherIconMode.CONDITION.getSpValue());
				editor.putInt(INT_BG_COLOR, 0x20888888);
				editor.putInt(INT_TEXT_COLOR, 0xfffffffe);
				editor.putString(STR_WEATHERICON_URI, "");
				editor.putString(STR_1STBTN_APP_PKG_NAME, "");
				editor.putString(STR_1STBTN_APP_ACTIVITY_NAME, "");
				editor.putString(STR_2NDBTN_APP_PKG_NAME, "");
				editor.putString(STR_2NDBTN_APP_ACTIVITY_NAME, "");
				editor.commit();
			}
		}
		{
			SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(AWType._1ST_4X1)[IDX_DEFAULT]);
			if (sp.getAll().size() == 0) {
				SharedPreferences.Editor editor = sp.edit();
				editor.putInt(INT_BG_COLOR, 0x00888888);
				editor.putInt(INT_TEXT_COLOR, 0xfffffffe);
				editor.commit();
			}
		}
		{
			SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(AWType._2ND_4X2)[IDX_DEFAULT]);
			if (sp.getAll().size() == 0) {
				SharedPreferences.Editor editor = sp.edit();
				editor.putInt(DiyText._1ST_TEXT.getSpKey(), TextContent.YMDW_CHN_MD.getSpValue());
				editor.putInt(DiyText._2ND_TEXT.getSpKey(), TextContent.TEMPERATURE.getSpValue());
				editor.putInt(DiyButton._1ST_BUTTON.getSpKey(), ButtonFunction.PLAY_TTS.getSpValue());
				editor.putInt(DiyButton._2ND_BUTTON.getSpKey(), ButtonFunction.TTS_SETTING.getSpValue());
				editor.putInt(INT_CITYNAME_MODE, CitynameMode.SHOW.getSpValue());
				editor.putInt(INT_WEATHERICON_MODE, WeatherIconMode.CONDITION.getSpValue());
				editor.putInt(INT_BG_COLOR, 0x00888888);
				editor.putInt(INT_TEXT_COLOR, 0xfffffffe);
				editor.putString(STR_WEATHERICON_URI, "");
				editor.putString(STR_1STBTN_APP_PKG_NAME, "");
				editor.putString(STR_1STBTN_APP_ACTIVITY_NAME, "");
				editor.putString(STR_2NDBTN_APP_PKG_NAME, "");
				editor.putString(STR_2NDBTN_APP_ACTIVITY_NAME, "");
				editor.commit();
			}
		}

		{
			SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(AWType._2ND_4X2)[IDX_CURRENT]);
			if (sp.getAll().size() == 0) {
				for (AWType type : AWType.values()) {
					restoreToDefault(c, type);
				}
			}

			fix15to14BtnBug(c);
		}
	}

	private static final int checkAndGetInt(Context c, String key, AWType type, int idx) {
		String fn = gType2Fn.get(type)[idx];
		if (idx == IDX_TEMP) {
			maybeCreateTempAttrs(c, type);
		}
		SharedPreferences sp = TianQiTongDataStorage.getSP(c, fn);
		int r = sp.getInt(key, -1);
		if (r == -1) {
			throw new IllegalStateException();// TODO +内容
		}
		return r;
	}

	private static final String checkAndGetStr(Context c, String key, AWType type, int idx) {
		String fn = gType2Fn.get(type)[idx];
		if (idx == IDX_TEMP) {
			maybeCreateTempAttrs(c, type);
		}
		SharedPreferences sp = TianQiTongDataStorage.getSP(c, fn);
		String r = sp.getString(key, null);
		if (r == null) {
			throw new IllegalStateException();
		}
		return r;
	}

	/**
	 * 取某文字区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @param diyText
	 *            文字区域
	 * @return 内容类型
	 * @throws IllegalStateException
	 */
	public static final TextContent getTextValue(Context c, AWType type, FileGettable fg, DiyText diyText) {
		int v = checkAndGetInt(c, diyText.getSpKey(), type, fg.getIdx());
		for (TextContent tv : TextContent.values()) {
			if (tv.getSpValue() == v) {
				return tv;
			}
		}
		throw new IllegalStateException();
	}

	/**
	 * 取某按钮区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @param diyButton
	 *            按钮区域
	 * @return 内容类型
	 * @throws IllegalStateException
	 */
	public static final ButtonFunction getButtonValue(Context c, AWType type, FileGettable fg, DiyButton diyButton) {
		int v = checkAndGetInt(c, diyButton.getSpKey(), type, fg.getIdx());
		for (ButtonFunction bv : ButtonFunction.values()) {
			if (bv.getSpValue() == v) {
				return bv;
			}
		}
		throw new IllegalStateException();
	}

	/**
	 * 取城市名区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @return 内容类型
	 * @throws IllegalStateException
	 */
	public static final CitynameMode getCitynameMode(Context c, AWType type, FileGettable fg) {
		int v = checkAndGetInt(c, INT_CITYNAME_MODE, type, fg.getIdx());
		for (CitynameMode cm : CitynameMode.values()) {
			if (cm.getSpValue() == v) {
				return cm;
			}
		}
		throw new IllegalStateException();
	}

	/**
	 * 取天气图标区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @return 内容类型
	 * @throws IllegalStateException
	 */
	public static final WeatherIconMode getWeatherIconMode(Context c, AWType type, FileGettable fg) {
		int v = checkAndGetInt(c, INT_WEATHERICON_MODE, type, fg.getIdx());
		for (WeatherIconMode wim : WeatherIconMode.values()) {
			if (wim.getSpValue() == v) {
				return wim;
			}
		}
		throw new IllegalStateException();
	}

	/**
	 * 取天气图标的包uri。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @return
	 */
	public static final String getWeatherIconUri(Context c, AWType type, FileGettable fg) {
		return checkAndGetStr(c, STR_WEATHERICON_URI, type, fg.getIdx());
	}

	/**
	 * 取万能按钮的包名
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @return
	 */
	public static final String getAppPackageName(Context c, AWType type, FileGettable fg, DiyButton btn) {
		String key = null;
		switch (btn) {
		case _1ST_BUTTON: {
			key = STR_1STBTN_APP_PKG_NAME;
		}
			break;
		case _2ND_BUTTON: {
			key = STR_2NDBTN_APP_PKG_NAME;
		}
			break;
		}
		return checkAndGetStr(c, key, type, fg.getIdx());
	}

	public static final String getAppActivityName(Context c, AWType type, FileGettable fg, DiyButton btn) {
		String key = null;
		switch (btn) {
		case _1ST_BUTTON: {
			key = STR_1STBTN_APP_ACTIVITY_NAME;
		}
			break;
		case _2ND_BUTTON: {
			key = STR_2NDBTN_APP_ACTIVITY_NAME;
		}
			break;
		}
		return checkAndGetStr(c, key, type, fg.getIdx());
	}

	/**
	 * 取背景颜色。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @return
	 */
	public static final int getBgColor(Context c, AWType type, FileGettable fg) {
		return checkAndGetInt(c, INT_BG_COLOR, type, fg.getIdx());
	}

	/**
	 * 取文字颜色。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param fg
	 *            取当前还是取临时
	 * @return
	 */
	public static final int getTextColor(Context c, AWType type, FileGettable fg) {
		return checkAndGetInt(c, INT_TEXT_COLOR, type, fg.getIdx());
	}

	static final void maybeCreateTempAttrs(Context c, AWType type) {
		String tempfn = gType2Fn.get(type)[IDX_TEMP];
		SharedPreferences sp = TianQiTongDataStorage.getSP(c, tempfn);
		if (sp.getAll().size() == 0) {
			replaceSP(c, tempfn, gType2Fn.get(type)[IDX_CURRENT]);
		}
	}

	private static final void putInt(Context c, String key, int value, AWType type, int idx) {// TODO idx无用
		SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[idx]);
		sp.edit().putInt(key, value).commit();
	}

	private static final void putStr(Context c, String key, String value, AWType type, int idx) {
		SharedPreferences sp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[idx]);
		sp.edit().putString(key, value).commit();
	}

	/**
	 * 设置临时数据的某文字区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param diyText
	 *            文字区域
	 * @param value
	 *            内容类型
	 */
	public static final void putTempTextValue(Context c, AWType type, DiyText diyText, TextContent value) {
		maybeCreateTempAttrs(c, type);
		putInt(c, diyText.getSpKey(), value.getSpValue(), type, IDX_TEMP);
	}

	/**
	 * 设置临时数据的某按钮区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param diyButton
	 *            按钮区域
	 * @param value
	 *            内容类型
	 */
	public static final void putTempButtonValue(Context c, AWType type, DiyButton diyButton, ButtonFunction value) {
		maybeCreateTempAttrs(c, type);
		putInt(c, diyButton.getSpKey(), value.getSpValue(), type, IDX_TEMP);
	}

	/**
	 * 设置临时数据的城市名称区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param citynameMode
	 *            内容类型
	 */
	public static final void putTempCitynameMode(Context c, AWType type, CitynameMode citynameMode) {
		maybeCreateTempAttrs(c, type);
		putInt(c, INT_CITYNAME_MODE, citynameMode.getSpValue(), type, IDX_TEMP);
	}

	/**
	 * 设置临时数据的天气图标区域的内容类型。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param weatherIconMode
	 *            内容类型
	 */
	public static final void puTempWeatherIconMode(Context c, AWType type, WeatherIconMode weatherIconMode) {
		maybeCreateTempAttrs(c, type);
		putInt(c, INT_WEATHERICON_MODE, weatherIconMode.getSpValue(), type, IDX_TEMP);
	}

	/**
	 * 设置临时数据的图标包。null或""表示使用默认。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param uri
	 *            uri
	 */
	public static final void putTempWeatherIconUri(Context c, AWType type, String uri) {
		maybeCreateTempAttrs(c, type);
		if (uri == null) {
			uri = "";
		}
		putStr(c, STR_WEATHERICON_URI, uri, type, IDX_TEMP);
	}

	/**
	 * 设置万能按钮表示的包
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param uri
	 *            uri
	 */
	public static final void putTempAppPackageNameAndActivityName(Context c, AWType type, String packageName, String activityName, DiyButton btn) {
		maybeCreateTempAttrs(c, type);
		if (packageName == null) {
			packageName = "";
		}
		String pkgNameKey = null;
		String activityNameKey = null;
		switch (btn) {
		case _1ST_BUTTON: {
			pkgNameKey = STR_1STBTN_APP_PKG_NAME;
			activityNameKey = STR_1STBTN_APP_ACTIVITY_NAME;
		}
			break;
		case _2ND_BUTTON: {
			pkgNameKey = STR_2NDBTN_APP_PKG_NAME;
			activityNameKey = STR_2NDBTN_APP_ACTIVITY_NAME;
		}
			break;
		}
		putStr(c, pkgNameKey, packageName, type, IDX_TEMP);
		putStr(c, activityNameKey, activityName, type, IDX_TEMP);
	}

	/**
	 * 设置临时数据背景颜色。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param color
	 *            颜色
	 */
	public static final void putTempBgColor(Context c, AWType type, int color) {
		maybeCreateTempAttrs(c, type);
		putInt(c, INT_BG_COLOR, color, type, IDX_TEMP);
	}

	/**
	 * 设置临时数据文字颜色。
	 * 
	 * @param c
	 * @param type
	 *            插件类型
	 * @param color
	 *            颜色
	 */
	public static final void putTempTextColor(Context c, AWType type, int color) {
		maybeCreateTempAttrs(c, type);
		putInt(c, INT_TEXT_COLOR, color, type, IDX_TEMP);
	}

	public static final boolean needSave(Context c, AWType type) {
		SharedPreferences tempSp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[IDX_TEMP]);
		if (tempSp.getAll().size() == 0) {
			return false;
		}

		SharedPreferences curSp = TianQiTongDataStorage.getSP(c, gType2Fn.get(type)[IDX_CURRENT]);

		for (String key : tempSp.getAll().keySet()) {
			Object v = tempSp.getAll().get(key);
			Object cv = curSp.getAll().get(key);
			if (!v.equals(cv)) {
				return true;
			}
		}
		return false;
	}

}
