package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_ALL_UPDATED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_CURRENT_CITY_CHANGED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_ONE_CITY_UPDATED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_TTS_PLAYING;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_TTS_PLAYING_FINISHED;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_BC_PAST_WEATHER_UPDATED;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_GUIDE_TYPE;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_GUIDE_TYPE_VALUE_CITYDRAG;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_GUIDE_TYPE_VALUE_MAIN;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_KEY_STR_CITYCODE;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_ADDRESS;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_CONTENT;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_DATE;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_LEVEL;
import static sina.mobile.tianqitong.service.IntentActionConstants.BUNDLE_WARNING_TITLE;
import static sina.mobile.tianqitong.service.IntentActionConstants.INTENT_EXTRA_FIRST_RUN;
import static sina.mobile.tianqitong.service.IntentActionConstants.INTENT_EXTRA_FORCE_POPUP_AND_AUTO_FINISH_AND_LOCK;
import static sina.mobile.tianqitong.service.IntentActionConstants.INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET;
import static sina.mobile.tianqitong.service.IntentActionConstants.INTENT_EXTRA_KEY_PAGE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_CHECK_NEW_VERSION;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_GET_PAST_WEATHER_INFO_XML_FROM_SERVER;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_CITYCODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.sendRequest;
import static sina.mobile.tianqitong.service.utility.SPUtility.getSPString;
import static sina.mobile.tianqitong.service.utility.SPUtility.getSPStringArray;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.sina.weibo.openapi.SendWeiBo;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.citymanager.CitySelector;
import sina.mobile.tianqitong.main.CustomFrameLayout.onCustomFrameOperationListener;
import sina.mobile.tianqitong.service.Constants;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.SubHelperGetAllPastWeatherData;
import sina.mobile.tianqitong.service.SubHelperGetPastWeatherData;
import sina.mobile.tianqitong.service.SubHelperLocateCityAndUpdate;
import sina.mobile.tianqitong.service.SubHelperUpdateAllWeatherData;
import sina.mobile.tianqitong.service.SubHelperUpdateWeatherData;
import sina.mobile.tianqitong.service.TianQiTongDataStorage;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.TianQiTongNotification;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.MsgResponseHandler;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.model.WarningInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import sina.mobile.tianqitong.service.utility.BitmapCache;
import sina.mobile.tianqitong.service.utility.CityUtil;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import sina.mobile.tianqitong.service.utility.Utility;
import sina.mobile.tianqitong.setting.SettingActivity;
import sina.mobile.tianqitong.setting.TTSSetting;
import sina.mobile.tianqitong.util.ScreenShot;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.text.ClipboardManager;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements ServiceConnection, OnClickListener, MsgResponseHandler, OnSharedPreferenceChangeListener, onCustomFrameOperationListener, OnTouchListener {

	private TianQiTongService _service = null;
	private BroadcastReceiver _br = null;
	private boolean _autoFinishAndLock = false;
	private Handler mHandler;

	private TextView _tvWarningInfo = null;

	private ImageView _tvWarningImage = null;
	private ImageView _tvRecommend = null;

	private int mUpdateTimePastDay;
	private CityDragView mCityDragView;

	public void onStart() {
		super.onStart();
		_va.loadBg();
	}

	public void onStop() {
		super.onStop();
		_va.releaseBg();
	}

	public void onServiceConnected(ComponentName className, IBinder service) {
		_service = ((TianQiTongService.TianQiTongBinder) service).getService();
		if (_service.getCityCodes().length == 0) {
			startActivity(new Intent(MainActivity.this, Splash.class));
			_service.stopSelf();
			finish();
		}

		if (mStartFromAppWidget) {
			String widgetCode = SPUtility.getSPString(this, R.string.str_widget_city_code);
			SPUtility.putSPString(this, R.string.str_current_city_code, widgetCode);
		}
		{
			// 防止service被停掉后无法从插件等地启动 lyang
// TianQiTongReciever.applyTickAlarm(this, System.currentTimeMillis());
			Intent i = new Intent(IntentActionConstants.ACTION_START_SERVICE_UPDATE_WIDGET_CLOCK);
			startService(i);
		}
		long updateTime = SPUtility.getSPStringLong(this, R.string.strlong_update_milletime);
		long refreshTime = SPUtility.getSPStringLong(this, R.string.strlong_refresh_milletime);
		if (updateTime > refreshTime) {
			SPUtility.putSPStringLong(this, R.string.strlong_refresh_milletime, updateTime);
		}

		long current = System.currentTimeMillis();

		// 两天没有更新做提示
		boolean isRemind = SPUtility.getSPBoolean(this, R.string.boolean_update_remind);

		if (isRemind && (updateTime + 2L * 24L * 3600L * 1000L) < current) {
			mUpdateTimePastDay = (int) ((current - updateTime) / (24L * 3600L * 1000L));
			showDialog(DIALOG_ID_UPDATE_REMIND);
			
		}

		{
			WeatherInfo wi = _service.getCurrentCityWeatherInfo();
			if (!wi.isValid()) {
				_service.updateAllWeatherData(null);
			}
		}

		updateUI(1);
		// updateUpdateText();

		if (SPUtility.getSPBoolean(this, R.string.boolean_is_1st_set_noti)) {
			// 初始话本地数据提醒
			TianQiTongNotification.init(this);
			WeatherInfo wi = _service.getWeatherInfo(getSPString(this, R.string.str_notification_city));
			TianQiTongNotification.setWeatherData(wi);
			TianQiTongNotification.applyNotificaiton(this, TianQiTongNotification.RETURN_WEATHER_NOTIFICATION);
			TianQiTongNotification.applyNotificaiton(this, TianQiTongNotification.RETURN_FESTIVAL_NOTIFICATION);
			TianQiTongNotification.applyNotificaiton(this, TianQiTongNotification.RETURN_JIEQI_NOTIFICATION);

			SPUtility.putSPBoolean(this, R.string.boolean_is_1st_set_noti, false);
		}

		_br = new BroadcastReceiver() {

			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				int curPage = _va.getCurrentChild();
				if (action.equals(ACTION_BC_ONE_CITY_UPDATED)) {
					String cityCode = intent.getStringExtra(BUNDLE_KEY_STR_CITYCODE);
					String currentCityCode = SPUtility.getSPString(context, R.string.str_current_city_code);

					boolean is2 = _va.getCurrentChild() == 0;
					boolean isCurrent = cityCode.equals(currentCityCode);

					if (is2 || (!is2 && isCurrent)) {

						TianQiTongLog.addNormalLog("receive update ui");
						updateUI(curPage);
						SPUtility.putSPStringLong(context, R.string.strlong_refresh_milletime, System.currentTimeMillis());
						updateUpdateText();
					} else {
						return;
					}
				} else if (action.equals(ACTION_BC_ALL_UPDATED)) {
					// 时区校正会触发这个
					updateUI(curPage);
					updateUpdateText();
				} else if (action.equals(ACTION_BC_TTS_PLAYING_FINISHED)) {
					if (_service.isTTSPlaying()) {
						_ivPlayTTSButton.setImageResource(R.drawable.stop_playing_tts_button);
					} else {
						_ivPlayTTSButton.setImageResource(R.drawable.play_tts_button);
					}
					finishAndReleaseLock();
				} else if (action.equals(ACTION_BC_TTS_PLAYING)) {
					if (_service.isTTSPlaying()) {
						_ivPlayTTSButton.setImageResource(R.drawable.stop_playing_tts_button);
					} else {
						_ivPlayTTSButton.setImageResource(R.drawable.play_tts_button);
					}
				} else if (action.equals(ACTION_BC_CURRENT_CITY_CHANGED)) {
					TianQiTongLog.addNormalLog("receive update ui");
					updateUI(curPage);
				} else if (action.equals(IntentActionConstants.ACTION_BC_NOTIFICATION_CITY_CHANGED)) {
					// 巧丹的预警提醒要加的
					Intent notiIntent = new Intent(ACTION_START_SERVICE_UPDATE_WEATHER_NOTIFICATION);
					context.startService(notiIntent);

// mCityDragView.notifyTTsCityChanger();
				}
			}
		};
		IntentFilter filter = new IntentFilter();
		filter.addAction(ACTION_BC_ONE_CITY_UPDATED);
		filter.addAction(ACTION_BC_ALL_UPDATED);
		filter.addAction(ACTION_BC_TTS_PLAYING);
		filter.addAction(ACTION_BC_TTS_PLAYING_FINISHED);
		filter.addAction(ACTION_BC_CURRENT_CITY_CHANGED);
		filter.addAction(ACTION_BC_PAST_WEATHER_UPDATED);
		// 在设置中改变播报城市
		filter.addAction(IntentActionConstants.ACTION_BC_NOTIFICATION_CITY_CHANGED);

		registerReceiver(_br, filter);

		if (SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_show_new_version_dialog) && _service._nvi._address != null && _service._nvi._address.length() != 0) {

			float vernum = Float.parseFloat(_service._nvi._version);
			float curvernum = Float.parseFloat(getString(R.string.ver));
			if (vernum > curvernum) {
				showShowDialogCheckBox = true;
				showDialog(DIALOG_ID_ASK_UPDATE);
			}
		}
	}

	private void sendSmsClicked() {
		SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_share_icon);

		showDialog(DIALOG_ID_TRANSMIT_WAY);
	}

	@Override
	public void onClick(View v) {
		cancelAutoLock();
		switch (v.getId()) {
		case R.id.recommend: {
			SPUtility.putSPBoolean(this, R.string.if_new_recommend_click, false);
			_tvRecommend.setBackgroundResource(R.drawable.recommend_normal);
			startActivity(new Intent(MainActivity.this, RecommendPanel.class));
		}
			break;

		case R.id.send_sms: {

			sendSmsClicked();

		}
			break;
		case R.id.play_tts: {

			if (_service.isTTSPlaying()) {
				_service.stopTTS(null);
			} else {

				SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_play_tts_icon);

				playTTS();
			}
		}
			break;
		case R.id.update:

		case R.id.update_icon: {

			if (mUpdateAllReqNum != -1) {
				Toast.makeText(this, "天气通正在更新全部城市数据，自动忽略更新当前城市的操作。请稍候。", Toast.LENGTH_SHORT).show();
				return;
			}

			if (mUpdateRequestNum == -1) {

// //TODO
// {
// long time = System.currentTimeMillis();
// time = time - 7L * 24L * 3600000L;
// time = time - 10L * 60000L;
// SPUtility.putSPStringLong(this, R.string.strlong_check_new_version_millitime, time);
// }

				SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_update_icon);
				updateWeather();
			} else {
				cancelUpdatingWeather();

			}

		}
			break;

		case R.id.warning_linear: {
			Intent intent = new Intent();
			ArrayList<WarningInfo> warningInfoArray = _service.getCurrentCityWarningInfo();
			int num = warningInfoArray.size();
			ArrayList<String> levelArray = new ArrayList<String>();
			ArrayList<String> titleArray = new ArrayList<String>();
			ArrayList<String> contentArray = new ArrayList<String>();
			ArrayList<String> dateArray = new ArrayList<String>();
			String mWarningAddress = "";
			String mWarningWeb = "";

			for (int i = 0; i < num; i++) {
				WarningInfo warning = warningInfoArray.get(i);
				String mCityName = _service.getCurrentCityName();
				String[] t = Utility.split(mCityName, '.');
				String cityName = t[t.length - 1];
				String mWarningLevel = warning.getLevel();
				String mWarningTitle = cityName + warning.getType() + warning.getLevel() + "预警";
				String mWarningContent = warning.getWarningText();
				String mWarningDate = warning.getPubdate();
				mWarningAddress = warning.getAddress();
				mWarningWeb = warning.getWebsite();

				if (!mWarningLevel.equalsIgnoreCase(WarningInfo.INVALID_WARNING_LEVEL)) {

					levelArray.add(mWarningLevel);
					titleArray.add(mWarningTitle);
					contentArray.add(mWarningContent);
					dateArray.add("发布时间：" + mWarningDate);
				}

			}
			_service.postWarningAddress(mWarningAddress, null);

			Bundle mBundle = new Bundle();
			mBundle.putStringArrayList(BUNDLE_WARNING_LEVEL, levelArray);
			mBundle.putStringArrayList(BUNDLE_WARNING_TITLE, titleArray);
			mBundle.putStringArrayList(BUNDLE_WARNING_CONTENT, contentArray);
			mBundle.putStringArrayList(BUNDLE_WARNING_DATE, dateArray);
			mBundle.putString(BUNDLE_WARNING_ADDRESS, mWarningWeb);
			intent.setClass(MainActivity.this, WarningDialogManager.class);
			intent.putExtras(mBundle);

			startActivity(intent);

		}
			break;
		}

	}

	public void onServiceDisconnected(ComponentName className) {
		_service = null;

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (_br != null) {
			unregisterReceiver(_br);
		}
		try {
			unbindService(this);
		} catch (IllegalArgumentException iae) {
			// 服务未绑定
		}

		if (_kl != null) {
			_kl.reenableKeyguard();
			_kl = null;
		}
		BitmapCache.clean();
		if (_service != null) {
			if (_service.isTTSPlaying()) {
				_service.stopTTS(null);
				_service = null;
			}
		}

		// add for clearing the memory
		if (mCityDragView != null) {
			mCityDragView.removeAllViews();
			mCityDragView = null;
		}
		_tvWarningInfo = null;
		_ivPlayTTSButton = null;
		_tvWarningImage = null;
		_tvRecommend = null;
		if (_va != null) {
			_va.removeAllViews();
// _va.removeListerner();
			_va = null;
		}

		CityUtil.clearCitys();
		//
		_ivUpdateIcon = null;
		_tvUpdateText = null;
		_llPages = null;
		if (_warningLayout != null) {
			_warningLayout.removeAllViews();
			_warningLayout = null;
		}
		if (_updateLayout != null) {
			_updateLayout.removeAllViews();
			_updateLayout = null;
		}
		_ivSendIcon = null;
		_handler = null;
		System.gc();

	}

	void showAddNewCityDialog() {
		boolean show = SPUtility.getSPBoolean(this, R.string.boolean_pop_add_city_dlg, true);
		if (show) {
			showDialog(DIALOG_ID_ADD_CITY);
		}
	}

	private Handler _handler;

	private CustomFrameLayout _va;

	private ImageView _ivUpdateIcon = null;
	private TextView _tvUpdateText = null;

	private LinearLayout _llPages = null;
	private LinearLayout _warningLayout = null;

	private LinearLayout _updateLayout = null;
	private ImageView _ivSendIcon = null;

	void updatePagePoints(int page) {

		if (_llPages == null) {
			return;
		}
		// _llPages.removeAllViewsInLayout();
		int currentPage = page;
		LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		for (int i = 0; i < _va.getChildCount(); i++) {
			ImageView ivPage = (ImageView) _llPages.getChildAt(i);
			if (currentPage == i) {
				ivPage.setImageResource(R.drawable.current_page_light);
			} else {
				ivPage.setImageResource(R.drawable.current_page_dark);
			}

			// ivPage.setLayoutParams(lllp);
			// _llPages.addView(ivPage);
		}
	}

	void initPagePoints(int page) {

		if (_llPages == null) {
			return;
		}
		_llPages.removeAllViewsInLayout();
		int currentPage = page;
		LinearLayout.LayoutParams lllp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		for (int i = 0; i < _va.getChildCount(); i++) {
			ImageView ivPage = new ImageView(this);
			if (currentPage == i) {
				ivPage.setImageResource(R.drawable.current_page_light);
			} else {
				ivPage.setImageResource(R.drawable.current_page_dark);
			}

			ivPage.setLayoutParams(lllp);
			_llPages.addView(ivPage);
		}
	}

	void updateRecommend(int page) {

		_tvRecommend = (ImageView) findViewById(R.id.recommend);

		int currentPage = page;

		if (currentPage == 0) {

			mHandler.postDelayed(new Runnable() {
				public void run() {
					_tvRecommend.setVisibility(View.VISIBLE);

					boolean clickRecommend = SPUtility.getSPBoolean(_service, R.string.if_new_recommend_click);
					if (clickRecommend) {
						_tvRecommend.setBackgroundResource(R.drawable.recommend_new);
					} else {
						_tvRecommend.setBackgroundResource(R.drawable.recommend_normal);
					}

				}

			}, 1000);
			_tvRecommend.setClickable(true);
			_tvRecommend.setOnClickListener(this);

		} else if (currentPage == 1 || currentPage == 2) {
			_tvRecommend.setVisibility(View.INVISIBLE);
			_tvRecommend.setClickable(false);

		}
	}

// public void playAnim() {
// boolean clickRecommend = SPUtility.getSPBoolean(this, R.string.if_new_recommend_click);
// if (clickRecommend) {
// MyAnimationDrawable mad = new MyAnimationDrawable((AnimationDrawable) getResources().getDrawable(R.anim.doll_playing_for_new)) {
// public void onAnimationEnd() {
// stopPlayingAnimForNew();
// }
// };
// _tvRecommend.setBackgroundDrawable(mad);
// mad.start();
//
// } else {
//
// MyAnimationDrawable mad = new MyAnimationDrawable((AnimationDrawable) getResources().getDrawable(R.anim.doll_playing)) {
// public void onAnimationEnd() {
// stopPlayingAnim();
// }
// };
// _tvRecommend.setBackgroundDrawable(mad);
// mad.start();
// }
//
// }
//
// private void stopPlayingAnim() {
//
// Drawable d = _tvRecommend.getBackground();
// if (d instanceof AnimationDrawable) {
// AnimationDrawable ad = (AnimationDrawable) d;
// ad.stop();
// _tvRecommend.setBackgroundResource(R.drawable.recommend_normal);
// _tvRecommend.setOnClickListener(this);
// }
// }
//
// private void stopPlayingAnimForNew() {
//
// Drawable d = _tvRecommend.getBackground();
// if (d instanceof AnimationDrawable) {
// AnimationDrawable ad = (AnimationDrawable) d;
// ad.stop();
// _tvRecommend.setBackgroundResource(R.drawable.recommend_btn);
// _tvRecommend.setOnClickListener(this);
// }
// }

	private KeyguardLock _kl = null;

	private void unlock() {
		if (_autoFinishAndLock && _kl == null) {
			KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
			if (km.inKeyguardRestrictedInputMode()) {
				_kl = km.newKeyguardLock("");
				_kl.disableKeyguard();
			} else {

			}

		}
	}

	private void finishAndReleaseLock() {
		if (_autoFinishAndLock) {
			_autoFinishAndLock = false;
			if (_kl != null) {
				_kl.reenableKeyguard();
				_kl = null;
			}
			finish();
		}
	}

	void cancelAutoLock() {
		if (_autoFinishAndLock) {
			_autoFinishAndLock = false;
			KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
			km.exitKeyguardSecurely(new KeyguardManager.OnKeyguardExitResult() {

				@Override
				public void onKeyguardExitResult(boolean success) {
					_kl.reenableKeyguard();
					_kl = null;

				}
			});
		}
	}

	public void onResume() {
		super.onResume();
		unlock();
		mHandler.postDelayed(new Runnable() {
			public void run() {
				showGuideByPage(1);
// updateRecommend(idx);
			}
		}, 1000);

	}

	public void onNewIntent(Intent i) {
		// 在用home键离开天气通后，服务可能会把本界面弹出。
		// 此时不会走onCreate，而会走这里。
		setIntent(i);

		if (i.getExtras() != null) {
			if (i.getExtras().containsKey(INTENT_EXTRA_KEY_PAGE)) {
				int currentPage = i.getIntExtra(INTENT_EXTRA_KEY_PAGE, 1);
				_va.setDisplayedChild(currentPage);
			} else {
				_va.setDisplayedChild(1);
			}
			if (i.getExtras().containsKey(INTENT_EXTRA_FORCE_POPUP_AND_AUTO_FINISH_AND_LOCK)) {
				_autoFinishAndLock = i.getBooleanExtra(INTENT_EXTRA_FORCE_POPUP_AND_AUTO_FINISH_AND_LOCK, false);
			}
			if (i.getBooleanExtra(INTENT_EXTRA_FIRST_RUN, false)) {
// showDialog(DIALOG_ID_UPDATE_WAY);
// Intent intent = new Intent(this, MainGuideActivity.class);
// intent.putExtra(BUNDLE_GUIDE_TYPE, BUNDLE_GUIDE_TYPE_VALUE_MAIN);
// startActivity(intent);
// showGuideByPage(currentPage);
			}

			if (i.getExtras().containsKey(INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET)) {
				mStartFromAppWidget = i.getBooleanExtra(INTENT_EXTRA_KEY_BOOLEAN_START_MAINACTIVITY_FROM_WIDGET, false);
			}
		} else {
			_va.setDisplayedChild(1);

		}
		unlock();
	}

	private boolean mStartFromAppWidget = false;

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// 如果有任何按键操作，都取消自动关闭并锁屏
		cancelAutoLock();
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		cancelAutoLock();
		return super.onTouchEvent(event);
	}

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mHandler = new Handler();
		DisplayMetrics dm = getResources().getDisplayMetrics();
		int height = dm.heightPixels;
		int width = dm.widthPixels;
		float proportion = (float) height / (float) width;
		if (proportion < 1.4) {
			requestWindowFeature(Window.FEATURE_NO_TITLE);
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		}

		String[] cityCodes = getSPStringArray(this, R.string.strs_cached_citys, ',');
		if (cityCodes.length == 0) {
			Intent i = new Intent(this, Splash.class);
			startActivity(i);
			finish();
			return;
		}

		{
// String cityCode = SPUtility.getSPString(this, R.string.str_alarm_tts_city_code);
			// changed by Maojianwei
			String[] cCodes = SPUtility.getSPStringArray(this, R.string.strs_cached_citys, ',');
			SPUtility.putSPString(this, R.string.str_current_city_code, cCodes[0]);
		}

		setContentView(R.layout.main);

		_va = (CustomFrameLayout) findViewById(R.id.main_animator);

		for (int i = 0; i < _va.getChildCount(); i++) {
			_va.getChildAt(i).setOnTouchListener(this);
		}

		onNewIntent(getIntent());

// int currentPage = 0;
//
// showGuideByPage(currentPage);

		_llPages = (LinearLayout) findViewById(R.id.pages);
		initPagePoints(1);

		_tvUpdateText = (TextView) findViewById(R.id.update_text);

		_warningLayout = (LinearLayout) findViewById(R.id.warning_linear);
		_tvWarningInfo = (TextView) findViewById(R.id.warning_info);
		_tvWarningImage = (ImageView) findViewById(R.id.warning_image);
		_warningLayout.setOnClickListener(this);

		_ivSendIcon = (ImageView) findViewById(R.id.send_sms);
		_ivSendIcon.setOnClickListener(this);

		_ivPlayTTSButton = (ImageView) findViewById(R.id.play_tts);
		_ivPlayTTSButton.setOnClickListener(this);

		_ivUpdateIcon = (ImageView) findViewById(R.id.update_icon);
		_ivUpdateIcon.setOnClickListener(this);
		_updateLayout = (LinearLayout) findViewById(R.id.update);
		_updateLayout.setOnClickListener(this);

		_tvRecommend = (ImageView) findViewById(R.id.recommend);

		_handler = new Handler() {
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case MSG_WHAT_STOP_UPDATE_ANMI: {
// _ivUpdateIcon.setImageResource(R.drawable.update_button);
// // _ivUpdateIcon.clearAnimation();

					// changed by Maojianwei
					if (null == _ivUpdateIcon) {
						_ivUpdateIcon = (ImageView) findViewById(R.id.update_icon);
						_ivUpdateIcon.setOnClickListener(MainActivity.this);
					}

					_ivUpdateIcon.setImageResource(R.drawable.update_button);
					_ivUpdateIcon.clearAnimation();

// Animation anim = _ivUpdateIcon.getAnimation();
// if (anim != null) {
// anim.setRepeatCount(1);
// anim.setAnimationListener(new AnimationListener() {
//
// Override
// public void onAnimationStart(Animation animation) {
// // TODO Auto-generated method stub
//
// }
//
// Override
// public void onAnimationRepeat(Animation animation) {
// // TODO Auto-generated method stub
//
// }
//
// Override
// public void onAnimationEnd(Animation animation) {
// _ivUpdateIcon.setImageResource(R.drawable.update_button);
// _ivUpdateIcon.clearAnimation();
//
// }
// });
// }

					updateUpdateText();
				}
					break;
				case MSG_WHAT_UPDATE_ANMI: {

				}
					break;
				}

			}
		};
// #ifndef WITHOUT_RECOMMEND
		boolean clickRecommend = SPUtility.getSPBoolean(this, R.string.if_new_recommend_click);
		_tvRecommend.setVisibility(View.VISIBLE);
		if (clickRecommend) {
			_tvRecommend.setBackgroundResource(R.drawable.recommend_new);
			_tvRecommend.setOnClickListener(this);
		} else {
			_tvRecommend.setBackgroundResource(R.drawable.recommend_normal);
			_tvRecommend.setOnClickListener(this);

		}
// #endif

		bindService(new Intent(this, TianQiTongService.class), this, Activity.BIND_AUTO_CREATE);
		findViewById(R.id.main_view).setDrawingCacheEnabled(true);
		// setSkin();

		TianQiTongDataStorage.getDefaultSP(this).registerOnSharedPreferenceChangeListener(this);

		mCityDragView = (CityDragView) findViewById(R.id.cdv);

		_va.setOnCustomFrameOperationListener(this);
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_activity_options, menu);

		return true;
	}

	public boolean onPrepareOptionsMenu(Menu menu) {

		if (_service.isTTSPlaying()) {
			menu.findItem(R.id.menu_play_tts).setIcon(R.drawable.menu_stop_playing);
		} else {
			menu.findItem(R.id.menu_play_tts).setIcon(R.drawable.menu_play_tts);
		}
		if (TianQiTongDownloadManger.getInstance(_service).isDownloading(_service._nvi._address)) {
			menu.findItem(R.id.menu_check_new_version).setEnabled(false).setTitle("下载中");
		} else {
			menu.findItem(R.id.menu_check_new_version).setEnabled(true).setTitle(R.string.check_new_version);
		}
		if (mUpdateAllReqNum == -1) {
			menu.findItem(R.id.menu_update).setTitle("全部更新").setEnabled(true);
		} else {
			menu.findItem(R.id.menu_update).setTitle("取消更新").setEnabled(true);
		}

		// #ifndef WITHOUT_SINA_APP

		/*
		 * Uri uri = Uri.parse(SINA_APP_URI); Intent i = new Intent(Intent.ACTION_VIEW, uri); if (Utility.isActivityAvailable(this, i)) { menu.findItem(R.id.menu_sina_app).setVisible(true); } else {
		 * menu.findItem(R.id.menu_sina_app).setVisible(false); }
		 */

		// #else
// @ menu.removeItem(R.id.menu_sina_app);
// #endif
		return true;
	}

	private static final String SINA_APP_URI = "http://tqt.sina.cn/wap/khd_tqt.html";

	private void playTTS() {

		{
			_service.playTTS(SPUtility.getSPString(this, R.string.str_current_city_code), null);
		}

	}

	private void updateAllWeather() {

		// 更新前加入判断
		if (Utility.isAirplaneModeOn(getApplicationContext())) {
			Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, this);
			dg.show();
			return;
		}

		if (!Utility.getAvailableNetWork(getApplicationContext())) {
			Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, this);
			dg.show();
			return;
		}
		// 结束
		_ivUpdateIcon.setImageResource(R.drawable.update_anim);
		_ivUpdateIcon.startAnimation(AnimationUtils.loadAnimation(this, R.anim.update));

		mUpdateAllReqNum = _service.updateAllWeatherData(new WeakReference<MsgResponseHandler>(this));

		Calendar c = Calendar.getInstance();
		String updateTime = null;
		long updateMillisecond = SPUtility.getSPStringLong(this, R.string.strlong_refresh_milletime);
		c.setTimeInMillis(updateMillisecond);

		if (!Utility.isToday(updateMillisecond)) {
			updateTime = Utility.getStrMD(c) + " " + Utility.getStrHM12or24(this, c);
		} else {
			updateTime = Utility.getStrHM12or24(this, c);
		}
		// _tvUpdateText.setText("正在更新：" + updateTime);

		_tvUpdateText.setText("正在更新... ");
		SPUtility.putSPStringLong(this, R.string.strlong_refresh_milletime, System.currentTimeMillis());

	}

	private int mUpdateAllReqNum = -1;
	private int mUpdateAllPastReqNum = -1;

	private void cancelUpdatingAll() {
		SubHelperUpdateAllWeatherData.cancelRequest(mUpdateAllReqNum);
		SubHelperGetAllPastWeatherData.cancelRequest(mUpdateAllPastReqNum);
		mUpdateAllReqNum = -1;
		mUpdateAllPastReqNum = -1;

		boolean isUseHistoryWeather = !SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_use_history_weather_check);
		if (isUseHistoryWeather) {
			SubHelperGetAllPastWeatherData.cancelRequest(mUpdateAllPastReqNum);
			mUpdateAllPastReqNum = -1;
		}

		_ivUpdateIcon.setImageResource(R.drawable.update_button);
		_ivUpdateIcon.clearAnimation();
		SPUtility.putSPStringLong(this, R.string.strlong_refresh_milletime, System.currentTimeMillis());
		updateUpdateText();
	}

	private String mUpdatingCityCode;
	private int mUpdateRequestNum = -1;
	private int mUpdatePastRequestNum = -1;
	private String mUpdatingPubdate = null;

	private void cancelUpdatingWeather() {
		if (mUpdatingCityCode != null && mUpdatingCityCode.startsWith(Constants.AUTO_LOCATE_CITYCODE_PREFIX)) {
			SubHelperLocateCityAndUpdate.getInstance(null).cancelRequest(mUpdateRequestNum);
		} else {
			SubHelperUpdateWeatherData.getInstance(null).cancelRequest(mUpdateRequestNum);
		}
		mUpdateRequestNum = -1;

		boolean isUseHistoryWeather = !SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_use_history_weather_check);
		if (isUseHistoryWeather) {
			SubHelperGetPastWeatherData.getInstance(null).cancelRequest(mUpdatePastRequestNum);
			mUpdatePastRequestNum = -1;
		}

		_ivUpdateIcon.setImageResource(R.drawable.update_button);
		_ivUpdateIcon.clearAnimation();
		SPUtility.putSPStringLong(this, R.string.strlong_refresh_milletime, System.currentTimeMillis());
		updateUpdateText();
	}

	private void updateWeather() {
		// 更新前加入判断
		if (Utility.isAirplaneModeOn(getApplicationContext())) {
			Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, this);
			dg.show();
			return;
		}

		if (!Utility.getAvailableNetWork(getApplicationContext())) {
			Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, this);
			dg.show();
			return;
		}
		// 结束
		_ivUpdateIcon.setImageResource(R.drawable.update_anim);
		_ivUpdateIcon.startAnimation(AnimationUtils.loadAnimation(this, R.anim.update));

// mUpdateRequestNum = _service.updateAllWeatherData(new WeakReference<MsgResponseHandler>(this));
		String cityCode = SPUtility.getSPString(this, R.string.str_current_city_code);

		mUpdatingCityCode = cityCode;

		WeakReference<MsgResponseHandler> sender = new WeakReference<MsgResponseHandler>(this);
		Bundle b = new Bundle();
		b.putString(MSG_DATA_KEY_STR_CITYCODE, cityCode);
		if (cityCode.startsWith(Constants.AUTO_LOCATE_CITYCODE_PREFIX)) {
			mUpdateRequestNum = sendRequest(MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER, b, sender, SubHelperLocateCityAndUpdate.getInstance(_service));
		} else {
			mUpdateRequestNum = sendRequest(MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER, b, sender, SubHelperUpdateWeatherData.getInstance(_service));
		}

		mUpdatingPubdate = _service.getWeatherInfo(mUpdatingCityCode).getPubdateStr();

		Calendar c = Calendar.getInstance();
		String updateTime = null;
		long updateMillisecond = SPUtility.getSPStringLong(this, R.string.strlong_refresh_milletime);
		c.setTimeInMillis(updateMillisecond);

		if (!Utility.isToday(updateMillisecond)) {
			updateTime = Utility.getStrMD(c) + " " + Utility.getStrHM12or24(this, c);
		} else {
			updateTime = Utility.getStrHM12or24(this, c);
		}
		// _tvUpdateText.setText("正在更新：" + updateTime);

		_tvUpdateText.setText("正在更新... ");
		SPUtility.putSPStringLong(this, R.string.strlong_refresh_milletime, System.currentTimeMillis());
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		/*
		 * case R.id.menu_sina_app: { startActivity(new Intent(this, SinaRecommendActivity.class)); return true; }
		 */
		case R.id.menu_send_sms: {
			sendSmsClicked();
			return true;
		}
		case R.id.menu_play_tts: {
			if (_service.isTTSPlaying()) {
				_service.stopTTS(null);
			} else {
				SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_play_tts_menuitem);
				playTTS();
			}
			return true;
		}
		case R.id.menu_setting: {
			startActivityForResult(new Intent(this, SettingActivity.class), START_SETTING_ACTIVITY);
		}
			break;
		case R.id.menu_update: {
			if (mUpdateAllReqNum == -1) {
				SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_update_menuitem);
				updateAllWeather();
			} else {
				cancelUpdatingAll();
				_ivUpdateIcon.setImageResource(R.drawable.update_button);
			}
		}
			break;
		case R.id.menu_exit: {
			SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_exit_menuitem);
			finish();
		}
			break;
		case R.id.menu_diy: {
			startActivity(new Intent(this, SoundWidgetTabActivity.class));
		}
			break;
		case R.id.menu_suggestion: {
			SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_suggest_menuitem);
			startActivity(new Intent(this, SendSuggestion.class));
		}
			break;
		case R.id.menu_about: {
			showDialog(DIALOG_ID_ABOUT);
		}
			break;
		case R.id.menu_check_new_version: {
			// 检查前加入判断
			if (Utility.isAirplaneModeOn(getApplicationContext())) {
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, MainActivity.this);
				dg.show();
				break;
			}

			if (!Utility.getAvailableNetWork(getApplicationContext())) {
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, MainActivity.this);
				dg.show();
				break;
			}
			// 结束
			_service.checkNewVersion(new WeakReference<MsgResponseHandler>(this));
		}
			break;
		case R.id.menu_help: {
			startActivity(new Intent(this, HelpActivity.class));
		}
		}
		return false;
	}

	private static final int DIALOG_ID_ABOUT = 0;
	private static final int DIALOG_ID_NETWORK_DOWN = 1;
	private static final int DIALOG_ID_WELCOME = 2;
	private static final int DIALOG_ID_ASK_UPDATE = 3;
	private static final int DIALOG_ID_NEWEST_VERSION = 4;
	private static final int DIALOG_ID_ADD_CITY = 5;
	private static final int DIALOG_ID_COMMON_FAILED = 6;
	/**
	 * 选择更新的方式
	 */
	private static final int DIALOG_ID_UPDATE_WAY = 7;
	/**
	 * 转发方式的选择弹出框
	 */
	private static final int DIALOG_ID_TRANSMIT_WAY = 8;
	private static final int DIALOG_ID_UPDATE_REMIND = 9;
	private static final int DIALOG_ID_DOWNLOAD_WEIBO = 10;

	public void onPrepareDialog(int id, Dialog dialog) {

		switch (id) {
		case DIALOG_ID_ASK_UPDATE: {
			TextView msg = (TextView) dialog.findViewById(R.id.msg);
			msg.setText(_service._nvi._message);

			CheckBox show = (CheckBox) dialog.findViewById(R.id.dont_show_the_dialog);
			if (showShowDialogCheckBox) {
				show.setVisibility(View.VISIBLE);
				show.setChecked(!SPUtility.getSPBoolean(this, R.string.boolean_show_new_version_dialog));
			} else {
				show.setVisibility(View.GONE);
			}

		}
		case DIALOG_ID_ABOUT: {
		}
		case DIALOG_ID_NETWORK_DOWN: {
		}
		case DIALOG_ID_WELCOME: {
		}
		}
	}

	private boolean showShowDialogCheckBox = true;

	public Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_ASK_UPDATE: {

			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.ask_update, null);
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("检测到新版本");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setView(v);
			b.setPositiveButton("立即升级", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (!Utility.sdAvailiable()) {
						Toast.makeText(MainActivity.this, "sd卡不可用", Toast.LENGTH_LONG).show();
						return;
					}
// _service.downloadNewApk(new WeakReference<MsgResponseHandler>(MainActivity.this));
					SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_show_new_version_dialog, false);
					removeDialog(DIALOG_ID_ASK_UPDATE);
					// lyang download from net
					{
						try {
							Intent intent = new Intent();
							intent.setAction(Intent.ACTION_VIEW);
							Uri uri = Uri.parse(_service._nvi._address);
							intent.setData(uri);
							startActivity(intent);
						} catch (ActivityNotFoundException e) {
							e.printStackTrace();
						}
					}
				}
			});
			b.setNegativeButton("暂不升级", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_ASK_UPDATE);
				}
			});

			CheckBox show = (CheckBox) v.findViewById(R.id.dont_show_the_dialog);
			show.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_show_new_version_dialog, !isChecked);

				}
			});

			return b.create();
		}
		case DIALOG_ID_ABOUT: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setTitle("关于");

			String about = getString(R.string.about_text);

			String buildDate = "";
// #ifdef BUILD_DATE
// #expand buildDate = "%BUILD_DATE%";
// @buildDate = "%BUILD_DATE%";
// #endif
			String version = getString(R.string.ver);
			// #ifdef BUILD_SUB_VERSION
			// #expand version = version + " %BUILD_SUB_VERSION%";
// @ version = version + " %BUILD_SUB_VERSION%";
// #endif
			about = String.format(about, version);
			b.setMessage(about);
			b.setPositiveButton("确定", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
		case DIALOG_ID_NETWORK_DOWN: {
			AlertDialog.Builder b = new Builder(this);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setTitle("天气通提示");
			b.setMessage("抱歉！连接网络失败，请您查看您的网络设置，WLAN用户请检查您是否获得访问权限。").setCancelable(true).setPositiveButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
		case DIALOG_ID_COMMON_FAILED: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("无法更新");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage("更新发生错误，请检查网络环境或者过一会儿再试。");
			b.setPositiveButton("设置", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {

					String action = "android.settings.WIRELESS_SETTINGS";

					final PackageManager packageManager = getPackageManager();
					final Intent intent = new Intent(action);
					List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
					if (list.size() > 0) {
						startActivity(intent);
					} else {
						Toast.makeText(MainActivity.this, "无法调用设置界面。", Toast.LENGTH_SHORT).show();
					}

				}
			});
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
		case DIALOG_ID_WELCOME: {

			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.welcome_dialog, null);

			String firstTTSTime = SPUtility.getSPStringHourAndMinuteStrWithColon12or24(this, R.string.str_1st_tts_time);
			String secondTTSTime = SPUtility.getSPStringHourAndMinuteStrWithColon12or24(this, R.string.str_2nd_tts_time);

			boolean useTTS = SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_use_tts);

			final TextView ttsTime = (TextView) v.findViewById(R.id.text);
			ttsTime.setText("播报时间：" + SPUtility.getSPStringBooleansDayOfWeekBriefCnString(this, R.string.str_days_for_play) + "；" + firstTTSTime + "、" + secondTTSTime);

			final TextView checkText = (TextView) v.findViewById(R.id.check_text);

			CheckBox checkBox = (CheckBox) v.findViewById(R.id.check);
			checkBox.setChecked(useTTS);
			if (useTTS) {
				ttsTime.setVisibility(View.VISIBLE);
				checkText.setTextAppearance(this, android.R.style.TextAppearance_Medium);
				checkText.setText(R.string.welcome_check);
			} else {
				ttsTime.setVisibility(View.GONE);
				checkText.setTextAppearance(this, android.R.style.TextAppearance_Medium_Inverse);
				checkText.setText(R.string.welcome_uncheck);
			}
			checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_use_tts, isChecked);
					if (isChecked) {
						ttsTime.setVisibility(View.VISIBLE);
						checkText.setTextAppearance(MainActivity.this, android.R.style.TextAppearance_Medium);
						checkText.setText(R.string.welcome_check);
					} else {
						ttsTime.setVisibility(View.GONE);
						checkText.setTextAppearance(MainActivity.this, android.R.style.TextAppearance_Medium_Inverse);
						checkText.setText(R.string.welcome_uncheck);
					}
				}
			});

			AlertDialog.Builder b = new AlertDialog.Builder(this);

			b.setView(v);

			b.setTitle(R.string.welcome_title);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));

			b.setNegativeButton("我知道了！", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_WELCOME);

					boolean useTTS = SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_use_tts);
					if (!useTTS) {
						SPUtility.userActionCounterIncreaseOne(MainActivity.this, R.string.int_times_of_disabling_tts_at_welcome);
					}
				}
			});

			b.setPositiveButton("设置语音播报", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					SPUtility.userActionCounterIncreaseOne(MainActivity.this, R.string.int_times_of_clicking_tts_button_at_welcome);

					startActivity(new Intent(MainActivity.this, TTSSetting.class));
					removeDialog(DIALOG_ID_WELCOME);

					boolean useTTS = SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_use_tts);
					if (!useTTS) {
						SPUtility.userActionCounterIncreaseOne(MainActivity.this, R.string.int_times_of_disabling_tts_at_welcome);
					}
				}
			});

			return b.create();
		}
		case DIALOG_ID_NEWEST_VERSION: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("检查新版本");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage("您现在用的是最新版本。");
			b.setNegativeButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
			return b.create();
		}
		case DIALOG_ID_ADD_CITY: {
			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.add_city_dlg, null);

			CheckBox checkBox = (CheckBox) v.findViewById(R.id.check);
			checkBox.setChecked(SPUtility.getSPBoolean(this, R.string.boolean_checkbox_checked, true));
			SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_pop_add_city_dlg, !checkBox.isChecked());
			checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_pop_add_city_dlg, !isChecked);
					SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_checkbox_checked, isChecked);
				}
			});

			AlertDialog.Builder b = new AlertDialog.Builder(this);

			b.setView(v);

			b.setTitle(R.string.add_city_dlg_title);
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));

			b.setNegativeButton(R.string.add_city_dlg_negative, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_ADD_CITY);
				}
			});

			b.setPositiveButton(R.string.add_city_dlg_positive, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					startActivityForResult(new Intent(MainActivity.this, CitySelector.class), REQUEST_CODE_SLIP_ADDCITY);
					removeDialog(DIALOG_ID_ADD_CITY);
				}
			});

			return b.create();
		}
		case DIALOG_ID_UPDATE_WAY: {

			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.updata_way, null);

			TextView text_live = (TextView) v.findViewById(R.id.text_live);
			TextView text_forecast = (TextView) v.findViewById(R.id.text_forecast);

			String start_time = SPUtility.getSPStringHourAndMinuteStrWithColon12or24(MainActivity.this, R.string.str_update_start_time);
			String end_time = SPUtility.getSPStringHourAndMinuteStrWithColon12or24(MainActivity.this, R.string.str_update_end_time);
			String time_scope = start_time + "-" + end_time;

			text_live.setText(time_scope + getString(R.string.update_live_explain));
			text_forecast.setText(getString(R.string.update_forecast_explain));

			final RadioButton m_Radio1 = (RadioButton) v.findViewById(R.id.RadioButton1);
			final RadioButton m_Radio2 = (RadioButton) v.findViewById(R.id.RadioButton2);

			// 这里需要从默认值的设置中区取
			int update_type_int = SPUtility.getSPStringInteger(MainActivity.this, R.string.strint_update_type);
			if (update_type_int == 0) {
				m_Radio2.setChecked(true);
				TextView update_forecast = (TextView) v.findViewById(R.id.update_forecast);
				update_forecast.setText(getString(R.string.update_forecast) + "（默认）");
			} else {
				m_Radio1.setChecked(true);
				TextView update_live = (TextView) v.findViewById(R.id.update_live);
				update_live.setText(getString(R.string.update_live) + "（默认）");
			}

			m_Radio1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (isChecked) {
						m_Radio2.setChecked(false);
					}

				}

			});
			m_Radio2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (isChecked) {
						m_Radio1.setChecked(false);
					}

				}

			});

			AlertDialog.Builder b = new AlertDialog.Builder(this);

			b.setView(v);

			b.setTitle("选择更新方式");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setPositiveButton("下一步", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					if (m_Radio1.isChecked()) {
						SPUtility.userActionCounterIncreaseOne(MainActivity.this, R.string.int_times_of_choosing_condition_mode_at_welcome);
					} else if (m_Radio2.isChecked()) {
						SPUtility.userActionCounterIncreaseOne(MainActivity.this, R.string.int_times_of_choosing_forecast_mode_at_welcome);
					}

					removeDialog(DIALOG_ID_UPDATE_WAY);
					if (m_Radio1.isChecked()) {
						// 实况模式，按间隔
						SPUtility.putSPStringInteger(MainActivity.this, R.string.strint_update_type, 1);
					} else if (m_Radio2.isChecked()) {
						// 预报模式，按次
						SPUtility.putSPStringInteger(MainActivity.this, R.string.strint_update_type, 0);
					}

					showDialog(DIALOG_ID_WELCOME);
				}
			});

			return b.create();
		}

		case DIALOG_ID_TRANSMIT_WAY: {

			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.transmit_way, null);

			RadioGroup radioGroup = (RadioGroup) v.findViewById(R.id.radio);

			final RadioButton m_Radio1 = (RadioButton) v.findViewById(R.id.RadioButton1);
			m_Radio1.setText("短信转发");
			m_Radio1.setChecked(true);
// final RadioButton m_Radio2 = (RadioButton) v.findViewById(R.id.RadioButton2);
// m_Radio2.setText("彩信转发");

			final RadioButton m_Radio3 = (RadioButton) v.findViewById(R.id.RadioButton3);
			m_Radio3.setText("分享到微博");
			final RadioButton m_Radio4 = (RadioButton) v.findViewById(R.id.RadioButton4);
			m_Radio4.setText("分享到其它");

			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("天气分享");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setView(v);

			radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {// 这样的监听让用户少点击一次
						@Override
						public void onCheckedChanged(RadioGroup group, int checkedId) {

							if (m_Radio1.isChecked()) {
								shareWeather(SEND_SMS);
							}
// if (m_Radio2.isChecked()) {
// shareWeather(SEND_MMS);
// }

							if (m_Radio3.isChecked()) {
								shareWeather(SEND_WEIBO);
							}
							if (m_Radio4.isChecked()) {
								shareWeather(SEND_OTHER);
							}
							removeDialog(DIALOG_ID_TRANSMIT_WAY);

						}

					});
			b.setPositiveButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					if (m_Radio1.isChecked()) {
						shareWeather(SEND_SMS);
					}
// if (m_Radio2.isChecked()) {
// shareWeather(SEND_MMS);
// }

					if (m_Radio3.isChecked()) {
						shareWeather(SEND_WEIBO);
					}
					if (m_Radio4.isChecked()) {
						shareWeather(SEND_OTHER);
					}
					removeDialog(DIALOG_ID_TRANSMIT_WAY);
				}
			});

			return b.create();
		}
		case DIALOG_ID_UPDATE_REMIND: {

			LayoutInflater li = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
			View v = li.inflate(R.layout.update_remind, null);

			final TextView textRemind = (TextView) v.findViewById(R.id.text_remind);

			textRemind.setText("您已经" + mUpdateTimePastDay + "天没有更新了，建议立即更新！");

			CheckBox checkBox = (CheckBox) v.findViewById(R.id.check);
			checkBox.setText("不再提醒");
			checkBox.setChecked(!SPUtility.getSPBoolean(this, R.string.boolean_update_remind));

			checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					SPUtility.putSPBoolean(MainActivity.this, R.string.boolean_update_remind, !isChecked);
				}
			});

			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setView(v);
			b.setTitle("更新提醒");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_UPDATE_REMIND);
				}
			});

			b.setPositiveButton("确定", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_UPDATE_REMIND);
					updateWeather();
				}
			});

			return b.create();
		}

		case DIALOG_ID_DOWNLOAD_WEIBO: {

			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("检测提示");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage("您还没有安装微博，推荐您立即下载。随时随地分享新鲜事！");
			b.setNegativeButton("以后再说", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_DOWNLOAD_WEIBO);
				}
			});

			b.setPositiveButton("马上安装", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_DOWNLOAD_WEIBO);
					Uri uri = Uri.parse("http://3g.sina.com.cn/3g/pro/?sa=t254d1356v150&vt=4&PHPSESSID=434c82079f261974c7fd8fa11c2db4fe");
					Intent intent = new Intent(Intent.ACTION_VIEW, uri);
					startActivity(intent);
				}
			});

			return b.create();
		}
		}
		return null;
	}

	private String makeForecastString(ForeCast fc, Calendar c, String[] daysOfWeek) {
		StringBuffer fcsb = new StringBuffer();
		c.set(Calendar.YEAR, fc.getDateYearNum());
		c.set(Calendar.MONTH, fc.getDateMonthNum() - 1);
		c.set(Calendar.DAY_OF_MONTH, fc.getDateDayNum());
		int dayNumOfWeek = c.get(Calendar.DAY_OF_WEEK);
		fcsb.append(daysOfWeek[dayNumOfWeek - 1]);
		fcsb.append(",");
		fcsb.append(fc.getText());
		fcsb.append(",");

		if (fc.getHigh() == -274) {

		} else {
			fcsb.append(fc.getHigh() + "℃");
			if (fc.getLow() == -274) {

			} else {
				fcsb.append("/");
			}
		}

		if (fc.getLow() == -274) {

		} else {
			fcsb.append(fc.getLow() + "℃");
		}

		String fcwind = fc.getWind();
		if (fcwind == WeatherInfo.INVALID_WIND) {

		} else {
			fcsb.append(",");
			fcsb.append(fc.getWind());
		}

		fcsb.append(";");
		return fcsb.toString();
	}

	private final static int SEND_SMS = 0;
	private final static int SEND_MMS = 1;
	private final static int SEND_WEIBO = 2;
	private final static int SEND_OTHER = 3;

	/**
	 * 天气预报的转发或者是截图的转发
	 * 
	 * @param sendWay
	 *            0短信，1彩信, 2微博,3其它
	 */
	private void shareWeather(int sendWay) {
		int type = SPUtility.getSPStringInteger(this, R.string.strint_send_sms);
		WeatherInfo wi = _service.getCurrentCityWeatherInfo();
		StringBuffer polychromeSubject = new StringBuffer();
		final int TYPE_CONDITION_2_DAYS = 0;
		final int TYPE_CONDITION_3_DATS = 1;
		final int TYPE_CONDITION_4_DAYS = 2;
		final int TYPE_CONDITION_5_DAYS = 3;
		final int TYPE_2_DAYS = 4;
		final int TYPE_3_DAYS = 5;
		final int TYPE_4_DAYS = 6;
		final int TYPE_5_DAYS = 7;
		StringBuffer sb = new StringBuffer();
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(System.currentTimeMillis());
		String cityName = _service.getCityName(wi.getCityCode());

		sb.append(cityName);
		polychromeSubject.append(cityName);

		int[] pubdateNums = wi.getPubdateYMDHMNumForLocal();
		int pubdateYearNum = pubdateNums[0];
		int pubdateMonthNum = pubdateNums[1];
		int pubdateDayNum = pubdateNums[2];
		int pubdateHourNum = pubdateNums[3];
		int pubdateMinuteNum = pubdateNums[4];

		sb.append(",");
		if (pubdateMonthNum < 10) {
			sb.append("0");
			polychromeSubject.append("0");
		}
		sb.append(pubdateMonthNum);
		polychromeSubject.append(pubdateMonthNum);

		sb.append("/");
		polychromeSubject.append("/");

		if (pubdateDayNum < 10) {
			sb.append("0");
			polychromeSubject.append("0");
		}
		sb.append(pubdateDayNum);
		polychromeSubject.append(pubdateDayNum);
		polychromeSubject.append("天气情况");

		sb.append(" ");

		if (pubdateHourNum < 10) {
			sb.append("0");
		}
		sb.append(pubdateHourNum);
		sb.append(":");
		if (pubdateMinuteNum < 10) {
			sb.append("0");
		}
		sb.append(pubdateMinuteNum);
		sb.append(",");

		if (!Utility.isOut(wi)) {
			// 拼出实况
			switch (type) {
			case TYPE_CONDITION_2_DAYS:
			case TYPE_CONDITION_3_DATS:
			case TYPE_CONDITION_4_DAYS:
			case TYPE_CONDITION_5_DAYS: {

				sb.append(WeatherInfo.getWeatherStrFromYahooCode(wi.getYCodeUsingSunRiseAndSet(), getResources()));

				if (wi.getCondition().getTemperature() == -274) {

				} else {
					sb.append(",");
					sb.append(wi.getCondition().getTemperature() + "℃");

				}
				String wind = wi.getCondition().getWind();
				if (wind == WeatherInfo.INVALID_WIND) {

				} else {
					sb.append(",");
					sb.append(wind);
				}

				sb.append(";");
			}
				break;
			case TYPE_2_DAYS:
			case TYPE_3_DAYS:
			case TYPE_4_DAYS:
			case TYPE_5_DAYS: {

			}
				break;
			}
		} else {

		}

		ArrayList<String> tal = new ArrayList<String>(5);
		c.setTimeInMillis(System.currentTimeMillis());
		String[] daysOfWeek = getResources().getStringArray(R.array.days_of_week_simple);

		ForeCast[] fcs = wi.getForecastsForCurrent(5);

		// 拼出预报
		switch (type) {
		case TYPE_CONDITION_5_DAYS:
		case TYPE_5_DAYS: {
			if (fcs[4] != ForeCast.EMPTY) {
				tal.add(0, makeForecastString(fcs[4], c, daysOfWeek));
			}
		}
			// 不要break;
		case TYPE_CONDITION_4_DAYS:
		case TYPE_4_DAYS: {
			if (fcs[3] != ForeCast.EMPTY) {
				tal.add(0, makeForecastString(fcs[3], c, daysOfWeek));
			}
		}
			// 不要break;
		case TYPE_CONDITION_3_DATS:
		case TYPE_3_DAYS: {
			if (fcs[2] != ForeCast.EMPTY) {
				tal.add(0, makeForecastString(fcs[2], c, daysOfWeek));
			}
		}
			// 不要break;
		case TYPE_CONDITION_2_DAYS:
		case TYPE_2_DAYS: {
			if (fcs[1] != ForeCast.EMPTY) {
				tal.add(0, makeForecastString(fcs[1], c, daysOfWeek));
			}
			if (fcs[0] != ForeCast.EMPTY) {
				tal.add(0, makeForecastString(fcs[0], c, daysOfWeek));
			}
		}
			// 不要break;
		}

		for (int i = 0; i < tal.size(); i++) {
			String t = tal.get(i);
			if (i == tal.size() - 1) {
				t = t.substring(0, t.length() - 1);
			}
			sb.append(t);
		}

		sb.append(".(来自@天气通 免费下载 http://t.cn/zO2NmwC )");

		if (sendWay == SEND_SMS) {// 转发短信
			Uri.Builder b = new Uri.Builder();
			b.scheme("sms");
			Intent i = new Intent(Intent.ACTION_SENDTO, b.build());
			i.putExtra("sms_body", sb.toString());
			final PackageManager packageManager = getPackageManager();
			List list = packageManager.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY);
			if (list.size() > 0) {
				startActivity(i);
			} else {
				ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				clipboard.setText(sb.toString());
				Toast.makeText(MainActivity.this, "文字信息已复制", Toast.LENGTH_LONG).show();
			}

		} else if (sendWay == SEND_MMS) {// 转发彩信//
			File file = ScreenShot.shoot(this, R.drawable.watermark);
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.putExtra("compose_mode", false);
			intent.putExtra("exit_on_sent", true);
			intent.putExtra("subject", polychromeSubject.toString());
			intent.putExtra("sms_body", sb.toString());
			intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
			intent.setClassName("com.android.mms", "com.android.mms.ui.ComposeMessageActivity");
			intent.setType("image/jpeg");
			final PackageManager packageManager = getPackageManager();
			List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
			if (list.size() > 0) {
				startActivity(intent);
			} else {
				Toast.makeText(MainActivity.this, "无法调用发送彩信界面。", Toast.LENGTH_SHORT).show();
			}
		} else if (sendWay == SEND_WEIBO) {// 转发微薄

			File file = ScreenShot.shoot(this, R.drawable.watermark);
// final PackageManager packageManager = getPackageManager();
// final Intent intent = new Intent(Intent.ACTION_SEND);
// intent.setComponent(new ComponentName("com.sina.weibo", "com.sina.weibo.NewBlog"));
// intent.setType("image/jpeg");
// intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
// intent.putExtra(Intent.EXTRA_TEXT, sb.toString());
// List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
// if (list.size() > 0) {
// startActivity(intent);
// } else {
// intent.setComponent(new ComponentName("com.sina.weibo", "com.sina.weibo.EditActivity"));
// list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
// if (list.size() > 0) {
// startActivity(intent);
// } else {
// showDialog(DIALOG_ID_DOWNLOAD_WEIBO);
// }
// }

			SendWeiBo SendWeiBo = new SendWeiBo(this, sb.toString(), file.getAbsolutePath());
			SendWeiBo.send();
		} else if (sendWay == SEND_OTHER) {

			Intent shareIntent = new Intent();

			shareIntent.setAction(Intent.ACTION_SEND);

			String mimeTyp = "image/*";

			shareIntent.setType(mimeTyp);

			File file = ScreenShot.shoot(this, R.drawable.watermark);

			if (file != null) {
				shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
				shareIntent.putExtra(Intent.EXTRA_TEXT, sb.toString());
				// 将文字放入剪切板中
				ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				clipboard.setText(sb.toString());
				Toast.makeText(MainActivity.this, "文字信息已复制", Toast.LENGTH_LONG).show();

			}

			startActivity(Intent.createChooser(shareIntent, "使用以下方式转发"));

		}

	}

	private static final int MSG_WHAT_UPDATE_ANMI = 1;
	private static final int MSG_WHAT_STOP_UPDATE_ANMI = 3;

	private static final int REQUEST_CODE_SLIP_ADDCITY = 4;
	private static final int START_SETTING_ACTIVITY = 5;

	public void onActivityResult(int requstCode, int responseCode, Intent data) {
		if (requstCode == START_SETTING_ACTIVITY) {
			if (responseCode == SettingActivity.RESULT_UPDATE_WEATHER) {
				WeatherInfo wi = _service.getCurrentCityWeatherInfo();
				String cityName = _service.getCurrentCityName();
				int skin = 0;
				if (Utility.isOut(wi)) {

					skin = setSkin(wi, true);
				} else {

					skin = setSkin(wi, false);
				}

				for (int i = 0; i < _va.getChildCount(); i++) {
					((WeatherViewInterface) _va.getChildAt(i)).updateUI(_service, cityName, wi, false, skin);
				}
			}
		}

		if (requstCode == REQUEST_CODE_SLIP_ADDCITY) {

			switch (responseCode) {
			case Activity.RESULT_OK: {
				String cityCode = data.getStringExtra(MSG_DATA_KEY_STR_CITYCODE);
				SPUtility.putSPString(this, R.string.str_current_city_code, cityCode);
			}

				break;
			case CitySelector.RESULT_EXCEPTION: {
				// 不关闭activity否则直接退出
// finish();
			}
				break;
			default:
				break;
			}

		}

	}

	private void updateUpdateText() {
		/*
		 * Calendar c = Calendar.getInstance(); String updateTime = null; long updateMillisecond = SPUtility.getSPStringLong(this, R.string.strlong_refresh_milletime);
		 * c.setTimeInMillis(updateMillisecond);
		 * 
		 * if (!Utility.isToday(updateMillisecond)) { updateTime = Utility.getStrMD(c) + " " + Utility.getStrHM12or24(this, c); } else { updateTime = Utility.getStrHM12or24(this, c); }
		 * _tvUpdateText.setText("更新时间：" + updateTime);
		 */

		WeatherInfo wi = _service.getCurrentCityWeatherInfo();
		StringBuilder sb = new StringBuilder();
		int pubDate[] = wi.getPubdateYMDHMNumForLocal();

		if (!Utility.isThisYear(wi)) {
			sb.append(pubDate[0] + "/");
		}

		if (!Utility.isToday(wi)) {
			if (Utility.isYestoday(wi)) {
				sb.append("昨天 ");
			} else {
				if (pubDate[1] < 10) {
					sb.append("0");
				}
				sb.append(pubDate[1]);
				sb.append("/");
				if (pubDate[2] < 10) {
					sb.append("0");
				}
				sb.append(pubDate[2]);
				sb.append(" ");
			}

		}

		if (!DateFormat.is24HourFormat(this)) {
			if (pubDate[3] > 12) {
				sb.append(this.getString(R.string.pm));
			} else {
				sb.append(this.getString(R.string.am));
			}
			sb.append(" ");
		}
		if (DateFormat.is24HourFormat(this)) {
			if (pubDate[3] < 10) {
				sb.append("0");
			}
			sb.append(pubDate[3]);
		} else {
			int h = pubDate[3];
			if (h > 12) {
				h = h - 12;
			}
			if (h < 10) {
				sb.append("0");
			}
			sb.append(h);
		}

		sb.append(":");
		if (pubDate[4] < 10) {
			sb.append("0");
		}
		sb.append(pubDate[4]);

		sb.append("发布");
		_tvUpdateText.setText(sb.toString());

	}

	private static final int[] mUpdateTextColor = new int[] { 0xff3f7eb4, 0xffffffff, 0xffd2bb96, 0xff558ee6, 0xff8781a0, 0xff54a5ea, 0xffffffff, 0xffaeb2bb, 0xffaeb2bb };

	private void updateUI(int page) {

		WeatherInfo wi = _service.getCurrentCityWeatherInfo();

		int skin = 0;
		if (Utility.isOut(wi)) {

			skin = setSkin(wi, true);
		} else {

			skin = setSkin(wi, false);
		}

		TianQiTongLog.addNormalLog("main activity update ui");

		if (_service.isTTSPlaying()) {
			_ivPlayTTSButton.setImageResource(R.drawable.stop_playing_tts_button);
		} else {
			_ivPlayTTSButton.setImageResource(R.drawable.play_tts_button);
		}

		String cityName = _service.getCurrentCityName();

		int pageIdx = page;

		for (int i = 0; i < _va.getChildCount(); i++) {
			((WeatherViewInterface) _va.getChildAt(i)).updateUI(_service, cityName, wi, pageIdx != 2, skin);
		}

		updateUpdateText();

		// 判断是否有最新推荐的图标
		boolean clickRecommend = SPUtility.getSPBoolean(this, R.string.if_new_recommend_click);
		if (clickRecommend) {
			_tvRecommend.setBackgroundResource(R.drawable.recommend_new);
			_tvRecommend.setOnClickListener(this);

		} else {
			_tvRecommend.setBackgroundResource(R.drawable.recommend_normal);
			_tvRecommend.setOnClickListener(this);
		}

		ArrayList<WarningInfo> warningInfoArray = _service.getCurrentCityWarningInfo();
		if (warningInfoArray != null) {
			if (warningInfoArray.size() > 0) {
				WarningInfo warning = warningInfoArray.get(0);
				String mWarningLevel = warning.getLevel();
				String mWarningTime = warning.getPubdate();
				long currentTime = System.currentTimeMillis();
				long warningTime = Utility.getDateTimeMillis(mWarningTime);
				long timeDifference = currentTime - warningTime;

				if (wi.getWarning().getWarningType().trim().equals("") || mWarningLevel.equalsIgnoreCase(WarningInfo.INVALID_WARNING_LEVEL) || timeDifference >= 3600L * 12L * 1000L) {
					_warningLayout.setVisibility(View.GONE);
				} else {
					if (wi.getWarning().getWarningLevel().contains("黄")) {
						_tvWarningInfo.setTextColor(_warningColors[0]);
						_tvWarningImage.setImageResource(_warningImage[0]);
					} else if (wi.getWarning().getWarningLevel().contains("橙")) {
						_tvWarningInfo.setTextColor(_warningColors[1]);
						_tvWarningImage.setImageResource(_warningImage[1]);
					} else if (wi.getWarning().getWarningLevel().contains("红")) {
						_tvWarningInfo.setTextColor(_warningColors[2]);
						_tvWarningImage.setImageResource(_warningImage[2]);
					} else if (wi.getWarning().getWarningLevel().contains("蓝")) {
						_tvWarningInfo.setTextColor(_warningColors[3]);
						_tvWarningImage.setImageResource(_warningImage[3]);
					}

					_warningLayout.setVisibility(View.VISIBLE);
					if (wi.getWarning().getWarningType().contains("森林火险") || wi.getWarning().getWarningType().contains("道路结冰")) {
						_tvWarningInfo.setText(wi.getWarning().getWarningType());
					} else {
						_tvWarningInfo.setText(wi.getWarning().getWarningType() + "预警");
					}

				}
			}
		}

	}

	private ImageView _ivPlayTTSButton;

	@Override
	public void handle(Message msg) {
		if (_handler == null) {
			return;
		}
		boolean isUseHistoryWeather = !SPUtility.getSPBoolean(MainActivity.this, R.string.boolean_use_history_weather_check);
		switch (msg.what) {
		case MsgUtility.MSG_WHAT_RESPONSE: {
			switch (msg.arg2) {
			case MsgUtility.MSG_ARG2_GET_ALL_PAST_WEATHER_INFO_FROM_SERVER: {
				Message tmsg = Message.obtain();
				tmsg.what = MSG_WHAT_STOP_UPDATE_ANMI;
				_handler.sendMessage(tmsg);
				mUpdateAllPastReqNum = -1;

				Bundle data = msg.getData();
				int resCode = data.getInt(MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE);
				if (resCode == MsgUtility.RESPONSE_CODE_SUCCESSFUL) {

				} else if (resCode == MsgUtility.RESPONSE_CODE_NETWORK_DOWN || resCode == MsgUtility.RESPONSE_CODE_SERVER_DOWN || resCode == MsgUtility.RESPONSE_CODE_BAD_XML) {
					_handler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_ID_NETWORK_DOWN);
						}
					});
				} else if (resCode == MsgUtility.RESPONSE_CODE_USER_CANCELED) {

				}
			}
				break;
			case MsgUtility.MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_SERVER: {
				if (!isUseHistoryWeather) {
					Message tmsg = Message.obtain();
					tmsg.what = MSG_WHAT_STOP_UPDATE_ANMI;
					_handler.sendMessage(tmsg);
				}
				
				mUpdateAllReqNum = -1;
				Bundle data = msg.getData();
				int resCode = data.getInt(MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE);
				if (resCode == MsgUtility.RESPONSE_CODE_SUCCESSFUL) {
					if (isUseHistoryWeather) {
						mUpdateAllPastReqNum = _service.updateAllPastWeatherData(new WeakReference<MsgResponseHandler>(this));
					}
				} else if (resCode == MsgUtility.RESPONSE_CODE_NETWORK_DOWN || resCode == MsgUtility.RESPONSE_CODE_SERVER_DOWN || resCode == MsgUtility.RESPONSE_CODE_BAD_XML) {
					_handler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_ID_NETWORK_DOWN);
						}
					});
				} else if (resCode == MsgUtility.RESPONSE_CODE_USER_CANCELED) {

				}
			}
				break;

			case MSG_ARG2_GET_PAST_WEATHER_INFO_XML_FROM_SERVER: {
				Message tmsg = Message.obtain();
				tmsg.what = MSG_WHAT_STOP_UPDATE_ANMI;
				_handler.sendMessage(tmsg);
				mUpdatePastRequestNum = -1;

				Bundle data = msg.getData();
				int resCode = data.getInt(MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE);
				switch (resCode) {
				case MsgUtility.RESPONSE_CODE_SUCCESSFUL: {		
					String tmp = _service.getWeatherInfo(mUpdatingCityCode).getPubdateStr();
					if (tmp.equals(mUpdatingPubdate)) {
						Toast.makeText(this, "您的天气数据已经是最新的了", Toast.LENGTH_SHORT).show();
					}

				}
					break;
				case MsgUtility.RESPONSE_CODE_NETWORK_DOWN:
				case MsgUtility.RESPONSE_CODE_SERVER_DOWN:
				case MsgUtility.RESPONSE_CODE_BAD_XML: {
					_handler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_ID_NETWORK_DOWN);
						}
					});
				}
					break;
				case MsgUtility.RESPONSE_CODE_USER_CANCELED:
					break;
				default:
					break;
				}
				mUpdatingPubdate = null;
			}
				break;
			case MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER: {
				if (!isUseHistoryWeather) {
					Message tmsg = Message.obtain();
					tmsg.what = MSG_WHAT_STOP_UPDATE_ANMI;
					_handler.sendMessage(tmsg);
				}
							
				mUpdateRequestNum = -1;
				Bundle data = msg.getData();
				int resCode = data.getInt(MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE);
				switch (resCode) {
				case MsgUtility.RESPONSE_CODE_SUCCESSFUL: {
					if (!isUseHistoryWeather) {
						String tmp = _service.getWeatherInfo(mUpdatingCityCode).getPubdateStr();
						if (tmp.equals(mUpdatingPubdate)) {
							Toast.makeText(this, "您的天气数据已经是最新的了", Toast.LENGTH_SHORT).show();
						}
					} else {
						mUpdatePastRequestNum = _service.updatePastWeatherData(mUpdatingCityCode, new WeakReference<MsgResponseHandler>(this));
					}
				}
					break;
				case MsgUtility.RESPONSE_CODE_NETWORK_DOWN:
				case MsgUtility.RESPONSE_CODE_SERVER_DOWN:
				case MsgUtility.RESPONSE_CODE_BAD_XML: {
					_handler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_ID_NETWORK_DOWN);
						}
					});
				}
					break;
				case MsgUtility.RESPONSE_CODE_USER_CANCELED:
					break;
				default:
					break;

				}

				if (!isUseHistoryWeather) {
					mUpdatingPubdate = null;
				}

// if (resCode == MsgUtility.RESPONSE_CODE_SUCCESSFUL) {
// mUpdateRequestNum = -1;
//
// } else if (resCode == MsgUtility.RESPONSE_CODE_NETWORK_DOWN) {
// mUpdateRequestNum = -1;
// _handler.post(new Runnable() {
// public void run() {
// showDialog(DIALOG_ID_NETWORK_DOWN);
// }
// });
// } else if (resCode == MsgUtility.RESPONSE_CODE_USER_CANCELED) {
//
// }

			}
				break;
			case MSG_ARG2_CHECK_NEW_VERSION: {

				Bundle data = msg.getData();
				int resCode = data.getInt(MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE);
				switch (resCode) {
				case MsgUtility.RESPONSE_CODE_SUCCESSFUL: {
					boolean hasNew = data.getBoolean(MsgUtility.MSG_DATA_KEY_BOOLEAN_HAS_NEW_VERSION);
					if (_service._nvi._address.length() != 0) {
						String ver = data.getString(MsgUtility.MSG_DATA_KEY_STR_VER);
						float vernum = Float.parseFloat(_service._nvi._version);
						float curvernum = Float.parseFloat(getString(R.string.ver));
						if (vernum > curvernum) {
							_handler.post(new Runnable() {
								public void run() {
									showShowDialogCheckBox = false;
									showDialog(DIALOG_ID_ASK_UPDATE);
								}
							});
						} else {
							_handler.post(new Runnable() {
								public void run() {
									showShowDialogCheckBox = false;
									showDialog(DIALOG_ID_NEWEST_VERSION);
								}
							});
						}

					} else {
						_handler.post(new Runnable() {
							public void run() {
								showShowDialogCheckBox = false;
								showDialog(DIALOG_ID_NEWEST_VERSION);
							}
						});
					}
				}
					break;
				case MsgUtility.RESPONSE_CODE_NETWORK_DOWN:
				case MsgUtility.RESPONSE_CODE_SERVER_DOWN:
				case MsgUtility.RESPONSE_CODE_BAD_XML: {
					mUpdateRequestNum = -1;
					_handler.post(new Runnable() {
						public void run() {
							showDialog(DIALOG_ID_NETWORK_DOWN);
						}
					});
				}
					break;
				case MsgUtility.RESPONSE_CODE_USER_CANCELED:
					break;
				default:
					break;

				}
// if (resCode == MsgUtility.RESPONSE_CODE_SUCCESSFUL) {
//
// boolean hasNew = data.getBoolean(MsgUtility.MSG_DATA_KEY_BOOLEAN_HAS_NEW_VERSION);
// if (_service._nvi._address.length() != 0) {
// String ver = data.getString(MsgUtility.MSG_DATA_KEY_STR_VER);
// _handler.post(new Runnable() {
// public void run() {
// showShowDialogCheckBox = false;
// showDialog(DIALOG_ID_ASK_UPDATE);
// }
// });
// } else {
// _handler.post(new Runnable() {
// public void run() {
// showShowDialogCheckBox = false;
// showDialog(DIALOG_ID_NEWEST_VERSION);
// }
// });
// }
// }

			}
				break;
			}
		}
		}

	}

	public static final int WP_0 = 0;
	public static final int WP_1 = 1;
	public static final int WP_2 = 2;

	public static final int[] _warningColors = new int[] { 0xffff7e00, 0xffff5500, 0xffc30a0a, 0xff063a74 };
	public static final int[] _warningImage = new int[] { R.drawable.warning_yellow, R.drawable.warning_orange, R.drawable.warning_red, R.drawable.warning_blue };

	private int setSkin(WeatherInfo wi, boolean isWeatherOut) {
		int bgId = -1;

		if (isWeatherOut) {
			ForeCast[] fcs = wi.getForecasts();

			if (fcs.length == 0) {
				bgId = R.drawable.app_bg_4;
			} else {
				ForeCast[] realForecastIdxes = wi.getForecastsForCurrent(5);

				if (realForecastIdxes.length != 0) {
					boolean isDay = wi.isDay();

					if (isDay) {
						bgId = WeatherInfo.getWeatherIconFromYahooCode(realForecastIdxes[0].getYcode(), WeatherInfo.BACKGROUND_TYPE, getResources());
					} else {
						bgId = WeatherInfo.getWeatherIconFromYahooCode(realForecastIdxes[0].getYcode2(), WeatherInfo.BACKGROUND_TYPE, getResources());
					}

				} else {
					bgId = R.drawable.app_bg_4;
				}

			}
		} else {
			bgId = WeatherInfo.getWeatherIconFromYahooCode(wi.getYCodeUsingSunRiseAndSet(), WeatherInfo.BACKGROUND_TYPE, getResources());
		}

		_va.setBigBG(bgId);

		int curBgType = -1;
		switch (bgId) {
		case R.drawable.app_bg_1:
			curBgType = 0;
			break;
		case R.drawable.app_bg_2:
			curBgType = 1;
			break;
		case R.drawable.app_bg_3:
			curBgType = 2;
			break;
		case R.drawable.app_bg_4:
			curBgType = 3;
			break;
		case R.drawable.app_bg_5:
			curBgType = 4;
			break;
		case R.drawable.app_bg_6:
			curBgType = 5;
			break;
		case R.drawable.app_bg_7:
			curBgType = 6;
			break;
		case R.drawable.app_bg_8:
			curBgType = 7;
			break;
		case R.drawable.app_bg_9:
			curBgType = 8;
			break;
		default:
			curBgType = 3;
			break;
		}

		_tvUpdateText.setTextColor(mUpdateTextColor[curBgType]);

		return curBgType;

	}

	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	@Override
	public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
		if (key.equals(getString(R.string.strlong_refresh_milletime))) {

		}
	}

	@Override
	public void onChildrenMoving(Rect[] notGoneChildrenRect, Rect customFrameLayoutRect) {

	}

	private VelocityTracker mVelocityTracker;

	/**
	 * view.OnTouchListener.onTouch
	 * 
	 * @param v
	 * @param event
	 * @return
	 */
	@Override
	public boolean onTouch(View v, MotionEvent event) {

		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN: {
			if (mVelocityTracker == null) {
				mVelocityTracker = VelocityTracker.obtain();
			}
		}
			break;
		case MotionEvent.ACTION_MOVE: {
			mVelocityTracker.addMovement(event);
		}
			break;
		case MotionEvent.ACTION_UP: {
			mVelocityTracker.computeCurrentVelocity(100);
			float vx = mVelocityTracker.getXVelocity();
			float vy = mVelocityTracker.getYVelocity();
			if (Math.abs(vy) > Math.abs(vx) && Math.abs(vy) > ViewConfiguration.getMinimumFlingVelocity()) {
				int currentPage = _va.getCurrentChild();
				if (currentPage == 0) {
					return false;
				}

				TianQiTongService service = _service;
				String[] cityCodes = service.getCityCodes();
				String cityCode = SPUtility.getSPString(this, R.string.str_current_city_code);
				int idx = 0;
				for (; idx < cityCodes.length; idx++) {
					if (cityCodes[idx].equals(cityCode)) {
						break;
					}
				}
				if (vy > 0) {
					if (idx == cityCodes.length - 1) {
						cityCode = cityCodes[0];
					} else {
						cityCode = cityCodes[idx + 1];
					}
				} else {
					if (idx == 0) {
						cityCode = cityCodes[cityCodes.length - 1];
					} else {
						cityCode = cityCodes[idx - 1];
					}
				}

				if (mUpdateRequestNum != -1) {
					Toast.makeText(this, "正在更新，请稍后。如需取消更新，请再次点击更新按钮。", Toast.LENGTH_LONG).show();
				} else {
					if (cityCode.equals(SPUtility.getSPString(this, R.string.str_current_city_code))) {
						showAddNewCityDialog();
					} else {
						SPUtility.putSPString(this, R.string.str_current_city_code, cityCode);
					}
				}

				if (mVelocityTracker != null) {
					mVelocityTracker.recycle();
					mVelocityTracker = null;
				}

			}

		}
		case MotionEvent.ACTION_CANCEL: {
			if (mVelocityTracker != null) {
				mVelocityTracker.recycle();
				mVelocityTracker = null;
			}
		}
			break;
		default: {

		}
		}

		return true;
	}

	@Override
	public void onInterceptTouchEvent() {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				cancelAutoLock();
			}
		});

	}

	public static String gChangeCity = null;

	@Override
	public void onCurrentChildChanged(final int idx) {

		if (gChangeCity != null) {
			SPUtility.putSPString(this, R.string.str_current_city_code, gChangeCity);
			gChangeCity = null;
		}

		runOnUiThread(new Runnable() {
			public void run() {
				updatePagePoints(idx);
				showGuideByPage(idx);
// #ifndef WITHOUT_RECOMMEND
				updateRecommend(idx);
// #endif

			}
		});
	}

	/****
	 * 如果第一次进入第三屏，则显示用户引导
	 * 
	 * */
	private void showGuideByPage(int pageNumber) {
		boolean ifShowGuideActivity;
		Intent intent = new Intent(this, MainGuideActivity.class);
		if (pageNumber == 0) {
			ifShowGuideActivity = SPUtility.getSPBoolean(this, R.string.show_city_drag_guide, true);
			if (ifShowGuideActivity) {
				SPUtility.putSPBoolean(MainActivity.this, R.string.show_city_drag_guide, false);
				intent.putExtra(BUNDLE_GUIDE_TYPE, BUNDLE_GUIDE_TYPE_VALUE_CITYDRAG);
				startActivity(intent);
				overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
			}
		} else if (pageNumber == 1) {
			ifShowGuideActivity = SPUtility.getSPBoolean(this, R.string.show_main_guide, true);
			if (ifShowGuideActivity) {
				SPUtility.putSPBoolean(MainActivity.this, R.string.show_main_guide, false);
				intent.putExtra(BUNDLE_GUIDE_TYPE, BUNDLE_GUIDE_TYPE_VALUE_MAIN);
				startActivity(intent);
				overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
			}
		}
	}

	public void click9GridAnimToRight() {
		_va.toNext();
	}

	@Override
	public void onBGFadeDone() {

	}
}
