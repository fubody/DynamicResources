package sina.mobile.tianqitong.citymanager;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_ARG2_GET_CITYCODE_VIA_NAUTICA;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_CITYCODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_CITYNAME;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_FAILED_CAN_NOT_DO_IT_AGAIN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_LOCATE_TIME_OUT;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_NO_LOCATION_PROVIDER;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SUCCESSFUL;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_USER_CANCELED;

import java.lang.ref.WeakReference;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.IntentActionConstants;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.MsgResponseHandler;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class LocateManager extends Activity implements ServiceConnection, MsgResponseHandler, android.view.View.OnClickListener {

	private static final long COUNT_DOWN_TIME = 12300;
	private static final long DURATION_TIME = 1 * 1000;
	private TianQiTongService _service;
	private Handler mHandler;

	private LinearLayout mLocateFailLayout;
	private ImageView mLocateFailImage;
	private TextView mLocateFailText;
	private TextView mLocateFailCity;
	private LinearLayout mLocateIngLayout;
	private ImageView mLocateIngImage;
// private ImageView mTimeIngImage;
	private TextView mTimeCountDownText;
	private Button mLocateFailOk;
	private TextView mLocateIngText;
	private LinearLayout mCancelLayout;
	private Button mCancelAll;
	private boolean mAutoLocate;// true 第一次启动然后自动定位

// private ImageView mCancelHalf, mOk;
	private Button mCancelHalf, mOk;
	public boolean mLocateIng = true;
// public boolean locateFail = false;

	private String mLastKnownCityCode = null;
	private String mLastKnownCityName = null;
	private CountDownTimer mCdtimer;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.locate_layout);
		Intent intent = getIntent();
		mAutoLocate = intent.getBooleanExtra(IntentActionConstants.EXTRA_WEATHER_AUTO_LOCATE, false);
		mHandler = new Handler();
		mLocateFailLayout = (LinearLayout) this.findViewById(R.id.locate_fail_linear);
		mLocateFailImage = (ImageView) this.findViewById(R.id.locate_fail_image);
		mLocateFailText = (TextView) this.findViewById(R.id.locate_fail_text);
		mLocateFailCity = (TextView) this.findViewById(R.id.locate_fail_city);
		mLocateIngLayout = (LinearLayout) this.findViewById(R.id.locate_ing_linear);
		mLocateIngImage = (ImageView) this.findViewById(R.id.locate_ing_image);
// mTimeIngImage = (ImageView) this.findViewById(R.id.time_ing_image);
		mTimeCountDownText = (TextView) this.findViewById(R.id.time_ing_text);
		mLocateFailOk = (Button) this.findViewById(R.id.ok_locate_fail);
		mLocateFailOk.setOnClickListener(this);
		mLocateIngText = (TextView) this.findViewById(R.id.locate_ing_text);
		mCancelLayout = (LinearLayout) this.findViewById(R.id.cancel_linear);
		mCancelAll = (Button) this.findViewById(R.id.cancel_locate_citye);
		if (mAutoLocate) {
			mCancelAll.setText("手动添加");
			mLocateIngText.setText("自动定位中...");
		} else {
			mCancelAll.setText("取  消");
			mLocateIngText.setText("正在定位...");
		}
		mCancelHalf = (Button) this.findViewById(R.id.cancel_half);
		mCancelAll.setOnClickListener(this);
		mCancelHalf.setOnClickListener(this);
		mOk = (Button) this.findViewById(R.id.ok_half);
		mOk.setOnClickListener(this);
		mCdtimer = new CountDownTimer(COUNT_DOWN_TIME, DURATION_TIME) {

			@Override
			public void onFinish() {
				// TODO Auto-generated method stub
				if (mLocateIng) {// 应该发超时消息，只是用来确保正确，正常不会被调用
					_service.stopLocateCity();
					stopPlayingGPSAnim();
				}
			}

			@Override
			public void onTick(long millisUntilFinished) { // TODO Auto-generated method stub
				mTimeCountDownText.setText(Utility.makeCentigradeImgStr("" + (millisUntilFinished) / 1000, LocateManager.this));
			}

		};

		stopPlayingGPSAnim();
		bindService(new Intent(LocateManager.this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

	}

	public final void onServiceConnected(ComponentName name, IBinder service) {
		_service = ((TianQiTongService.TianQiTongBinder) service).getService();
		SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_gps);
		_service.locateCity(new WeakReference<MsgResponseHandler>(this));
		mHandler.post(new Runnable() {

			public void run() {
				playGPSAnim();
			}

		});
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.cancel_locate_citye: {

			_service.stopLocateCity();
			cancleLocate();

		}
			break;
		case R.id.cancel_half: {// 城市定位失败，且有定位成功城市的时候取消
			setResult(CitySelector.RESULT_EXCEPTION);
			finish();
		}
			break;
		case R.id.ok_locate_fail: {// 城市定位失败，无成功城市记录
			setResult(CitySelector.RESULT_EXCEPTION);
			finish();
		}
			break;

		case R.id.ok_half: {
			Intent intent = new Intent();
			if (mLastKnownCityCode != null) {
				intent.putExtra(MSG_DATA_KEY_STR_CITYCODE, mLastKnownCityCode);
				setResult(Activity.RESULT_OK, intent);
			} else {
				setResult(CitySelector.RESULT_EXCEPTION);
			}
			mLastKnownCityCode = null;
			mLastKnownCityName = null;
			finish();
		}
			break;
		}

	}

// private static final int DIALOG_ID_DOWNLOADING = 1;
// private static final int DIALOG_ID_NETWORK_DOWN = 2;
// private static final int DIALOG_ID_SERVER_DOWN = 3;
	private static final int DIALOG_ID_IF_USE_CACHED_CITY = 4;
	private static final int DIALOG_ID_ASK_ENABLE_PROVIDER = 5;
	private static final int DIALOG_ID_LOCATE_FAILED = 6;

// public static final int RESULT_EXCEPTION = 2;

	public Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_ASK_ENABLE_PROVIDER: {
			setResult(CitySelector.RESULT_EXCEPTION);
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("定位失败");
			// 所有定位都没开
			b.setMessage("基站定位和GPS定位都不存在或者未打开。");
			b.setPositiveButton("设置", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					String action = "android.settings.LOCATION_SOURCE_SETTINGS";

					final PackageManager packageManager = getPackageManager();
					final Intent intent = new Intent(action);
					List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
					if (list.size() > 0) {
						startActivity(intent);
					} else {
						Toast.makeText(LocateManager.this, "无法调用设置界面。", Toast.LENGTH_SHORT).show();

					}
					finish();
				}
			});
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_ASK_ENABLE_PROVIDER);
					finish();
				}
			});
			return b.create();
		}

		case DIALOG_ID_LOCATE_FAILED: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("定位失败");
			b.setIcon(android.R.drawable.ic_dialog_alert);
			b.setMessage("定位失败，请手动选择城市。");
			b.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(DIALOG_ID_LOCATE_FAILED);
					mLastKnownCityCode = null;
					mLastKnownCityName = null;
				}
			});
			return b.create();
// break;
		}
		}
		return null;
	}

	public void onDestroy() {
		super.onDestroy();
		// 很奇怪为什么finish()之后不立即调用，而是下次进入时执行onDestroy
// _service.cancelLocateCity();
		unbindService(this);

	}

	public void tcDismissDialog(int id) {
		try {
			dismissDialog(id);
		} catch (IllegalArgumentException iae) {

		}
	}

	@Override
	public void handle(Message msg) {
		Bundle responseDate = msg.getData();
		int responseCode = responseDate.getInt(MSG_DATA_KEY_INT_RESPONSE_CODE);
		int eventId = msg.arg2;
		switch (eventId) {
		case MSG_ARG2_GET_CITYCODE_VIA_NAUTICA: {
			mLocateIng = false;
			stopPlayingGPSAnim();
			switch (responseCode) {
			case RESPONSE_CODE_SUCCESSFUL: {
				SPUtility.userActionCounterIncreaseOne(this, R.string.int_times_of_using_gps_successfully);
				String cityCode = responseDate.getString(MSG_DATA_KEY_STR_CITYCODE);
				mHandler.post(new Runnable() {

					public void run() {
						mLocateIngLayout.setVisibility(View.GONE);
						mCancelAll.setVisibility(View.GONE);

					}

				});
				if (_service.getCityName(cityCode) == null) {
					Intent intent = new Intent();
					intent.putExtra(MSG_DATA_KEY_STR_CITYCODE, cityCode);
					setResult(Activity.RESULT_OK, intent);

				} else {
					setResult(CitySelector.CITY_ALREADY_EXITS);
					Toast.makeText(this, "位置未改变", Toast.LENGTH_SHORT).show();

				}
				finish();
				break;
			}
			case RESPONSE_CODE_USER_CANCELED: {// 用户主动取消，或者点击返回键
				setResult(Activity.RESULT_CANCELED);
				finish();
				break;
			}
			case RESPONSE_CODE_FAILED_CAN_NOT_DO_IT_AGAIN: {
				setResult(CitySelector.RESULT_EXCEPTION);
				Toast.makeText(this, "错误：定位中", Toast.LENGTH_SHORT).show();
				finish();
				break;
			}
			case RESPONSE_CODE_NO_LOCATION_PROVIDER:
// {
// mHandler.post(new Runnable() {
// public void run() {
// mLocateIngLayout.setVisibility(View.GONE);
// mCancelAll.setVisibility(View.GONE);
//
// }
//
// });
// showDialog(DIALOG_ID_ASK_ENABLE_PROVIDER);
// break;
// }
			case RESPONSE_CODE_LOCATE_TIME_OUT: {
				mLastKnownCityCode = responseDate.getString(MSG_DATA_KEY_STR_CITYCODE);
				mLastKnownCityName = responseDate.getString(MSG_DATA_KEY_STR_CITYNAME);
				if (mLastKnownCityCode != null && _service.getCityName(mLastKnownCityCode) == null) {
					mHandler.post(new Runnable() {
						public void run() {
							mLocateIngLayout.setVisibility(View.GONE);
							mLocateFailCity.setVisibility(View.VISIBLE);
							mCancelLayout.setVisibility(View.VISIBLE);
							mLocateFailLayout.setVisibility(View.VISIBLE);
							mCancelAll.setVisibility(View.GONE);
							mLocateFailText.setText("当前无法定位");
							mLocateFailCity.setText("是否启用上次位置：" + mLastKnownCityName);
						}

					});
				} else {
					mHandler.post(new Runnable() {
						public void run() {
							mLocateIngLayout.setVisibility(View.GONE);
							mLocateFailLayout.setVisibility(View.VISIBLE);
							if (mAutoLocate) {
								mLocateFailText.setText("当前无法自动定位");
								mLocateFailOk.setText("手动添加");
							} else {
								mLocateFailText.setText("当前无法定位，请返回手动添加");
								mLocateFailOk.setText("返回");
							}

							mCancelAll.setVisibility(View.GONE);
							mLocateFailOk.setVisibility(View.VISIBLE);
						}

					});
				}

				break;
			}
			}
			break;
		}
		}

	}

	private void stopPlayingGPSAnim() {
		Drawable d = mLocateIngImage.getBackground();
		if (d instanceof AnimationDrawable) {
			AnimationDrawable ad = (AnimationDrawable) d;
			ad.stop();

		}
		mCdtimer.cancel();
// d = mTimeIngImage.getBackground();
// if (d instanceof AnimationDrawable) {
// AnimationDrawable ad = (AnimationDrawable) d;
// ad.stop();
// }

	}

	private void cancleLocate() {
		stopPlayingGPSAnim();
		setResult(Activity.RESULT_CANCELED);
		finish();
	}

	private void playGPSAnim() {
		mLocateIngImage.setBackgroundResource(R.anim.locating);
		AnimationDrawable locateAd = (AnimationDrawable) mLocateIngImage.getBackground();
		locateAd.start();

		mCdtimer.start();

	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		_service = null;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK: {
			if (mLocateIng) {
				_service.stopLocateCity();
// stopPlayingGPSAnim();
				cancleLocate();
			} else {
				setResult(CitySelector.RESULT_EXCEPTION);
				finish();
			}
			return true;
		}
		default:
			return super.onKeyDown(keyCode, event);
		}

	}

	@Override
	public void onStop() {
		super.onStop();
		if (mLocateIng) {
			_service.stopLocateCity();
// stopPlayingGPSAnim();
// cancleLocate();
			stopPlayingGPSAnim();
			setResult(CitySelector.RESULT_EXCEPTION);
			finish();
		}
	}

}
