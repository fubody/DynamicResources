package sina.mobile.tianqitong.service.frm;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_WHAT_REQUEST;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public abstract class MsgRequestExecutorHelper implements MsgRequestExecutor {

	protected Handler _handler = null;

	@Override
	public void execute(Message msg) {
		if (getValidEvents() != null) {
			for (int event : getValidEvents()) {
				if (event == msg.arg2) {
					_handler.sendMessage(msg);
					return;
				}
			}
			throw new UnsupportedOperationException();
		} else {
			_handler.sendMessage(msg);
		}
	}

	public void newHandler(Looper looper) {
		_handler = new Handler(looper) {
			public void handleMessage(Message msg) {

				int type = msg.what;
				int event = msg.arg2;

				switch (type) {
				case MSG_WHAT_REQUEST: {
					int requestNum = msg.arg1;
					Bundle args = (Bundle) msg.getData().clone();
					executeRequest(event, requestNum, args);

				}
					break;
				}
			}
		};

	}

	public abstract void executeRequest(int event, int requestNum, Bundle args);

	public abstract int[] getValidEvents();

}
