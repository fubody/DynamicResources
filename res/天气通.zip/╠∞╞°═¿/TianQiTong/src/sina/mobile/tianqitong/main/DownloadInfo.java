package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_STR_URL;

import java.io.File;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.frm.HandlerObserver;
import sina.mobile.tianqitong.service.frm.MsgRequestExecutorHelper;
import sina.mobile.tianqitong.service.frm.MsgUtility;
import sina.mobile.tianqitong.service.model.DownloadItem;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class DownloadInfo extends Activity implements ServiceConnection, Callback {

	private TianQiTongService _service;

// private BroadcastReceiver _br = new BroadcastReceiver() {
//
// Override
// public void onReceive(Context context, Intent intent) {
// int step = intent.getIntExtra(MsgUtility.MSG_DATA_KEY_INT_STEP, 0);
// _pbStep.setProgress(step);
// if (step == 100) {
// showDialog(DIALOG_ID_ASK_INSTALL);
// }
// }
// };

	private TextView _tvFilename;
	private TextView _tvMessage;
	private ProgressBar _pbStep;
// private int _requestNum = -1;

	private int _step = 0;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		onNewIntent();

		setContentView(R.layout.download_apk_info);

// IntentFilter intentfilter = new IntentFilter("sina.mobile.tianqitong.downloadapk_step");
// registerReceiver(_br, intentfilter);

		_tvFilename = (TextView) findViewById(R.id.filename);
		_tvMessage = (TextView) findViewById(R.id.message);
		_pbStep = (ProgressBar) findViewById(R.id.progress);
		Button _btCancel = (Button) findViewById(R.id.cancel);

		_pbStep.setProgress(_step);
		if (_step == 100) {
			_pbStep.setVisibility(View.INVISIBLE);
			_btCancel.setVisibility(View.INVISIBLE);
		} else {
			_btCancel.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showDialog(DIALOG_ID_ASK_CANCEL);
				}
			});
		}

		bindService(new Intent(this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

		HandlerObserver.registerObserver(mHandler, new int[] { HandlerObserver.NTY2HANDLER_MSG_WHAT_DOWNLOADITEM_PROGRESS_UPDATED });

	}

	private Handler mHandler = new Handler(this);

	public void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		setIntent(intent);
		onNewIntent();
	}

	private static final int DIALOG_ID_ASK_INSTALL = 0;
	private static final int DIALOG_ID_SHOW_APK_LOCATION = 1;
	private static final int DIALOG_ID_ASK_CANCEL = 2;

	public Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_ASK_INSTALL: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("安装最新版本");

			final NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

			String fn = _service._nvi._address;
			String[] tmp = Utility.split(fn, '/');
			fn = tmp[tmp.length - 1];
			File f = new File(Utility.getDownloadDir(), fn);
			final String filePath = f.getAbsolutePath();

			b.setMessage(fn);
			b.setPositiveButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					Intent i = new Intent(Intent.ACTION_VIEW);

					i.setDataAndType(Uri.parse("file:/" + filePath), "application/vnd.android.package-archive");
					startActivity(i);
					mNotificationManager.cancel(R.id.ok);
					dialog.dismiss();
				}
			});
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					mNotificationManager.cancel(R.id.ok);
					showDialog(DIALOG_ID_SHOW_APK_LOCATION);
					dialog.dismiss();
				}
			});

			b.setOnCancelListener(new DialogInterface.OnCancelListener() {

				@Override
				public void onCancel(DialogInterface dialog) {
					finish();
				}
			});

			return b.create();
// break;
		}
		case DIALOG_ID_SHOW_APK_LOCATION: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			String fn = _service._nvi._address;
			String[] tmp = Utility.split(fn, '/');
			fn = tmp[tmp.length - 1];
			File f = new File(Utility.getDownloadDir(), fn);
			final String filePath = f.getAbsolutePath();
			b.setTitle("下载完成");
			b.setMessage("安装文件已经下载到" + filePath + "。点击确定关闭。");
			b.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
					dialog.dismiss();
					dialog.cancel();
				}
			});
			return b.create();
// break;
		}
		case DIALOG_ID_ASK_CANCEL: {
			AlertDialog.Builder b = new AlertDialog.Builder(this);
			b.setTitle("取消下载");
			b.setMessage("是否取消下载？");
			b.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					TianQiTongDownloadManger.getInstance(_service).cancelRequest(mUrl);
					NotificationManager mNotificationManager = (NotificationManager) DownloadInfo.this.getSystemService(Context.NOTIFICATION_SERVICE);
					mNotificationManager.cancel(R.id.ok);
					finish();
				}
			});
			b.setNegativeButton(R.string.no, null);
			return b.create();
		}
		}
		throw new IllegalArgumentException();

	}

	private String mUrl = null;

	private void onNewIntent() {
		Intent i = getIntent();
		mUrl = i.getStringExtra(MsgUtility.MSG_DATA_KEY_STR_URL);
		_step = i.getIntExtra("step", 0);
	}

	public void onDestroy() {
		super.onDestroy();
		unbindService(this);
// unregisterReceiver(_br);
	}

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		_service = ((TianQiTongService.TianQiTongBinder) service).getService();
		_tvFilename.setText(_service._nvi._address);
		_tvMessage.setText(_service._nvi._message);
		if (_step == 100) {
			showDialog(DIALOG_ID_ASK_INSTALL);
		}
	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		_service = null;

	}

	@Override
	public boolean handleMessage(Message msg) {
		String url = msg.getData().getString(MSG_DATA_KEY_STR_URL);
		if (url.equals(_service._nvi._address)) {
			DownloadItem di = TianQiTongDownloadManger.getInstance(_service).getDownloadItem(url);
			_pbStep.setProgress(di.getProgress());
			if (di.getProgress() == 100) {
				showDialog(DIALOG_ID_ASK_INSTALL);
			}
		}
		return false;
	}
}
