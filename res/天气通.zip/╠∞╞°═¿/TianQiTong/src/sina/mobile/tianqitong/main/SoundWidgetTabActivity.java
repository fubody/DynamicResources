package sina.mobile.tianqitong.main;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.ad.AdManager;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.AdList.AdEntity;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.simplelistdata.TQTSimpleDataManager;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.TabActivity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TabHost;

public class SoundWidgetTabActivity extends TabActivity implements ServiceConnection, Callback {
	private RadioGroup mButton = null;
	private TabHost mHost;
	private Intent mIntent1, mIntent2;
	private TianQiTongService mService;

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		mService = ((TianQiTongService.TianQiTongBinder) service).getService();

		String widgetCityCode = SPUtility.getSPString(this, R.string.str_widget_city_code);
		WeatherInfo wi = mService.getWeatherInfo(widgetCityCode);
		String cityName = mService.getCityName(widgetCityCode);

		am = mService.getADManger();
		am.setDataManagerListener(mHandler);
		am.refreshAdEntities(null);

// buileData();

		DiyableAppWidgetPreviewManager.init(this, wi, cityName, FileGettable.CURRENT);

	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		mService = null;

	}

	private Handler mHandler = new Handler(this);

	private AdEntity mAdEntity = null;

	private void buileData() {

		ArrayList<AdEntity> al = new ArrayList<AdEntity>();
		{
			AdEntity[] aeArray = am.getAdEntitys();
			for (int i = 0; i < aeArray.length; i++) {
				if (aeArray[i].getPos() == AdEntity.POS_BANNER) {
					al.add(aeArray[i]);
				}
			}
		}

		if (al.size() != 0) {
			int whichIndex = (int) (Math.random() * (al.size()));
			mAdEntity = al.get(whichIndex);
			if (Utility.getADSDir() == null) {
				return;
			}
			mAdEntity.setAdImage(mImageView);
		}

	}

	private AdManager am = null;

	private ImageView mImageView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sound_widget_tabs);
		mHost = getTabHost();
		mButton = (RadioGroup) findViewById(R.id.tabRadio);
		mButton.setOnCheckedChangeListener(new ButtonChecked());

		bindService(new Intent(this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

		mIntent1 = new Intent(this, PlugInActivity.class);
		mIntent2 = new Intent(this, SoundActivity.class);

		mImageView = (ImageView) findViewById(R.id.ad);
		mImageView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mAdEntity != null && mAdEntity.getAct() == AdEntity.ACT_LINK) {

					String url = mAdEntity.getMainUrl();
					String id = mAdEntity.getId();

					ArrayList<NameValuePair> al = new ArrayList<NameValuePair>();
					al.add(new BasicNameValuePair("product_id", id));
					al.add(new BasicNameValuePair("orul", url));

					URI uri;
					try {
						uri = URIUtils.createURI("http", "tqt.sina.cn", -1, "/download.php", URLEncodedUtils.format(al, "UTF-8"), null);
						Uri uuri = Uri.parse(uri.toString());
						Intent intent = new Intent();
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(uuri);
						startActivity(intent);
					} catch (URISyntaxException e1) {
						e1.printStackTrace();
					} catch (ActivityNotFoundException e) {
						e.printStackTrace();
					}

				} else if (mAdEntity.getAct() == AdEntity.ACT_DOWNLOAD) {
					Uri uuri = Uri.parse(mAdEntity.getMainUrl());
					try {
						Intent intent = new Intent();
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(uuri);
						startActivity(intent);
					} catch (ActivityNotFoundException e) {
						e.printStackTrace();
					}
				}

			}
		});

		setupIntent();
	}

	public void onDestroy() {
		unbindService(this);
		DiyableAppWidgetPreviewManager.releaseAll();
		super.onDestroy();
	}

	private void setupIntent() {
		mHost.clearAllTabs();

		mHost.addTab(mHost.newTabSpec("tab1").setIndicator("", getResources().getDrawable(R.drawable.icon)).setContent(mIntent1));

		mHost.addTab(mHost.newTabSpec("tab2").setIndicator("", getResources().getDrawable(R.drawable.icon)).setContent(mIntent2));
	}

	private class ButtonChecked implements OnCheckedChangeListener {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {

			switch (checkedId) {
			case R.id.button1: {

				mHost.setCurrentTabByTag("tab1");
			}
				break;
			case R.id.button2: {
				mHost.setCurrentTabByTag("tab2");
			}
				break;

			}

		}
	}

	public boolean handleMessage(Message msg) {
		switch (msg.what) {
		case TQTSimpleDataManager.MSG_WHAT_LIST_UPDATED: {
			buileData();
			return true;
		}
		case TQTSimpleDataManager.MSG_WHAT_AUTO_DOWNLOAD_DONE: {
			mAdEntity.setAdImage(mImageView);
			return true;
		}
		case TQTSimpleDataManager.MSG_WHAT_LIST_NOT_CHANGE: {
			buileData();
			return true;
		}

		}
		return false;
	};

}
