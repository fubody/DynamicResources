package sina.mobile.tianqitong.appwidgetskinpkg;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;

import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.model.WeatherInfo.ForeCast;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.format.DateFormat;

public class Image extends AbstractSkinLayoutUnit {

	private String Src = null;
	private String FunctionId = null;
	private String Prefix = null;
	private String NightCWIPrefix = null;
	private String OffsetTime = null;

	private String mFileName = null;

	protected Image(AppWidgetSkin aws) {
		super(aws);
	}

	@Override
	protected Rect doMeasureDrawRectWAndH() {
		if (mFileName == null) {
			return null;
		}

		int[] rect = new int[] { 0, 0 };
		try {
			rect = mAws.getAppWidgetImageUnitWH(mFileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Rect r = new Rect(0, 0, rect[0], rect[1]);

		// TODO 有点丑...想办法弄掉。
		if (FunctionId != null && (FunctionId.equals("clock_hourhand") || FunctionId.equals("clock_minutehand"))) {
			DatumPoint = TOP | LEFT;
		}

		return r;

	}

	@Override
	protected boolean setSubValue(String attrName, String attrValue) {
		if (attrName.equals("Src")) {
			Src = attrValue;
		} else if (attrName.equals("FunctionId")) {
			FunctionId = attrValue;
		} else if (attrName.equals("Prefix")) {
			Prefix = attrValue;
		} else if (attrName.equals("NightCWIPrefix")) {
			NightCWIPrefix = attrValue;
		} else if (attrName.equals("OffsetTime")) {
			OffsetTime = attrValue;
		} else {
			return false;
		}
		return true;
	}

	@Override
	public void draw(Canvas c) {
		if (mFileName == null) {
			return;
		}

		Bitmap bmp = null;
		try {
			bmp = mAws.getAppWidgetImageUnit(mFileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (bmp == null) {
			return;
		}

		Paint p = new Paint();
		p.setAntiAlias(true);

		if (FunctionId != null && FunctionId.equals("clock_hourhand")) {
			Matrix m = new Matrix();
			int w = bmp.getWidth();
			int h = bmp.getHeight();
			int px = mDrawRect.left;
			int py = mDrawRect.top;

			Calendar calendar = Calendar.getInstance();
			int hour = calendar.get(Calendar.HOUR);
			int minute = calendar.get(Calendar.MINUTE);
			float time = ((float) hour) + (((float) minute) / 60f);
			float degrees = time * 360f / 12f;

			m.postTranslate(mDrawRect.left - w / 2, mDrawRect.top - h / 2);
			m.postRotate(degrees, px, py);

			c.drawBitmap(bmp, m, p);

		} else if (FunctionId != null && FunctionId.equals("clock_minutehand")) {
			Matrix m = new Matrix();
			int w = bmp.getWidth();
			int h = bmp.getHeight();
			int px = mDrawRect.left;
			int py = mDrawRect.top;

			Calendar calendar = Calendar.getInstance();

			int minute = calendar.get(Calendar.MINUTE);

			float degrees = ((float) minute) * 360f / 60f;

			m.postTranslate(mDrawRect.left - w / 2, mDrawRect.top - h / 2);
			m.postRotate(degrees, px, py);

			c.drawBitmap(bmp, m, p);
		} else {
			c.drawBitmap(bmp, mDrawRect.left, mDrawRect.top, p);
		}

	}

	private String getFn(int ycode) {

		String[] fns = new String[] { "_06.png", "_10.png", "_10.png", "_10.png", "_10.png", "_13.png", "_14.png", "_14.png", "_14.png", "_08.png", "_14.png", "_08.png", "_09.png", "_11.png",
				"_11.png", "_11.png", "_12.png", "_14.png", "_14.png", "_06.png", "_05.png", "_06.png", "_06.png", "_06.png", "_06.png", "_04.png", "_04.png", "_16.png", "_03.png", "_16.png",
				"_02.png", "_15.png", "_01.png", "_15.png", "_01.png", "_14.png", "_01.png", "_10.png", "_10.png", "_07.png", "_07.png", "_12.png", "_11.png", "_12.png", "_02.png", "_10.png",
				"_11.png", "_10.png", "_17.png", "_17.png", };

		return fns[ycode];
	}

	@Override
	void setWeatherInfo(WeatherInfo wi) {
		mFileName = null;
		if (Src != null) {
			mFileName = Src;
		} else if (FunctionId != null) {

			int offsetDay = 0;
			int daySign = 1;
			if (OffsetTime != null) {
				if (OffsetTime.startsWith("-")) {
					daySign = -1;
					OffsetTime = OffsetTime.substring(1);
				} else if (OffsetTime.startsWith("+")) {
					daySign = 1;
					OffsetTime = OffsetTime.substring(1);
				} else {
					daySign = 1;
					OffsetTime = OffsetTime.substring(0);
				}
				if (OffsetTime.endsWith("d")) {
					offsetDay = daySign * Integer.parseInt(OffsetTime.substring(0, OffsetTime.length() - 1));
				}
			}

			String fnWithoutPrefix = null;

			ForeCast careForecast = null;
// int[] realForecastIdxes = null;
			ForeCast[] fcs = wi.getForecastsForCurrent(5);
// realForecastIdxes = wi.getRealForcastIdxs(System.currentTimeMillis());
// fcs = wi.getForecasts();

			if (offsetDay < fcs.length) {
				careForecast = fcs[offsetDay];
			}

			int ycode = WeatherInfo.INVALID_YCODE;
			if (FunctionId.equals("c_weather_icon")) {
				ycode = wi.getYCodeUsingSunRiseAndSet();
				fnWithoutPrefix = getFn(ycode);
			} else if (FunctionId.equals("day_weather_icon")) {
				if (careForecast != ForeCast.EMPTY) {
					ycode = careForecast.getYcode();
				}
				fnWithoutPrefix = getFn(ycode);
			} else if (FunctionId.equals("night_weather_icon")) {
				if (careForecast != ForeCast.EMPTY) {
					ycode = careForecast.getYcode();
				}
				fnWithoutPrefix = getFn(ycode);
			}

			careForecast = null;

			if (fnWithoutPrefix != null) {
				setFileName(fnWithoutPrefix, "wi", wi);
				return;
			}

			if (FunctionId.equals("clock_ampm")) {
				Calendar c = Calendar.getInstance();

				int ampm = c.get(Calendar.AM_PM);
				if (ampm == Calendar.AM) {
					fnWithoutPrefix = "_am.png";
				} else {
					fnWithoutPrefix = "_pm.png";
				}

			} else if (FunctionId.equals("clock_hourhand")) {
				fnWithoutPrefix = "_hourhand.png";
			} else if (FunctionId.equals("clock_minutehand")) {
				fnWithoutPrefix = "_minutehand.png";
			}

			if (fnWithoutPrefix != null) {
				setFileName(fnWithoutPrefix, "clock", wi);
				return;
			}

			Calendar c = Calendar.getInstance();
			int hour = -1;
			int h12 = -1;
			int h24 = -1;
			if (DateFormat.is24HourFormat(TianQiTongAppWidgetSkinManager.getInstance(null)._wrService.get())) {
				hour = c.get(Calendar.HOUR_OF_DAY);
				h24 = hour;
			} else {
				hour = c.get(Calendar.HOUR);
				if (hour == 0) {
					hour = 12;
				}
				h12 = hour;
			}
			int minute = c.get(Calendar.MINUTE);

			String strNum = null;
			if (FunctionId.equals("clock_h")) {
				strNum = AppWidgetSkinUtility.num(hour);
			} else if (FunctionId.equals("clock_h24")) {
				strNum = AppWidgetSkinUtility.num(h24);
			} else if (FunctionId.equals("clock_h12")) {
				strNum = AppWidgetSkinUtility.num(h12);
			} else if (FunctionId.equals("clock_m")) {
				strNum = AppWidgetSkinUtility.num(minute);
			} else if (FunctionId.equals("clock_hd")) {
				strNum = (hour / 10) + "";
			} else if (FunctionId.equals("clock_h24d")) {
				strNum = (h24 / 10) + "";
			} else if (FunctionId.equals("clock_h12d")) {
				strNum = (h12 / 10) + "";
			} else if (FunctionId.equals("clock_hu")) {
				strNum = (hour % 10) + "";
			} else if (FunctionId.equals("clock_h24u")) {
				strNum = (h24 % 10) + "";
			} else if (FunctionId.equals("clock_h12u")) {
				strNum = (h12 % 10) + "";
			} else if (FunctionId.equals("clock_md")) {
				strNum = (minute / 10) + "";
			} else if (FunctionId.equals("clock_mu")) {
				strNum = (minute % 10) + "";
			}

			if (strNum != null) {
				fnWithoutPrefix = "_" + strNum + ".png";

				if (fnWithoutPrefix != null) {
					setFileName(fnWithoutPrefix, "clock", wi);
					return;
				}
			} else {
				mFileName = null;
			}

		}

	}

	private void setFileName(String fnWithoutPrefix, String defaultPrefix, WeatherInfo wi) {
		try {

			mFileName = null;

			if (FunctionId != null && FunctionId.equals("c_weather_icon")) {
				if (NightCWIPrefix != null) {
					if (!wi.isDay()) {
						mFileName = NightCWIPrefix + fnWithoutPrefix;
						if ((!mAws.checkImage(mFileName))) {
							mFileName = null;
						}
					}
				}
			}

			if (mFileName == null) {
				if (Prefix != null) {
					mFileName = Prefix + fnWithoutPrefix;
					if ((!mAws.checkImage(mFileName))) {
						mFileName = null;
					}
				}
			}

			if (mFileName == null) {
				mFileName = defaultPrefix + fnWithoutPrefix;
				if ((!mAws.checkImage(mFileName))) {
					mFileName = null;
				}
			}

		} catch (FileNotFoundException e) {
			mFileName = null;
			e.printStackTrace();
		} catch (IOException e) {
			mFileName = null;
			e.printStackTrace();
		}
	}

	@Override
	boolean isClockUnit() {
		return FunctionId != null && FunctionId.contains("clock");
	}
}
