package sina.mobile.tianqitong.main;

import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_4x1WIDGET;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_4x2WIDGET;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidget.Widget4x1Provider;
import sina.mobile.tianqitong.appwidget.WidgetProvider;
import sina.mobile.tianqitong.appwidgetskinpkg.TianQiTongAppWidgetSkinManager;
import sina.mobile.tianqitong.diyappwidget.AppWidgetDiyTool;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager;
import sina.mobile.tianqitong.service.AppWidgetSkinManager;
import sina.mobile.tianqitong.service.TianQiTongDownloadManger;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.AppWidgetSkin;
import sina.mobile.tianqitong.service.model.DownloadItem;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.Utility;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class PlugInActivity extends BaseListActivity implements ServiceConnection, Callback {
	private List<AppWidgetSkin> mListData4x1 = new ArrayList<AppWidgetSkin>();
	private List<AppWidgetSkin> mListData4x2 = new ArrayList<AppWidgetSkin>();
	private AppWidgetSkinManager mAppWidgetSkinManager;
	private HashMap<String, HolderView> holderViewHashMap = new HashMap<String, HolderView>();
	private RadioButton check4x1 = null;
	private RadioButton check4x2 = null;
	private ButtonChecked mButtonChecked = null;

	private ButtonTypeDownListener mButtonTypeDownListener = null;
	private ButtonCheckedUseristener mButtonCheckedListener = null;
	private ButtonCancelListener mButtonCancelListener = null;
	private ButtonTypeDeleteListener mButtonTypeDeleteListener = null;
	private PlugDefaultSettingListener mPlugDefaultSettingListener = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		View turnView = LayoutInflater.from(this).inflate(R.layout.listviewofdesk_plugin_turn, null);
		LinearLayout mRootLinearLayout = (LinearLayout) findViewById(R.id.root_ll);
		mRootLinearLayout.addView(turnView, 0);

		DiyAppWidgetAttrUtil.initDefaultValues(this);
		DiyableAppWidgetPreviewManager.init(this, null, null, FileGettable.CURRENT);

		// default-35359539
		// 获取的插件的keyName
		mWhich4X2Using = SPUtility.getSPString(this, R.string.appwidget_key_name_4X2);
		mWhich4X1Using = SPUtility.getSPString(this, R.string.appwidget_key_name_4X1);

		getApplicationContext().bindService(new Intent(this, TianQiTongService.class), this, BIND_AUTO_CREATE);

		mButtonTypeDownListener = new ButtonTypeDownListener();
		mButtonTypeDeleteListener = new ButtonTypeDeleteListener();
		mButtonCancelListener = new ButtonCancelListener();
		mButtonCheckedListener = new ButtonCheckedUseristener();
		mPlugDefaultSettingListener = new PlugDefaultSettingListener();

		listView.setCacheColorHint(0);

		check4x1 = (RadioButton) findViewById(R.id.check_button_4_1);
		check4x2 = (RadioButton) findViewById(R.id.check_button_4_2);
		mButtonChecked = new ButtonChecked();
		check4x1.setOnCheckedChangeListener(mButtonChecked);
		check4x2.setOnCheckedChangeListener(mButtonChecked);

		findViewById(R.id.add_button).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(PlugInActivity.this, ResManagerHelp.class));

			}
		});

	}

	private String mWhich4X2Using;
	private String mWhich4X1Using;

	private void orderListData(List<AppWidgetSkin> lists, byte type) {
		ArrayList<AppWidgetSkin> hasdownListData = new ArrayList<AppWidgetSkin>();
		ArrayList<AppWidgetSkin> notdownListData = new ArrayList<AppWidgetSkin>();
		ArrayList<AppWidgetSkin> defaultListData = new ArrayList<AppWidgetSkin>();

		for (AppWidgetSkin aws : lists) {
			if (aws == null) {
				// TODO 其实根本不应该到这里的。
				continue;
			}

			switch (aws.getId()) {
			case AppWidgetSkin.ID_DEFAULT_1st4x1:
			case AppWidgetSkin.ID_DEFAULT_1st4x2:
			case AppWidgetSkin.ID_DEFAULT_2nd4x2: {

				defaultListData.add(aws);
			}
				break;
			default: {
				if (aws.getSkinPkgFile() == null) {
					notdownListData.add(aws);
				} else {

					hasdownListData.add(aws);
				}
			}
			}

		}

		lists.clear();
		lists.addAll(defaultListData);
		lists.addAll(hasdownListData);
		if (type == AppWidgetSkin.TYPE_4X2) {
			indexOfDivideCenter = lists.size() - 1;// 记录去线的位置

		}
		lists.add(null);
		lists.addAll(notdownListData);
		if (type == AppWidgetSkin.TYPE_4X2) {
			indexOfDivideBottom = lists.size() - 1;// 记录去线的位置
		}

		if (check4x1.isChecked()) {
			mMyBaseAdapter.setListData(mListData4x1);
		} else if (check4x2.isChecked()) {
			mMyBaseAdapter.setListData(mListData4x2);
		}
	}

	private HashMap<String, AppWidgetSkin> _4x2urlKeyHashMap = new HashMap<String, AppWidgetSkin>();
	private HashMap<String, AppWidgetSkin> _4x1urlKeyHashMap = new HashMap<String, AppWidgetSkin>();

	private int indexOfDivideCenter = 0;
	private int indexOfDivideBottom = 0;

	private void buildData(byte type) {
		if (mAppWidgetSkinManager == null) {
			return;
		}
		AppWidgetSkin[] aws = null;
		List<AppWidgetSkin> listData = null;
		HashMap<String, AppWidgetSkin> urlKeyHashMap = null;
		switch (type) {
		case AppWidgetSkin.TYPE_4X2: {
			aws = mAppWidgetSkinManager.get4x2AppWidgetSkins();

			Arrays.sort(aws, new java.util.Comparator<AppWidgetSkin>() {
				@Override
				public int compare(AppWidgetSkin o1, AppWidgetSkin o2) {
					if (o1.getId() == AppWidgetSkin.ID_DEFAULT_1st4x2) {
						if (o2.getId() == AppWidgetSkin.ID_DEFAULT_2nd4x2) {
							return -1;
						} else {
							return -1;
						}
					} else {
						if (o2.getId() == AppWidgetSkin.ID_DEFAULT_2nd4x2) {
							return 1;
						} else {
							return 0;
						}
					}
				}

			});
			listData = mListData4x2;
			urlKeyHashMap = _4x2urlKeyHashMap;

			{
				boolean is1st4x2using = mWhich4X2Using.equals(AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME);
				boolean is2nd4x2using = mWhich4X2Using.equals(AppWidgetSkin.DEFAULT_2ND4X2_KEYNAME);
				if (is1st4x2using || is2nd4x2using) {

				} else {
					boolean currentOk = false;
					if (Utility.sdAvailiable()) {
						String pkgName = mWhich4X2Using + ".zip";
						String path = mAppWidgetSkinManager.get4x2DataManager().getSDDir();
						if (path != null) {
							File f = new File(path, pkgName);
							if (f.exists() && f.isFile()) {
								currentOk = true;
							}
						}
					}
					if (!currentOk) {
						mWhich4X2Using = AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME;
						SPUtility.putSPInteger(PlugInActivity.this, R.string.strint_which_default_4x2, AWType._1ST_4X2.getId());
						SPUtility.putSPString(PlugInActivity.this, R.string.appwidget_key_name_4X2, AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME);
						Intent i = new Intent(ACTION_START_SERVICE_UPDATE_4x1WIDGET);
						startService(i);
					}
				}
			}
		}
			break;
		case AppWidgetSkin.TYPE_4X1: {

			aws = mAppWidgetSkinManager.get4x1AppWidgetSkins();
			Arrays.sort(aws, new Comparator<AppWidgetSkin>() {
				@Override
				public int compare(AppWidgetSkin o1, AppWidgetSkin o2) {
					if (o1.getId() == AppWidgetSkin.ID_DEFAULT_1st4x1) {
						return -1;
					} else {
						return 0;
					}
				}

			});

			listData = mListData4x1;
			urlKeyHashMap = _4x1urlKeyHashMap;

			{
				boolean is1st4x1using = mWhich4X1Using.equals(AppWidgetSkin.DEFAULT_1ST4X1_KEYNAME);
				if (is1st4x1using) {

				} else {
					boolean currentOk = false;
					if (Utility.sdAvailiable()) {
						String pkgName = mWhich4X1Using + ".zip";
						String path = mAppWidgetSkinManager.get4x1DataManager().getSDDir();
						if (path != null) {
							File f = new File(path, pkgName);
							if (f.exists() && f.isFile()) {
								currentOk = true;
							}
						}
					}
					if (!currentOk) {
						mWhich4X1Using = AppWidgetSkin.DEFAULT_1ST4X1_KEYNAME;
						SPUtility.putSPString(PlugInActivity.this, R.string.appwidget_key_name_4X1, AppWidgetSkin.DEFAULT_1ST4X1_KEYNAME);
						Intent i = new Intent(ACTION_START_SERVICE_UPDATE_4x1WIDGET);
						startService(i);
					}
				}
			}

		}
			break;
		}

		listData.clear();

		for (int i = 0; i < aws.length; i++) {

			listData.add(aws[i]);

			if (aws[i].getSkinPkgHttpUrl() != null) {
				urlKeyHashMap.put(aws[i].getSkinPkgHttpUrl(), aws[i]);
			}
		}
		orderListData(listData, type);

		mMyBaseAdapter.notifyDataSetInvalidated();

	}

	@Override
	public void buildData() {
		buildData(AppWidgetSkin.TYPE_4X2);
		buildData(AppWidgetSkin.TYPE_4X1);
	}

	private class HolderView {
		ImageView dividerHorizontal;
		BgProgressBar mBgProgressBar;
		ImageView plugSculpture;
		ImageView plugUsing;
		TextView plugName;
		TextView fileSize;
		TextView authorName;
		ImageView stars;
		ImageView plugDown;
		LinearLayout plugDownDes;
		TextView plugProgressText;
		ImageView plugCancel;
		RadioButton plugUseRadio;
		ImageView plugDelete;
		ImageView plugDefaultSetting;

		public View initView(View convertView, int position, List<AppWidgetSkin> mListData) {

			dividerHorizontal = (ImageView) convertView.findViewById(R.id.divider_horizontal);
			mBgProgressBar = (BgProgressBar) convertView.findViewById(R.id.myProgressBar);

			plugSculpture = (ImageView) convertView.findViewById(R.id.plug_sculpture);
			plugUsing = (ImageView) convertView.findViewById(R.id.plug_using);
			plugName = (TextView) convertView.findViewById(R.id.plug_name);

			fileSize = (TextView) convertView.findViewById(R.id.file_size);

			authorName = (TextView) convertView.findViewById(R.id.author_name);
			stars = (ImageView) convertView.findViewById(R.id.stars);

			plugDown = (ImageView) convertView.findViewById(R.id.plug_down);
			plugDownDes = (LinearLayout) convertView.findViewById(R.id.plug_down_des);
			plugProgressText = (TextView) convertView.findViewById(R.id.plug_progress_text);
			plugDown = (ImageView) convertView.findViewById(R.id.plug_down);
			plugCancel = (ImageView) convertView.findViewById(R.id.plug_cancel);
			plugUseRadio = (RadioButton) convertView.findViewById(R.id.plug_use_radio);
			plugDelete = (ImageView) convertView.findViewById(R.id.plug_delete);
			plugDefaultSetting = (ImageView) convertView.findViewById(R.id.plug_default_setting);

			AppWidgetSkin aws = mListData.get(position);
			authorName.setText(aws.getAuthor());
			stars.setImageBitmap(getStartsBitmap(aws.getStarCount()));
			if (aws.getFileSizeKb() != -1)
				fileSize.setText(aws.getFileSizeKb() + "k");
			plugName.setText(aws.getName());

			holderViewHashMap.put(aws.getKey(), this);

			aws.setIcon(plugSculpture);

			// 只有自定义的才可以插进设置
			if (aws.isDefaultAppWidget()) {
				plugDefaultSetting.setVisibility(View.VISIBLE);
			} else {
				plugDefaultSetting.setVisibility(View.INVISIBLE);
			}

			boolean is4x2 = aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X2;
			boolean is4x1 = aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X1;
			boolean is4x2using = is4x2 && mWhich4X2Using.equals(aws.getKey());
			boolean is4x1using = is4x1 && mWhich4X1Using.equals(aws.getKey());
			if (is4x1using || is4x2using) {
				plugUseRadio.setChecked(true);
				plugUsing.setVisibility(View.VISIBLE);
			} else {
				plugUseRadio.setChecked(false);
				plugUsing.setVisibility(View.INVISIBLE);
			}

			if (tdl.isInDownloadItems(aws.getSkinPkgHttpUrl()) != -1) {
				plugDown.setVisibility(View.GONE);
				plugDownDes.setVisibility(View.VISIBLE);
				mBgProgressBar.setVisibility(View.VISIBLE);
				plugProgressText.setText(tdl.isInDownloadItems(aws.getSkinPkgHttpUrl()) + "%");

			} else {
				plugDownDes.setVisibility(View.GONE);
				mBgProgressBar.setVisibility(View.GONE);
				if ((!aws.isDefaultAppWidget()) && aws.getSkinPkgFile() == null) {
					plugDown.setVisibility(View.VISIBLE);
				} else {
					plugDown.setVisibility(View.INVISIBLE);
				}
			}

//			if (aws.isMainUrlDownloading()) {
//				plugProgressText.setText(progress + "%");
//			} else {
//				plugProgressText.setText(0 + "%");
//			}

			if (aws.isDefaultAppWidget() || aws.getSkinPkgFile() != null) {
				plugUseRadio.setVisibility(View.VISIBLE);

			} else {
				plugUseRadio.setVisibility(View.INVISIBLE);

			}

			if ((!aws.isDefaultAppWidget()) && aws.getSkinPkgFile() != null) {
				plugDelete.setVisibility(View.VISIBLE);
			} else {
				plugDelete.setVisibility(View.INVISIBLE);
			}
			if (aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X2) {
				if (position == indexOfDivideCenter || position == indexOfDivideBottom) {

					dividerHorizontal.setVisibility(View.INVISIBLE);
				} else {
					dividerHorizontal.setVisibility(View.VISIBLE);
				}
			}
			plugDown.setTag(aws);
			plugDown.setOnClickListener(mButtonTypeDownListener);

			plugUseRadio.setTag(aws);
			plugUseRadio.setOnCheckedChangeListener(mButtonCheckedListener);

			plugCancel.setTag(aws);
			plugCancel.setOnClickListener(mButtonCancelListener);

			plugDelete.setTag(aws);
			plugDelete.setOnClickListener(mButtonTypeDeleteListener);
			plugDefaultSetting.setTag(aws);
			plugDefaultSetting.setOnClickListener(mPlugDefaultSettingListener);
			return convertView;
		}
	}

	// private HashSet<String> downUrl = new HashSet();

	/**
	 * 下载语言包的监听
	 * 
	 * @author zhangxi
	 * 
	 */
	private class ButtonTypeDownListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			if (!Utility.sdAvailiable()) {
				Toast.makeText(PlugInActivity.this, "找不到sd卡", Toast.LENGTH_LONG).show();
				return;
			}

			if (Utility.isAirplaneModeOn(getApplicationContext())) {
// Toast.makeText(PlugInActivity.this, "飞行模式中，请联网后再试！", Toast.LENGTH_LONG).show();
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_AIR_MODE, PlugInActivity.this);
				dg.show();
				return;
			}

			if (!Utility.getAvailableNetWork(getApplicationContext())) {
// Toast.makeText(PlugInActivity.this, "无可用网络，请稍后再试！", Toast.LENGTH_LONG).show();
				Dialog dg = Utility.buildNetWorkDialog(Utility.DIALOG_TYPE_NET_WORK_DOWN, PlugInActivity.this);
				dg.show();
				return;
			}

			AppWidgetSkin downLoadAppWidgetSkin = (AppWidgetSkin) v.getTag();
			downLoadAppWidgetSkin.downloadMainUrl(false);
			v.setVisibility(View.GONE);
			holderViewHashMap.get(downLoadAppWidgetSkin.getKey()).plugProgressText.setText("0%");
			holderViewHashMap.get(downLoadAppWidgetSkin.getKey()).plugDownDes.setVisibility(View.VISIBLE);
			holderViewHashMap.get(downLoadAppWidgetSkin.getKey()).mBgProgressBar.setVisibility(View.VISIBLE);

		}
	}

	private AppWidgetSkin deleteAppWidgetSkin = null;

	public static final int TIANQITONG_DIALOG_DELETE = 2;

	@Override
	public Dialog onCreateDialog(int id) {
		AlertDialog.Builder b = null;
		switch (id) {

		case TIANQITONG_DIALOG_DELETE: {
			b = new AlertDialog.Builder(this);
			b.setTitle("删除提示");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage("确定要删除吗？");
			b.setPositiveButton("确定", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {

					// 删除当前正在使用的插件皮肤，回复的默认

					boolean is4x2 = deleteAppWidgetSkin.getAppWidgetType() == AppWidgetSkin.TYPE_4X2;
					boolean is4x1 = deleteAppWidgetSkin.getAppWidgetType() == AppWidgetSkin.TYPE_4X1;
					int currentkey = is4x2 ? R.string.appwidget_key_name_4X2 : (is4x1 ? R.string.appwidget_key_name_4X1 : 0);
					String currentUsingKey = SPUtility.getSPString(PlugInActivity.this, currentkey);
					boolean deleteUsing = currentUsingKey.equals(deleteAppWidgetSkin.getKey());
					if (deleteUsing) {
						SPUtility.putSPString(PlugInActivity.this, currentkey, AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME);

						if (is4x2) {
							mWhich4X2Using = AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME;
						} else if (is4x1) {
							mWhich4X1Using = AppWidgetSkin.DEFAULT_1ST4X1_KEYNAME;
						}

					}

					mAppWidgetSkinManager.delAppWidgetSkin(deleteAppWidgetSkin);
					deleteAppWidgetSkin = null;
					// 刷新ui lyang
// buildData();

				}
			});
			b.setNegativeButton("取消", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(TIANQITONG_DIALOG_DELETE);
				}
			});

		}
			break;

		case DIALOG_ID_NO4x2WIDGET:
		case DIALOG_ID_NO4x1WIDGET: {
			String size = "4x2";
			String space = "1/2";

			if (id == DIALOG_ID_NO4x1WIDGET) {
				size = "4x1";
				space = "1/4";
			}
			StringBuilder sb = new StringBuilder();
			sb.append("您当前还没有添加");
			sb.append(size);
			sb.append("天气桌面插件，需要手动添加。\n两种方法添加：1.返回手机桌面->空白处长摁2秒以上->菜单中 选择添加小部件(Moto)或者小插件(HTC)->列表中点选");
			sb.append(size);
			sb.append("天气通(如果提示没有足够空间，请在其他桌面空余处放置， 需要预留");
			sb.append(space);
			sb.append("空闲屏幕)；\n2.手机桌面->菜单键->添加小部件；手机桌面->菜单键->个性化设置->小插件。注：天气桌面丢失，请卸载后，重新安装天气通到手机内存而非SD卡 -详情见菜单->更多->天气通常见问题");

			b = new AlertDialog.Builder(this);
			b.setTitle("添加插件提示");
			b.setIcon(getResources().getDrawable(R.drawable.dialog_icon));
			b.setMessage(sb.toString());
			b.setPositiveButton(R.string.ok, null);

		}

		}
		if (b != null) {
			return b.create();
		}
		return null;
	}

	private class ButtonTypeDeleteListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			deleteAppWidgetSkin = (AppWidgetSkin) v.getTag();
			showDialog(TIANQITONG_DIALOG_DELETE);
		}
	}

	private class ButtonCheckedUseristener implements OnCheckedChangeListener {

		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			if (isChecked) {
				AppWidgetSkin aws = (AppWidgetSkin) buttonView.getTag();

				if (aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X2) {
					mWhich4X2Using = aws.getKey();
					if (aws.getId() == AppWidgetSkin.ID_DEFAULT_1st4x2) {
						SPUtility.putSPInteger(PlugInActivity.this, R.string.strint_which_default_4x2, AWType._1ST_4X2.getId());
					} else if (aws.getId() == AppWidgetSkin.ID_DEFAULT_2nd4x2) {
						SPUtility.putSPInteger(PlugInActivity.this, R.string.strint_which_default_4x2, AWType._2ND_4X2.getId());
					}

					SPUtility.putSPString(PlugInActivity.this, R.string.appwidget_key_name_4X2, aws.getKey());
					Intent i = new Intent(ACTION_START_SERVICE_UPDATE_4x2WIDGET);
					startService(i);
				} else if (aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X1) {
					mWhich4X1Using = aws.getKey();

					SPUtility.putSPString(PlugInActivity.this, R.string.appwidget_key_name_4X1, aws.getKey());
					Intent i = new Intent(ACTION_START_SERVICE_UPDATE_4x1WIDGET);
					startService(i);
				}
				mMyBaseAdapter.notifyDataSetChanged();
			}
		}
	}

	private class ButtonCancelListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			AppWidgetSkin aws = (AppWidgetSkin) v.getTag();
			aws.cancelDownloadingMainUrl();
			if (holderViewHashMap.get(aws.getKey()) != null) {
				holderViewHashMap.get(aws.getKey()).plugProgressText.setText("0%");
				holderViewHashMap.get(aws.getKey()).plugDownDes.setVisibility(View.GONE);
				holderViewHashMap.get(aws.getKey()).mBgProgressBar.setVisibility(View.GONE);
			}

			progress = 0;
			mMyBaseAdapter.notifyDataSetChanged();
		}
	}

// Override
// public boolean onKeyDown(int keyCode, KeyEvent event) {
//
// if (keyCode == KeyEvent.KEYCODE_BACK) {
// // downUrl.clear();
// return true;
// }
//
// return super.onKeyDown(keyCode, event);
// }

	private class PlugDefaultSettingListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			int typeId = 0;
			AppWidgetSkin aws = (AppWidgetSkin) v.getTag();
			if (aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X2) {

				/*
				 * if (!have4x2Widget()) { showDialog(DIALOG_ID_NO4x2WIDGET); return; } else
				 */{

					if (aws.getKey().equals(AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME)) {
						typeId = AWIDX_1ST4X2;
						DiyableAppWidgetPreviewManager.layoutDiyableUnits(AWType._1ST_4X2);
					} else if (aws.getKey().equals(AppWidgetSkin.DEFAULT_2ND4X2_KEYNAME)) {
						typeId = AWIDX_2ND4X2;
						DiyableAppWidgetPreviewManager.layoutDiyableUnits(AWType._2ND_4X2);
					}

				}
			} else if (aws.getAppWidgetType() == AppWidgetSkin.TYPE_4X1) {

				/*
				 * if (!have4x1Widget()) { showDialog(DIALOG_ID_NO4x1WIDGET); return; } else
				 */{
					typeId = AWIDX_1ST4X1;
					DiyableAppWidgetPreviewManager.layoutDiyableUnits(AWType._1ST_4X1);
				}
			}
			Intent intent = new Intent(PlugInActivity.this, AppWidgetDiyTool.class);
			intent.putExtra("type", typeId);
			startActivityForResult(intent, 0);

		}
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (resultCode) {
		case Activity.RESULT_OK:
			Bundle b = data.getExtras();
			int type = b.getInt("type");

			if (type == AWType._1ST_4X2.getId()) {
				SPUtility.putSPString(PlugInActivity.this, R.string.appwidget_key_name_4X2, AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME);

				mWhich4X2Using = AppWidgetSkin.DEFAULT_1ST4X2_KEYNAME;

			} else if (type == AWType._2ND_4X2.getId()) {
				SPUtility.putSPString(PlugInActivity.this, R.string.appwidget_key_name_4X2, AppWidgetSkin.DEFAULT_2ND4X2_KEYNAME);

				mWhich4X2Using = AppWidgetSkin.DEFAULT_2ND4X2_KEYNAME;

			} else if (type == AWType._1ST_4X1.getId()) {
				mWhich4X1Using = AppWidgetSkin.DEFAULT_1ST4X1_KEYNAME;
			}
			break;

		}
		mMyBaseAdapter.notifyDataSetChanged();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		TianQiTongAppWidgetSkinManager.clearBitmapCache();

	}

	private class ButtonChecked implements OnCheckedChangeListener {

		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			int id = buttonView.getId();

			if (isChecked) {
				switch (id) {
				case R.id.check_button_4_1: {
					mMyBaseAdapter.setListData(mListData4x1);
					mMyBaseAdapter.notifyDataSetChanged();
					check4x2.setChecked(false);
				}
					break;
				case R.id.check_button_4_2: {
					mMyBaseAdapter.setListData(mListData4x2);
					mMyBaseAdapter.notifyDataSetChanged();
					check4x1.setChecked(false);
				}
					break;
				}
			}
		}

	}

// /////////////////////一下的方法是从 AppWidgetPreview 移过来的///////////////////

	public void onStart() {
		super.onStart();
		DiyableAppWidgetPreviewManager.setCurAWType(null);

	}

	private static int AWIDX_1ST4X2 = 0;
	private static int AWIDX_1ST4X1 = 1;
	private static int AWIDX_2ND4X2 = 2;

	private static final int DIALOG_ID_NO4x2WIDGET = 0;
	private static final int DIALOG_ID_NO4x1WIDGET = 1;

	private boolean have4x2Widget() {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
		int[] _4x2_ids = appWidgetManager.getAppWidgetIds(new ComponentName(this, WidgetProvider.class));
		if (_4x2_ids.length == 0) {
			return false;
		} else {
			return true;
		}
	}

	private boolean have4x1Widget() {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
		int[] _4x1_ids = appWidgetManager.getAppWidgetIds(new ComponentName(this, Widget4x1Provider.class));
		if (_4x1_ids.length == 0) {
			return false;
		} else {
			return true;
		}
	}

	TianQiTongDownloadManger tdl = null;

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		TianQiTongService lservice = ((TianQiTongService.TianQiTongBinder) service).getService();
		mAppWidgetSkinManager = lservice.getAppWidgetSkinManager();
		Handler handler = new Handler(this);
		mAppWidgetSkinManager.get4x2DataManager().setDataManagerListener(handler);
		mAppWidgetSkinManager.get4x2DataManager().refresh(null);
		mAppWidgetSkinManager.get4x1DataManager().setDataManagerListener(handler);
		mAppWidgetSkinManager.get4x1DataManager().refresh(null);
		buildData();
		tdl = TianQiTongDownloadManger.getInstance(null);

	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		// TODO Auto-generated method stub

	}

	@Override
	protected View constructConvertView(View convertView, LayoutInflater mInflater, int position, List<?> mListData) {
		convertView = mInflater.inflate(R.layout.listviewofdesk_plugin_item, null);
		HolderView hv = new HolderView();
		hv.initView(convertView, position, (List<AppWidgetSkin>) mListData);
		return convertView;
	}

	@Override
	protected String getHeadText() {
		return null;
	}

	@Override
	protected String getCenterText() {
		return null;
	}

	@Override
	public void onMainDownloadDone(String url) {
		AppWidgetSkin s = _4x2urlKeyHashMap.get(url);
		if (s != null) {
			orderListData(mListData4x2, AppWidgetSkin.TYPE_4X2);
		}
		s = _4x1urlKeyHashMap.get(url);
		if (s != null) {
			orderListData(mListData4x1, AppWidgetSkin.TYPE_4X1);
		}
	}

	// 为了解决在上下滑动的时候数字变为0的问题
	int progress = 0;

	@Override
	public void onMainDownloadProgressUpdated(String url, int progress) {
		this.progress = progress;
		AppWidgetSkin s = _4x2urlKeyHashMap.get(url);
		if (s != null) {
			String currlyDownKeyName = s.getKey();
			if (holderViewHashMap.get(currlyDownKeyName) != null) {
				holderViewHashMap.get(currlyDownKeyName).plugDownDes.setVisibility(View.VISIBLE);
				holderViewHashMap.get(currlyDownKeyName).mBgProgressBar.setVisibility(View.VISIBLE);
				holderViewHashMap.get(currlyDownKeyName).plugProgressText.setVisibility(View.VISIBLE);

				holderViewHashMap.get(currlyDownKeyName).mBgProgressBar.setProgress(progress);
				holderViewHashMap.get(currlyDownKeyName).plugProgressText.setText(progress + "%");
			}
		}
		s = _4x1urlKeyHashMap.get(url);
		if (s != null) {
			String currlyDownKeyName = s.getKey();
			if (holderViewHashMap.get(currlyDownKeyName) != null) {
				holderViewHashMap.get(currlyDownKeyName).plugDownDes.setVisibility(View.VISIBLE);
				holderViewHashMap.get(currlyDownKeyName).mBgProgressBar.setVisibility(View.VISIBLE);
				holderViewHashMap.get(currlyDownKeyName).plugProgressText.setVisibility(View.VISIBLE);

				holderViewHashMap.get(currlyDownKeyName).mBgProgressBar.setProgress(progress);
				holderViewHashMap.get(currlyDownKeyName).plugProgressText.setText(progress + "%");

			}
		}

	}

}
