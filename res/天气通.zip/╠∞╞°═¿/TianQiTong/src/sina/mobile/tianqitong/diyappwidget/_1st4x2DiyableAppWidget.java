package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getClockNumbers;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;

import java.util.EnumMap;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.ButtonFunction;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyButton;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyText;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;

public class _1st4x2DiyableAppWidget extends AbstractDiyableAppWidget {

	_1st4x2DiyableAppWidget() {
		super((int) (320f * getDensity()), (int) (240f * getDensity()), AWType._1ST_4X2);
	}

	@Override
	protected void doDraw(Canvas canvas, AbstractDiyableUnit[] diyableUnits) {

		Resources res = getActivity().getResources();
		int width = getWidthPixels();
		float density = getDensity();

		{
			diyableUnits[IDX_WIDGET_BG].drawOnCanvas(canvas);
		}

		int yTimeBg = (int) (20d * density);
		int timebgw;
		int timebgh;
		{
			Bitmap timebg = getBitmap(res, R.drawable.widget_time_bg);// BitmapFactory.decodeResource(res, R.drawable.widget_time_bg);
			Matrix m = new Matrix();
			int dx = width / 2 - timebg.getWidth();
			int dy = yTimeBg;
			m.postTranslate(dx, dy);
			canvas.drawBitmap(timebg, m, null);
			m = new Matrix();
			m.postTranslate(width / 2, yTimeBg);
			canvas.drawBitmap(timebg, m, null);
			timebgw = timebg.getWidth();
			timebgh = timebg.getHeight();

			timebg = null;
		}
		int yOfNumbers;
		int[] clockNumbers = getClockNumbers();
		int[] _numberDrawableIds = new int[] { R.drawable.clock_0, R.drawable.clock_1, R.drawable.clock_2, R.drawable.clock_3, R.drawable.clock_4, R.drawable.clock_5, R.drawable.clock_6,
				R.drawable.clock_7, R.drawable.clock_8, R.drawable.clock_9, };
		{
			Bitmap chd = getBitmap(res, _numberDrawableIds[clockNumbers[0]]);// BitmapFactory.decodeResource(res, _numberDrawableIds[clockNumbers[0]]);
			yOfNumbers = yTimeBg + timebgh / 2 - chd.getHeight() / 2 - (int) (5.5 * density);
			Matrix m = new Matrix();
			m.postTranslate(width / 2 - timebgw / 2 - chd.getWidth(), yOfNumbers);
			canvas.drawBitmap(chd, m, null);
			chd = null;
		}
		{
			Bitmap chu = getBitmap(res, _numberDrawableIds[clockNumbers[1]]);// BitmapFactory.decodeResource(res, _numberDrawableIds[clockNumbers[1]]);
			Matrix m = new Matrix();
			m.postTranslate(width / 2 - timebgw / 2, yOfNumbers);
			canvas.drawBitmap(chu, m, null);
			chu = null;
		}
		{
			Bitmap cmd = getBitmap(res, _numberDrawableIds[clockNumbers[2]]);// BitmapFactory.decodeResource(res, _numberDrawableIds[clockNumbers[2]]);
			Matrix m = new Matrix();
			m.postTranslate(width / 2 + timebgw / 2 - cmd.getWidth(), yOfNumbers);
			canvas.drawBitmap(cmd, m, null);
			cmd = null;
		}
		{
			Bitmap cmu = getBitmap(res, _numberDrawableIds[clockNumbers[3]]);// BitmapFactory.decodeResource(res, _numberDrawableIds[clockNumbers[3]]);
			Matrix m = new Matrix();
			m.postTranslate(width / 2 + timebgw / 2, yOfNumbers);
			canvas.drawBitmap(cmu, m, null);
			cmu = null;
		}

		{
			diyableUnits[IDX_WEATHERICON].drawOnCanvas(canvas);
		}

		{
			diyableUnits[IDX_CITYNAME].drawOnCanvas(canvas);
		}

		{
			diyableUnits[IDX_2ND_BUTTON].drawOnCanvas(canvas);
			diyableUnits[IDX_1ST_BUTTON].drawOnCanvas(canvas);
		}

		{
			diyableUnits[IDX_1ST_TEXT].drawOnCanvas(canvas);
		}

		{
			diyableUnits[IDX_2ND_TEXT].drawOnCanvas(canvas);
		}

	}

	@Override
	protected void doLayout(AbstractDiyableUnit[] diyableUnits) {

		float density = getDensity();
		int width = getWidthPixels();

		{
			int yOfClockBg = (int) (50d * density);
			int anchorFlag = DiyableBG.ANCHOR_FLAG_TOP | DiyableBG.ANCHOR_FLAG_HCENTER;
			diyableUnits[IDX_WIDGET_BG].measureDrawRect(width / 2, yOfClockBg, anchorFlag);
		}

		{
			int yOfWeatherIcon = (int) (100d * density);
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_HCENTER | AbstractDiyableUnit.ANCHOR_FLAG_TOP;
			diyableUnits[IDX_WEATHERICON].measureDrawRect(width / 2, yOfWeatherIcon, anchorFlag);
		}

		{
			int xOfCityNameText = diyableUnits[IDX_WIDGET_BG].getDrawBounds().left + (int) (5d * density);
			int yOfCityNameText = diyableUnits[IDX_WIDGET_BG].getDrawBounds().bottom - (int) (5d * density);
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_LEFT | AbstractDiyableUnit.ANCHOR_FLAG_BOTTOM;
			diyableUnits[IDX_CITYNAME].measureDrawRect(xOfCityNameText, yOfCityNameText, anchorFlag);
		}

		{
			int gapBetweenBtnAndSide = (int) (5d * density);
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_TOP | AbstractDiyableUnit.ANCHOR_FLAG_RIGHT;
			int tx = diyableUnits[IDX_WIDGET_BG].getDrawBounds().right - gapBetweenBtnAndSide;
			int ty = diyableUnits[IDX_CITYNAME].getDrawBounds().top;
			diyableUnits[IDX_2ND_BUTTON].measureDrawRect(tx, ty, anchorFlag);
			tx = diyableUnits[IDX_2ND_BUTTON].getDrawBounds().left;
			diyableUnits[IDX_1ST_BUTTON].measureDrawRect(tx, ty, anchorFlag);
		}

		int gapBetweenTextAndSide = (int) (25d * density);
		int yOfText = (int) (150d * density);

		{
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_TOP | AbstractDiyableUnit.ANCHOR_FLAG_LEFT;
			diyableUnits[IDX_1ST_TEXT].measureDrawRect(gapBetweenTextAndSide, yOfText, anchorFlag);
		}

		{
			int anchorFlag = AbstractDiyableUnit.ANCHOR_FLAG_TOP | AbstractDiyableUnit.ANCHOR_FLAG_RIGHT;
			diyableUnits[IDX_2ND_TEXT].measureDrawRect(width - gapBetweenTextAndSide, yOfText, anchorFlag);
		}

	}

	static final int IDX_WIDGET_BG = 0;
	static final int IDX_WEATHERICON = 1;
	static final int IDX_1ST_TEXT = 2;
	static final int IDX_2ND_TEXT = 3;
	static final int IDX_CITYNAME = 4;
	static final int IDX_1ST_BUTTON = 5;
	static final int IDX_2ND_BUTTON = 6;

	@Override
	protected AbstractDiyableUnit[] newDiyableUnits() {

		float density = getDensity();
		AWType type = AWType._1ST_4X2;

		AbstractDiyableUnit[] r = new AbstractDiyableUnit[7];

		DiyableBG bg = new DiyableBG(type, R.drawable.widget_bg);
		r[IDX_WIDGET_BG] = bg;

		r[IDX_WEATHERICON] = new DiyableWeatherIcon(type, 1f, true, bg);

		int cityNameTextSize = (int) (17d * density);
		r[IDX_CITYNAME] = new DiyableCityname(type, cityNameTextSize, bg);

		EnumMap<ButtonFunction, Integer> function2ResidMap = new EnumMap<DiyAppWidgetAttrUtil.ButtonFunction, Integer>(ButtonFunction.class);
		{
			function2ResidMap.put(ButtonFunction.PLAY_TTS, R.drawable.widget_play_tts);
			function2ResidMap.put(ButtonFunction.TTS_SETTING, R.drawable.widget_setalarm);
			function2ResidMap.put(ButtonFunction.WEIBO, R.drawable.widget_weibo);
			function2ResidMap.put(ButtonFunction.UPDATE_DATA, R.drawable.widget_update);
			function2ResidMap.put(ButtonFunction.APP, R.drawable.widget_app);
		}
		r[IDX_2ND_BUTTON] = new DiyableButton(type, DiyButton._2ND_BUTTON, function2ResidMap);
		r[IDX_1ST_BUTTON] = new DiyableButton(type, DiyButton._1ST_BUTTON, function2ResidMap);

		int textSize = (int) (16d * density);
		r[IDX_1ST_TEXT] = new DiyableText(type, textSize, DiyText._1ST_TEXT, bg, false);
		r[IDX_2ND_TEXT] = new DiyableText(type, textSize, DiyText._2ND_TEXT, bg, false);

		return r;

	}

}
