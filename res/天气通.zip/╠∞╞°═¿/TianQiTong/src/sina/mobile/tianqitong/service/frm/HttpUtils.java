package sina.mobile.tianqitong.service.frm;

import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_FILE_FILE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_RESPONSE_CODE;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_INT_STEP;
import static sina.mobile.tianqitong.service.frm.MsgUtility.MSG_DATA_KEY_S_DATA;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_BAD_XML;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_NETWORK_DOWN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SERVER_DOWN;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_STORAGE_ERROR;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_SUCCESSFUL;
import static sina.mobile.tianqitong.service.frm.MsgUtility.RESPONSE_CODE_USER_CANCELED;
import static sina.mobile.tianqitong.service.frm.MsgUtility.sendResponse;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.os.Bundle;

/**
 * http模块的静态方法。
 * 
 * @author 黄恪
 * 
 */
public final class HttpUtils {
	private HttpUtils() {

	}

	/**
	 * 这个方法功能不是十分明确，仅仅是为了节省代码量才用的。<br>
	 * 做了以下工作：<br>
	 * 设置代理，并按照url打开网络连接，如果打开失败，按照requestNum响应网络失败，并返回null；<br>
	 * 组装connection，组装上method、超时等属性，然后返回connection。
	 * 
	 * @param requestNum
	 * @param method
	 * @param uri
	 * @return 返回null表示连接建立失败，已经把失败的响应发了，后续方法不需要再发。
	 */
	public static HttpURLConnection makeConnection(Context context, int requestNum, String method, URL url) {
		return makeConnection(context, requestNum, method, url, null);
	}

	public static HttpURLConnection makeConnection(Context context, int requestNum, String method, URL url, HashSet<Integer> cancelSet) {

		if (requestNum < 0) {
			throw new IllegalStateException();
		}
		if (method == null) {
			throw new IllegalArgumentException();
		} else if ((!method.equals("GET")) && (!method.equals("POST"))) {
			throw new UnsupportedOperationException();
		}
		if (url == null) {
			throw new IllegalArgumentException();
		}
		
		

		NetEnv netEnv = getNetworkEnviroment(context);
		HttpURLConnection connection = null;

		if (!netEnv.mIsValid) {
			// 不在需要遍历所有的NetworkInfo来找能联网的。
			// 现在是提示用户去设置网络。
			Bundle b = new Bundle();
			if (cancelSet != null) {
				synchronized (cancelSet) {
					if (cancelSet.contains(requestNum)) {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
					} else {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
					}
				}
			} else {
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
			}
			sendResponse(requestNum, b);
			return null;
		}

		// 设置代理
		try {
			if (netEnv.mProxyHost != null && netEnv.mProxyHost.length() != 0 && netEnv.mProxyPort != -1) {
				InetSocketAddress isa = new InetSocketAddress(netEnv.mProxyHost, netEnv.mProxyPort);
				java.net.Proxy proxy = new java.net.Proxy(java.net.Proxy.Type.HTTP, isa);
				connection = (HttpURLConnection) url.openConnection(proxy);
			} else {
				connection = (HttpURLConnection) url.openConnection();
			}
			TianQiTongLog.addNormalLog("makeconnection: "+url.toString());
		} catch (IOException e) {
			Bundle b = new Bundle();
			if (cancelSet != null) {
				synchronized (cancelSet) {
					if (cancelSet.contains(requestNum)) {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
					} else {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
					}
				}
			} else {
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
			}
			sendResponse(requestNum, b);
			TianQiTongLog.addException(e);
			return null;
		}

		// 设置连接的其它参数
		try {
			connection.setRequestMethod(method);
		} catch (ProtocolException e) {
			TianQiTongLog.addException(e);
			throw new IllegalStateException();
		}
		// for android 4.0
		boolean ifOutPut = method.equals("GET") ? false : true;
		connection.setDoOutput(ifOutPut);
		connection.setDoInput(true);
		connection.setChunkedStreamingMode(0);
		connection.setConnectTimeout(15000);
		connection.setReadTimeout(15000);
		connection.setRequestProperty("Accept", "*, */*");
		connection.setRequestProperty("Accept-Encoding", "*, */*");
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		return connection;
	}

	public static final class NetEnv {
		public boolean mIsWifi;
		public String mApnName;
		public String mProxyHost;
		public int mProxyPort;
		public boolean mIsValid;
	}

	public static NetEnv getNetworkEnviroment(Context context) {

		NetEnv r = new NetEnv();

		ConnectivityManager cm = (ConnectivityManager) (context.getSystemService(Context.CONNECTIVITY_SERVICE));

		NetworkInfo ani = cm.getActiveNetworkInfo();
		if (ani == null) {
			r.mIsValid = false;
			return r;
		} else {
			r.mIsValid = true;
		}

		if (cm.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_WIFI) {
			r.mIsWifi = true;
		} else {
			r.mIsWifi = false;
		}
		cm = null;

		r.mApnName = ani.getSubtypeName();

		if (r.mIsWifi) {
			r.mProxyHost = "";
			r.mProxyPort = -1;
		} else {
			r.mProxyHost = Proxy.getDefaultHost();
			r.mProxyPort = Proxy.getDefaultPort();
		}

		return r;
	}

	/**
	 * 这个方法功能不是十分明确，仅仅是为了节省代码量才用的。<br>
	 * 做了以下工作：<br>
	 * 如果传入的connection为null，返回HTTP_SERVER_ERROR；<br>
	 * 执行connection.connect()并取返回值，如果抛出了超时异常或者IO异常，按照requestNum响应网络失败，并返回-1； <br>
	 * 如果返回值不是HTTP_OK，按照requestNum响应服务器错误，并返回-1。
	 * 
	 * @param requestNum
	 * @param method
	 * @param uri
	 * @return
	 */
	public static int getResponseCode(int requestNum, HttpURLConnection connection, HashSet<Integer> cancelSet) {

		if (requestNum < 0) {
			throw new IllegalStateException();
		}

		int responseCode = HttpURLConnection.HTTP_SERVER_ERROR;

		if (connection == null) {
			// 连接建立失败，已经在makeConnection方法中处理过了，不需要再处理。
			return -1;
		}

		TianQiTongLog.addNormalLog(connection.getURL().toString());

		try {
			connection.connect();
			responseCode = connection.getResponseCode();
		} catch (SocketTimeoutException ste) {
			Bundle b = new Bundle();
			if (cancelSet != null) {
				synchronized (cancelSet) {
					if (cancelSet.contains(requestNum)) {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
					} else {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
					}
				}
			} else {
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
			}
			sendResponse(requestNum, b);
			TianQiTongLog.addException(ste);
			return -1;
		} catch (IOException e) {
			Bundle b = new Bundle();
			if (cancelSet != null) {
				synchronized (cancelSet) {
					if (cancelSet.contains(requestNum)) {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
					} else {
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
					}
				}
			} else {
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
			}
			sendResponse(requestNum, b);
			TianQiTongLog.addException(e);
			return -1;
		}

		if (responseCode != HttpURLConnection.HTTP_OK) {
			Bundle b = new Bundle();
			b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_SERVER_DOWN);
			b.putInt("httpresponsecode", responseCode);
			sendResponse(requestNum, b);
			return -1;
		}

		return HttpURLConnection.HTTP_OK;

	}

	public static int getResponseCode(int requestNum, HttpURLConnection connection) {
		return getResponseCode(requestNum, connection, null);
	}

	/**
	 * 读取InputStream到文件，期间，会返回错误，或者发布通知给外面。<br>
	 * 随读随写。这种做法要比全读出成byte[]再传给存储模块存，效率要高。 做了以下工作：<br>
	 * 按照dir和fileName新建一个文件，如果抛出IO异常，响应写文件错误，返回；<br>
	 * 从connection中获得InputStream，随读随写到文件的BufferOutputStream里，写的过程中，会把进度按照requestNum通知百分比出去；<br>
	 * 如果读写过程中发生IO异常，可能会响应写文件错误，或者网络错误，并返回；<br>
	 * 读写完成后，此时responseCode必然是HTTP_OK，响应成功，并返回。
	 * 
	 * 
	 * @param requestNum
	 * @param connection
	 * @param dir
	 * @param fileName
	 * @return
	 */

	public static interface DownloadListener {
		public void onDownloading(String url, int progress);

		public void onCanceled(String url);
	}

	public static final boolean readHttpInputStreamAndWriteToOutputStream(OutputStream os, int responseCode, int requestNum, HttpURLConnection connection, Set<Integer> cancledNumSet,
			DownloadListener downloadListener) {
		return readHttpInputStreamAndWriteToOutputStream(os, responseCode, requestNum, connection, cancledNumSet, downloadListener, -1);
	}

	public static final boolean readHttpInputStreamAndWriteToOutputStream(OutputStream os, int responseCode, int requestNum, HttpURLConnection connection, Set<Integer> cancledNumSet,
			DownloadListener downloadListener, int limitByte) {

		if (connection == null) {
			// 连接建立失败，已经在makeConnection方法中处理过了，不需要再处理。
			return false;
		}
		if (responseCode != HttpURLConnection.HTTP_OK) {
			// 在getResponseCode方法中已经处理这种情况了。
			return false;
		}

		InputStream httpIs = null;
		BufferedInputStream bis = null;

		try {
			// 取得输入流
			try {
				httpIs = connection.getInputStream();
			} catch (IOException e) {
				closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
				Bundle b = new Bundle();
				if (cancledNumSet != null) {
					synchronized (cancledNumSet) {
						if (cancledNumSet.contains(requestNum)) {
							b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
						} else {
							b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
						}
					}
				} else {
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_NETWORK_DOWN);
				}
				sendResponse(requestNum, b);
				return false;
			}
			bis = new BufferedInputStream(httpIs);

			int bufferSize = 102400;
			if (limitByte != -1 && limitByte < bufferSize) {
				bufferSize = limitByte;
			}
			byte[] buffer = new byte[bufferSize]; // 创建存放读入字节的缓冲
			int num = -1; // 读入的字节数
			long downloadedBytes = 0;
			final long totalSize;
			{
				String contentLength = connection.getHeaderField("Content-Length");
				if (contentLength != null) {
					totalSize = Long.parseLong(contentLength);
				} else {
					totalSize = -1L;
				}
			}

			int step = 0;

			while (true) {
				if (cancledNumSet != null) {
					synchronized (cancledNumSet) {
						if (cancledNumSet.contains(requestNum)) {
							break;
						}
					}
				}

				try {
					num = bis.read(buffer); // 读入到缓冲区
				} catch (IOException e) {
					closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
					Bundle b = new Bundle();
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_SERVER_DOWN);
					sendResponse(requestNum, b);
					return false;
				}
				try {
					if (num == -1) {
						os.flush();
						break; // 已经读完
					}
					os.write(buffer, 0, num);
				} catch (IOException e) {
					closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
					Bundle b = new Bundle();
					b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_STORAGE_ERROR);
					sendResponse(requestNum, b);
					return false;
				}

				if (limitByte != -1 && downloadedBytes >= limitByte) {
					if (downloadListener != null) {
						downloadListener.onDownloading(connection.getURL().toString(), 100);
					}
					break;
				}

				int tstep = (int) (downloadedBytes * 100L / totalSize);

				if (totalSize != -1) {
					downloadedBytes += num;
				}
				if (step != tstep) {
					step = tstep;
					if (downloadListener != null) {
						downloadListener.onDownloading(connection.getURL().toString(), step);
					}
				}
			}

			if (cancledNumSet != null) {
				synchronized (cancledNumSet) {
					if (cancledNumSet.contains(requestNum)) {
						closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
						cancledNumSet.remove(requestNum);
						Bundle b = new Bundle();
						b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_USER_CANCELED);
						b.putInt(MSG_DATA_KEY_INT_STEP, step);
						sendResponse(requestNum, b);
						if (downloadListener != null) {
							downloadListener.onCanceled(connection.getURL().toString());
						}
						return false;
					}
				}
			}

			try {
				os.flush();
			} catch (IOException e) {
				closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
				Bundle b = new Bundle();
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_STORAGE_ERROR);
				sendResponse(requestNum, b);
				return false;
			}

			closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
			if (downloadListener != null) {
				downloadListener.onDownloading(connection.getURL().toString(), 100);
			}
			
			System.out.println("dd:"+totalSize+" "+connection.getURL().toString());
			TianQiTongLog.addNormalLog("dd:"+totalSize+" "+connection.getURL().toString());
			return true;

		} finally {
			closeStreams(new InputStream[] { httpIs, bis }, new OutputStream[] { os });
		}

	}

	public static final byte[] readHttpInputStreamAndWriteToOutputStream(int responseCode, int requestNum, HttpURLConnection connection, Set<Integer> cancledNumSet, DownloadListener downloadListener) {
		return readHttpInputStreamAndWriteToOutputStream(responseCode, requestNum, connection, cancledNumSet, downloadListener, -1);
	}

	public static final byte[] readHttpInputStreamAndWriteToOutputStream(int responseCode, int requestNum, HttpURLConnection connection, Set<Integer> cancledNumSet, DownloadListener downloadListener,
			int limitByts) {

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(baos);
		boolean tt = readHttpInputStreamAndWriteToOutputStream(bos, responseCode, requestNum, connection, cancledNumSet, downloadListener, limitByts);
		if (tt == false) {
			return null;
		}
		byte[] r = baos.toByteArray();
		return r;

	}

	public static final URL makeURL(HashMap<String, String> paramsForGet, String host, String path) {
		// TODO list->map
		List<NameValuePair> qparams = new ArrayList<NameValuePair>();
		if (paramsForGet != null) {
			for (String key : paramsForGet.keySet()) {
				String value = paramsForGet.get(key);
				qparams.add(new BasicNameValuePair(key, value));
			}
		}

		URI uri = null;
		try {
			uri = URIUtils.createURI("http", host, -1, path, URLEncodedUtils.format(qparams, "UTF-8"), null);
		} catch (URISyntaxException e) {
			TianQiTongLog.addException(e);
			throw new IllegalStateException();
		}
		URL url;
		try {
			url = uri.toURL();
			return url;
		} catch (MalformedURLException e) {
			// 不可能到这里。万一到这里了，也不应该发送通常的返回。
			TianQiTongLog.addException(e);
			throw new IllegalStateException();
		}

	}

	public static final URL makeURL(LinkedList<String> paramsForGet, String host, String path) {
// TODO list->map
		List<NameValuePair> qparams = new ArrayList<NameValuePair>();
		if (paramsForGet != null) {
			Iterator<String> iterator = paramsForGet.iterator();
			while (iterator.hasNext()) {
				String key = iterator.next();
				String value = iterator.next();
				qparams.add(new BasicNameValuePair(key, value));
			}
		}

		URI uri = null;
		try {
			uri = URIUtils.createURI("http", host, -1, path, URLEncodedUtils.format(qparams, "UTF-8"), null);
		} catch (URISyntaxException e) {
			TianQiTongLog.addException(e);
			throw new IllegalStateException();
		}
		URL url;
		try {
			url = uri.toURL();
			return url;
		} catch (MalformedURLException e) {
			// 不可能到这里。万一到这里了，也不应该发送通常的返回。
			TianQiTongLog.addException(e);
			throw new IllegalStateException();
		}

	}

	public static final boolean writeToFile(File f, byte[] bytes, int requestNum, Serializable obj) {
		if (obj != null && bytes != null) {

			BufferedOutputStream bos = null;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(f));
				bos.write(bytes);
				bos.flush();
			} catch (IOException e) {
				Bundle b = new Bundle();
				b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_STORAGE_ERROR);
				sendResponse(requestNum, b);
				return false;
			} finally {
				if (bos != null) {
					try {
						bos.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

			Bundle b = new Bundle();
			b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_SUCCESSFUL);
			b.putSerializable(MSG_DATA_KEY_FILE_FILE, f);
			b.putSerializable(MSG_DATA_KEY_S_DATA, obj);
			sendResponse(requestNum, b);
			return true;

		} else {
			Bundle b = new Bundle();
			b.putInt(MSG_DATA_KEY_INT_RESPONSE_CODE, RESPONSE_CODE_BAD_XML);
			sendResponse(requestNum, b);
			return false;
		}
	}

	private static final void closeStreams(InputStream[] iss, OutputStream[] oss) {
		if (iss != null) {
			for (InputStream is : iss) {
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (oss != null) {
			for (OutputStream os : oss) {
				if (os != null) {
					try {
						os.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}

		}
	}
}
