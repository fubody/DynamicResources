package sina.mobile.tianqitong.citymanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.IBinder;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class DragController {
	private static final String TAG = "DragController";

	public static final int DRAG_ACTION_MOVE = 0;
	public static final int DRAG_ACTION_COPY = 1;
	private static final int VIBRATE_DURATION = 35;
	private Context mContext;
	private Vibrator mVibrator;
	private View mOriginator;
	private final int[] mCoordinatesTemp = new int[2];
	private InputMethodManager mInputMethodManager;
	private IBinder mWindowToken;
	private DisplayMetrics mDisplayMetrics = new DisplayMetrics();
	/** Whether or not we're dragging. */
	private boolean mDragging;
	private ImageView floatView = null;

	/** X coordinate of the down event. */
	private float mMotionDownX;

	/** Y coordinate of the down event. */
	private float mMotionDownY;

	private DragView mDragView;
	private DropTarget mDropTarget;
	private DragSource mDragSource;

	private DragListener mRubbishListener;

	public interface DragListener {

		void onDragStart(DragSource source, boolean index0Changer);

		/**
		 * The drag has eneded
		 */
		void onDragEnd(boolean index0Changer);
	}

	public void setRubbishListener(DragListener mListener) {
		this.mRubbishListener = mListener;
	}

	public void setDropTarget(DropTarget dropTarget) {
		this.mDropTarget = dropTarget;
	}

	public void setFloatView(ImageView floatView) {
		this.floatView = floatView;
	}

	public DragController(Context context) {
		mContext = context;
		mVibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);

	}

	public void startDrag(View v, DragSource source, int dragAction) {
		mOriginator = v;
		if (mRubbishListener != null) {

			mRubbishListener.onDragStart(source, v.getTag().toString().equals("0"));
		}
		Bitmap b = getViewBitmap(v);

		if (b == null) {
			// out of memory?
			return;
		}

		int[] loc = mCoordinatesTemp;
		v.getLocationOnScreen(loc);
		int screenX = loc[0];
		int screenY = loc[1];

		startDrag(b, screenX, screenY, 0, 0, b.getWidth(), b.getHeight(), source, dragAction);

		b.recycle();

		if (dragAction == DRAG_ACTION_MOVE) {
			v.setVisibility(View.INVISIBLE);
		}
	}

	public void startDrag(Bitmap b, int screenX, int screenY, int textureLeft, int textureTop, int textureWidth, int textureHeight, DragSource source, int dragAction) {

		// Hide soft keyboard, if visible
		if (mInputMethodManager == null) {
			mInputMethodManager = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
		}
		mInputMethodManager.hideSoftInputFromWindow(mWindowToken, 0);

		int registrationX = ((int) mMotionDownX) - screenX;
		int registrationY = ((int) mMotionDownY) - screenY;

		mDragSource = source;
		mDragging = true;
		isRemove = false;
		mVibrator.vibrate(VIBRATE_DURATION);
		DragView dragView = mDragView = new DragView(mContext, b, registrationX, registrationY, textureLeft, textureTop, textureWidth, textureHeight);
		dragView.setScale(1.2f);
		dragView.show(mWindowToken, (int) mMotionDownX, (int) mMotionDownY);
	}

	/**
	 * Call this from a drag source view.
	 */
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		final int action = ev.getAction();

		if (action == MotionEvent.ACTION_DOWN) {
			recordScreenSize();
		}

		final int screenX = clamp((int) ev.getRawX(), 0, mDisplayMetrics.widthPixels);
		final int screenY = clamp((int) ev.getRawY(), 0, mDisplayMetrics.heightPixels);

		switch (action) {
		case MotionEvent.ACTION_MOVE:
			break;

		case MotionEvent.ACTION_DOWN:
			// Remember location of down touch
			mMotionDownX = screenX;
			mMotionDownY = screenY;
			break;

		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			endDrag();
			break;
		}

		return mDragging;
	}

	Rect mRectTemp = new Rect();

// boolean isEnter = true;

	/**
	 * Call this from a drag source view.
	 */
	public boolean onTouchEvent(MotionEvent ev) {
		if (!mDragging) {
			return false;
		}

		final int action = ev.getAction();
		final int screenX = clamp((int) ev.getRawX(), 0, mDisplayMetrics.widthPixels);
		final int screenY = clamp((int) ev.getRawY(), 0, mDisplayMetrics.heightPixels);

		switch (action) {
		case MotionEvent.ACTION_DOWN:
			// Remember where the motion event started
			mMotionDownX = screenX;
			mMotionDownY = screenY;
			break;
		case MotionEvent.ACTION_MOVE:
			// Update the drag view. Don't use the clamped pos here so the dragging looks
			// like it goes off screen a little, intead of bumping up against the edge.
			mDragView.move((int) ev.getRawX(), (int) ev.getRawY());
			final Rect r = mRectTemp;
			final int[] dropCoordinates = mCoordinatesTemp;
			mDropTarget.getHitRect(r);
			mDropTarget.getLocationOnScreen(dropCoordinates);

			r.offset(dropCoordinates[0] - mDropTarget.getLeft(), dropCoordinates[1] - mDropTarget.getTop());
			int dragTarget = mDragSource.containsIn9Grid(screenX, screenY);

			if (r.contains(screenX, screenY)) {
				mDropTarget.onDragEnter();
				Paint p = new Paint();
				p.setStyle(Paint.Style.FILL);
				p.setColor(0x88dd0011);
				mDragView.setPaint(p);
				isRemove = true;
			} else {
				isRemove = false;
				mDragView.setPaint(null);
				mDropTarget.onDragExit();
			}

			if (dragTarget != -1) {

				isTrade = true;
				// mGridListener.onDragStart(source);
				dragTargetIndex = dragTarget;

			} else {
				isTrade = false;
			}

			break;
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_CANCEL:
			cancelDrag();
			mDropTarget.onDragExit();
		}

		return true;
	}

	Bitmap targetGridViewBitmap = null;
	private int lastGridViewId = 0;
	View targetView = null;

	public void onEnterGridView(View v) {
		if (lastGridViewId != v.getId()) {
			floatView.clearAnimation();
			floatView.refreshDrawableState();
			floatView.clearColorFilter();
			if (targetGridViewBitmap != null) {
				targetGridViewBitmap.recycle();
			}
			targetGridViewBitmap = null;
		}
		if (targetGridViewBitmap == null) {
			floatView.clearAnimation();
			if (targetView != null) {
				targetView.setVisibility(View.VISIBLE);
			}
			targetView = v;
			v.setVisibility(View.GONE);
			targetGridViewBitmap = getViewBitmap(v);
			lastGridViewId = v.getId();

			floatView.setVisibility(View.VISIBLE);
			floatView.setImageBitmap(targetGridViewBitmap);
			RelativeLayout.LayoutParams flp = (RelativeLayout.LayoutParams) floatView.getLayoutParams();
			floatView.refreshDrawableState();
// System.out.println(targetGridViewBitmap.getWidth() + " ==bitMap== " + targetGridViewBitmap.getHeight());

// System.out.println(v.getLeft() + " ==from== " + v.getTop());
			flp.leftMargin = v.getLeft();
			flp.topMargin = v.getTop();
			// flp.setMargins(v.getLeft(), v.getTop(), v.getLeft() + targetGridViewBitmap.getWidth(), v.getTop() + targetGridViewBitmap.getHeight());
			floatView.setLayoutParams(flp);
// System.out.println(floatView.getLeft() + " ==floatView.getTop()== " + floatView.getTop());

// System.out.println(floatView.getWidth() + " ==Width=floatView=Height== " + floatView.getHeight());
			TranslateAnimation mAnimation = new TranslateAnimation(0, -v.getLeft() + mOriginator.getLeft(), 0, -v.getTop() + mOriginator.getTop());
			mAnimation.setFillAfter(true);

// System.out.println(mOriginator.getLeft() + " ***To** " + mOriginator.getTop());

			// TranslateAnimation mAnimation = new TranslateAnimation(0,150, 0,150);

			mAnimation.setInterpolator(new DecelerateInterpolator());
			mAnimation.setDuration(1000);
			floatView.startAnimation(mAnimation);
			floatView.invalidate();
		}

	}

	public void onEnterFloatView() {

	}

	/**
	 * Draw the view into a bitmap.
	 */
	private Bitmap getViewBitmap(View v) {
		v.clearFocus();
		v.setPressed(false);

		boolean willNotCache = v.willNotCacheDrawing();
		v.setWillNotCacheDrawing(false);

		// Reset the drawing cache background color to fully transparent
		// for the duration of this operation
		int color = v.getDrawingCacheBackgroundColor();
		v.setDrawingCacheBackgroundColor(0);

		if (color != 0) {
			v.destroyDrawingCache();
		}
		v.buildDrawingCache();
		Bitmap cacheBitmap = v.getDrawingCache();
		if (cacheBitmap == null) {
			Log.e(TAG, "failed getViewBitmap(" + v + ")", new RuntimeException());
			return null;
		}

		Bitmap bitmap = Bitmap.createBitmap(cacheBitmap);

		// Restore the view
		v.destroyDrawingCache();
		v.setWillNotCacheDrawing(willNotCache);
		v.setDrawingCacheBackgroundColor(color);

		return bitmap;
	}

	/**
	 * Stop dragging without dropping.
	 */
	public void cancelDrag() {
		endDrag();
	}

	boolean isRemove = false;
	boolean isTrade = false;
	int dragTargetIndex = 0;
	int deleteIndex = 0;

	private void endDrag() {
		if (mDragging) {
			// targetView.setVisibility(View.VISIBLE);
			mDragging = false;
			if (mOriginator != null && !isRemove) {
				mOriginator.setVisibility(View.VISIBLE);
			} else {
				mDragSource.deleteCityWeathInfo(Integer.parseInt((String) mOriginator.getTag()));
			}
			isRemove = false;

			floatView.setVisibility(View.GONE);
			floatView.clearAnimation();
			boolean index0Changer = false;
			if (isTrade) {
				int one = dragTargetIndex;
				int other = Integer.parseInt((String) mOriginator.getTag());
				if (one == 0 || other == 0) {
					index0Changer = true;
				}
				if (dragTargetIndex != other) {
					mDragSource.tradeCityWeathInfo(one, other);
				}

			} else {
				mOriginator.setVisibility(View.VISIBLE);
				if (targetView != null)
					targetView.setVisibility(View.VISIBLE);
			}
			if (mRubbishListener != null) {
				mRubbishListener.onDragEnd(index0Changer);
			}
			isTrade = false;

			if (mDragView != null) {
				mDragView.remove();
				mDragView = null;
			}
			targetGridViewBitmap = null;
			targetView = null;
		}
	}

	/**
	 * Get the screen size so we can clamp events to the screen size so even if you drag off the edge of the screen, we find something.
	 */
	private void recordScreenSize() {
		((WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(mDisplayMetrics);
	}

	/**
	 * Clamp val to be &gt;= min and &lt; max.
	 */
	private static int clamp(int val, int min, int max) {
		if (val < min) {
			return min;
		} else if (val >= max) {
			return max - 1;
		} else {
			return val;
		}
	}

	public void setWindowToken(IBinder token) {
		mWindowToken = token;
	}

}
