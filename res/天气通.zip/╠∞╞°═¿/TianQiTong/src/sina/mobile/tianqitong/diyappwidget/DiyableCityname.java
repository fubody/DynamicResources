package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getCitynameMode;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.putTempCitynameMode;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getCityName;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getTempOrCurrent;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.CitynameMode;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.NinePatchDrawable;
import android.text.TextPaint;
import android.view.View;

class DiyableCityname extends AbstractDiyableUnitWithItsOptionItemsAreRadioButtons<CitynameMode> {

	private int mCitynameTextSize;

	private DiyableBG mBg;

	public DiyableCityname(AWType type, int textSize, DiyableBG bg) {
		super(type);

		mCitynameTextSize = textSize;
		mBg = bg;

		remakeParams();
	}

	private static final float GAP_BETWEEN_TEXT_AND_BUTTON_DIP = 10f;

	@Override
	public void drawOnCanvas(Canvas c) {

		float density = getDensity();

		int gapBetweenTextAndButton = (int) (GAP_BETWEEN_TEXT_AND_BUTTON_DIP * density);

		Rect mCitynameRect = getDrawBounds();

		switch (getTempValue()) {
		case NULL: {

		}
			break;
		case SHOW: {
			NinePatchDrawable d = (NinePatchDrawable) getActivity().getResources().getDrawable(R.drawable.appwidget_cityname);
			d.setBounds(mCitynameRect);
			d.draw(c);
			d = null;
		}
		case ONLY_TEXT: {
			TextPaint p = new TextPaint();
			p.setColor(mBg.getTextColor());
			p.setTextSize(mCitynameTextSize);
			p.setAntiAlias(true);

			int left = mCitynameRect.left + gapBetweenTextAndButton;
			int bottom = mCitynameRect.bottom - gapBetweenTextAndButton;
			c.drawText(getCityName(), left, bottom, p);
		}
			break;
		}

	}

	@Override
	public View[] makeOptions() {

		boolean remoteSetBackgroundResource = false;
		try {
			Method[] ms = View.class.getMethods();
			for (Method m : ms) {
				if (m.getName().equals("setBackgroundResource")) {
					Annotation[] as = m.getAnnotations();
					for (Annotation a : as) {
						if (a.toString().contains("RemotableViewMethod")) {
							remoteSetBackgroundResource = true;
							break;
						}
					}
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		CitynameMode[] modes;
		if (remoteSetBackgroundResource) {
			modes = new CitynameMode[] { CitynameMode.NULL, CitynameMode.ONLY_TEXT, CitynameMode.SHOW, };
		} else {
			modes = new CitynameMode[] { CitynameMode.NULL, CitynameMode.SHOW, };
		}

		String[] optionTexts = new String[modes.length];

		for (int i = 0; i < modes.length; i++) {
			optionTexts[i] = "";

			switch (modes[i]) {
			case NULL: {
				optionTexts[i] = "不显示";
			}
				break;
			case ONLY_TEXT: {
				optionTexts[i] = "只显示城市名";
			}
				break;
			case SHOW: {
				optionTexts[i] = "默认";
			}
				break;
			}
		}

		return makeRadioOptions(modes, optionTexts);
	}

	@Override
	public void putTempValue(CitynameMode tempValue) {
		putTempCitynameMode(getActivity(), getType(), tempValue);
	}

	@Override
	public Rect getTouchableBounds() {
		return getDrawBounds();
	}

	@Override
	protected Rect doMeasureDrawRect() {

		float density = getDensity();

		int gapBetweenTextAndButton = (int) (GAP_BETWEEN_TEXT_AND_BUTTON_DIP * density);

		String text = getCityName();
		TextPaint p = new TextPaint();
		p.setColor(mBg.getTextColor());
		p.setTextSize(mCitynameTextSize);
		p.setAntiAlias(true);

		Rect textbounds = new Rect();
		p.getTextBounds(text, 0, text.length(), textbounds);
		offsetTextRect2Zero(textbounds);

		int left = textbounds.left - gapBetweenTextAndButton;
		int top = textbounds.top - gapBetweenTextAndButton;
		int right = textbounds.right + gapBetweenTextAndButton;
		int bottom = textbounds.bottom + gapBetweenTextAndButton;

		Rect mCitynameRect = new Rect(left, top, right, bottom);

		offsetRect(mCitynameRect);

		return mCitynameRect;

	}

	@Override
	protected CitynameMode getValueFromTempSPFile() {
		return getCitynameMode(getActivity(), getType(), getTempOrCurrent());
	}

	@Override
	public String getOptionsTitle() {
		return "设置城市名称按钮";
	}

}
