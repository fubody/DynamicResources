package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getBitmap;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getNullBmp;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.releaseBitmapCache;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.releaseBitmapCacheAndWallpaper;
import static sina.mobile.tianqitong.service.IntentActionConstants.ACTION_START_SERVICE_UPDATE_WIDGET;
import static sina.mobile.tianqitong.service.utility.SPUtility.getSPInteger;
import static sina.mobile.tianqitong.service.utility.SPUtility.putSPInteger;
import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidget.Widget4x1Provider;
import sina.mobile.tianqitong.appwidget.WidgetProvider;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.FileGettable;
import sina.mobile.tianqitong.main.CustomFrameLayout;
import sina.mobile.tianqitong.main.CustomFrameLayout.onCustomFrameOperationListener;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.SPUtility;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class AppWidgetPreview extends Activity implements ServiceConnection, View.OnClickListener, onCustomFrameOperationListener {

	/**
	 * 天气通服务
	 */
	private TianQiTongService mService;

	private ImageView[] mPreviewViews;

	private CustomFrameLayout mCustomFrameLayout;

	private boolean mMakePreviewOk = false;

	private ImageView mLeftBtn;
	private ImageView mRightBtn;
	private TextView mAWName;
	private TextView mPages;
	private TextView mApplyBtn;

	private static int AWIDX_1ST4X2 = 0;
	private static int AWIDX_1ST4X1 = 1;
	private static int AWIDX_2ND4X2 = 2;
	private static AWType[] AWTYPES = new AWType[] { AWType._1ST_4X2, AWType._1ST_4X1, AWType._2ND_4X2 };

	public void onStart() {
		super.onStart();
		DiyableAppWidgetPreviewManager.setCurAWType(null);
		if (mService != null) {
			for (int i = 0; i < mPreviewViews.length; i++) {
				ImageView iv = mPreviewViews[i];
				iv.setImageBitmap(getNullBmp());
				System.gc();
			}
			for (int i = 0; i < AWTYPES.length; i++) {
				ImageView iv = mPreviewViews[i];
				Bitmap bmp = getPreview(AWType.getAWType(AWTYPES[i].getId()));
				iv.setImageBitmap(bmp);
			}
		}

	}

	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		DiyAppWidgetAttrUtil.initDefaultValues(this);

		setContentView(R.layout.appwidget_preview);

		mCustomFrameLayout = (CustomFrameLayout) findViewById(R.id.previews);
		mCustomFrameLayout.setOnCustomFrameOperationListener(this);

		mPreviewViews = new ImageView[3];

		DiyableAppWidgetPreviewManager.init(this, null, null, FileGettable.CURRENT);

		for (AWType type : AWTYPES) {
			Bitmap bmp = DiyableAppWidgetPreviewManager.getWallpaper();
			ImageView iv = new ImageView(this);
			mPreviewViews[type.getId()] = iv;

			final int typeId = type.getId();
			iv.setImageBitmap(bmp);
			iv.setTag(typeId);

			bmp = null;

			iv.setOnClickListener(this);

			mCustomFrameLayout.addView(iv);
		}
		mCustomFrameLayout.requestLayout();

		mLeftBtn = (ImageView) findViewById(R.id.left);
		mLeftBtn.setOnClickListener(this);

		mRightBtn = (ImageView) findViewById(R.id.right);
		mRightBtn.setOnClickListener(this);

		mAWName = (TextView) findViewById(R.id.aw_name);
		mPages = (TextView) findViewById(R.id.pages);

		mApplyBtn = (TextView) findViewById(R.id.apply);

		mApplyBtn.setOnClickListener(this);

		bindService(new Intent(this, TianQiTongService.class), this, Context.BIND_AUTO_CREATE);

		if (!SPUtility.getSPBoolean(this, R.string.boolean_awpv_help_shown)) {
			startActivity(new Intent(this, AppWidgetPreviewHelp.class));
			SPUtility.putSPBoolean(this, R.string.boolean_awpv_help_shown, true);
		}

	}

	private Bitmap getPreview(AWType type) {

		if (mService == null) {
			throw new IllegalStateException();
		}

		int percent = 80;

		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		int width = dm.widthPixels;
		int height = dm.heightPixels;
		float density = dm.density;

		int statusBarHeight = (int) (25d * density);

		Bitmap bmp0 = Bitmap.createBitmap(width * percent / 100, (height - statusBarHeight) * percent / 100, Config.ARGB_8888);
		Canvas c = new Canvas(bmp0);
		Matrix mm = new Matrix();
		float s = ((float) percent) / 100f;
		mm.setScale(s, s);
		c.setMatrix(mm);

		Bitmap bg = DiyableAppWidgetPreviewManager.getWallpaper();
		c.drawBitmap(bg, 0f, 0f, null);
		bg = null;

		DiyableAppWidgetPreviewManager.getPreview(type, c);

		int spvalue = getSPInteger(this, R.string.strint_which_default_4x2);
		if (have4x2Widget()) {
			if (spvalue == type.getId()) {
				Bitmap icon = getBitmap(getResources(), R.drawable.chosen_one);
				Matrix m = new Matrix();
				m.postScale(2f, 2f);
				m.postTranslate(bmp0.getWidth() * 100 / percent - ((float) icon.getWidth() * 2f), 0);
				c.drawBitmap(icon, m, null);
				icon = null;
			}
		}

		if (have4x1Widget()) {
			if (type == AWType._1ST_4X1) {
				Bitmap icon = getBitmap(getResources(), R.drawable.chosen_one);
				Matrix m = new Matrix();
				m.postScale(2f, 2f);
				m.postTranslate(bmp0.getWidth() * 100 / percent - ((float) icon.getWidth() * 2f), 0);
				c.drawBitmap(icon, m, null);
				icon = null;
			}
		}

		c = null;

// Bitmap rbmp = Bitmap.createScaledBitmap(bmp0, width * percent / 100, height * percent / 100, false);
// bmp0 = null;
		Bitmap rbmp = bmp0;

		return rbmp;
	}

	public void onDestroy() {
		unbindService(this);
		DiyableAppWidgetPreviewManager.releaseAll();
		super.onDestroy();
	}

	public void onStop() {
		super.onStop();
		releaseBitmapCacheAndWallpaper();
		for (int i = 0; i < mPreviewViews.length; i++) {
			ImageView iv = mPreviewViews[i];
			iv.setImageBitmap(getNullBmp());
			System.gc();
		}
	}

	@Override
	public void onServiceConnected(ComponentName name, IBinder service) {
		mService = ((TianQiTongService.TianQiTongBinder) service).getService();

		String widgetCityCode = SPUtility.getSPString(this, R.string.str_widget_city_code);
		WeatherInfo wi = mService.getWeatherInfo(widgetCityCode);
		String cityName = mService.getCityName(widgetCityCode);

		DiyableAppWidgetPreviewManager.init(this, wi, cityName, FileGettable.CURRENT);

		for (int i = 0; i < mPreviewViews.length; i++) {
			ImageView iv = mPreviewViews[i];
			iv.setImageBitmap(getNullBmp());
			System.gc();
		}

		new Thread() {
			public void run() {
				for (AWType type : AWTYPES) {
					final AWType ttype = type;
					int iidx = 0;
					for (int i = 0; i < AWTYPES.length; i++) {
						if (AWTYPES[i].getId() == type.getId()) {
							iidx = i;
							break;
						}
					}
					final ImageView iv = mPreviewViews[iidx];

					runOnUiThread(new Runnable() {
						public void run() {
							Bitmap bmp = getPreview(ttype);
							iv.setImageBitmap(bmp);
						}
					});
				}

				mMakePreviewOk = true;
// mBackground = null;
			}
		}.start();

	}

	private static final int DIALOG_ID_NO4x2WIDGET = 0;
	private static final int DIALOG_ID_NO4x1WIDGET = 1;

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_ID_NO4x2WIDGET:
		case DIALOG_ID_NO4x1WIDGET: {
			String size = "4x2";
			String space = "1/2";

			if (id == DIALOG_ID_NO4x1WIDGET) {
				size = "4x1";
				space = "1/4";
			}
			StringBuilder sb = new StringBuilder();
			sb.append("您当前还没有添加");
			sb.append(size);
			sb.append("天气桌面插件，需要手动添加。\n两种方法添加：1.返回手机桌面->空白处长摁2秒以上->菜单中 选择添加小部件(Moto)或者小插件(HTC)->列表中点选");
			sb.append(size);
			sb.append("天气通(如果提示没有足够空间，请在其他桌面空余处放置， 需要预留");
			sb.append(space);
			sb.append("空闲屏幕)；\n2.手机桌面->菜单键->添加小部件；手机桌面->菜单键->个性化设置->小插件。注：天气桌面丢失，请卸载后，重新安装天气通到手机内存而非SD卡 -详情见菜单->更多->天气通常见问题");

			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setMessage(sb.toString());
			builder.setPositiveButton(R.string.ok, null);
			return builder.create();
		}
		}
		return null;
	}

	@Override
	public void onServiceDisconnected(ComponentName name) {
		mService = null;

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.left: {
			mCustomFrameLayout.toPrevious();
		}
			break;
		case R.id.right: {
			mCustomFrameLayout.toNext();
		}
			break;
		case R.id.apply: {
			int idx = mCustomFrameLayout.getCurrentChild();

			switch (AWTYPES[idx]) {
			case _1ST_4X2:
			case _2ND_4X2: {
				if (have4x2Widget()) {

					int typeId = AWTYPES[idx].getId();
					putSPInteger(this, R.string.strint_which_default_4x2, typeId);
					for (int i = 0; i < mPreviewViews.length; i++) {
						ImageView iv = mPreviewViews[i];
						iv.setImageBitmap(getNullBmp());
						System.gc();
					}
					for (AWType type : AWTYPES) {
						int iidx = 0;
						for (int i = 0; i < AWTYPES.length; i++) {
							if (AWTYPES[i].getId() == type.getId()) {
								iidx = i;
								break;
							}
						}
						final ImageView iv = mPreviewViews[iidx];
						final Bitmap bmp = getPreview(type);
						iv.setImageBitmap(bmp);

					}
					releaseBitmapCacheAndWallpaper();
					Intent i = new Intent(ACTION_START_SERVICE_UPDATE_WIDGET);
					startService(i);
				} else {
					showDialog(DIALOG_ID_NO4x2WIDGET);
				}
			}
				break;
			case _1ST_4X1: {
				if (have4x1Widget()) {

				} else {
					showDialog(DIALOG_ID_NO4x1WIDGET);
				}
			}
				break;
			}
		}
			break;
		default: {
			if (!mMakePreviewOk) {
				return;
			}

			int idx = mCustomFrameLayout.getCurrentChild();

			switch (AWTYPES[idx]) {
			case _1ST_4X2:
			case _2ND_4X2: {
				if (!have4x2Widget()) {
					showDialog(DIALOG_ID_NO4x2WIDGET);
					return;
				}
			}
				break;
			case _1ST_4X1: {
				if (!have4x1Widget()) {
					showDialog(DIALOG_ID_NO4x1WIDGET);
					return;
				}
			}
				break;
			}

			releaseBitmapCache();
			int typeId = (Integer) v.getTag();
			Intent intent = new Intent(AppWidgetPreview.this, AppWidgetDiyTool.class);
			intent.putExtra("type", typeId);
			startActivityForResult(intent, 0);
			overridePendingTransition(R.anim.appwidget_diy_tools_scale_in, R.anim.appwidget_preview_fade_out);
		}
		}

	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {

	}

	@Override
	public void onChildrenMoving(Rect[] notGoneChildrenRect, Rect customFrameLayoutRect) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onInterceptTouchEvent() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onCurrentChildChanged(int idx) {

		mLeftBtn.setVisibility(View.VISIBLE);
		mRightBtn.setVisibility(View.VISIBLE);
		if (idx == 0) {
			mLeftBtn.setVisibility(View.GONE);
		} else if (idx == 2) {
			mRightBtn.setVisibility(View.GONE);
		}

		switch (AWTYPES[idx]) {
		case _1ST_4X2: {
			mAWName.setText("默认桌面4x2");
			if (have4x2Widget()) {
				int typeId = AWTYPES[idx].getId();
				if (typeId == getSPInteger(this, R.string.strint_which_default_4x2)) {
					mApplyBtn.setText("使用中");
					mApplyBtn.setEnabled(false);
				} else {
					mApplyBtn.setText("应用");
					mApplyBtn.setEnabled(true);
				}
			} else {
				mApplyBtn.setText("应用");
				mApplyBtn.setEnabled(true);
			}
		}
			break;
		case _2ND_4X2: {
			mAWName.setText("简洁桌面4x2");
			if (have4x2Widget()) {
				int typeId = AWTYPES[idx].getId();
				if (typeId == getSPInteger(this, R.string.strint_which_default_4x2)) {
					mApplyBtn.setText("使用中");
					mApplyBtn.setEnabled(false);
				} else {
					mApplyBtn.setText("应用");
					mApplyBtn.setEnabled(true);
				}
			} else {
				mApplyBtn.setText("应用");
				mApplyBtn.setEnabled(true);
			}
		}
			break;
		case _1ST_4X1: {
			mAWName.setText("默认桌面4x1");
			if (have4x1Widget()) {
				mApplyBtn.setText("使用中");
				mApplyBtn.setEnabled(false);
			} else {
				mApplyBtn.setText("应用");
				mApplyBtn.setEnabled(true);
			}
		}
			break;
		}

		mPages.setText((idx + 1) + "/3");

	}

	private boolean have4x2Widget() {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
		int[] _4x2_ids = appWidgetManager.getAppWidgetIds(new ComponentName(this, WidgetProvider.class));
		if (_4x2_ids.length == 0) {
			return false;
		} else {
			return true;
		}
	}

	private boolean have4x1Widget() {
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
		int[] _4x1_ids = appWidgetManager.getAppWidgetIds(new ComponentName(this, Widget4x1Provider.class));
		if (_4x1_ids.length == 0) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public void onBGFadeDone() {
		// TODO Auto-generated method stub
		
	}

}
