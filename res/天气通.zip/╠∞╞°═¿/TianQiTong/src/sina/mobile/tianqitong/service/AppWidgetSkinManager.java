package sina.mobile.tianqitong.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.zip.ZipException;

import org.xmlpull.v1.XmlPullParserException;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.appwidgetskinpkg.TianQiTongAppWidgetSkinManager;
import sina.mobile.tianqitong.appwidgetskinpkg.TianQiTongAppWidgetSkinManager.SkinCfg;
import sina.mobile.tianqitong.service.model.AppWidgetSkin;
import sina.mobile.tianqitong.service.model.AppWidgetSkinList;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataList;
import sina.mobile.tianqitong.service.simplelistdata.TQTListDataListItem;
import sina.mobile.tianqitong.service.simplelistdata.TQTSimpleDataManager;
import sina.mobile.tianqitong.service.simplelistdata.TQTSimpleDataManager.TQTSimpleDataDelegate;
import sina.mobile.tianqitong.service.utility.Utility;
import android.os.Looper;

/**
 * 管理桌面插件皮肤包的类。
 * 
 * @author 黄恪
 * 
 */
public class AppWidgetSkinManager implements TQTSimpleDataDelegate {

	private TianQiTongService mService;

	private TQTSimpleDataManager m4x2DataManager;
	private TQTSimpleDataManager m4x1DataManager;

	AppWidgetSkinManager(TianQiTongService service) {
		m4x2DataManager = new TQTSimpleDataManager(this, new AppWidgetSkinList(), "forecast.sina.cn", "/app/skin.php", Constants.APPWIDGETSKIN4X2_LIST_FILENAME, service, true);
		m4x1DataManager = new TQTSimpleDataManager(this, new AppWidgetSkinList(), "forecast.sina.cn", "/app/skin.php", Constants.APPWIDGETSKIN4X1_LIST_FILENAME, service, true);
		mService = service;
	}

	public void close() {
		m4x2DataManager.close();
		m4x1DataManager.close();
	}

	/**
	 * 取当前所有的皮肤包。包括列表中的、本地的和默认皮肤包
	 * 
	 * @return
	 */
	public AppWidgetSkin[] get4x2AppWidgetSkins() {

		TQTListDataListItem[] tmp = m4x2DataManager.getListData().getAll();
		AppWidgetSkin[] awses = new AppWidgetSkin[tmp.length];
		System.arraycopy(tmp, 0, awses, 0, tmp.length);

		return awses;
	}

	public AppWidgetSkin[] get4x1AppWidgetSkins() {

		TQTListDataListItem[] tmp = m4x1DataManager.getListData().getAll();
		AppWidgetSkin[] awses = new AppWidgetSkin[tmp.length];
		System.arraycopy(tmp, 0, awses, 0, tmp.length);

		return awses;
	}

	public void delAppWidgetSkin(AppWidgetSkin aws) {
		aws.deleteMainFile();
	}

	/**
	 * 从网上取皮肤包列表，重新创建内存中的皮肤列表，删除无用的文件。<br>
	 * 列表取完后，会通过注册的handler通知列表已经改变，然后用get方法就能得到新的列表。
	 * 
	 * @param sender
	 */
// public void refresh4x2AppWidgetSkins(WeakReference<MsgResponseHandler> sender) {
// m4x2DataManager.refresh(sender);
// }
//
// public void refresh4x1AppWidgetSkins(WeakReference<MsgResponseHandler> sender) {
// m4x1DataManager.refresh(sender);
// }

	@Override
	public void buildNetworkRequestGetArgs(TQTSimpleDataManager manager, HashMap<String, String> getArgs) {
		String dpi = mService.getString(R.string.dpi);
		String size = mService.getString(R.string.size);
		String aspect = mService.getString(R.string.aspect);
		String resolution = size + "-" + aspect + "-" + dpi;
		String pid = "free";
		// #ifdef PID
		// #expand pid = "%PID%";// 渠道
//@		pid = "%PID%";// 渠道
		// #endif
		getArgs.put("pt", "1");
		getArgs.put("device", android.os.Build.MODEL + "/" + android.os.Build.VERSION.RELEASE);
		getArgs.put("resolution", resolution);
		getArgs.put("ver", mService.getString(R.string.ver));
		getArgs.put("pd", "0");
		getArgs.put("pid", pid);
		getArgs.put("uid", TianQiTongService.getIMEI(mService));
		getArgs.put("awver", "2");

		if (manager.getCacheFileName() == Constants.APPWIDGETSKIN4X2_LIST_FILENAME) {
			getArgs.put("awtype", "4x2");
		} else {
			getArgs.put("awtype", "4x1");
		}

		getArgs.put("pgno", "1");

		String timeStamp = null;
		if (manager.getCacheFileName() == Constants.APPWIDGETSKIN4X2_LIST_FILENAME) {
			timeStamp = ((AppWidgetSkinList) m4x2DataManager.getListData()).mTimeStamp;
		} else {
			timeStamp = ((AppWidgetSkinList) m4x1DataManager.getListData()).mTimeStamp;
		}
		if (timeStamp != null) {
			getArgs.put("timestamp", timeStamp);
		}
	}

	@Override
	public TQTListDataList parseResponseData(TQTSimpleDataManager manager, InputStream is) throws IOException {
		if (manager.getCacheFileName() == Constants.APPWIDGETSKIN4X2_LIST_FILENAME) {
			return TianQiTongXmlParseUtils.parseAppWidgetSkinList(is, AppWidgetSkin.TYPE_4X2);
		} else {
			return TianQiTongXmlParseUtils.parseAppWidgetSkinList(is, AppWidgetSkin.TYPE_4X1);
		}
	}

	@Override
	public TQTListDataListItem[] getCustomTQTLisDataListItems(TQTSimpleDataManager manager) {
		if (manager.getCacheFileName() == Constants.APPWIDGETSKIN4X2_LIST_FILENAME) {
			AppWidgetSkin aws0 = AppWidgetSkin.getDefault1st4x2AppWidgetSkin();
			AppWidgetSkin aws1 = AppWidgetSkin.getDefault2nd4x2AppWidgetSkin();
			return new TQTListDataListItem[] { aws0, aws1 };
		} else {
			AppWidgetSkin aws0 = AppWidgetSkin.getDefault1st4x1AppWidgetSkin();
			return new TQTListDataListItem[] { aws0 };
		}
	}

	@Override
	public TQTListDataListItem makeLocalListItem(TQTSimpleDataManager manager, File f) {
		try {
			SkinCfg sc = TianQiTongAppWidgetSkinManager.getCfg(f);
			// 找不到cfg文件，或者版本号大于2，跳过。
			if (sc == null || sc.Version > 2) {
				return null;
			}
		} catch (ZipException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			return null;
		}
		return AppWidgetSkin.makeLocalAppWidgetSkin(f);
	}

	@Override
	public File getSDDir(TQTSimpleDataManager manager) {
		if (manager.getCacheFileName() == Constants.APPWIDGETSKIN4X2_LIST_FILENAME) {
			return Utility.getAppWidget4x2Dir();
		} else {
			return Utility.getAppWidget4x1Dir();
		}
	}

	@Override
	public void newHandler(Looper looper) {
		m4x2DataManager.newHandler(looper);
		m4x1DataManager.newHandler(looper);
	}

	public TQTSimpleDataManager get4x2DataManager() {
		return m4x2DataManager;
	}

	public TQTSimpleDataManager get4x1DataManager() {
		return m4x1DataManager;
	}

}
