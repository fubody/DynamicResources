package sina.mobile.tianqitong.contentprovider;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import sina.mobile.tianqitong.service.TianQiTongService;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;

public class TqtContentProvider extends ContentProvider {

	private static final String AUTHORITY = "sina.mobile.tianqitong";

	private static final int URI_TYPE_IMAGE_FILE = 0;

	private static final String URI_PATH_IMAGE_FILE = "image";

	private static final UriMatcher mUriMatcher;
	static {
		mUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		mUriMatcher.addURI(AUTHORITY, URI_PATH_IMAGE_FILE + "/*", URI_TYPE_IMAGE_FILE);
	}

	@Override
	public boolean onCreate() {
		return true;
	}

	public static final Uri getImageFileUri(String filename) {
		return Uri.parse("content://" + AUTHORITY + "/" + URI_PATH_IMAGE_FILE + "/" + filename);
	}

	@Override
	public String getType(Uri uri) {
		switch (mUriMatcher.match(uri)) {
		case URI_TYPE_IMAGE_FILE: {
			return "vnd.android.cursor.item" + "/image/* ";
		}
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}

	}

	/*
	 * 
	 * 目前不需要增删改查操作。
	 */

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		throw new UnsupportedOperationException();
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		throw new UnsupportedOperationException();
	}

	@Override
	public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {

		File cache = getContext().getFilesDir();

		File f = null;

		switch (mUriMatcher.match(uri)) {
		case URI_TYPE_IMAGE_FILE: {
			String path = uri.getEncodedPath();
			int idx = path.lastIndexOf('/');
			String fn = path.substring(idx + 1);
			f = new File(cache, fn);
		}
			break;
		default:
			throw new IllegalArgumentException("Unknown URI " + uri);
		}

		int imode = 0;
		if (mode.contains("w")) {
			throw new UnsupportedOperationException();
		}
		if (mode.contains("r")) {
			imode |= ParcelFileDescriptor.MODE_READ_ONLY;
		}

		if (mode.contains("+")) {
			throw new UnsupportedOperationException();
		}
		return ParcelFileDescriptor.open(f, imode);
	}
}
