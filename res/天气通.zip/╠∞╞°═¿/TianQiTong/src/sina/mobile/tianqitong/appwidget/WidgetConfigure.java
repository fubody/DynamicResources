package sina.mobile.tianqitong.appwidget;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.citymanager.CitySelector;
import sina.mobile.tianqitong.service.TianQiTongNotification;
import sina.mobile.tianqitong.service.TianQiTongService;
import sina.mobile.tianqitong.service.model.WeatherInfo;
import sina.mobile.tianqitong.service.utility.SPUtility;
import sina.mobile.tianqitong.service.utility.TianQiTongLog;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;

/**
 * 这个Acitivyt“理论上”是给Widget进行配置用的。<br>
 * 实际上，目前这个类负责的是，如果是刚安装的天气通，引导用户选择城市。<br>
 * 这个Activity是全透明的。
 * 
 * @author 黄恪
 * 
 */
public class WidgetConfigure extends Activity {

	int _widgetId;
	public static WeatherInfo gWeatherInfo;

	public void onCreate(Bundle b) {
		super.onCreate(b);
		TianQiTongLog.addNormalLog("widgetconfigure start");
		Intent intent = getIntent();
		Bundle extras = intent.getExtras();
		if (extras != null) {
			_widgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
		}

	}

	public void onResume() {
		super.onResume();
		// 用户不是第一次运行天气通，告知系统Widget创建成功
		// 然后关掉自己。
		Intent resultValue = new Intent();
		resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, _widgetId);
		setResult(RESULT_OK, resultValue);
		finish();
	}

	public void onActivityResult(int requestCode, int responseCode, Intent data) {
		switch (responseCode) {
		case Activity.RESULT_OK: {
			if (SPUtility.getSPBoolean(this, R.string.boolean_is_1st_set_noti)) {
				// 初始话本地数据提醒
				TianQiTongNotification.init(this);
				TianQiTongNotification.setWeatherData(gWeatherInfo);
				TianQiTongNotification.applyNotificaiton(this, TianQiTongNotification.RETURN_WEATHER_NOTIFICATION);
				TianQiTongNotification.applyNotificaiton(this, TianQiTongNotification.RETURN_FESTIVAL_NOTIFICATION);
				TianQiTongNotification.applyNotificaiton(this, TianQiTongNotification.RETURN_JIEQI_NOTIFICATION);

				SPUtility.putSPBoolean(this, R.string.boolean_is_1st_set_noti, false);
			}

			Intent resultValue = new Intent();
			resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, _widgetId);
			setResult(RESULT_OK, resultValue);
			finish();
		}
			break;
		default: {
			// 用户取消，Widget创建失败。
			Intent resultValue = new Intent();
			resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, _widgetId);
			setResult(RESULT_CANCELED, resultValue);
			finish();
			stopService(new Intent(this, TianQiTongService.class));
		}
		}
	}

	public void onDestroy() {
		super.onDestroy();
	}

}
