package sina.mobile.tianqitong.service.frm;

import java.lang.ref.WeakReference;
import java.util.HashMap;

import android.os.Bundle;
import android.os.Message;

/**
 * 天气通两个模块之间就靠这个类里面的方法来传递消息或调用。
 * 
 * @author 黄恪
 * 
 */
public final class MsgUtility {
	private MsgUtility() {

	}

	// 用一个Message存请求、响应和通知。
	// message的what存类型，是请求、应答还是通知，
	// message的arg1存请求号，这个号全局唯一，用来在发送响应的时候从hashmap里找对应请求的相关参数，
	// （本来感觉存请求message就行了，结果发现Looper在处理了Message之后会把这个message回收，于是只好存Object[]了）
	// message的arg2存事件id。

	/*
	 * message的what存类型，是请求、应答还是通知
	 */
	public static final int MSG_WHAT_REQUEST = 0;
	public static final int MSG_WHAT_RESPONSE = 1;
// public static final int MSG_WHAT_NOTIFY = 2;

	/*
	 * message的arg1存请求号
	 */
	private static int _requestNum = 0;

	/*
	 * message的arg2存事件id
	 */
	// 最基础的功能，
	public static final int MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER = 0;
	public static final int MSG_ARG2_GET_PAST_WEATHER_INFO_XML_FROM_SERVER = MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER + 1;
	public static final int MSG_ARG2_SAVE_WEATHER_INFO_XML_TO_CACHE = MSG_ARG2_GET_PAST_WEATHER_INFO_XML_FROM_SERVER + 1;
	public static final int MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE = MSG_ARG2_SAVE_WEATHER_INFO_XML_TO_CACHE + 1;
	public static final int MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE_SYNCHRONIZED = MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE + 1;
	public static final int MSG_ARG2_DELETE_WEATHER_INFO_XML_IN_CACHE = MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE_SYNCHRONIZED + 1;
	public static final int MSG_ARG2_CHECK_NEW_VERSION = MSG_ARG2_DELETE_WEATHER_INFO_XML_IN_CACHE + 1;
	public static final int MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE_SYNCHRONIZED = MSG_ARG2_CHECK_NEW_VERSION + 1;
	public static final int MSG_ARG2_SAVE_NEW_APK = MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE_SYNCHRONIZED + 1;
	public static final int MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE = MSG_ARG2_SAVE_NEW_APK + 1;
	public static final int MSG_ARG2_DO = MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE + 1;
	public static final int MSG_ARG2_GET_CITYCODE_VIA_NAUTICA = MSG_ARG2_DO + 1;
	public static final int MSG_ARG2_DOWNLOAD = MSG_ARG2_GET_CITYCODE_VIA_NAUTICA + 1;
	public static final int MSG_ARG2_REFRESH = MSG_ARG2_DOWNLOAD + 1;
	public static final int MSG_ARG2_GET_SOUND_ENTITY_LIST_FROM_SERVER = MSG_ARG2_REFRESH + 1;
	public static final int MSG_ARG2_GET_APPWIDGET_SKIN_LIST_FROM_SERVER = MSG_ARG2_GET_SOUND_ENTITY_LIST_FROM_SERVER + 1;

	// 比较基础的功能，由最基础功能组成，
	public static final int MSG_ARG2_INIT_TIANQITONG = MSG_ARG2_GET_APPWIDGET_SKIN_LIST_FROM_SERVER + 1;
	public static final int MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_CACHE = MSG_ARG2_INIT_TIANQITONG + 1;
	public static final int MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_SERVER = MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_CACHE + 1;
	public static final int MSG_ARG2_DELETE_WEATHER_INFO = MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_SERVER + 1;
	public static final int MSG_ARG2_SEND_SUGGESION_2_WEIBO = MSG_ARG2_DELETE_WEATHER_INFO + 1;
	public static final int MSG_ARG2_SEND_SUGGESION_2_TQT = MSG_ARG2_SEND_SUGGESION_2_WEIBO + 1;
	public static final int MSG_ARG2_GET_ALL_PAST_WEATHER_INFO_FROM_SERVER = MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_SERVER + 1;
// 提醒

	// 尚未归类的功能
	public static final int MSG_ARG2_INIT_TTS = MSG_ARG2_GET_ALL_PAST_WEATHER_INFO_FROM_SERVER + 1;
	public static final int MSG_ARG2_PLAY_TTS = MSG_ARG2_INIT_TTS + 1;
	public static final int MSG_ARG2_STOP_PLAYING_TTS = MSG_ARG2_PLAY_TTS + 1;
	public static final int MSG_ARG2_CHANGE_TTS_VOLUMN = MSG_ARG2_STOP_PLAYING_TTS + 1;
	public static final int MSG_ARG2_SCHEDULE_ALARM = MSG_ARG2_CHANGE_TTS_VOLUMN + 1;
	public static final int MSG_ARG2_UPDATE_APPWIDGET = MSG_ARG2_SCHEDULE_ALARM + 1;
	/**
	 * 用户行为请求id
	 */
	public static final int MSG_ARG2_USER_ACTION = MSG_ARG2_UPDATE_APPWIDGET + 1;
	/**
	 * 广告的请求id
	 */
	public static final int MSG_ARG2_AD_ACTION = MSG_ARG2_USER_ACTION + 1;
	public static final int MSG_ARG2_GET_AD_LIST_FROM_SERVER = MSG_ARG2_AD_ACTION + 1;

	public static final int MSG_ARG2_GET_SINA_RECOMMEND_LIST_FROM_SERVER = MSG_ARG2_GET_AD_LIST_FROM_SERVER + 1;

	public static final int MSG_WARNING_DO = MSG_ARG2_GET_SINA_RECOMMEND_LIST_FROM_SERVER + 1;
	public static final int MSG_ARG2_GET_WARNING_INFO_FROM_SERVER = MSG_WARNING_DO + 1;
	public static final int MSG_POST_WARNING_ADDRESS = MSG_ARG2_GET_WARNING_INFO_FROM_SERVER + 1;

	public static final int MSG_ARG2_GET_WEEK_RECOMMEND_LIST_FROM_SERVER = MSG_POST_WARNING_ADDRESS + 1;

	public static final int MSG_ARG2_SEND_ID_FOR_SERVER = MSG_ARG2_GET_WEEK_RECOMMEND_LIST_FROM_SERVER + 1;
	public static final int MSG_ARG2_SEND_CLICK_ID_FOR_SERVER = MSG_ARG2_SEND_ID_FOR_SERVER + 1;
	public static final int MSG_ARG2_SEND_WEEK_RECOMMEND_ID_FOR_SERVER = MSG_ARG2_SEND_CLICK_ID_FOR_SERVER + 1;
	public static final int MSG_ARG2_SEND_WEEK_CLICK_ID_FOR_SERVER = MSG_ARG2_SEND_WEEK_RECOMMEND_ID_FOR_SERVER + 1;

	// 架子用到的参数，该有的时候一定要有，不该有的时候一定不能有。
	public static final String MSG_DATA_KEY_BUNDLE_REQUEST_ARGS = "request_args";
	public static final String MSG_DATA_KEY_INT_RESPONSE_CODE = "response_code";
	public static final String MSG_DATA_KEY_INT_REF_REQUEST_NUM = "ref_request_num";
	public static final String MSG_DATA_KEY_INT_STEP = "int_step";
// public static final String MSG_DATA_KEY_STR_STEP = "str_step";
	public static final String MSG_DATA_KEY_STR_PROXY_HOST = "proxy_host";
	public static final String MSG_DATA_KEY_INT_PROXY_PORT = "proxy_port";
	public static final String MSG_DATA_KEY_STR_CITYCODE = "citycode";
	public static final String MSG_DATA_KEY_STR_WARNING_ADDRESS = "warning_address";
	public static final String MSG_DATA_KEY_WARNING_CITYCODE = "warningcitycode";
// public static final String MSG_DATA_KEY_STR_AUTO_LOCATED_CITYCODE = "auto_located_citycode";
	public static final String MSG_DATA_KEY_STRS_CITYCODES = "citycodes";
// public static final String MSG_DATA_KEY_BOOLEAN_FIRST_TIME = "first_time";
	public static final String MSG_DATA_KEY_STR_CITYNAME = "cityname";

	// 特定功能用到的的参数，该有的时候一定要有，不该有的时候也可以有。
	public static final String MSG_DATA_KEY_BOOLEAN_INIT_TIANQITONG_WITH_CACHE = "init_with_cache";
	public static final String MSG_DATA_KEY_STR_TOCKEN = "tocken";
	public static final String MSG_DATA_KEY_S_DATA = "data";
// public static final String MSG_DATA_KEY_FILE_DIR = "dir";
	public static final String MSG_DATA_KEY_FILE_FILE = "file";
	public static final String MSG_DATA_KEY_STR_IMEI = "imei";
	public static final String MSG_DATA_KEY_STR_VER = "ver";
	public static final String MSG_DATA_KEY_INT_SEND_FROM = "from";
	public static final String MSG_DATA_KEY_INT_NET_RETRY_TIMES = "net_retry";
	public static final String MSG_DATA_KEY_INT_DB_RETRY_TIMES = "db_retry";
	public static final String MSG_DATA_KEY_BOOLEAN_CITY_HASMORE = "wather_has_more";
	public static final String MSG_DATA_KEY_BOOLEAN_AW_JUST_UPDATE_BTN = "just_update_btn";
	public static final String MSG_DATA_KEY_HASHMAP_CITYCODES_2_WEATHERINFOS = "citycodes2weatherinfos";
	public static final String MSG_DATA_KEY_LONG_TIMEMILLISECOND = "millisecond";
	public static final String MSG_DATA_KEY_STR_MSG = "msg";
	public static final String MSG_DATA_KEY_STR_URL = "url";
	public static final String MSG_DATA_KEY_BOOLEAN_HAS_NEW_VERSION = "has_new_version";
	public static final String MSG_DATA_KEY_STR_CONFIGURE = "configure";
	public static final String MSG_DATA_KEY_STR_CONFIGFILE = "configfile";
	public static final String MSG_DATA_KEY_STR_CONTACT = "contact";
	public static final String MSG_DATA_KEY_STR_RESOLUTION = "resolution";
	public static final String MSG_DATA_KEY_STR_ABSOLUTE_PATH = "path";
	public static final String MSG_DATA_KEY_INT_PAGE_NO = "page_no";
	public static final String MSG_DATA_KEY_INT_PAGE_SIZE = "page_size";
	public static final String MSG_DATA_KEY_INT_AWVER = "awver";
	public static final String MSG_DATA_KEY_STR_AWTYPE = "awtype";
	public static final String MSG_DATA_KEY_STR_TIMESTAMP = "timestamp";
	public static final String MSG_DATA_KEY_PARCELABLE_APPWIDGET = "appwidget_remoteviews";
	public static final String MSG_DATA_KEY_INT_CLICK_ID = "click_id";
	public static final String MSG_DATA_KEY_BOOLEAN_AW_UPDATE_CLOCK = "update_clock";
	public static final String MSG_DATA_KEY_INT_WEEK_RECOMMEND_CLICK_ID = "week_click_id";
	public static final String MSG_DATA_KEY_STR_PAGENO = "page_no";

	/**
	 * 用户行为-xml行为内容
	 */
	public static final String MSG_DATA_KEY_USER_ACTION_CONTENT = "user_key_action_content";

	public static final String MSG_DATA_KEY_S_HTTP_RESPONSE_DATA = "http_response_data";
	public static final String MSG_DATA_KEY_STR_HTTP_METHOD = "http_method";
	public static final String MSG_DATA_KEY_BYTES_HTTP_POST_DATA = "http_post_data";
	public static final String MSG_DATA_KEY_S_HTTP_GET_ARGS = "http_get_args";
	public static final String MSG_DATA_KEY_STR_HTTP_HOST = "http_host";
	public static final String MSG_DATA_KEY_STR_HTTP_PATH = "http_host_path";

	// 返回Bundle里面的返回号
	public static final int RESPONSE_CODE_SUCCESSFUL = 0;
	public static final int RESPONSE_CODE_NETWORK_DOWN = 1;
	public static final int RESPONSE_CODE_SERVER_DOWN = 2;
	public static final int RESPONSE_CODE_STORAGE_ERROR = 3;
// public static final int RESPONSE_CODE_WRITE_FILE_FAILED = 3;
// public static final int RESPONSE_CODE_READ_CACHE_FAILED_NO_SUCH_FILE = 4;
// public static final int RESPONSE_CODE_READ_FILE_FAILED = 5;
// public static final int RESPONSE_CODE_COMMON_FAILED = 6;
	public static final int RESPONSE_CODE_USER_CANCELED = 7;
	public static final int RESPONSE_CODE_NO_LOCATION_PROVIDER = 8;
	public static final int RESPONSE_CODE_LOCATE_TIME_OUT = 9;
	public static final int RESPONSE_CODE_FAILED_CAN_NOT_DO_IT_AGAIN = 10;
	public static final int RESPONSE_CODE_BAD_XML = 11;

// public static final String STEP_CODE_PAUSED = "paused";
// public static final String STEP_CODE_RESUMED = "resumed";

	// 存下的请求Object[]的索引号
	private static final int REQUEST_IDX_INT_EVENT_ID = 0;
	private static final int REQUEST_IDX_BUNDLE_ARGS = 1;
	private static final int REQUEST_IDX_WR_SENDER = 2;

	// #ifdef DEBUG_MSG
// @
// @ private static final HashMap<Integer, String> _arg2Dict = new HashMap<Integer, String>();
// @ static {
// @ _arg2Dict.put(MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER, "MSG_ARG2_GET_WEATHER_INFO_XML_FROM_SERVER");
// @ _arg2Dict.put(MSG_ARG2_SAVE_WEATHER_INFO_XML_TO_CACHE, "MSG_ARG2_SAVE_WEATHER_INFO_XML_TO_CACHE");
// @ _arg2Dict.put(MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE, "MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE");
// @ _arg2Dict.put(MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE_SYNCHRONIZED, "MSG_ARG2_GET_WEATHER_INFO_FROM_CACHE_SYNCHRONIZED");
// @ _arg2Dict.put(MSG_ARG2_DELETE_WEATHER_INFO_XML_IN_CACHE, "MSG_ARG2_DELETE_WEATHER_INFO_XML_IN_CACHE");
// @ _arg2Dict.put(MSG_ARG2_CHECK_NEW_VERSION, "MSG_ARG2_CHECK_NEW_VERSION");
// @ _arg2Dict.put(MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE_SYNCHRONIZED, "MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE_SYNCHRONIZED");
// @ _arg2Dict.put(MSG_ARG2_DOWNLOAD, "MSG_ARG2_DOWNLOAD");
// @ _arg2Dict.put(MSG_ARG2_SAVE_NEW_APK, "MSG_ARG2_SAVE_NEW_APK");
// @ _arg2Dict.put(MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE, "MSG_ARG2_GET_NEW_VERSION_INFO_FROM_CACHE");
// @ _arg2Dict.put(MSG_ARG2_DO, "MSG_ARG2_DO");
// @ _arg2Dict.put(MSG_ARG2_GET_CITYCODE_VIA_NAUTICA, "MSG_ARG2_GET_CITYCODE_VIA_NAUTICA");
// @
// @ _arg2Dict.put(MSG_ARG2_INIT_TIANQITONG, "MSG_ARG2_INIT_TIANQITONG");
// @ _arg2Dict.put(MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_CACHE, "MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_CACHE");
// @ _arg2Dict.put(MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_SERVER, "MSG_ARG2_GET_ALL_WEATHER_INFO_FROM_SERVER");
// @ _arg2Dict.put(MSG_ARG2_DELETE_WEATHER_INFO, "MSG_ARG2_DELETE_WEATHER_INFO");
// @ _arg2Dict.put(MSG_ARG2_SEND_SUGGESION_2_WEIBO, "MSG_ARG2_SEND_SUGGESION_2_WEIBO");
// @ _arg2Dict.put(MSG_ARG2_SEND_SUGGESION_2_TQT, "MSG_ARG2_SEND_SUGGESION_2_TQT");
// @
// @ _arg2Dict.put(MSG_ARG2_INIT_TTS, "MSG_ARG2_INIT_TTS");
// @ _arg2Dict.put(MSG_ARG2_PLAY_TTS, "MSG_ARG2_PLAY_TTS");
// @ _arg2Dict.put(MSG_ARG2_STOP_PLAYING_TTS, "MSG_ARG2_STOP_PLAYING_TTS");
// @ _arg2Dict.put(MSG_ARG2_CHANGE_TTS_VOLUMN, "MSG_ARG2_CHANGE_TTS_VOLUMN");
// @ _arg2Dict.put(MSG_ARG2_SCHEDULE_ALARM, "MSG_ARG2_SCHEDULE_ALARM");
// @ }
// @
// @ private static final HashMap<Integer, String> _responseCodeDict = new HashMap<Integer, String>();
// @ static {
// @ _responseCodeDict.put(RESPONSE_CODE_SUCCESSFUL, "RESPONSE_CODE_SUCCESSFUL");
// @ _responseCodeDict.put(RESPONSE_CODE_NETWORK_DOWN, "RESPONSE_CODE_NETWORK_DOWN");
// @ _responseCodeDict.put(RESPONSE_CODE_SERVER_DOWN, "RESPONSE_CODE_SERVER_DOWN");
// @ _responseCodeDict.put(RESPONSE_CODE_BAD_XML, "RESPONSE_CODE_BAD_XML");
// @ _responseCodeDict.put(RESPONSE_CODE_STORAGE_ERROR, "RESPONSE_CODE_STORAGE_ERROR");
// @ _responseCodeDict.put(RESPONSE_CODE_USER_CANCELED, "RESPONSE_CODE_USER_CANCELED");
// @ _responseCodeDict.put(RESPONSE_CODE_NO_LOCATION_PROVIDER, "RESPONSE_CODE_NO_LOCATION_PROVIDER");
// @ _responseCodeDict.put(RESPONSE_CODE_LOCATE_TIME_OUT, "RESPONSE_CODE_LOCATE_TIME_OUT");
// @ }
// @
// @ private static String request2String(int requsetNum, int eventId, Bundle args, WeakReference<MsgResponseHandler> sender, MsgRequestExecutor reciever) {
// @ StringBuilder sb = new StringBuilder();
// @
// @ sb.append("===============REQUEST: " + requsetNum + "\n");
// @ sb.append("event: " + _arg2Dict.get(eventId) + "\n");
// @ sb.append("args: \n");
// @ for (String key : args.keySet()) {
// @ sb.append(" " + key + " =");
// @ Object v = args.get(key);
// @ if (v instanceof Object[]) {
// @ v = java.util.Arrays.toString((Object[]) v);
// @ }
// @ sb.append(" " + v + "\n");
// @ }
// @
// @ sb.append("from: ");
// @ if (sender == null || sender.get() == null) {
// @ sb.append("null\n");
// @ } else {
// @ String t = sender.get().toString();
// @ t = sina.mobile.tianqitong.service.utility.Utility.split(t, '@')[0];
// @ String[] tt = sina.mobile.tianqitong.service.utility.Utility.split(t, '.');
// @ t = tt[tt.length - 1];
// @ sb.append(t + "\n");
// @ }
// @
// @ String t = reciever.toString();
// @ t = sina.mobile.tianqitong.service.utility.Utility.split(t, '@')[0];
// @ String[] tt = sina.mobile.tianqitong.service.utility.Utility.split(t, '.');
// @ t = tt[tt.length - 1];
// @ sb.append("to: " + t + "\n\n");
// @
// @ return sb.toString();
// @ }
// @
// @ private static String response2String(int requestNum, Bundle data) {
// @ StringBuilder sb = new StringBuilder();
// @ sb.append("==============RESPONSE: " + requestNum + "\n");
// @ sb.append("datas: \n");
// @ for (String key : data.keySet()) {
// @ sb.append(" " + key + " =");
// @ if (key.equals(MSG_DATA_KEY_INT_RESPONSE_CODE)) {
// @ String tmp = _responseCodeDict.get(data.get(key));
// @ if (tmp == null) {
// @ tmp = key + "";
// @ }
// @ sb.append(" " + tmp + "\n");
// @ } else {
// @ Object v = data.get(key);
// @ if (v instanceof Object[]) {
// @ v = java.util.Arrays.toString((Object[]) v);
// @ }
// @ sb.append(" " + v + "\n");
// @ }
// @
// @ }
// @ sb.append("\n");
// @ return sb.toString();
// @ }
// @
// @ private static String request2String(Object[] request) {
// @ WeakReference<MsgResponseHandler> wr = (WeakReference<MsgResponseHandler>) request[REQUEST_IDX_WR_SENDER];
// @ Bundle requestArgs = (Bundle) request[REQUEST_IDX_BUNDLE_ARGS];
// @ int eventId = ((Integer) request[REQUEST_IDX_INT_EVENT_ID]).intValue();
// @
// @ StringBuilder sb = new StringBuilder();
// @ sb.append(" REQUEST: \n");
// @ sb.append("  event: " + _arg2Dict.get(eventId) + "\n");
// @ if (wr != null) {
// @ sb.append("  sender: " + wr.get());
// @ } else {
// @ sb.append("  sender: null");
// @ }
// @ sb.append("\n");
// @ sb.append("  requestArgs: \n");
// @ for (String key : requestArgs.keySet()) {
// @ sb.append("   " + key + " =");
// @ Object v = requestArgs.get(key);
// @ if (v instanceof Object[]) {
// @ v = java.util.Arrays.toString((Object[]) v);
// @ }
// @ sb.append(" " + v + "\n");
// @ }
// @ sb.append("\n");
// @ return sb.toString();
// @
// @ }
// @
// @ private static String notify2String(int requestNum, Bundle data) {
// @ StringBuilder sb = new StringBuilder();
// @ sb.append("================NOTIFY: " + requestNum + "\n");
// @ sb.append("datas: \n");
// @ for (String key : data.keySet()) {
// @ sb.append(" " + key + " =");
// @ Object v = data.get(key);
// @ if (v instanceof Object[]) {
// @ v = java.util.Arrays.toString((Object[]) v);
// @ }
// @ sb.append(" " + v + "\n");
// @ }
// @ sb.append("\n");
// @ return sb.toString();
// @ }
// @
	// #endif

	/*
	 * 请求号到请求的哈希表
	 */
	private static final HashMap<Integer, Object[]> _requestNumMessageMap = new HashMap<Integer, Object[]>();

	/**
	 * 向reciever发送请求。强制要求传入一个WeakReference作为sender，坚决避免传入匿名内部类。<br>
	 * 由于使用弱引用，匿名内部类一旦脱离创建的位置，就会被gc掉。<br>
	 * 向reciever发送eventId请求，参数是args，返回的时候使用sender。
	 * 
	 * @param eventId
	 * @param args
	 * @param sender
	 * @param reciever
	 * @return 请求的requestNum，取消用的。
	 */
	public static final int sendRequest(int eventId, Bundle args, WeakReference<MsgResponseHandler> sender, MsgRequestExecutor reciever) {
		return sendRequest(eventId, args, sender, reciever, -1);
	}

	public static final int sendRequest(int eventId, Bundle args, WeakReference<MsgResponseHandler> sender, MsgRequestExecutor reciever, int refRequestNum) {
		synchronized (_requestNumMessageMap) {
			if (_requestNumMessageMap.get(_requestNum) != null) {
				throw new IllegalStateException();
			}
			// #ifdef DEBUG_MSG
// @ sina.mobile.tianqitong.service.utility.TianQiTongLog.addMsgLog(request2String(_requestNum, eventId, args, sender, reciever));
			// #endif

			if (refRequestNum != -1) {
				args.putInt(MSG_DATA_KEY_INT_REF_REQUEST_NUM, refRequestNum);
			}

			Message msg = Message.obtain();
			msg.what = MSG_WHAT_REQUEST;
			Bundle b = msg.getData();
			b.clear();
			b.putAll(args);
			msg.setData(b);
			msg.arg1 = _requestNum;
			_requestNum++;
			msg.arg2 = eventId;

			Object[] tmpreq = new Object[3];
			tmpreq[REQUEST_IDX_INT_EVENT_ID] = Integer.valueOf(eventId);
			tmpreq[REQUEST_IDX_BUNDLE_ARGS] = args;
			tmpreq[REQUEST_IDX_WR_SENDER] = sender;

			_requestNumMessageMap.put(msg.arg1, tmpreq);
			reciever.execute(msg);

			return _requestNum - 1;

		}
	}

//
// /**
// * 取消功能不靠谱。<br>
// * 例如，取单个城市数据，操作细分为：从网上取数据，存数据，解析数据保存到内存。<br>
// * 假设，数据已经存到缓存了，此时取消，表示用户希望整个更新单个城市这个操作被取消掉。但是原有数据已经不存在了。不可能取消。<br>
// * 除非规定某几个操作不可被取消。还得考虑一下......<br>
// * 进而，还必须给每个操作的处理上，加上对取消的处理。工程量比较大。<br>
// * 个人感觉，为如此小的需求大动干戈必要性不大。
// */
// private static final HashSet<Integer> _canceledRequest = new HashSet<Integer>();
//
// /**
// * 取消某条请求。
// *
// * @param requestNum
// */
// public static final void cancelRequest(int requestNum) {
// synchronized (_requestNumMessageMap) {
// if (_requestNumMessageMap.containsKey(requestNum)) {
// // 标记取消
// _canceledRequest.add(requestNum);
// } else {
// // 已经被返回了。不能取消。
// }
// }
// }
//
// /**
// * 判断一类事件是否还在执行没被返回。<br>
// * 是通过id号判断的，所以，只是判断类型，不是判断某条（某条事件的话应该用requestNum判断）。<br>
// *
// * @param eventId
// * @return
// */
// public static final boolean isInProcess(int eventId) {
//
// for (Object[] r : _requestNumMessageMap.values()) {
// int id = ((Integer) r[REQUEST_IDX_INT_EVENT_ID]).intValue();
//
// if (id == eventId) {
// return true;
// }
// }
// return false;
// }
//
// /**
// * 取消一系列相关的请求。
// */
// public static final void cancelRequstChain(int requestNum) {
// synchronized (_requestNumMessageMap) {
// if (_requestNumMessageMap.containsKey(requestNum)) {
// // 标记取消
// _canceledRequest.add(requestNum);
//
// // 在一次循环中新取消的请求数
// int newCanceled = 0;
//
// do {
// newCanceled = 0;
// // 遍历所有还存在的请求
// for (Integer curRequestNum : _requestNumMessageMap.keySet()) {
// // 取当前请求引用的请求号
// Object[] request = _requestNumMessageMap.get(curRequestNum);
// int refRequestNum = ((Bundle) request[REQUEST_IDX_BUNDLE_ARGS]).getInt(MSG_DATA_KEY_INT_REF_REQUEST_NUM, -1);
//
// if (refRequestNum != -1 && _canceledRequest.contains(refRequestNum)) {
// // 如果请求中有引用别的请求号，并且被引用的这个请求号被标记为取消，
// // 则把当前这个请求号标记为取消，
// _canceledRequest.add(curRequestNum);
// // 记录新找到一个要取消的请求。
// newCanceled++;
// }
// }
// // 只要还能找到需要取消的请求，就循环找下去。
// } while (newCanceled != 0);
//
// } else {
// // 已经被返回了。不能取消。
// }
// }
// }

	/**
	 * 发送响应。仅需要两个参数，请求号，和返回数据。<br>
	 * 当发送了响应之后，请求就从哈希表中被清除了。
	 * 
	 * @param requestNum
	 * @param data
	 */
	public static final boolean sendResponse(int requestNum, Bundle data) {

		synchronized (_requestNumMessageMap) {
			// #ifdef DEBUG_MSG
// @ sina.mobile.tianqitong.service.utility.TianQiTongLog.addMsgLog(response2String(requestNum, data));
			// #endif
			Object[] request = _requestNumMessageMap.get(requestNum);

			if (request == null) {
				// TODO 不应该有这个判断。在发送意见和建议的时候，偶尔会出现这种情况。原因待查。
				System.out.println("null request!!!");
				return false;
			}
			// #ifdef DEBUG_MSG
// @ sina.mobile.tianqitong.service.utility.TianQiTongLog.addMsgLog(request2String(request));
			// #endif
			_requestNumMessageMap.remove(requestNum);
			WeakReference<MsgResponseHandler> wr = (WeakReference<MsgResponseHandler>) request[REQUEST_IDX_WR_SENDER];

			if (wr != null) {
				MsgResponseHandler sender = wr.get();

				if (sender != null) {
					Message msg = Message.obtain();
					msg.what = MSG_WHAT_RESPONSE;
					Bundle b = msg.getData();
					b.clear();
					b.putBundle(MSG_DATA_KEY_BUNDLE_REQUEST_ARGS, (Bundle) request[REQUEST_IDX_BUNDLE_ARGS]);
					b.putAll(data);
					msg.setData(b);
					msg.arg1 = requestNum;
					msg.arg2 = ((Integer) request[REQUEST_IDX_INT_EVENT_ID]).intValue();

					sender.handle(msg);
					return true;
				}
			}
			return false;

		}

	}

	/*
	 * 下面是目前无用的代码。黄恪写着用来琢磨2.0用的。欢迎拍砖。
	 */

}
