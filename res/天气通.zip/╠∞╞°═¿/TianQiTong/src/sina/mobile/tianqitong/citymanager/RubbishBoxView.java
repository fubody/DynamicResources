package sina.mobile.tianqitong.citymanager;

import sina.mobile.tianqitong.R;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class RubbishBoxView extends LinearLayout implements DropTarget {

	public RubbishBoxView(Context context) {
		super(context);

	}

	// private ImageView cannotBox = null;
	private ImageView rubbish_box = null;

// private TextView cityUpdate = null;

	public RubbishBoxView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	protected void onFinishInflate() {

		rubbish_box = (ImageView) findViewById(R.id.rubbish_box);

	}

	boolean isOnlyOne;

	public void initViewState(boolean isOnlyOne) {
		this.isOnlyOne = isOnlyOne;
		if (isOnlyOne) {
			rubbish_box.setImageResource(R.drawable.edit_open);

		} else {
			rubbish_box.setImageResource(R.drawable.rubbish_close);
		}
	}

	@Override
	public void onDragEnter() {
		if (isOnlyOne) {
			rubbish_box.setImageResource(R.drawable.edit_enter);

		} else {
			rubbish_box.setImageResource(R.drawable.rubbish_open);
		}

	}

	@Override
	public void onDragExit() {
		if (isOnlyOne) {
			rubbish_box.setImageResource(R.drawable.edit_open);

		} else {
			rubbish_box.setImageResource(R.drawable.rubbish_close);
		}
	}

}
