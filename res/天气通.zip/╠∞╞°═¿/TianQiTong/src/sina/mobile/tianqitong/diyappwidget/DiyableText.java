package sina.mobile.tianqitong.diyappwidget;

import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.getTextValue;
import static sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.putTempTextValue;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getActivity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getDensity;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getTempOrCurrent;
import static sina.mobile.tianqitong.diyappwidget.DiyableAppWidgetPreviewManager.getWeatherInfo;
import sina.mobile.tianqitong.appwidget.WidgetProvider;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.AWType;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.DiyText;
import sina.mobile.tianqitong.diyappwidget.DiyAppWidgetAttrUtil.TextContent;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.text.TextPaint;
import android.view.View;
import android.widget.CompoundButton;

class DiyableText extends AbstractDiyableUnitWithItsOptionItemsAreRadioButtons<TextContent> {

	private int mTextSize;

	private DiyText mTextType;

	private String mText;

	private DiyableBG mBg;

	private TextPaint mTp;

	private boolean mHaveTheLongItem = false;

	public DiyableText(AWType type, int textSize, DiyText textType, DiyableBG bg, boolean haveTheLongItem) {
		super(type);
		mTextSize = textSize;
		mTextType = textType;
		mBg = bg;
		int textColor = mBg.getTextColor();
		mTp = new TextPaint();
		mTp.setColor(textColor);
		mTp.setTextSize(mTextSize);
		mTp.setAntiAlias(true);
		mHaveTheLongItem = haveTheLongItem;

		remakeParams();
	}

	@Override
	public void drawOnCanvas(Canvas c) {

		Rect r = getDrawBounds();
		int textColor = mBg.getTextColor();
		mTp.setColor(textColor);
		c.drawText(mText, r.left, r.bottom, mTp);

	}

	@Override
	public View[] makeOptions() {

		TextContent[] textContents = new TextContent[] { TextContent.CHN_YMD, TextContent.YMDW, TextContent.LongMDW, TextContent.MDW, TextContent.WEATHER, TextContent.TEMPERATURE,
				TextContent.HUMIDITY, TextContent.UV, TextContent.CWASH, TextContent.COLD, TextContent.COMFORT, TextContent.YMDW_CHN_MD, };
		if (!mHaveTheLongItem) {
			textContents = new TextContent[] { TextContent.CHN_YMD, TextContent.YMDW, TextContent.LongMDW, TextContent.MDW, TextContent.WEATHER, TextContent.TEMPERATURE, TextContent.HUMIDITY,
					TextContent.UV, TextContent.CWASH, TextContent.COLD, TextContent.COMFORT, };
		}

		String[] optionTexts = new String[textContents.length];

		for (int i = 0; i < textContents.length; i++) {
			optionTexts[i] = WidgetProvider.getContentUserDefinedAboutWeather(textContents[i], getActivity(), getWeatherInfo(), true);
			if (optionTexts[i] == null || optionTexts[i].length() == 0) {
				optionTexts[i] = WidgetProvider.getContentUserDefinedAboutDate(textContents[i], getActivity());
			}
			if (optionTexts[i] == null) {
				optionTexts[i] = textContents[i].toString();
			}
		}

		return makeRadioOptions(textContents, optionTexts);
	}

	@Override
	public void putTempValue(TextContent tempValue) {
		putTempTextValue(getActivity(), getType(), mTextType, tempValue);

	}

	@Override
	public Rect getTouchableBounds() {
		Rect r = getDrawBounds();
		r.bottom += (7f * getDensity());
		r.top -= (7f * getDensity());
		return r;
	}

	@Override
	protected Rect doMeasureDrawRect() {

		Rect r = new Rect();
		mTp.getTextBounds(mText, 0, mText.length(), r);

		offsetRect(r);

		return r;

	}

	@Override
	protected void remakeParams() {

		super.remakeParams();

		String text = WidgetProvider.getContentUserDefinedAboutWeather(getTempValue(), getActivity(), getWeatherInfo(), false);
		if (text == null || text.length() == 0) {
			text = WidgetProvider.getContentUserDefinedAboutDate(getTempValue(), getActivity());
		}

		if (mText == null || !mText.equals(text)) {
			mText = text;
		}

	}

	public final void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

		super.onCheckedChanged(buttonView, isChecked);
		String text = WidgetProvider.getContentUserDefinedAboutWeather(getTempValue(), getActivity(), getWeatherInfo(), false);
		if (text == null || text.length() == 0) {
			text = WidgetProvider.getContentUserDefinedAboutDate(getTempValue(), getActivity());
		}

		if (mText == null || !mText.equals(text)) {
			mText = text;
		}
	}

	@Override
	protected TextContent getValueFromTempSPFile() {
		return getTextValue(getActivity(), getType(), getTempOrCurrent(), mTextType);
	}

	@Override
	public String getOptionsTitle() {
		return "设置文字区域";
	}
}
