package sina.mobile.tianqitong.appwidgetskinpkg;

import sina.mobile.tianqitong.service.model.WeatherInfo;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Button extends AbstractSkinLayoutUnit {

	private int Idx = -1;
	private String FunctionId = null;
	private String Src = null;
	private String StopPlayingSrc = null;
	private String PkgName = null;
	private String ActivityName = null;
	private String IntoClock = null;

	public int getIdx() {
		return Idx;
	}

	public String getFuncitonId() {
		return FunctionId;
	}
	
	public String getIntoClock() {
		return IntoClock;
	}

	public String getStopPlayingSrc() {
		return StopPlayingSrc;
	}

	public String getSrc() {
		return Src;
	}

	public String getPkgName() {
		return PkgName;
	}

	public String getActivityName() {
		return ActivityName;
	}

	protected Button(AppWidgetSkin aws) {
		super(aws);
	}

	@Override
	protected boolean setSubValue(String attrName, String attrValue) {
		if (attrName.equals("Idx")) {
			Idx = Integer.parseInt(attrValue);
		} else if (attrName.equals("FunctionId")) {
			FunctionId = attrValue;
		} else if (attrName.equals("Src")) {
			Src = attrValue;
		} else if (attrName.equals("StopPlayingSrc")) {
			StopPlayingSrc = attrValue;
		} else if (attrName.equals("PkgName")) {
			PkgName = attrValue;
		} else if (attrName.equals("ActivityName")) {
			ActivityName = attrValue;
		} else if(attrName.equals("IntoClock")){
			IntoClock = attrValue;
		} else {
			return false;
		}
		return true;
	}

	@Override
	protected Rect doMeasureDrawRectWAndH() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	void draw(Canvas c) {
		// TODO Auto-generated method stub

	}

	@Override
	void setWeatherInfo(WeatherInfo wi) {
		// TODO Auto-generated method stub

	}

	@Override
	boolean isClockUnit() {
		// TODO Auto-generated method stub
		return false;
	}

}
