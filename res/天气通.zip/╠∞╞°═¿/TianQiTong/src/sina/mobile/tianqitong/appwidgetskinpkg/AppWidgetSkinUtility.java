package sina.mobile.tianqitong.appwidgetskinpkg;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import sina.mobile.tianqitong.R;
import sina.mobile.tianqitong.service.utility.Utility;
import android.content.Context;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/**
 * 本类静态方法或者跟且仅跟缓存文件和全局常量有关。<br>
 * 或者是纯粹的无状态的函数。
 * 
 * @author 黄恪
 * 
 */
public final class AppWidgetSkinUtility {

	private AppWidgetSkinUtility() {

	}

	static final String APPWIDGETSKIN_ICON_FILENAME = "icon.png";
	static final String APPWIDGETSKIN_WALLPAPER_FILENAME = "wallpaper.jpg";
	static final String APPWIDGETSKIN_NULL_FILENAME = "NULL";
	static final String APPWIDGETSKIN_LAND_DRAWABLE_CACHE_FILENAME = "land_drawable_cache.txt";
	static final String APPWIDGETSKIN_PORT_DRAWABLE_CACHE_FILENAME = "port_drawable_cache.txt";
	static final String APPWIDGETSKIN_LAND_LAYOUT_CACHE_FILENAME = "layout-land.xml";
	static final String APPWIDGETSKIN_PORT_LAYOUT_CACHE_FILENAME = "layout-port.xml";
	static final String APPWIDGETSKIN_LAND_DRAWABLE_DIRNAME = "drawable-land";
	static final String APPWIDGETSKIN_PORT_DRAWABLE_DIRNAME = "drawable-port";
	static final String APPWIDGETSKIN_CACHE_IDFILE = "skin.txt";

	static int mDensityDpi = 160;
	static float mDensity = 1f;

	static final void init(Context c) {
		WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		mDensity = dm.density;
		mDensityDpi = dm.densityDpi;
	}

	static final int px(String attrValue) {
		int dip = Integer.parseInt(attrValue);
		return (int) (((float) dip) * mDensity);
	}

	static final String num(int num) {
		return (num <= 9 ? "0" : "") + num + "";
	}

	static boolean checkCacheDir(File mZipSkinFile, File dir) {
		if ((!dir.exists()) || dir.isFile()) {
			return false;
		}
		File skintxt = new File(dir, APPWIDGETSKIN_CACHE_IDFILE);
		if ((!skintxt.exists()) || skintxt.isDirectory()) {
			return false;
		}

		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(skintxt));
			String fn = br.readLine();
			if (fn == null) {
				return false;
			}
			if (!fn.equals(mZipSkinFile.getName())) {
				return false;
			}
			long length = Long.parseLong(br.readLine());
			if (length != mZipSkinFile.length()) {
				return false;
			}
			long lastModified = Long.parseLong(br.readLine());
			if (lastModified != mZipSkinFile.lastModified()) {
				return false;
			}
			return true;

		} catch (Exception e) {
			return false;
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {

				}
			}
		}

	}

	public static final void releaseCacheDir(Context context, final int type) {

		File dir = context.getFilesDir();
		final String prefix;
		final File cacheDir;
		if (type == AppWidgetSkin.TYPE_4X2) {
			prefix = AppWidgetSkin.CACHE_4X2BMP_PREFIX;
			cacheDir = get4x2AppWidgetSkinCacheDir();
		} else if (type == AppWidgetSkin.TYPE_4X1) {
			prefix = AppWidgetSkin.CACHE_4X1BMP_PREFIX;
			cacheDir = get4x1AppWidgetSkinCacheDir();
		} else {
			prefix = "";
			cacheDir = null;
		}
		Utility.deleteDirectory(cacheDir);

		File[] fs = dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {

				if (name.startsWith(prefix) && name.endsWith(".png")) {
					return true;
				}
				return false;
			}
		});
		for (File f : fs) {
			f.delete();
		}
		fs = null;
	}

	static final void makeCacheDir(final Context context, final File mZipSkinFile, final File cacheDir) throws ZipException, IOException {

		String size = context.getString(R.string.size);
		String aspect = context.getString(R.string.aspect);
		String dpi = context.getString(R.string.dpi);

		if ((!mZipSkinFile.isFile()) || (!mZipSkinFile.exists())) {
			throw new IllegalArgumentException();
		}

		String[] zipEntryNames = new String[0];

		ZipFile pkgZipFile = null;

		pkgZipFile = new ZipFile(mZipSkinFile);

		{
			HashSet<String> zipEntryNameSet = new HashSet<String>();
			ArrayList<String> zipEntryNameList = new ArrayList<String>();

			// 遍历整个zip文件。

			Enumeration<? extends ZipEntry> e = pkgZipFile.entries();
			while (e.hasMoreElements()) {
				ZipEntry ze = e.nextElement();

				if (!ze.isDirectory()) {
					zipEntryNameList.add(ze.getName());
					zipEntryNameSet.add(ze.getName());
				}

			}

			if (!zipEntryNameSet.contains("cfg.xml")) {
				throw new IllegalArgumentException();
			}
			zipEntryNames = new String[zipEntryNameList.size()];
			zipEntryNameList.toArray(zipEntryNames);

		}

		HashMap<String, String[]> imageZEName2DirZENamesMap = new HashMap<String, String[]>();
		String[] layoutZENames = new String[0];
		{
			HashSet<String> layoutZENameSet = new HashSet<String>();
			HashMap<String, HashSet<String>> imageFn2DrawableDirSetMap = new HashMap<String, HashSet<String>>();
			for (int i = 0; i < zipEntryNames.length; i++) {
				String zename = zipEntryNames[i];

				if (zename.startsWith("layout")) {
					if (!zename.endsWith(".xml")) {
						throw new IllegalArgumentException();
					}
					layoutZENameSet.add(zename);
				} else if (zename.endsWith(".png")) {
					if (zename.equals(APPWIDGETSKIN_ICON_FILENAME)) {
						continue;
					}
					String[] tmp = Utility.split(zename, '/');
					if (tmp.length != 2) {
						throw new IllegalArgumentException();
					}
					String dir = tmp[0];
					String fn = tmp[1];

					HashSet<String> diral = imageFn2DrawableDirSetMap.get(fn);
					if (diral == null) {
						diral = new HashSet<String>();
						imageFn2DrawableDirSetMap.put(fn, diral);
					}
					diral.add(dir);
				}
			}
			if (layoutZENameSet.size() == 0) {
				throw new IllegalArgumentException();
			}
			layoutZENames = new String[layoutZENameSet.size()];
			layoutZENameSet.toArray(layoutZENames);

			for (String imageZEName : imageFn2DrawableDirSetMap.keySet()) {
				HashSet<String> DirZENameSet = imageFn2DrawableDirSetMap.get(imageZEName);
				String[] dirZENames = new String[DirZENameSet.size()];
				DirZENameSet.toArray(dirZENames);
				imageZEName2DirZENamesMap.put(imageZEName, dirZENames);
			}
		}

		{

			String portZipEntryName = getMatchingFilename(size, aspect, "port", dpi, layoutZENames);
			if (portZipEntryName != null) {

				BufferedReader br = null;
				BufferedWriter bw = null;
				try {

					File f = new File(cacheDir, APPWIDGETSKIN_PORT_LAYOUT_CACHE_FILENAME);
					f.delete();
					f.createNewFile();

					ZipEntry ze = pkgZipFile.getEntry(portZipEntryName);

					br = new BufferedReader(new InputStreamReader(pkgZipFile.getInputStream(ze), "utf-8"));
					bw = new BufferedWriter(new FileWriter(f));

					String line = br.readLine();
					while (line != null) {
						bw.append(line);
						bw.newLine();
						line = br.readLine();
					}
				} finally {
					if (br != null) {
						try {
							br.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					if (bw != null) {
						try {
							bw.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			}

			String landZipEntryName = getMatchingFilename(size, aspect, "land", dpi, layoutZENames);
			if (landZipEntryName != null) {
				BufferedReader br = null;
				BufferedWriter bw = null;
				try {

					File f = new File(cacheDir, APPWIDGETSKIN_LAND_LAYOUT_CACHE_FILENAME);
					f.delete();
					f.createNewFile();

					ZipEntry ze = pkgZipFile.getEntry(landZipEntryName);

					br = new BufferedReader(new InputStreamReader(pkgZipFile.getInputStream(ze), "utf-8"));
					bw = new BufferedWriter(new FileWriter(f));

					String line = br.readLine();
					while (line != null) {
						bw.append(line);
						bw.newLine();
						line = br.readLine();
					}
				} finally {
					if (br != null) {
						try {
							br.close();
						} catch (IOException e) {

						}
					}
					if (bw != null) {
						try {
							bw.close();
						} catch (IOException e) {

						}
					}
				}
			}

		}

		{

			File landDrawableCacheFile = new File(cacheDir, APPWIDGETSKIN_LAND_DRAWABLE_CACHE_FILENAME);
			File portDrawableCacheFile = new File(cacheDir, APPWIDGETSKIN_PORT_DRAWABLE_CACHE_FILENAME);

			BufferedWriter landbw = null;
			BufferedWriter portbw = null;
			try {
				landDrawableCacheFile.createNewFile();
				portDrawableCacheFile.createNewFile();
				landbw = new BufferedWriter(new FileWriter(landDrawableCacheFile));
				portbw = new BufferedWriter(new FileWriter(portDrawableCacheFile));
				Set<String> imageZENameSet = imageZEName2DirZENamesMap.keySet();
				String[] imageZENames = new String[imageZENameSet.size()];
				imageZENameSet.toArray(imageZENames);
				Arrays.sort(imageZENames);

				for (String imageZEName : imageZENames) {

					String[] dirZENames = imageZEName2DirZENamesMap.get(imageZEName);

					String portDirZipEntryName = getMatchingFilename(size, aspect, "port", dpi, dirZENames);
					if (portDirZipEntryName != null) {
						portbw.append(portDirZipEntryName);
						portbw.append("/");
						portbw.append(imageZEName);
						portbw.newLine();
					}

					String landDirZipEntryName = getMatchingFilename(size, aspect, "land", dpi, dirZENames);
					if (landDirZipEntryName != null) {
						landbw.append(landDirZipEntryName);
						landbw.append("/");
						landbw.append(imageZEName);
						landbw.newLine();
					}

				}
			} finally {
				if (portbw != null) {
					try {
						portbw.close();
					} catch (IOException e) {

					}
				}
				if (landbw != null) {
					try {
						landbw.close();
					} catch (IOException e) {

					}
				}

			}

		}

		File skintxt = new File(cacheDir, APPWIDGETSKIN_CACHE_IDFILE);
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(skintxt));
			bw.append(mZipSkinFile.getName());
			bw.newLine();
			bw.append(mZipSkinFile.length() + "");
			bw.newLine();
			bw.append(mZipSkinFile.lastModified() + "");
			bw.flush();
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	/*
	 * 
	 */

	/**
	 * 取得皮肤缓存文件所在的目录。
	 * 
	 * @return
	 */
	static final File get4x2AppWidgetSkinCacheDir() {
		File cacheDir = Environment.getExternalStorageDirectory();
		cacheDir = new File(cacheDir, "TianQiTong");
		cacheDir = new File(cacheDir, "AppWidgetSkinCache");
		cacheDir.mkdirs();
		return cacheDir;
	}

	static final File get4x1AppWidgetSkinCacheDir() {
		File cacheDir = Environment.getExternalStorageDirectory();
		cacheDir = new File(cacheDir, "TianQiTong");
		cacheDir = new File(cacheDir, "AppWidgetSkin4x1Cache");
		cacheDir.mkdirs();
		return cacheDir;
	}

	static final String getMatchingFilename(String size, String aspect, String orientation, String dpi, String[] filenames) {

		HashMap<String[], String> cfg2filenameMap = new HashMap<String[], String>();
		int IDX_SIZE = 0;
		int IDX_ASPECT = 1;
		int IDX_ORIENTATION = 2;
		int IDX_DPI = 3;

		HashSet<String> sizes = new HashSet<String>();
		sizes.add("small");
		sizes.add("normal");
		sizes.add("large");

		HashSet<String> aspects = new HashSet<String>();
		aspects.add("long");
		aspects.add("notlong");

		HashSet<String> orientations = new HashSet<String>();
		orientations.add("port");
		orientations.add("land");

		HashSet<String> dpis = new HashSet<String>();
		dpis.add("ldpi");
		dpis.add("mdpi");
		dpis.add("hdpi");

		for (String fn : filenames) {
			String filename = Utility.split(fn, '.')[0];
			String[] tmp = Utility.split(filename, '-');
			String[] tmpcfgs = new String[tmp.length - 1];
			System.arraycopy(tmp, 1, tmpcfgs, 0, tmpcfgs.length);

			String[] cfgs = new String[4];

			Arrays.fill(cfgs, "");

			for (String cfg : tmpcfgs) {
				if (sizes.contains(cfg)) {
					cfgs[IDX_SIZE] = cfg;
					continue;
				}
				if (aspects.contains(cfg)) {
					cfgs[IDX_ASPECT] = cfg;
					continue;
				}
				if (orientations.contains(cfg)) {
					cfgs[IDX_ORIENTATION] = cfg;
					continue;
				}
				if (dpis.contains(cfg)) {
					cfgs[IDX_DPI] = cfg;
					continue;
				}
			}

			cfg2filenameMap.put(cfgs, fn);

		}

		// 第一步，剔除跟当前配置有冲突的排版方案。
		{
			Iterator<Entry<String[], String>> iterator = cfg2filenameMap.entrySet().iterator();
			while (iterator.hasNext()) {
				String[] cur = iterator.next().getKey();
				if (cur[IDX_ASPECT].length() != 0 && (!cur[IDX_ASPECT].equals(aspect))) {
					iterator.remove();
				} else if (cur[IDX_ORIENTATION].length() != 0 && (!cur[IDX_ORIENTATION].equals(orientation))) {
					iterator.remove();
				} else if (cur[IDX_SIZE].length() != 0 && (!cur[IDX_SIZE].equals(size))) {
					iterator.remove();
				}
			}
		}

		if (cfg2filenameMap.size() == 0) {
			return null;
		}

		// 第二步，检查尺寸。
		// 如果，经过第一步剩下的布局中，任一一种布局，提到了尺寸，那么就剔除其余没提到的布局方案。
		// 否则，跳过尺寸比检查，进行第三步纵横比检查。
		// 第三步，检查纵横比。
		// 第四步，检查方向。
		{
			int[] cfgPriority = new int[] { IDX_SIZE, IDX_ASPECT, IDX_ORIENTATION };
			for (int ttcfg : cfgPriority) {
				HashMap<String[], String> tempAl = new HashMap<String[], String>();
				Iterator<Entry<String[], String>> iterator = cfg2filenameMap.entrySet().iterator();
				while (iterator.hasNext()) {
					Entry<String[], String> cure = iterator.next();
					String[] cur = cure.getKey();
					if (cur[ttcfg].length() != 0) {
						tempAl.put(cur, cure.getValue());
					}
				}
				if (tempAl.size() != 0) {
					cfg2filenameMap = tempAl;
				}
				if (cfg2filenameMap.size() == 0) {
					return null;
				}
			}
		}

		// 第五步，检查像素密度。
		// 如果剩下的布局中，有完全匹配的，那么就找到了；
		// 如果没有完全匹配的，那么优先选用没限定密度的方案；
		// 再没有，选用最高密度的方案。
		{
			for (String[] cur : cfg2filenameMap.keySet()) {
				if (cur[IDX_DPI].equals(dpi)) {
					return cfg2filenameMap.get(cur);
				}
			}
			for (String[] cur : cfg2filenameMap.keySet()) {
				if (cur[IDX_DPI].length() == 0) {
					return cfg2filenameMap.get(cur);
				}
			}
			for (String[] cur : cfg2filenameMap.keySet()) {
				if (cur[IDX_DPI].equals("hdpi")) {
					return cfg2filenameMap.get(cur);
				}
			}
			for (String[] cur : cfg2filenameMap.keySet()) {
				if (cur[IDX_DPI].equals("mdpi")) {
					return cfg2filenameMap.get(cur);
				}
			}
			for (String[] cur : cfg2filenameMap.keySet()) {
				if (cur[IDX_DPI].equals("ldpi")) {
					return cfg2filenameMap.get(cur);
				}
			}
		}

		// 仍然没找到。（貌似不可能到这里）
		return null;

	}

}
