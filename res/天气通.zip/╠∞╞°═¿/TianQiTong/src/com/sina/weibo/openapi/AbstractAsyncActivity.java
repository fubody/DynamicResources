package com.sina.weibo.openapi;

import java.io.File;
import java.util.HashMap;

import com.sina.weibo.openapi.net.HttpUtil;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import android.widget.Toast;

/**
 * 有联网操作的继承这个 activity
 * 
 * @author Administrator
 * 
 */
public abstract class AbstractAsyncActivity extends Activity {
	protected static final String TAG = AbstractAsyncActivity.class.getSimpleName();

	private ProgressDialog _progressDialog;

	@Override
	protected void onDestroy() {
		super.onDestroy();
		dismissProgressDialog();
		if (_progressDialog != null)
			_progressDialog.dismiss();
	}

	public void showProgressDialog(CharSequence message) {
		if (_progressDialog == null) {
			_progressDialog = ProgressDialog.show(this, null, message);
			_progressDialog.setIndeterminate(true);
		}

		_progressDialog.setMessage(message);
		_progressDialog.show();
	}

	public void dismissProgressDialog() {
		if (_progressDialog != null) {
			_progressDialog.dismiss();
		}
	}

	/**
	 * 检查网络链接
	 * 
	 * @return
	 */
	public boolean checkNetwork() {
		if (HttpUtil.checkNetworkAndHint(this) == 0) {
			return true;
		}
		return false;
	}
}
