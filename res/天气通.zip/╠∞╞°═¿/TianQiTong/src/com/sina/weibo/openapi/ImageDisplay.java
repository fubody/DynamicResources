package com.sina.weibo.openapi;

import java.io.File;
import java.io.IOException;

import sina.mobile.tianqitong.R;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

import com.sina.weibo.openapi.util.BitmapUtils;

public class ImageDisplay extends Activity implements OnClickListener {
	private Button btIvdelete, btBack;
	private View rotateBtns;
	private ImageView ivDisplayImage;
	private String temPath;
	private Uri imageUri = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weibo_imageviewer);
		Intent i = getIntent();
		temPath = i.getStringExtra("picPath");


// BitmapFactory.Options op = new BitmapFactory.Options();
// op.inSampleSize = 5;
		srcbmp = BitmapFactory.decodeFile(temPath);
		ivDisplayImage = (ImageView) findViewById(R.id.ivImage);
		ivDisplayImage.setImageBitmap(srcbmp);

		btBack = (Button) findViewById(R.id.btIvBack);
		btIvdelete = (Button) findViewById(R.id.btIvdelete);
		btBack.setOnClickListener(this);
		btIvdelete.setOnClickListener(this);
		rotateBtns = findViewById(R.id.ibTurnButtons);
		findViewById(R.id.ibTurnLeft).setOnClickListener(this);
		findViewById(R.id.ibTurnRight).setOnClickListener(this);

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btIvBack:
			File file;
			try {
				if (changedBmp != null) {// 说明没有对图片做处理
					file = BitmapUtils.saveBitmap(this, changedBmp);
					Intent intent = new Intent();
					intent.putExtra("picPath", file.getAbsolutePath());
					setResult(102, intent);
				}
				finish();
			} catch (IOException e) {
				e.printStackTrace();
			}

			break;
		case R.id.btIvdelete:

			setResult(RESULT_OK);
			finish();
			break;
		case R.id.ibTurnLeft:
			turnLeft();
			break;
		case R.id.ibTurnRight:
			turnRight();
			break;

		default:
			break;
		}
	}

	private boolean isRotate = false;
	private int rotateRate = 0;

	private void turnLeft() {
		rotateRate--;
		if (rotateRate == -4) {
			rotateRate = 0;
		}

		displayChangedBmp();
	}

	private Bitmap changedBmp;
	private Bitmap srcbmp;

	private void displayChangedBmp() {
		ivDisplayImage.setImageBitmap(null);
		if (changedBmp != null)
			changedBmp.recycle();
		if (rotateRate != 0) {
			int centerW = ivDisplayImage.getWidth() / 2;
			int centerH = ivDisplayImage.getHeight() / 2;
			// 向左旋转
			if (rotateRate == -1 || rotateRate == 3) {
				final Matrix m = new Matrix();
				m.setRotate(-90, centerW, centerH);
				m.postScale((float)srcbmp.getWidth()/(float)srcbmp.getHeight(), (float)srcbmp.getWidth()/(float)srcbmp.getHeight());
				changedBmp = Bitmap.createBitmap(srcbmp, 0, 0, srcbmp.getWidth(), srcbmp.getHeight(), m, true);
			} else if (rotateRate == 1 || rotateRate == -3) {// 向右旋转
				final Matrix m = new Matrix();
				m.postRotate(90, centerW, centerH);
				m.postScale((float)srcbmp.getWidth()/(float)srcbmp.getHeight(), (float)srcbmp.getWidth()/(float)srcbmp.getHeight());
				changedBmp = Bitmap.createBitmap(srcbmp, 0, 0, srcbmp.getWidth(), srcbmp.getHeight(), m, true);
			} else {// 旋转180度
				final Matrix m = new Matrix();
				m.postRotate(180);
				changedBmp = Bitmap.createBitmap(srcbmp, 0, 0, srcbmp.getWidth(), srcbmp.getHeight(), m, true);
			}

		} else {
			changedBmp = srcbmp.copy(srcbmp.getConfig(), true);
		}
		ivDisplayImage.setImageBitmap(changedBmp);
	}

	private void turnRight() {
		rotateRate++;
		if (rotateRate == 4) {
			rotateRate = 0;
		}
		displayChangedBmp();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			File file;
			try {
				if (changedBmp != null) {// 说明没有对图片做处理
					file = BitmapUtils.saveBitmap(this, changedBmp);
					Intent intent = new Intent();
					intent.putExtra("picPath", file.getAbsolutePath());
					setResult(102, intent);
				}
				finish();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
}
