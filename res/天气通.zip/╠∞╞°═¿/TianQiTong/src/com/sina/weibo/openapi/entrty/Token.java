package com.sina.weibo.openapi.entrty;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

public class Token implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1614656622189350728L;

	private static Token mToken = null;

// {
// "access_token": "ACCESS_TOKEN",
// "expires_in": 1234,
// "refresh_token": "REFRESH_TOKEN"
// }
	public static Token getInstance() {

		if (mToken == null) {
			throw new RuntimeException("没有进行token的初始化");
		}

		return mToken;
	}

	private Token() {

	}

	/**
	 * 这个构造方法只在获取token的时候用一次，其他的都不能用。
	 * 
	 * @param json
	 * @throws JSONException
	 */
	public Token(String json) throws JSONException {
		JSONObject jsonO;

		jsonO = new JSONObject(json);
		this.accessToken = jsonO.getString("access_token");
		this.expiresIn = jsonO.getString("expires_in");

		// 由于微博系统返回的json有问题没有refresh_token因此在这里只能做这样的处理 refresh_token无法正常使用
		try {
			this.refreshToken = jsonO.getString("refresh_token");
		} catch (JSONException e) {
			this.refreshToken = jsonO.getString("uid");
		}

		mToken = this;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public String getExpiresIn() {
		return expiresIn;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	private String accessToken;

	private String expiresIn;

	private String refreshToken;

	@Override
	public String toString() {
		return "accessToken:'" + accessToken + "',expiresIn:'" + expiresIn + "',refreshToken:'" + refreshToken + "'";
	}

}
