package com.sina.weibo.openapi.engine;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;

import android.content.Context;

public class ObtionTokenEngine extends BaseEngine {

	public ObtionTokenEngine(Context con) {
		super(con);

	}

	public String getAccessToken(HashMap<String, String> paramH) {

		if (paramH != null) {
			paramH.put("client_id", CLIENT_ID);
			paramH.put("client_secret", CLIENT_SECRET);
			paramH.put("grant_type", GRANT_TYPE);

		}

		String resultJsonStr = httpUtil.postRequest(NetConstants.URL_OAUTH_TOKEN, paramH);
		// String resultJsonStr = httpUtil.getTokenRequest( paramH.get("username"),paramH.get("password")).getAccessToken();

		if (resultJsonStr != null) {
			try {
				Token t = new Token(resultJsonStr);
				return t.getAccessToken();
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	public boolean requestAttentionTqt() {
		HashMap<String, String> paramH = new HashMap<String, String>();
		if (paramH != null) {
			paramH.put("access_token", Token.getInstance().getAccessToken());
			paramH.put("screen_name", "天气通");

		}

		String resultJsonStr = httpUtil.postRequest(NetConstants.URL_GUANZHU, paramH);
		if (resultJsonStr != null) {
			try {
				JSONObject jso = new JSONObject(resultJsonStr);
				String screnName = jso.getString("screen_name");

				if (screnName.equals("天气通")) {
					return true;
				}

			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public void clearData() {

	}

}
