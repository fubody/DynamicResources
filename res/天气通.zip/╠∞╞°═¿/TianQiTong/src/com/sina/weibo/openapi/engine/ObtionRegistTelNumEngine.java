package com.sina.weibo.openapi.engine;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;

import android.content.Context;

public class ObtionRegistTelNumEngine extends BaseEngine {

	public ObtionRegistTelNumEngine(Context con) {
		super(con);

	}

	public String getRegistNum() {
		HashMap<String, String> paramHashMap = new HashMap();

		paramHashMap.put("wm", "4534");
		String xmlStr = httpUtil.getRequest(NetConstants.URL_GET_REGIST, paramHashMap);
		String num = null;
		if (xmlStr != null)
			num = parseXmlStr(xmlStr);

		if (num == null) {
			num = "1069019555610194";
		}

		return num;
	}

	@Override
	public void clearData() {

	}

	private String parseXmlStr(String str) {
		String num = null;
		XmlPullParserFactory factory;
		XmlPullParser xpp;

		try {
			factory = XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			xpp = factory.newPullParser();
			xpp.setInput(new StringReader(str));
			int eventType = xpp.getEventType();

			lab: while (eventType != XmlPullParser.END_DOCUMENT) {

				switch (eventType) {
				case XmlPullParser.START_TAG: {

					if (xpp.getName().equals("cmcc")) {
						num = xpp.nextText();
						break lab;
					}
				}
				}
				eventType = xpp.next();
			}

		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return num;
	}
}
