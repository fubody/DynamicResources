package com.sina.weibo.openapi.util;

import sina.mobile.tianqitong.R;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class DialogUtil {

	public static void showAlertDialog(Context context, String strMsg, DialogInterface.OnClickListener clickListener) {
		if (context == null || strMsg == null) {
			return;
		}
		new AlertDialog.Builder(context).setTitle(R.string.app_name).setIcon(R.drawable.dialog_icon).setMessage(strMsg).setPositiveButton(R.string.ok, clickListener).show();
	}

	public static void showAlertDialog(Context context, int resId, DialogInterface.OnClickListener clickListener) {
		if (context == null) {
			return;
		}
		showAlertDialog(context, context.getResources().getString(resId), clickListener);
	}

	public static void showAlertDialog(Context context, String msg, int resPositiveId, int resNegativeId, DialogInterface.OnClickListener positiveListener,
			DialogInterface.OnClickListener negativeListener) {
		new AlertDialog.Builder(context).setTitle(R.string.app_name).setIcon(R.drawable.dialog_icon).setMessage(msg).setPositiveButton(resPositiveId, positiveListener)
				.setNegativeButton(resNegativeId, negativeListener).show();
	}

	public static void showAlertDialog(Context context, int msgResId, int resPositiveId, int resNegativeId, DialogInterface.OnClickListener positiveListener,
			DialogInterface.OnClickListener negativeListener) {
		new AlertDialog.Builder(context).setTitle(R.string.app_name).setIcon(R.drawable.dialog_icon).setMessage(msgResId).setPositiveButton(resPositiveId, positiveListener)
				.setNegativeButton(resNegativeId, negativeListener).show();
	}
}
