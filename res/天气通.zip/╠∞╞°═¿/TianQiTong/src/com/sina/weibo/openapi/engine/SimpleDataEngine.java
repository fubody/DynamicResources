package com.sina.weibo.openapi.engine;

import java.util.HashMap;

import android.content.Context;

public class SimpleDataEngine extends BaseEngine {

	public SimpleDataEngine(Context con) {
		super(con);
		
	}


	
	@Override
	public void clearData() {
	

	}

}
