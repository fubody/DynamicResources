package com.sina.weibo.openapi.engine;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;
import com.sina.weibo.openapi.entrty.UserInfo;
import com.sina.weibo.openapi.manager.DataStorageManager;

import android.content.Context;
import android.text.TextUtils;

public class AtFriendsEngine extends AccTokenBaseEngine {

	public AtFriendsEngine(Context con) {
		super(con);

	}

	private HashMap<String, ArrayList> hashMap = new HashMap();

	public ArrayList getAtFriendsList(String query) {

		ArrayList<String> list = new ArrayList();

		if (TextUtils.isEmpty(query))
			return list;

		query = query.trim();

		if (hashMap.containsKey(query)) {
			return hashMap.get(query);
		} else {

			HashMap<String, String> paramH = new HashMap();
			paramH.put("q", URLEncoder.encode(query));
			String resultJsonStr = getAtFriendsRequset(paramH);

			if (resultJsonStr != null) {
				try {
					JSONArray jsa = new JSONArray(resultJsonStr);
					for (int i = 0; i < jsa.length(); i++) {

						JSONObject jso = (JSONObject) jsa.get(i);
						list.add((String) jso.get("nickname"));
						System.out.println(jso.get("nickname"));
					}
					hashMap.put(query, list);

					return list;
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

		}

		return list;

	}

	private synchronized String getAtFriendsRequset(HashMap<String, String> paramH) {

		paramH.put("count", "30");
		paramH.put("type", "0");
		paramH.put("range", "0");
		addAcctoken(paramH);
		String resultJsonStr = httpUtil.getRequest(NetConstants.URL_GET_AT_FRIENDS, paramH);
		if (resultJsonStr != null)
			System.out.println(resultJsonStr);

		else {
			System.out.println("返回的是 ==null");
		}

		return resultJsonStr;
	}

	@Override
	public void clearData() {

	}

}
