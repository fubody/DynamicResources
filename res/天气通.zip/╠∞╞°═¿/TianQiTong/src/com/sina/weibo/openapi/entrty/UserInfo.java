package com.sina.weibo.openapi.entrty;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

public class UserInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6522698592546442601L;
	private static UserInfo mUserInfo = null;

	public static UserInfo getInstance() {
		if (mUserInfo == null) {
			throw new RuntimeException("没有进行UserInfo的初始化");
		}

		return mUserInfo;
	}

	private UserInfo() {

	}

	private String uid = null;
	private String screenName = null;

	/**
	 * 创建的时候构造
	 * 
	 * @param json
	 * @throws JSONException
	 */
	public UserInfo(String json) throws JSONException {
		JSONObject jsonO;

		jsonO = new JSONObject(json);
		this.uid = jsonO.getString("idstr");
		this.screenName = jsonO.getString("screen_name");
		mUserInfo = this;

	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

}
