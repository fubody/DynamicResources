package com.sina.weibo.openapi;

import sina.mobile.tianqitong.R;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Toast;

import com.sina.weibo.openapi.constants.Constants;
import com.sina.weibo.openapi.engine.ObtionRegistTelNumEngine;
import com.sina.weibo.openapi.engine.UserInfoEngine;
import com.sina.weibo.openapi.entrty.UserInfo;
import com.sina.weibo.openapi.manager.DataStorageManager;
import com.sina.weibo.openapi.service.LocalService;
import com.sina.weibo.openapi.util.DialogUtil;

public class LoginWeiboActivity extends AbstractAsyncActivity implements OnClickListener {
	private Button bnLogin = null;
	private Button bnRegist = null;
	private EditText etLoginUsername = null;
	private EditText etPwd = null;
	private CheckBox mCheckBox = null;

	/**
	 * 如果登陆成功这个广播接收
	 */
	private BroadcastReceiver loginReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			dismissProgressDialog();
			String action = intent.getAction();
			if (action.equals(Constants.ACTION_BC_LOGIN)) {
				if (intent.getIntExtra("success", 1) == Constants.REQUEST_OK) {
					Intent i = new Intent(LoginWeiboActivity.this, ShareActivity.class);
					LoginWeiboActivity.this.startActivity(i);
					finish();
				} else {
					Toast.makeText(LoginWeiboActivity.this, "登录失败", Toast.LENGTH_SHORT).show();
				}

			}

		}

	};

	/**
	 * 是否关注天气通
	 */
	private boolean isAttentionTqt = true;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weibo_login);
		bnLogin = (Button) findViewById(R.id.bnLogin);

		bnRegist = (Button) findViewById(R.id.bnRegist);
		etLoginUsername = (EditText) findViewById(R.id.etLoginUsername);
		etPwd = (EditText) findViewById(R.id.etPwd);
		mCheckBox = (CheckBox) findViewById(R.id.check);
		// mCheckBox.setOnCheckedChangeListener(checkListener);

		bnLogin.setOnClickListener(this);
		bnRegist.setOnClickListener(this);

		IntentFilter filter = new IntentFilter();
		filter.addAction(Constants.ACTION_BC_LOGIN);
		registerReceiver(loginReceiver, filter);

	}

	OnCheckedChangeListener checkListener = new OnCheckedChangeListener() {
		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			if (isChecked) {
				isAttentionTqt = true;

			} else {
				isAttentionTqt = false;
			}
		}
	};

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.bnLogin:

			final String user = etLoginUsername.getText().toString();
			final String pass = etPwd.getText().toString();
			if (user.length() == 0) {
				Toast.makeText(LoginWeiboActivity.this, "登录名不能为空", Toast.LENGTH_SHORT).show();
				return;
			}
			if (pass.length() == 0) {
				Toast.makeText(LoginWeiboActivity.this, "密码不能为空", Toast.LENGTH_SHORT).show();
				return;
			}

			if (checkNetwork()) {
				Intent intent = new Intent(LoginWeiboActivity.this, LocalService.class);
				intent.putExtra(Constants.USER_NAME, user);
				intent.putExtra(Constants.PASSSWORD, pass);
				intent.putExtra(Constants.IS_ATTENTIONTQT, isAttentionTqt);

				showProgressDialog("登录中...");
				startService(intent);
			}

			break;

		case R.id.bnRegist:

// Intent i = new Intent(LoginWeiboActivity.this, RegisterActivity.class);
// LoginWeiboActivity.this.startActivity(i);
			RegisterHelper rh = new RegisterHelper(this);
			rh.sendMessageReqister();

			break;

		default:
			break;
		}

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			dismissProgressDialog();
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {

		super.onDestroy();

		if (loginReceiver != null) {
			unregisterReceiver(loginReceiver);
		}

	}

	public static class RegisterHelper {
		Context mContext = null;
		private TelephonyManager mTelephonyManager;

		public RegisterHelper(Context context) {
			mContext = context;
			mTelephonyManager = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);

		}

		public void sendMessageReqister() {

			DialogUtil.showAlertDialog(mContext, R.string.register_weibo_info, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					new RegistTask().execute();
				}

			});

		}

		private class RegistTask extends AsyncTask<Void, Void, String> {
			ObtionRegistTelNumEngine mObtionRegistTelNumEngine = new ObtionRegistTelNumEngine(mContext);

			@Override
			protected String doInBackground(Void... params) {
				return mObtionRegistTelNumEngine.getRegistNum();
			}

			protected void onPostExecute(String result) {
				sendSMS(result);
			}
		}

		private void sendSMS(String phonenumber) {// 发送短信的类

			if (mTelephonyManager.getSimState() == TelephonyManager.SIM_STATE_READY) {// 检查电话的状态
				SmsManager smsManager = SmsManager.getDefault();
				PendingIntent sentIntent = PendingIntent.getBroadcast(mContext, 0, new Intent(), 0);
				smsManager.sendTextMessage(phonenumber, null, mContext.getString(R.string.share_content), sentIntent, null);
				Toast.makeText(mContext, mContext.getString(R.string.info_sending), Toast.LENGTH_SHORT).show();

			} else {
				Toast.makeText(mContext, mContext.getString(R.string.check_sim_prompt), Toast.LENGTH_SHORT).show();
			}

		}

	}

}