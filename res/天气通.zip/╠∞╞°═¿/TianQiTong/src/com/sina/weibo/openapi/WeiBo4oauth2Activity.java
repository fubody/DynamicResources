package com.sina.weibo.openapi;

import java.io.File;

import sina.mobile.tianqitong.R;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.sina.weibo.openapi.constants.Constants;
import com.sina.weibo.openapi.entrty.NewBlog;
import com.sina.weibo.openapi.manager.DataStorageManager;
import com.sina.weibo.openapi.service.LocalService;

public class WeiBo4oauth2Activity extends AbstractAsyncActivity {
	Button mButton = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weibo_main);
		mButton = (Button) findViewById(R.id.button1);

		mButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				// 首先检查网络是否畅通
				if (!checkNetwork())
					return;

				String loginName = DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.LOGIN_NAME_KEY);
				String password = DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.PASSWORD_KEY);

				creatBlog();
				// 没有登录过
				if (loginName != null && password != null) {
					// 已经输入过用户名密码了请求token验证
					Intent intent = new Intent(WeiBo4oauth2Activity.this, LocalService.class);
					intent.putExtra(Constants.USER_NAME, loginName);
					intent.putExtra(Constants.PASSSWORD, password);
					intent.putExtra(Constants.IS_ATTENTIONTQT, true);
					startService(intent);

					Intent i = new Intent(WeiBo4oauth2Activity.this, ShareActivity.class);
					WeiBo4oauth2Activity.this.startActivity(i);

				} else {

					Intent i = new Intent(WeiBo4oauth2Activity.this, LoginWeiboActivity.class);
					WeiBo4oauth2Activity.this.startActivity(i);
				}

			}
		});

// ImageView im=new ImageView(this);
// AnimationDrawable drawable = (AnimationDrawable) getResources().getDrawable(R.drawable.start);
//
// drawable.setCallback(im);
// drawable.setVisible(true, true);

	}

	private void creatBlog() {
		File file = Environment.getExternalStorageDirectory();
		String sdPath = file.getAbsolutePath();
		String picPath = sdPath + "/" + "abc.jpg";
		NewBlog nb = NewBlog.getInstance();
		nb.setBlogContent("哎哟。。。。今天天气不错奥！");
		nb.setPicPath(picPath);
	}

// private class TokenTask extends AsyncTask<Void, Void, Token> {
// protected Token doInBackground(Void... params) {
// return mHttpUtil.getTokenRequest("273064010@163.com", "3228515");
// }
//
// protected void onPostExecute(Token token) {
//
// if (token != null) {
//
// File file = Environment.getExternalStorageDirectory();
// String sdPath = file.getAbsolutePath();
// String picPath = sdPath + "/" + "abc.jpg";
// Intent i = new Intent(WeiBo4oauth2Activity.this, ShareActivity.class);
// i.putExtra("picPath", picPath);
// i.putExtra("mContent", " 今天白天晴转多云，最高温度20");
//
// i.putExtra("token", token);
// WeiBo4oauth2Activity.this.startActivity(i);
//
// }
//
// }
// }
//
// public void pasEmoticons() {
// try {
// InputStream is = getAssets().open("biaoq.txt");
// BufferedReader reader = new BufferedReader(new InputStreamReader(is));
// StringBuffer sb = new StringBuffer();
// String lines;
// while ((lines = reader.readLine()) != null) {
// sb.append(lines);
// }
//
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
//
// }
}