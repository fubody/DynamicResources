package com.sina.weibo.openapi.net;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONException;

import sina.mobile.tianqitong.R;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;
import com.sina.weibo.openapi.util.DialogUtil;

public class HttpUtil {

	private static String MULTIPART_FORM_DATA = "multipart/form-data";
	private static String BOUNDARY = "---------7d4a6d158c9";
	private static final int TIMEOUT = 30000;
	private static final int UPLOAD_TIMEOUT = 60000;
	private Context mContext;

	private HttpURLConnection connection = null;
	/**
	 * 是否要设置取消
	 */
	private boolean bIsStop = false;
	protected Object objAbort = new Object();
	private Handler mHandler = null;

	public HttpUtil(Context context) {
		this.mContext = context;
	}

	/**
	 * 为了通知上传下载进度的
	 * 
	 * @param handler
	 */
	public void setHandler(Handler handler) {
		mHandler = handler;
	}

	/**
	 * 用来停止网络请求的
	 */
	public synchronized void cancel() {
		try {
			bIsStop = true;
			if (connection != null) {
				connection.disconnect();
				connection = null;
			}
			synchronized (objAbort) {
				objAbort.wait(50);
			}
		} catch (Exception ex) {
			Log.v("HttpUtil", "canel", ex);
		}
	}

	private HttpURLConnection getURLConnection(URL url) throws HttpException {
		HttpURLConnection conn = null;
		try {
			NetworkUtil.NetworkState state = NetworkUtil.getNetworkState(mContext);
			if (state == NetworkUtil.NetworkState.NOTHING) {
				throw new HttpException(new NoSignalException());
			} else if (state == NetworkUtil.NetworkState.MOBILE) {
				NetworkUtil.APNWrapper wrapper;
				wrapper = NetworkUtil.getAPN(mContext);
				if (!TextUtils.isEmpty(wrapper.proxy)) {
					Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, new InetSocketAddress(wrapper.proxy, wrapper.port));
					conn = (HttpURLConnection) url.openConnection(proxy);

				} else {
					conn = (HttpURLConnection) url.openConnection();
				}

			} else {
				conn = (HttpURLConnection) url.openConnection();
			}
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setUseCaches(false);
			conn.setConnectTimeout(TIMEOUT);
			conn.setReadTimeout(UPLOAD_TIMEOUT);
			conn.setRequestProperty("Charset", "UTF-8");

		} catch (IOException e) {
			throw new HttpException(e);
		}
		return conn;
	}

	/** 发送GET请求 */
	public String getRequest(String strUrl, HashMap<String, String> paramHashMap) {
		if (TextUtils.isEmpty(strUrl)) {
			return null;
		}
		final String fixurl;
		bIsStop = false;
		URL getUrl = null;

		if (paramHashMap != null && paramHashMap.size() != 0) {
			StringBuffer paramBuffer = new StringBuffer();
			Iterator iter = paramHashMap.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry entry = (Map.Entry) iter.next();
				String key = (String) entry.getKey();
				String val = (String) entry.getValue();
				paramBuffer.append(key + "=" + val + "&");

			}
			if (bIsStop) {
				return null;
			}
			String paramStr = paramBuffer.toString().substring(0, paramBuffer.toString().length() - 1);
			strUrl = strUrl + "?" + paramStr;
		}

		try {
			getUrl = new URL(strUrl);
		} catch (MalformedURLException ex) {
			Log.e("HttpUtil", "get MalformedURL", ex);
			return null;
		}
		bIsStop = false;
		InputStream input = null;
		ByteArrayOutputStream byteOutStream = null;
		HttpURLConnection conn = null;
		byte[] outData = null;
		try {
			FakeX509TrustManager.allowAllSSL();
			conn = getURLConnection(getUrl);
			connection = conn;

			if (bIsStop) {
				return null;
			}
			conn.connect();
			input = conn.getInputStream();
			if (bIsStop) {
				return null;
			}
			String webcontent = null;

			byteOutStream = new ByteArrayOutputStream();
			int i = 0;

			while (!bIsStop && (i = input.read(tmpBuf)) != -1) {
				byteOutStream.write(tmpBuf, 0, i);
			}

			if (bIsStop) {
				return null;
			}
			outData = byteOutStream.toByteArray();
			if (outData != null && outData.length > 0) {
				webcontent = new String(outData);
			}
			if (bIsStop) {
				return null;
			}
			return webcontent;
		} catch (Exception ex) {
			Log.e("HttpUtil", "get", ex);
			// return ex.getMessage();
		} finally {
			try {
				outData = null;
				if (input != null) {
					input.close();
					input = null;
				}
				if (byteOutStream != null) {
					byteOutStream.close();
					byteOutStream = null;
				}
				if (conn != null) {
					conn.disconnect();
					conn = null;
				}
			} catch (Exception ex) {
				Log.e("HttpUtil", "get finally", ex);
				// return ex.getMessage();
			}
			if (bIsStop) {
				synchronized (objAbort) {
					objAbort.notify();
				}
			}
		}

		return null;
	}

	/**
	 * 发送只有字符串参数的post请求
	 * 
	 * @param urlStr
	 * @param paramHashMap
	 * @return
	 */
	public String postRequest(String urlStr, HashMap<String, String> paramHashMap) {
		HttpURLConnection conn = null;
		URL url = null;
		OutputStream ops = null;
		BufferedOutputStream dos = null;
		InputStream is = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		bIsStop = false;
		try {
			FakeX509TrustManager.allowAllSSL();
			url = new URL(urlStr);
			conn = getURLConnection(url);
			connection = conn;
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Connection", "Keep-Alive");
			if (bIsStop) {
				return null;
			}
			if (paramHashMap != null && paramHashMap.size() != 0) {
				StringBuffer paramBuffer = new StringBuffer();
				Iterator iter = paramHashMap.entrySet().iterator();
				while (iter.hasNext()) {
					Map.Entry entry = (Map.Entry) iter.next();
					String key = (String) entry.getKey();
					String val = (String) entry.getValue();
					paramBuffer.append(key + "=" + val + "&");

				}
				if (bIsStop) {
					return null;
				}
				String paramStr = paramBuffer.toString().substring(0, paramBuffer.toString().length() - 1);
				System.out.println("====0000====" + paramStr);
				ops = conn.getOutputStream();

				dos = new BufferedOutputStream(ops);

				dos.write(paramStr.getBytes());
				dos.flush();
			}

			int state = conn.getResponseCode();
			if (bIsStop) {
				return null;
			}
			if (state != 200) {
				if (conn.getErrorStream() == null)
					return null;
				BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				System.out.println(" ============================= ");
				System.out.println(" Contents of get request ");
				System.out.println(" ============================= ");
				StringBuffer sb2 = new StringBuffer();
				String lines;
				while ((lines = reader.readLine()) != null) {
					sb2.append(lines);
				}

				System.out.println(" ===========error================== ");
				System.out.println(sb2.toString());
				System.out.println(" ============================= ");

				dos.close();
				conn.disconnect();
				throw new HttpException(String.format("Invalid response from server —— code: %d", state));
			}

			is = conn.getInputStream();
			isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
			if (bIsStop) {
				return null;
			}
			StringBuffer sb = new StringBuffer();
			String lines;
			while ((lines = br.readLine()) != null) {
				sb.append(lines);
			}

			br.close();
			// 断开连接
			conn.disconnect();

			return sb.toString();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// 关闭输入流
			closeStream(ops);
			// 关闭输入的buf流
			closeStream(dos);
			closeStream(is);
			closeStream(isr);
			closeStream(br);

			if (conn != null) {
				conn.disconnect();
			}

			if (bIsStop) {
				synchronized (objAbort) {
					objAbort.notify();
				}
			}

		}

		return null;

	}

	/**
	 * 发送微博
	 * 
	 * @param access_token
	 * @param status
	 * @param picpath
	 * @return
	 * @throws HttpException
	 */
	public boolean postNewMBlog(String access_token, String status, String picpath) throws HttpException {
		OutputStream ops = null;
		BufferedOutputStream dos = null;
		InputStream is = null;
		HttpURLConnection conn = null;
		try {

			bIsStop = false;

			byte buf[] = new byte[4096];
			int r = 0;
			URL url = null;

			url = new URL(NetConstants.URL_SERVER);

			conn = getURLConnection(url);
			conn.setRequestMethod("POST");

			conn.setRequestProperty("Connection", "Keep-Alive");
			conn.setRequestProperty("Content-Type", MULTIPART_FORM_DATA + "; boundary=" + BOUNDARY);

			connection = conn;
			StringBuilder sb = new StringBuilder();

			// 要发布的微博文本内容，必须做URLencode，内容不超过140个汉字。
			sb.append("--");
			sb.append(BOUNDARY);
			sb.append("\r\n");
			sb.append("Content-Disposition: form-data; name=\"status\"\r\n\r\n");
			sb.append(URLEncoder.encode(status));
			sb.append("\r\n");

			// 采用OAuth授权方式不需要此参数，其他授权方式为必填参数，数值为应用的AppKey。
			sb.append("--");
			sb.append(BOUNDARY);
			sb.append("\r\n");
			sb.append("Content-Disposition: form-data; name=\"source\"\r\n\r\n");
			sb.append(NetConstants.CLIENT_ID);
			sb.append("\r\n");

			// //采用OAuth授权方式为必填参数，其他授权方式不需要此参数，OAuth授权后获得。
			sb.append("--");
			sb.append(BOUNDARY);
			sb.append("\r\n");
			sb.append("Content-Disposition: form-data; name=\"access_token\"\r\n\r\n");
			sb.append(access_token);
			sb.append("\r\n");

			// DataOutputStream dos = new
			// DataOutputStream(conn.getOutputStream());
			ops = conn.getOutputStream();
			dos = new BufferedOutputStream(conn.getOutputStream());

			// 如果取消了发送微博
			if (bIsStop) {
				return false;
			}

			dos.write(sb.toString().getBytes());
			if (picpath != null) {
				StringBuilder split = new StringBuilder();
				File f = new File(picpath);
				FileInputStream fis = new FileInputStream(f);
				split.append("--");
				split.append(BOUNDARY);
				split.append("\r\n");
				split.append("Content-Disposition: form-data;name=\"pic\";filename=\"" + f.getName() + "\"\r\n");
				split.append("Content-Type: image/jpeg\r\n\r\n");
				dos.write(split.toString().getBytes());
				while (!bIsStop && (r = fis.read(buf, 0, 4096)) > 0) {
					dos.write(buf, 0, r);
					dos.flush();
				}
				dos.write("\r\n".getBytes());
			}

			// 如果取消了发送微博
			if (bIsStop) {
				return false;
			}

			byte[] end_data = ("--" + BOUNDARY + "--\r\n").getBytes();
			dos.write(end_data);
			dos.flush();
			int state = conn.getResponseCode();
			if (state != 200) {
				if (conn.getErrorStream() == null)
					return false;
				BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				System.out.println(" ============================= ");
				System.out.println(" Contents of get request ");
				System.out.println(" ============================= ");
				StringBuffer sb2 = new StringBuffer();
				String lines;
				while ((lines = reader.readLine()) != null) {
					sb2.append(lines);
				}

				System.out.println(" ===========error================== ");
				System.out.println(sb2.toString());
				System.out.println(" ============================= ");
				reader.close();
				dos.close();
				conn.disconnect();

				throw new HttpException(String.format("Invalid response from server —— code: %d", state));
			}
			is = conn.getInputStream();
			sb = new StringBuilder();
			while ((r = is.read(buf, 0, 4096)) > 0) {
				sb.append(new String(buf, 0, r));
			}

			dos.close();
			conn.disconnect();

			String result = sb.toString();

			System.out.println(" ===========result================== ");
			System.out.println(result);
			System.out.println(" ============================= ");

			return true;
		} catch (MalformedURLException e) {
			throw new HttpException(e);
		} catch (ProtocolException e) {
			throw new HttpException(e);
		} catch (FileNotFoundException e) {
			throw new HttpException(e);
		} catch (IOException e) {
			throw new HttpException(e);
		} finally {
			try {

				if (ops != null) {
					ops.close();
				}
				if (dos != null) {
					dos.close();
				}
				if (is != null) {
					is.close();
				}

				if (conn != null) {
					conn.disconnect();
				}

				if (bIsStop) {
					synchronized (objAbort) {
						objAbort.notify();
					}
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/*
	 * 获取token
	 */
	public Token getTokenRequest(String userName, String password) {
		HttpURLConnection conn = null;
		URL url;

		try {
			FakeX509TrustManager.allowAllSSL();
			url = new URL(NetConstants.URL_OAUTH_TOKEN);
			conn = getURLConnection(url);
			conn.setRequestMethod("POST");

			String param = String.format("client_id=%s&client_secret=%s&grant_type=%s&username=%s&password=%s", NetConstants.CLIENT_ID, NetConstants.CLIENT_SECRET, NetConstants.GRANT_TYPE, userName,
					password);
			System.out.println("param===" + param);
			BufferedOutputStream dos = new BufferedOutputStream(conn.getOutputStream());

			dos.write(param.getBytes());
			dos.flush();
			int state = conn.getResponseCode();
			System.out.println("state===" + state);

			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			System.out.println(" ============================= ");
			System.out.println(" Contents of get request ");
			System.out.println(" ============================= ");
			StringBuffer sb = new StringBuffer();
			String lines;
			while ((lines = reader.readLine()) != null) {
				sb.append(lines);
			}

			reader.close();
			// 断开连接
			conn.disconnect();

			System.out.println(" ============================= ");
			System.out.println(sb.toString());
			System.out.println(" ============================= ");
			Token t = new Token(sb.toString());
			return t;

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {

			e.printStackTrace();
		}

		return null;

	}

	/**
	 * 请求关注
	 * 
	 * @param access_token
	 * @return
	 */
	public String requestGuanZhu(String access_token) {
		HttpURLConnection conn = null;
		URL url;
		try {
			FakeX509TrustManager.allowAllSSL();
			// url = new URL(String.format(GUANZHU_URL +
			// "?access_token=%s&uid=%s", access_token, UID));
			url = new URL(NetConstants.URL_GUANZHU);
			conn = getURLConnection(url);
			conn.setRequestMethod("POST");
			StringBuilder sb = new StringBuilder();
			sb.append(String.format("access_token=%s&screen_name=%s", access_token, "天气通"));
			BufferedOutputStream dos = new BufferedOutputStream(conn.getOutputStream());

			dos.write(sb.toString().getBytes());
			dos.flush();
			int state = conn.getResponseCode();
			System.out.println("state===" + state);

			Map<String, List<String>> map = conn.getHeaderFields();
			Iterator iter = map.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry entry = (Map.Entry) iter.next();
				String key = (String) entry.getKey();
				System.out.println("key===" + key);
				List<String> val = (List<String>) entry.getValue();
				for (String s : val) {
					System.out.println(s + "  ");
				}

				System.out.println(" ----------------- ");
			}

			if (state != 200) {

				BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				System.out.println(" ============================= ");
				System.out.println(" Contents of get request ");
				System.out.println(" ============================= ");
				StringBuffer sb2 = new StringBuffer();
				String lines;
				while ((lines = reader.readLine()) != null) {
					sb2.append(lines);
				}

				System.out.println(" ===========error================== ");
				System.out.println(sb2.toString());
				System.out.println(" ============================= ");

				dos.close();
				conn.disconnect();
				// throw new
				// HttpException(String.format("Invalid response from server —— code: %d",
				// state));
			}

			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			System.out.println(" ============================= ");
			System.out.println(" Contents of get request ");
			System.out.println(" ============================= ");
			StringBuffer sb2 = new StringBuffer();
			String lines;
			while ((lines = reader.readLine()) != null) {
				sb2.append(lines);
			}

			reader.close();
			// 断开连接
			conn.disconnect();

			System.out.println(" ============================= ");
			System.out.println(sb2.toString());
			System.out.println(" ============================= ");

			return sb2.toString();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;

	}

	private static final int BUF_LEN = 512;// 数据缓冲长度
	byte[] tmpBuf = new byte[BUF_LEN];
	byte[] tmpBuf2 = new byte[BUF_LEN * 2];

	public static int checkNetworkAvailable(Context context) {
		if (context == null) {
			return -1;
		}

		ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity == null) {
			return -1;
		}

		/*
		 * NetworkInfo info = connectivity.getActiveNetworkInfo(); if(info == null){ return false; } if(info.isAvailable()){ return true; }
		 */
		// 20100622，为三星双网双待手机增加的网络检查
		/*
		 * TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE); TelephonyManager telephonyManager2 = (TelephonyManager)
		 * context.getSystemService(Context.TELEPHONY_SERVICE_2); if(telephonyManager != null && telephonyManager2 != null){ int nSimState = telephonyManager.getSimState(); int nSimStateGsm =
		 * telephonyManager2.getSimState(); WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE); int wifiState = wifiManager.getWifiState(); if(wifiState ==
		 * WifiManager.WIFI_STATE_DISABLED) { if(nSimState != TelephonyManager.SIM_STATE_READY && nSimStateGsm == TelephonyManager.SIM_STATE_READY) { return 0; } } }
		 */

		NetworkInfo[] info = connectivity.getAllNetworkInfo();
		if (info != null) {
			for (int i = 0; i < info.length; i++) {
				if (info[i].getState() == NetworkInfo.State.CONNECTED) {
					return 1;
				}
			}
		}

		return -1;
	}

	/**
	 * 检查网络状态，如果网络无法连接则给出相应的提示 return 0 网络正常 return -1 联网失败
	 * */
	public static int checkNetworkAndHint(Context context) {
		if (checkNetworkAvailable(context) < 0) {
			DialogUtil.showAlertDialog(context, R.string.no_network, null);
			return -1;
		} else if (HttpUtil.checkNetworkAvailable(context) == 0) {
			DialogUtil.showAlertDialog(context, R.string.unsupport_network, null);
			return -1;
		}
		return 0;
	}

	public static class ApiException extends Exception {

		private static final long serialVersionUID = 4851415466864471511L;

		public ApiException() {
			super();
		}

		public ApiException(String detailMessage) {
			super(detailMessage);
		}

		public ApiException(String detailMessage, Throwable throwable) {
			super(detailMessage, throwable);
		}

		public ApiException(Throwable throwable) {
			super(throwable);
		}

	}

	/**
	 * Thrown when there were problems contacting the remote API server, either because of a network error, or the server returned a bad status code.
	 */
	public static class HttpException extends Exception {
		private static final long serialVersionUID = 5672654600892372211L;

		private int statusCode = -1;

		public int getStatusCode() {
			return statusCode;
		}

		public void setStatusCode(int statusCode) {
			this.statusCode = statusCode;
		}

		public HttpException() {
			super();
		}

		public HttpException(int statusCode) {
			super();
			this.statusCode = statusCode;
		}

		public HttpException(String detailMessage) {
			super(detailMessage);
		}

		public HttpException(String detailMessage, Throwable throwable) {
			super(detailMessage, throwable);
		}

		public HttpException(Throwable throwable) {
			super(throwable);
		}

	}

	public static class NoSignalException extends Exception {

		private static final long serialVersionUID = 4854482225687754615L;

		public NoSignalException() {
			super();
		}

		public NoSignalException(String detailMessage) {
			super(detailMessage);
		}

		public NoSignalException(String detailMessage, Throwable throwable) {
			super(detailMessage, throwable);
		}

		public NoSignalException(Throwable throwable) {
			super(throwable);
		}

	}

	private void closeStream(Closeable stream) {
		if (stream != null) {
			try {
				stream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

// public HttpClient getNewHttpClient() {
// try {
// KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
// trustStore.load(null, null);
//
// SSLSocketFactory sf = new SSLSocketFactoryEx(trustStore);
// sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
//
// HttpParams params = new BasicHttpParams();
// HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
// HttpProtocolParams.setContentCharset(params, HTTP.UTF_8);
//
// SchemeRegistry registry = new SchemeRegistry();
// registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
// registry.register(new Scheme("https", sf, 443));
//
// ClientConnectionManager ccm = new ThreadSafeClientConnManager(params, registry);
//
// return new DefaultHttpClient(ccm, params);
// } catch (Exception e) {
// return new DefaultHttpClient();
// }
// }
//
// public Token getTokenRequest2(String userName, String password) {
// // String url = String.format(URL_OAUTH_TOKEN +
// // "?client_id=%s&client_secret=%s&grant_type=%s&username=%s&password=%s",
// // CLIENT_ID, CLIENT_SECRET, GRANT_TYPE, userName, password);
// HttpClient httpClient = getNewHttpClient();
// HttpPost post = new HttpPost(Constant.URL_OAUTH_TOKEN);
// // post.addHeader(name, value)
// try {
//
// HttpResponse response = httpClient.execute(post);
//
// System.out.println(EntityUtils.toString(response.getEntity()));
//
// } catch (ClientProtocolException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
//
// return null;
// }
//
// public Token requestGuanZhu2(String access_token) {
// // String url = String.format(URL_OAUTH_TOKEN +
// // "?client_id=%s&client_secret=%s&grant_type=%s&username=%s&password=%s",
// // CLIENT_ID, CLIENT_SECRET, GRANT_TYPE, userName, password);
// String url = String.format(Constant.GUANZHU_URL + "?access_token=%s&screen_name=%s", access_token, URLEncoder.encode("天气通"));
//
// HttpClient httpClient = getNewHttpClient();
// HttpPost post = new HttpPost(Constant.GUANZHU_URL);
//
// // post.addHeader("source", CLIENT_ID);
// // post.addHeader("access_token", access_token);
// // post.addHeader("screen_name", URLEncodedUtils"天气通");
// // post.addHeader("uid", "1726834811");
//
// List<NameValuePair> qparams = new ArrayList<NameValuePair>();
// qparams.add(new BasicNameValuePair("access_token", access_token));
// qparams.add(new BasicNameValuePair("screen_name", "天气通"));
//
// try {
// post.setEntity(new UrlEncodedFormEntity(qparams));
// HttpResponse response = httpClient.execute(post);
//
// System.out.println(EntityUtils.toString(response.getEntity()));
//
// } catch (ClientProtocolException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// } catch (IOException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
//
// return null;
// }
}
