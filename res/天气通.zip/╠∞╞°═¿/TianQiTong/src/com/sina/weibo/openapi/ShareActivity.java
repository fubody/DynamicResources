package com.sina.weibo.openapi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import sina.mobile.tianqitong.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sina.weibo.openapi.constants.Constants;
import com.sina.weibo.openapi.engine.SendBlogEngine;
import com.sina.weibo.openapi.entrty.NewBlog;
import com.sina.weibo.openapi.entrty.UserInfo;
import com.sina.weibo.openapi.manager.DataStorageManager;
import com.sina.weibo.openapi.util.BitmapUtils;
import com.sina.weibo.openapi.view.AtFriendsView;
import com.sina.weibo.openapi.view.AtFriendsView.onAtSelectAction;
import com.sina.weibo.openapi.view.EmotionView;

public class ShareActivity extends AbstractAsyncActivity implements OnClickListener {
	private TextView mTextNum;
	private Button mSend;
	private EditText mEdit;
	private FrameLayout mPiclayout;
	private String mPicPath = null;
	private String mContent = "";
	private ImageButton mInsertPic;
	private ImageButton mfaceKeyboard;
	private ImageButton mAtButton;

	// private FaceClickHealper mFaceClickHealper;
	private EmotionView mEmotionView;
	public static final int WEIBO_MAX_LENGTH = 140;
	private File sdcardTempFile;
	private InputMethodManager mInputMethodManager;
	private TextView mTitleText = null;
	private String factContent = "";
	private AtFriendsView mAtFriendsView = null;
	private ImageView smallImage = null;
	private int len = 0;
	/**
	 * 接收到用户信息的广播
	 */
	private BroadcastReceiver userReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			System.out.println("userReceiver");
			String action = intent.getAction();
			if (action.equals(Constants.ACTION_BC_OBTION_USERINF)) {
				if (intent.getFlags() == Constants.REQUEST_OK) {
					mTitleText.setText(UserInfo.getInstance().getScreenName());

					System.out.println(UserInfo.getInstance().getScreenName() + "==userReceiver");
				}

			}
		}

	};

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.weibo_newblog);

		mInputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		mPicPath = NewBlog.getInstance().getPicPath();
		mContent = NewBlog.getInstance().getBlogContent();

		mTitleText = (TextView) findViewById(R.id.titleText);
		String screenName = DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.SCREEN_NAME_KEY);
		if (screenName != null) {
			mTitleText.setText(screenName);
		}
		smallImage = (ImageView) this.findViewById(R.id.ivImage);
		Button close = (Button) this.findViewById(R.id.titleBack);
		close.setOnClickListener(this);
		mSend = (Button) this.findViewById(R.id.titleSave);
		mSend.setOnClickListener(this);
		LinearLayout total = (LinearLayout) this.findViewById(R.id.ll_text_limit_unit);
		total.setOnClickListener(this);
		mTextNum = (TextView) this.findViewById(R.id.tv_text_limit);
		mAtButton = (ImageButton) findViewById(R.id.ib_insert_at);
		mInsertPic = (ImageButton) findViewById(R.id.ib_insert_pic);
		mfaceKeyboard = (ImageButton) findViewById(R.id.ib_face_keyboard);

		mEdit = (EditText) this.findViewById(R.id.et_mblog);
		mEdit.addTextChangedListener(new TextWatcher() {
			public void afterTextChanged(Editable s) {
			}

			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			public void onTextChanged(CharSequence s, int start, int before, int count) {
				String mText = mEdit.getText().toString();
				String mStr;
				len = mText.length();
				if (len <= WEIBO_MAX_LENGTH) {
					len = WEIBO_MAX_LENGTH - len;
					mTextNum.setTextColor(R.color.text_num_gray);
					if (!mSend.isEnabled())
						mSend.setEnabled(true);
				} else {
					len = WEIBO_MAX_LENGTH - len;

					mTextNum.setTextColor(Color.RED);
// if (mSend.isEnabled())
// mSend.setEnabled(false);
				}
				mTextNum.setText(String.valueOf(len));
			}
		});
		mEdit.setText(mContent);
		mPiclayout = (FrameLayout) ShareActivity.this.findViewById(R.id.flPic);
		if (TextUtils.isEmpty(this.mPicPath)) {
			mPiclayout.setVisibility(View.GONE);
		} else {

			File file = new File(mPicPath);
			if (file.exists()) {
				Bitmap pic = BitmapFactory.decodeFile(this.mPicPath);
				smallImage.setImageBitmap(pic);
				mPiclayout.setVisibility(View.VISIBLE);
			} else {
				mPiclayout.setVisibility(View.GONE);
			}
		}

		mPiclayout.setOnClickListener(this);
		mInsertPic.setOnClickListener(this);
		mfaceKeyboard.setOnClickListener(this);
		mAtButton.setOnClickListener(this);

		// 临时图片的目录
		sdcardTempFile = new File(Environment.getExternalStorageDirectory(), "tqt_tem.jpg");

		// 表情
		mEmotionView = (EmotionView) findViewById(R.id.emotion_view);
		mEmotionView.setEmotionAdapter(mEmotionAdapter);
		// mFaceClickHealper = new FaceClickHealper(this);

		// 好友列表
		mAtFriendsView = (AtFriendsView) findViewById(R.id.at_friends_view);
		mAtFriendsView.setOnAtSelectAction(new onAtSelectAction() {
			@Override
			public void onAtFriendsSelect(String friendName) {
				System.out.println(friendName);
				Editable eb = mEdit.getEditableText();
				int position = mEdit.getSelectionStart();
				eb.insert(position, friendName);
			}
		});
		// 注册广播
		IntentFilter filter = new IntentFilter();
		filter.addAction(Constants.ACTION_BC_OBTION_USERINF);
		registerReceiver(userReceiver, filter);
	}

	/**
	 * 删除的请求code
	 */
	public static final int DELETE_REQUEST_CODE = 101;

	@Override
	public void onClick(View v) {
		int viewId = v.getId();
		switch (viewId) {
		case R.id.titleBack: {
			finish();
			break;
		}
		case R.id.titleSave: {

			if (!TextUtils.isEmpty(mEdit.getText().toString())) {
				if (len < 0) {
					Toast.makeText(this, "输入文字不能超过140个", Toast.LENGTH_SHORT).show();
					return;
				}
				new NewBlogTask().execute(mEdit.getText().toString(), mPicPath);

			} else {
				Toast.makeText(this, this.getString(R.string.please_login), Toast.LENGTH_LONG);
			}

			break;
		}
		case R.id.ll_text_limit_unit: {
			Dialog dialog = new AlertDialog.Builder(this).setTitle(R.string.attention).setMessage(R.string.delete_all).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					mEdit.setText("");
				}
			}).setNegativeButton(R.string.cancel, null).create();
			dialog.show();
			break;
		}
		case R.id.flPic: {
			Intent intent = new Intent(this, ImageDisplay.class);
			intent.putExtra("picPath", mPicPath);
			startActivityForResult(intent, DELETE_REQUEST_CODE);

			break;
		}
		case R.id.ib_insert_pic: {
			showDialog(DIALOG_ALERT_IMPORT);
			break;
		}
		case R.id.ib_face_keyboard: {
			onFaceKeyboard();
			break;
		}
		case R.id.ib_insert_at: {
			if (mAtFriendsView.getVisibility() == View.VISIBLE) {
				mAtFriendsView.setVisibility(View.INVISIBLE);
			} else {
				mAtFriendsView.setVisibility(View.VISIBLE);
			}

			break;
		}
		default:
		}
	}

	/**
	 * 发送微博的task
	 * 
	 * @author zhangxi
	 * 
	 */
	private class NewBlogTask extends AsyncTask<String, Void, Boolean> {
		SendBlogEngine sbe = new SendBlogEngine(ShareActivity.this);

		protected void onPreExecute() {
			showProgressDialog("发布中...");
		}

		protected Boolean doInBackground(String... params) {
			return sbe.sendWeiBo(params[0], params[1]);
		}

		protected void onPostExecute(Boolean result) {
			dismissProgressDialog();
			if (result) {
				Toast.makeText(ShareActivity.this, "发布成功", Toast.LENGTH_SHORT).show();
				// 发布成功关闭发送页面
				finish();
			} else {
				Toast.makeText(ShareActivity.this, "发布失败", Toast.LENGTH_SHORT).show();
			}
		}
	}

	// 默认的是表情图标
	private boolean isFace = true;

	private void onFaceKeyboard() {
		if (isFace) {
			mfaceKeyboard.setImageResource(R.drawable.btn_insert_keyboard);

			setEmotionViewVisibility(true);
			mInputMethodManager.hideSoftInputFromWindow(mEdit.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

			isFace = false;

		} else {
			mfaceKeyboard.setImageResource(R.drawable.btn_insert_face);
			setEmotionViewVisibility(false);
			mInputMethodManager.showSoftInput(mEdit, 0);
			isFace = true;
		}

	}

	/*
	 * public void insterFace() { Editable eb = mEdit.getEditableText();
	 * 
	 * // 获取光标位置
	 * 
	 * int position = mEdit.getSelectionStart();
	 * 
	 * // 插入图片
	 * 
	 * // 定义图片所占字节数(“Tag”的长度)
	 * 
	 * SpannableString ss = new SpannableString("Tag");
	 * 
	 * // 定义插入图片
	 * 
	 * Drawable drawable = getResources().getDrawable(R.drawable.ic_launcher);
	 * 
	 * ss.setSpan(new ImageSpan(drawable, ImageSpan.ALIGN_BASELINE), 0, ss.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
	 * 
	 * drawable.setBounds(2, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
	 * 
	 * // 插入图片
	 * 
	 * eb.insert(position, ss); // eb.gets
	 * 
	 * // 设置可输入最大字节数
	 * 
	 * // ed.setFilters(new InputFilter[] { new InputFilter.LengthFilter(10) });
	 * 
	 * }
	 */

	static final int DIALOG_ALERT_IMPORT = 1001;
	static final int REQUEST_CODE_GALLERY = 2001;
	static final int REQUEST_CODE_CAMERA = 2002;

	protected Dialog onCreateDialog(int id) {
		Dialog dialog = null;
		if (id == DIALOG_ALERT_IMPORT) {
			dialog = new AlertDialog.Builder(this).setTitle("设置")
					.setItems(new CharSequence[] { getString(R.string.menu_camera), getString(R.string.menu_gallery) }, new DialogInterface.OnClickListener() {

						public void onClick(DialogInterface dialog, int which) {
							switch (which) {
							case 0:
								startToCameraActivity();
								break;

							case 1:
								startToMediaActivity();
								break;
							}
						}

					}).create();
		}

		return dialog;
	}

	private void startToCameraActivity() {
		if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
			final Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			final Uri picUri = Uri.fromFile(sdcardTempFile);
			i.putExtra(MediaStore.EXTRA_OUTPUT, picUri);
			startActivityForResult(i, REQUEST_CODE_CAMERA);
		} else {
			Toast.makeText(this, "请你安装sd卡", Toast.LENGTH_SHORT).show();
		}
	}

	private void startToMediaActivity() {
		startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), REQUEST_CODE_GALLERY);
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		if (requestCode == DELETE_REQUEST_CODE) {// 从照片查看页面返回。
			if (resultCode == 102) {
				String path = data.getStringExtra("picPath");
				mPicPath = path;
				File file = new File(path);
				smallImage.setImageURI(Uri.fromFile(file));
				findViewById(R.id.flPic).setVisibility(View.VISIBLE);
			}
		}

		if (resultCode != Activity.RESULT_OK) {
			return;
		}

		Uri uri = null;
		if ((requestCode == REQUEST_CODE_CAMERA) && Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
			uri = Uri.fromFile(sdcardTempFile);

			File file = BitmapUtils.saveBitmap(this, uri);
			findViewById(R.id.flPic).setVisibility(View.VISIBLE);
			smallImage.setImageURI(Uri.fromFile(file));
			mPicPath = file.getAbsolutePath();

		} else if (REQUEST_CODE_GALLERY == requestCode) {
			uri = data.getData();

			File file = BitmapUtils.saveBitmap(this, uri);
			findViewById(R.id.flPic).setVisibility(View.VISIBLE);
			smallImage.setImageURI(Uri.fromFile(file));
			mPicPath = file.getAbsolutePath();

		}
		if (requestCode == DELETE_REQUEST_CODE) {
			findViewById(R.id.flPic).setVisibility(View.GONE);
			mPicPath = null;
			return;
		}
	}

	void setEmotionViewVisibility(boolean visibility) {
		if (mEmotionView != null) {
			mEmotionView.setVisibility(visibility ? View.VISIBLE : View.GONE);
		}
	}

	boolean setInputMethodVisibility(boolean visibility) {
		if ((mInputMethodManager != null) && (mEdit != null)) {
			if (visibility) {
				mInputMethodManager.showSoftInput(mEdit, 0);
			} else {
				if (mInputMethodManager.isActive(mEdit)) {
					mInputMethodManager.hideSoftInputFromWindow(mEdit.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

				}
			}
		}
		return false;
	}

	private EmotionView.EmotionAdapter mEmotionAdapter = new EmotionView.EmotionAdapter() {
		public void doAction(int resId, String desc) {
			final int start = mEdit.getSelectionStart();
			final int end = mEdit.getSelectionEnd();
			final String preText = mEdit.getText().toString();
			final String addText = desc;

			Editable eb = mEdit.getEditableText();

			// 获取光标位置
			int position = mEdit.getSelectionStart();

			// 插入图片
			SpannableString ss = new SpannableString(addText);

			// 定义插入图片

			Drawable drawable = getResources().getDrawable(resId);

			ss.setSpan(new ImageSpan(drawable, ImageSpan.ALIGN_BASELINE), 0, ss.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

			drawable.setBounds(2, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());

			// 插入图片

			eb.insert(position, ss);

			// 设置可输入最大字节数

			// ed.setFilters(new InputFilter[] { new InputFilter.LengthFilter(10) });

		}
	};

// final class FaceClickHealper {
// private boolean isFaceDiaplay = false;
// private ShareActivity activity;
//
// boolean isFaceDiaplay() {
// EditText et;
//
// return isFaceDiaplay;
// }
//
// void onClick(View v) {
// activity.setEmotionViewVisibility(!isFaceDiaplay);
// if (isFaceDiaplay) {
// activity.displayFaceImageSrc();
// } else {
// activity.displayKeyboardImageSrc();
// }
// activity.setInputMethodVisibility(isFaceDiaplay);
// changeDiaplayFlag();
// }
//
// boolean onFinish() {
// if (isFaceDiaplay) {
// activity.displayFaceImageSrc();
// activity.setEmotionViewVisibility(false);
// changeDiaplayFlag();
// // 返回键拦截
// return true;
// }
// // 返回键默认处理
// return false;
// }
//
// private void changeDiaplayFlag() {
// isFaceDiaplay = !isFaceDiaplay;
// }
//
// public FaceClickHealper(ShareActivity activity) {
// super();
// this.activity = activity;
// }
// }

	@Override
	protected void onDestroy() {

		super.onDestroy();

		if (userReceiver != null) {
			unregisterReceiver(userReceiver);
		}

	}

}
