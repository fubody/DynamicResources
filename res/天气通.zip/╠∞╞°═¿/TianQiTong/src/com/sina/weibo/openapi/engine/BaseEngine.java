package com.sina.weibo.openapi.engine;

import android.content.Context;
import android.os.Handler;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.net.HttpUtil;

public abstract class BaseEngine extends NetConstants {

	HttpUtil httpUtil = null;
	Context mContext = null;

	public BaseEngine(Context con) {
		mContext = con;
		httpUtil = new HttpUtil(con);
	}

	/**
	 * 停止联网
	 */
	public void cancel() {
		httpUtil.cancel();

	}

	public void setHandler(Handler handler) {
		httpUtil.setHandler(handler);
	}

	public abstract void clearData();

}
