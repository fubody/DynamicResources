package com.sina.weibo.openapi.service;

import java.util.HashMap;

import android.app.Service;
import android.content.Intent;
import android.database.CursorJoiner.Result;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.sina.weibo.openapi.constants.Constants;
import com.sina.weibo.openapi.engine.ObtionTokenEngine;
import com.sina.weibo.openapi.engine.UserInfoEngine;
import com.sina.weibo.openapi.entrty.UserInfo;
import com.sina.weibo.openapi.manager.DataStorageManager;

public class LocalService extends Service {

	private ObtionTokenEngine mObtionTokenEngine = null;
	private TokenTask mTokenTask = null;
	private Boolean isAttentionTqt = true;
	private String mLoginName = null;
	private String mPassword = null;

	private final IBinder mBinder = new LocalBinder();

	/**
	 * 请求tooken ，请求关注，请求用户信息 当 请求状态自增到 3 时， 表示service 请求完成，进行关闭service
	 */
	private int requestState = 0;

	public class LocalBinder extends Binder {
		LocalService getService() {
			return LocalService.this;
		}
	}

	@Override
	public void onCreate() {
		mObtionTokenEngine = new ObtionTokenEngine(this);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i("LocalService", "Received start id " + startId + ": " + intent);

		mLoginName = intent.getStringExtra(Constants.USER_NAME);
		mPassword = intent.getStringExtra(Constants.PASSSWORD);
		isAttentionTqt = intent.getBooleanExtra(Constants.IS_ATTENTIONTQT, true);

		mTokenTask = new TokenTask();
		mTokenTask.execute(mLoginName, mPassword);

		return START_STICKY;
	}

	@Override
	public void onDestroy() {

		// Toast.makeText(this, "service 停止了", Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return mBinder;
	}

	private class TokenTask extends AsyncTask<String, Void, String> {

		protected String doInBackground(String... params) {
			// return mHttpUtil.getTokenRequest(params[0], params[1]);
			HashMap<String, String> hashMap = new HashMap();
			hashMap.put("username", params[0]);
			hashMap.put("password", params[1]);

			return mObtionTokenEngine.getAccessToken(hashMap);
		}

		protected void onPostExecute(String token) {
			if (token != null) {
				Intent intent = new Intent();
				intent.putExtra("success", Constants.REQUEST_OK);
				intent.setAction(Constants.ACTION_BC_LOGIN);// action与接收器相同
				sendBroadcast(intent);

				String loginName = DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.LOGIN_NAME_KEY);
				String password = DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.PASSWORD_KEY);

				// 登录成功保存用户名，密码
				if (loginName == null && password == null) {
					DataStorageManager.putSPString(getApplicationContext(), DataStorageManager.LOGIN_NAME_KEY, mLoginName);
					DataStorageManager.putSPString(getApplicationContext(), DataStorageManager.PASSWORD_KEY, mPassword);

				}

				String isattStr = DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.IS_HAVING_ATTENTION_TQT);
				if (isattStr == null) {
					isattStr = "false";
				}
				requestState++;

				// 没有关注过天气通进行关注处理 如果没有关注 isattStr==null
				if (isAttentionTqt && isattStr.equals("false"))
					new AttentionTqtTask().execute();

				// 没有获取的用户的信息
				if (DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.UID_KEY) == null)
					new GetUserInfoTask().execute();

				// 如果关注过天气通，并且 用户的信息也在本地保存了 做关闭service 的处理
				if (isattStr.equals("true") && DataStorageManager.getSPString(getApplicationContext(), DataStorageManager.UID_KEY) != null)
					stopSelf();

			} else {
				Intent intent = new Intent();
				intent.putExtra("success", Constants.REQUEST_NO);
				intent.setAction(Constants.ACTION_BC_LOGIN);//
				sendBroadcast(intent);
				// 获取token失败关闭service
				stopSelf();
			}

		}
	}

	/**
	 * 关注天气通
	 * 
	 * @author zhangxi
	 * 
	 */
	private class AttentionTqtTask extends AsyncTask<Void, Void, Boolean> {

		@Override
		protected Boolean doInBackground(Void... params) {

			return mObtionTokenEngine.requestAttentionTqt();
		}

		@Override
		protected void onPostExecute(Boolean result) {

			if (result) {

				System.out.println("AttentionTqtTask==》关注天气通成功");
				DataStorageManager.putSPString(getApplicationContext(), DataStorageManager.IS_HAVING_ATTENTION_TQT, result + "");
			}

			requestState++;
			if (requestState == 3) {
				System.out.println("AttentionTqtTask==》关闭service");
				stopSelf();
			}
		}

	}

	/**
	 * 获取UserInfo
	 * 
	 * @author zhangxi
	 * 
	 */
	private class GetUserInfoTask extends AsyncTask<Void, Void, Boolean> {
		UserInfoEngine userInfoEngine = new UserInfoEngine(getApplicationContext().getApplicationContext());

		@Override
		protected Boolean doInBackground(Void... params) {
			return userInfoEngine.getUserInfo();
		}

		protected void onPostExecute(Boolean result) {
			if (result) {
				Intent intent = new Intent();
				intent.addFlags(Constants.REQUEST_OK);
				intent.setAction(Constants.ACTION_BC_OBTION_USERINF);// action与接收器相同

				System.out.println("GetUserInfoTask==》用户信息请求成功");
				DataStorageManager.putSPString(getApplicationContext(), DataStorageManager.UID_KEY, UserInfo.getInstance().getUid());
				DataStorageManager.putSPString(getApplicationContext(), DataStorageManager.SCREEN_NAME_KEY, UserInfo.getInstance().getScreenName());
				sendBroadcast(intent);
			} else {
				Intent intent = new Intent();
				intent.addFlags(Constants.REQUEST_NO);
				intent.setAction(Constants.ACTION_BC_OBTION_USERINF);//
				sendBroadcast(intent);
			}
			requestState++;
			if (requestState == 3) {
				System.out.println("GetUserInfoTask==》关闭service");
				stopSelf();
			}
		}
	}

}
