package com.sina.weibo.openapi.manager;

public class ImageCacheManager {

}
