package com.sina.weibo.openapi.constants;

public class NetConstants {

	// //////////////////////////获取 token/////////////////////////////////////////
	/**
	 * OAuth2的access_token接口 URL
	 */
	public final static String URL_OAUTH_TOKEN = "https://api.weibo.com/oauth2/access_token";

	/**
	 * 申请应用时分配的AppKey。 这里给定的是android天气通的appkey
	 */
	public final static String CLIENT_ID = "3817130083";
	/**
	 * 申请应用时分配的AppSecret 这里给定的是android天气通的AppSecret
	 */
	public final static String CLIENT_SECRET = "a87a745e65d159cb7a3ab9699773153e";
	/**
	 * 请求的类型，可以为authorization_code、password、refresh_token。
	 */
	public final static String GRANT_TYPE = "password";

	// //////////////////////发送新的微博/////////////////////////////////////

	public final static String URL_SERVER = "https://api.weibo.com/2/statuses/upload.json";
	public final static String URL_SERVER_NO_PIC = "https://api.weibo.com/2/statuses/update.json";
	// ///////////////////////////请求关注///////////////////////////
	/**
	 * 关注接口
	 */
	public final static String URL_GUANZHU = "https://api.weibo.com/2/friendships/create.json";
	public final static String UID = "1726834811";
	public final static String SCREEN_NAME = "1926068507";

	/**
	 * 估计token获取uid
	 */
	public final static String URL_GET_UID = "https://api.weibo.com/2/account/get_uid.json";

	/**
	 * 根据用户ID获取用户信息
	 */
	public final static String URL_GET_USERINF = "https://api.weibo.com/2/users/show.json";

	/**
	 * at 用户时的联想建议
	 */
	public final static String URL_GET_AT_FRIENDS = "https://api.weibo.com/2/search/suggestions/at_users.json";
	/**
	 * 获取注册的号码
	 */
	public final static String URL_GET_REGIST = "http://api.weibo.cn/interface/f/ttt/v3/getwmsmsnum.php";

}
