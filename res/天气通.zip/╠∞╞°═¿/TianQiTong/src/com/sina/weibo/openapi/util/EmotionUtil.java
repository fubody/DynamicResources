package com.sina.weibo.openapi.util;

import sina.mobile.tianqitong.R;

public class EmotionUtil {

	public static int[] emotionResIds = { R.drawable.emo_001, R.drawable.emo_002, R.drawable.emo_003, R.drawable.emo_004, R.drawable.emo_005, R.drawable.emo_006, R.drawable.emo_007,
			R.drawable.emo_008, R.drawable.emo_009, R.drawable.emo_010, R.drawable.emo_011, R.drawable.emo_012, R.drawable.emo_013, R.drawable.emo_014, R.drawable.emo_015, R.drawable.emo_016,
			R.drawable.emo_017, R.drawable.emo_018, R.drawable.emo_019, R.drawable.emo_020, R.drawable.emo_021, R.drawable.emo_022, R.drawable.emo_023, R.drawable.emo_024, R.drawable.emo_025,
			R.drawable.emo_026, R.drawable.emo_027, R.drawable.emo_028, R.drawable.emo_029, R.drawable.emo_030, R.drawable.emo_031, R.drawable.emo_032, R.drawable.emo_033, R.drawable.emo_034,
			R.drawable.emo_035, R.drawable.emo_036, R.drawable.emo_037, R.drawable.emo_038, R.drawable.emo_039, R.drawable.emo_040, R.drawable.emo_041, R.drawable.emo_042, R.drawable.emo_043,
			R.drawable.emo_044, R.drawable.emo_045, R.drawable.emo_046, R.drawable.emo_047, R.drawable.emo_048, R.drawable.emo_049, R.drawable.emo_050, R.drawable.emo_051, R.drawable.emo_052,
			R.drawable.emo_053, R.drawable.emo_054, R.drawable.emo_055, R.drawable.emo_056, R.drawable.emo_057, R.drawable.emo_058, R.drawable.emo_059, R.drawable.emo_060, R.drawable.emo_061,
			R.drawable.emo_062, R.drawable.emo_063, R.drawable.emo_064, R.drawable.emo_065, R.drawable.emo_066, R.drawable.emo_067, R.drawable.emo_068, R.drawable.emo_069, R.drawable.emo_070,
			R.drawable.emo_071, R.drawable.emo_072, R.drawable.emo_073, R.drawable.emo_074, R.drawable.emo_075, R.drawable.emo_076, R.drawable.emo_077, R.drawable.emo_078, R.drawable.emo_079,
			R.drawable.emo_080, R.drawable.emo_081, R.drawable.emo_082, R.drawable.emo_083, R.drawable.emo_084, R.drawable.emo_085, R.drawable.emo_086, R.drawable.emo_087, R.drawable.emo_088

	};

	public static String[] des = { "[兔子]", "[熊猫]", "[给力]", "[神马]", "[浮云]", "[织]", "[围观]", "[威武]", "[嘻嘻]", "[哈哈]", "[爱你]", "[晕]", "[泪]", "[馋嘴]", "[抓狂]", "[哼]", "[可爱]", "[怒]", "[汗]", "[呵呵]", "[睡觉]",
			"[钱]", "[偷笑]", "[酷]", "[衰]", "[吃惊]", "[闭嘴]", "[鄙视]", "[挖鼻屎]", "[花心]", "[鼓掌]", "[失望]", "[帅]", "[照相机]", "[落叶]", "[汽车]", "[飞机]", "[爱心传递]", "[奥特曼]", "[实习]", "[思考]", "[生病]", "[亲亲]", "[怒骂]",
			"[太开心]", "[懒得理你]", "[右哼哼]", "[左哼哼]", "[嘘]", "[委屈]", "[吐]", "[可怜]", "[打哈气]", "[顶]", "[疑问]", "[做鬼脸]", "[害羞]", "[不要]", "[good]", "[弱]", "[ok]", "[赞]", "[来]", "[耶]", "[心]", "[伤心]", "[握手]",
			"[猪头]", "[咖啡]", "[话筒]", "[月亮]", "[太阳]", "[干杯]", "[萌]", "[礼物]", "[互粉]", "[蜡烛]", "[绿丝带]", "[沙尘暴]", "[钟]", "[自行车]", "[蛋糕]", "[围脖]", "[手套]", "[雪]", "[雪人]", "[温暖帽子]", "[微风]" };

	public static String[] des2 = { "[兔子]", "[熊貓]", "[給力]", "[神馬]", "[浮雲]", "[織]", "[圍觀]", "[威武]", "[嘻嘻]", "[哈哈]", "[愛你]", "[暈]", "[淚]", "[饞嘴]", "[抓狂]", "[哼]", "[可愛]", "[怒]", "[汗]", "[呵呵]", "[睡覺]",
			"[錢]", "[偷笑]", "[酷]", "[衰]", "[吃驚]", "[閉嘴]", "[鄙視]", "[挖鼻屎]", "[花心]", "[鼓掌]", "[失望]", "[帥]", "[照相機]", "[落葉]", "[汽車]", "[飛機]", "[愛心傳遞]", "[奧特曼]", "[實習]", "[思考]", "[生病]", "[親親]", "[怒罵]",
			"[太開心]", "[懶得理你]", "[右哼哼]", "[左哼哼]", "[噓]", "[委屈]", "[吐]", "[可憐]", "[打哈氣]", "[頂]", "[疑問]", "[做鬼臉]", "[害羞]", "[不要]", "[good]", "[弱]", "[ok]", "[贊]", "[來]", "[耶]", "[心]", "[傷心]", "[握手]",
			"[豬頭]", "[咖啡]", "[話筒]", "[月亮]", "[太陽]", "[幹杯]", "[萌]", "[禮物]", "[互粉]", "[蠟燭]", "[綠絲帶]", "[沙塵暴]", "[鐘]", "[自行車]", "[蛋糕]", "[圍脖]", "[手套]", "[雪]", "[雪人]", "[溫暖帽子]", "[微風]" };
}
