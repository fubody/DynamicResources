package com.sina.weibo.openapi.constants;

public class Constants {
	/**
	 * 登陆广播
	 */
	public static final String ACTION_BC_LOGIN = " com.sina.weibo.openapi.login";
	/**
	 * 关注广播
	 */
	public static final String ACTION_BC_ATTENTIONTQT = " com.sina.weibo.openapi.AttentionTqt";
	/**
	 * 获取到用户信息的广播
	 */
	public static final String ACTION_BC_OBTION_USERINF = " com.sina.weibo.openapi.userinf";

	public static final String USER_NAME = "username";
	public static final String PASSSWORD = "passsword";
	/**
	 * 关注
	 */
	public static final String IS_ATTENTIONTQT = "is_attentiontqt";
	/**
	 * 请求成功
	 */
	public static final int REQUEST_OK = 0;
	/**
	 * 请求失败
	 */
	public static final int REQUEST_NO = 1;

}
