package com.sina.weibo.openapi;

import sina.mobile.tianqitong.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

public class RegisterActivity extends Activity implements OnClickListener {

	private WebView mWv;
	private WebSettings ws;
	private static final String emailurl = "http://weibo.cn/dpool/ttt/h5/reg.php";
	final Activity activity = this;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.getWindow().requestFeature(Window.FEATURE_PROGRESS);
		setContentView(R.layout.weibo_emailclient);
		final ImageView requestError = (ImageView) findViewById(R.id.imageView1);

		mWv = (WebView) findViewById(R.id.wvpage);
		ws = mWv.getSettings();
		ws.setAllowFileAccess(true);// 设置允许访问文件数据
		ws.setJavaScriptEnabled(true);// 设置支持javascript脚本
		ws.setBuiltInZoomControls(true);// 设置支持缩放
		mWv.setWebChromeClient(new WebChromeClient() {
			public void onProgressChanged(WebView view, int progress) {
				setTitle("Loading...");
				setProgress(progress * 100);
				if (progress == 100)
					setTitle(R.string.app_name);
			}
		});

		mWv.setWebViewClient(new WebViewClient() {
			boolean bReceivedError = false;

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				bReceivedError = true;
				view.setVisibility(View.GONE);
				requestError.setVisibility(View.VISIBLE);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				if (!bReceivedError)
					view.setVisibility(View.VISIBLE);
			}
		});

		mWv.loadUrl(emailurl);

	}

	protected void onDestroy() {
		super.onDestroy();
		mWv.clearCache(true);

	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWv.canGoBack()) {
			mWv.goBack();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

}