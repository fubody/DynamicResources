package com.sina.weibo.openapi.util;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore.Images.ImageColumns;

public class BitmapUtils {

	private static final String TAG = "BitmapUtils";
	private static final int DEFAULT_COMPRESS_QUALITY = 90;
	private static int baseWidth = 440;

	private final static String ALBUM_PATH = Environment.getExternalStorageDirectory() + "/TianQiTong/weibo/";

	public static File saveBitmap(Context context, Bitmap bitmap, String directory, String filename, CompressFormat format) {

		if (directory == null) {
			directory = context.getCacheDir().getAbsolutePath();
		} else {
			// Check if the given directory exists or try to create it.
			File file = new File(directory);
			if (!file.isDirectory() && !file.mkdirs()) {
				return null;
			}
		}

		File file = null;
		OutputStream os = null;

		try {
			filename = (format == CompressFormat.PNG) ? filename + ".png" : filename + ".jpg";
			file = new File(directory, filename);
			os = new FileOutputStream(file);
			bitmap.compress(format, DEFAULT_COMPRESS_QUALITY, os);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			closeStream(os);
		}
		return file;
	}

	public static File saveBitmap(Context context, Uri uri) {

		try {
			BitmapFactory.Options opts = new BitmapFactory.Options();
			Bitmap bm;
			opts.inJustDecodeBounds = true;
			// 先拿到图片的宽高
			bm = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri), null, opts);

			if (opts.outWidth > baseWidth) {
				opts.inSampleSize = opts.outWidth / baseWidth;
			}

			opts.inJustDecodeBounds = false;

			bm = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri), null, opts);
			File file = saveBitmap(context, bm);
			bm.recycle();
			return file;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static File saveBitmap(Context context, String sourcePath) throws IOException {

		Bitmap bmp = BitmapFactory.decodeFile(sourcePath);
		int width = bmp.getWidth();
		int dstHeight = 0;
		if (width > baseWidth) {
			dstHeight = bmp.getHeight() * baseWidth / width;
		}
		bmp = bmp.createScaledBitmap(bmp, baseWidth, dstHeight, true);
		return saveFile(bmp, "tem.jpg");
	}

	public static File saveBitmap(Context context, Bitmap source) throws IOException {
		Bitmap bit = source;
		int width = source.getWidth();
		int dstHeight = source.getHeight();
		if (width > baseWidth) {
			dstHeight = source.getHeight() * baseWidth / width;
			bit = Bitmap.createScaledBitmap(source, baseWidth, dstHeight, true);
		}
		return saveFile(bit, "tem" + SystemClock.currentThreadTimeMillis() + "+.jpg");
	}

	/**
	 * 保存文件
	 * 
	 * @param bm
	 * @param fileName
	 * @throws IOException
	 */
	public static File saveFile(Bitmap bm, String fileName) throws IOException {
		File dirFile = new File(ALBUM_PATH);
		if (!dirFile.exists()) {
			dirFile.mkdir();
		}
		// 删除这个文件夹中的临时文件
		File[] files = dirFile.listFiles();
		for (File file : files) {
			file.delete();
		}

		File myCaptureFile = new File(ALBUM_PATH + fileName);
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(myCaptureFile));
		bm.compress(Bitmap.CompressFormat.JPEG, 100, bos);
		bos.flush();
		bos.close();
		bm.recycle();
		return myCaptureFile;
	}

	public static Bitmap createRotatedBitmap(Bitmap source, int degrees, int dstWidth, int dstHeight) {

		Matrix matrix = new Matrix();
		// if(Math.abs(degrees)==90||Math.abs(degrees)==270){
		matrix.preRotate(degrees, source.getWidth() / 2, source.getHeight() / 2);
		// }

		Bitmap newb = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Config.ARGB_8888);
		Canvas c = new Canvas(newb);
		c.drawBitmap(source, matrix, null);

		System.out.println(source.getWidth() + "---" + source.getHeight());
		return newb;

	}

	private static Bitmap createBitmap(String bitmapPath, int x, int y, int width, int height, Matrix m) {
		// Re-implement Bitmap createBitmap() to always return a mutable bitmap.
		Bitmap source = BitmapFactory.decodeFile(bitmapPath);
		Canvas canvas = new Canvas();
		Bitmap bitmap;
		Paint paint;
		if ((m == null) || m.isIdentity()) {
			bitmap = Bitmap.createBitmap(width, height, source.getConfig());
			paint = null;
		} else {
			RectF rect = new RectF(0, 0, width, height);
			m.mapRect(rect);
			bitmap = Bitmap.createBitmap(Math.round(rect.width()), Math.round(rect.height()), source.getConfig());

			canvas.translate(-rect.left, -rect.top);
			canvas.concat(m);

			paint = new Paint(Paint.FILTER_BITMAP_FLAG);
			if (!m.rectStaysRect()) {
				paint.setAntiAlias(true);
			}
		}
		bitmap.setDensity(source.getDensity());
		canvas.setBitmap(bitmap);

		Rect srcBounds = new Rect(x, y, x + width, y + height);
		RectF dstBounds = new RectF(0, 0, width, height);
		canvas.drawBitmap(source, srcBounds, dstBounds, paint);
		return bitmap;
	}

	private static void closeStream(Closeable stream) {
		if (stream != null) {
			try {
				stream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}