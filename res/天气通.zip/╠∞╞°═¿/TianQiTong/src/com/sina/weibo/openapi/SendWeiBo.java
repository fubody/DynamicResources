package com.sina.weibo.openapi;

import android.content.Context;
import android.content.Intent;

import com.sina.weibo.openapi.constants.Constants;
import com.sina.weibo.openapi.entrty.NewBlog;
import com.sina.weibo.openapi.manager.DataStorageManager;
import com.sina.weibo.openapi.net.HttpUtil;
import com.sina.weibo.openapi.service.LocalService;

public class SendWeiBo {
	Context mContext = null;
	NewBlog nb = null;

	public SendWeiBo(Context context, String weiboContent, String picPath) {
		mContext = context;
		nb = NewBlog.getInstance();
		nb.setBlogContent(weiboContent);
		nb.setPicPath(picPath);
	}

	public boolean checkNetwork() {
		if (HttpUtil.checkNetworkAndHint(mContext) == 0) {
			return true;
		}
		return false;
	}

	/**
	 * 发送微博
	 */
	public void send() {
		// 首先检查网络是否畅通
		if (!checkNetwork())
			return;

		String loginName = DataStorageManager.getSPString(mContext, DataStorageManager.LOGIN_NAME_KEY);
		String password = DataStorageManager.getSPString(mContext, DataStorageManager.PASSWORD_KEY);

		// 没有登录过
		if (loginName != null && password != null) {
			// 已经输入过用户名密码了请求token验证
			Intent intent = new Intent(mContext, LocalService.class);
			intent.putExtra(Constants.USER_NAME, loginName);
			intent.putExtra(Constants.PASSSWORD, password);
			intent.putExtra(Constants.IS_ATTENTIONTQT, true);
			mContext.startService(intent);

			Intent i = new Intent(mContext, ShareActivity.class);
			mContext.startActivity(i);

		} else {

			Intent i = new Intent(mContext, LoginWeiboActivity.class);
			mContext.startActivity(i);
		}

	}
}
