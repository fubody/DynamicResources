package com.sina.weibo.openapi.manager;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class DataStorageManager {
	public static final String LOGIN_NAME_KEY = "login_name_key";
	public static final String PASSWORD_KEY = "password_key";
	public static final String TOKEN_ACC_KEY = "token_acc_key";
	public static final String UID_KEY = "uid_key";
	public static final String SCREEN_NAME_KEY = "screen_name_key";
	public static final String REGIST_NUM_KEY = "regist_num_key";

	/**
	 * true 关注过天气通，false 为没有
	 * 
	 */
	public static final String IS_HAVING_ATTENTION_TQT = "is_having_attention_tqt";

// private Context mcontext;
//
// private DataStorageManager(Context context) {
// this.mcontext = context;
// }
//
// public static DataStorageManager mDataStorageManager = null;
//
// public static DataStorageManager getInstance(Context context) {
// if (mDataStorageManager == null) {
// mDataStorageManager = new DataStorageManager(context);
// }
// return mDataStorageManager = null;
// }

	public static void putSPString(Context context, String key, String value) {
		SharedPreferences mPerferences = PreferenceManager.getDefaultSharedPreferences(context);
		SharedPreferences.Editor mEditor = mPerferences.edit();
		mEditor.putString(key, value);
		mEditor.commit();
	}

	public static String getSPString(Context context, String key) {
		SharedPreferences mPerferences = PreferenceManager.getDefaultSharedPreferences(context);
		return mPerferences.getString(key, null);
	}
}
