package com.sina.weibo.openapi.entrty;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

public class NewBlog implements Serializable {
	private static final long serialVersionUID = -8660384734991885554L;
	/**
	 * 微博内容
	 */
	private String blogContent;
	/**
	 * 图片的地址
	 */
	private String picPath = null;

	private static NewBlog mNewBlog = null;

	private NewBlog() {

	}

	public static NewBlog getInstance() {
		if (mNewBlog == null) {
			mNewBlog = new NewBlog();
		}
		return mNewBlog;
	}

	public String getBlogContent() {
		return blogContent;
	}

	public void setBlogContent(String blogContent) {
		this.blogContent = blogContent;
	}

	public String getPicPath() {
		return picPath;
	}

	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}

}
