package com.sina.weibo.openapi.engine;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;
import com.sina.weibo.openapi.entrty.UserInfo;
import com.sina.weibo.openapi.manager.DataStorageManager;

import android.content.Context;

public class UserInfoEngine extends AccTokenBaseEngine {

	public UserInfoEngine(Context con) {
		super(con);

	}

	private String getUID() {

		HashMap<String, String> paramH = new HashMap();
		addAcctoken(paramH);
		String resultJsonStr = httpUtil.getRequest(NetConstants.URL_GET_UID, paramH);

		if (resultJsonStr != null) {
			try {
				JSONObject jso = new JSONObject(resultJsonStr);

				return jso.getString("uid");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	public boolean getUserInfo() {
		String uid = getUID();
		System.out.println("uid========" + uid);
		if (uid == null) {
			return false;
		}
		HashMap<String, String> paramH = new HashMap();
		paramH.put("uid", uid);

		addAcctoken(paramH);

		String resultJsonStr = httpUtil.getRequest(NetConstants.URL_GET_USERINF, paramH);
		if (resultJsonStr != null) {
			System.out.println(resultJsonStr);
			try {
				UserInfo user = new UserInfo(resultJsonStr);

				return true;

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return false;
	}

	@Override
	public void clearData() {

	}

}
