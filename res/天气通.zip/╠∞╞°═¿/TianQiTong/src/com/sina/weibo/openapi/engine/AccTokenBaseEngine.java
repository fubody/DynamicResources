package com.sina.weibo.openapi.engine;

import java.util.HashMap;

import android.content.Context;
import android.os.Handler;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;
import com.sina.weibo.openapi.net.HttpUtil;

public abstract class AccTokenBaseEngine extends BaseEngine {

	public AccTokenBaseEngine(Context con) {
		super(con);
	}

	void addAcctoken(HashMap<String, String> paramH) {
		try {
			if (Token.getInstance().getAccessToken() != null) {
				paramH.put("access_token", Token.getInstance().getAccessToken());
			} else {
				throw new RuntimeException("没有获取的 token");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
