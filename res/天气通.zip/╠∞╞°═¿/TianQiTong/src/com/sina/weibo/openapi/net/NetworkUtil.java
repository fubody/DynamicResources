package com.sina.weibo.openapi.net;

import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.net.Uri;
import android.text.TextUtils;

public class NetworkUtil {

	public static class APNWrapper {
		String name;
		String apn;
		String proxy;
		int port;

		public String getApn() {
			return apn;
		}

		public String getName() {
			return name;
		}

		public int getPort() {
			return port;
		}

		public String getProxy() {
			return proxy;
		}

		APNWrapper() {
		}
	}

	public enum NetworkState {
		NOTHING, MOBILE, WIFI
	}

	static final Uri PREFERRED_APN_URI = Uri
			.parse("content://telephony/carriers/preferapn");

	static APNWrapper wrapper;

	public static APNWrapper getAPN(Context ctx) {
		final Cursor cursor = ctx.getContentResolver().query(PREFERRED_APN_URI,
				new String[] { "name", "apn", "proxy", "port" }, null, null,
				null);

		cursor.moveToFirst();
		if (wrapper == null) {
			wrapper = new APNWrapper();
		}
		if (cursor.isAfterLast()) {
			wrapper.name = "N/A";
			wrapper.apn = "N/A";
		}
		else {
			wrapper.name = cursor.getString(0) == null ? "" : cursor.getString(
					0).trim();
			wrapper.apn = cursor.getString(1) == null ? "" : cursor
					.getString(1).trim();
		}

		wrapper.proxy = Proxy.getDefaultHost();
		wrapper.proxy = TextUtils.isEmpty(wrapper.proxy) ? "" : wrapper.proxy;
		wrapper.port = Proxy.getDefaultPort();
		wrapper.port = wrapper.port > 0 ? wrapper.port : 80;
		cursor.close();
		return wrapper;
	}
	public static NetworkState getNetworkState(Context ctx) {
		ConnectivityManager cm = (ConnectivityManager) ctx
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = cm.getActiveNetworkInfo();
		if (info == null || !info.isAvailable()) {
			return NetworkState.NOTHING;
		}
		else {
			if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
				return NetworkState.MOBILE;
			}
			else {
				return NetworkState.WIFI;
			}
		}
	}

	private NetworkUtil() {
	}
}
