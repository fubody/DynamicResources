package com.sina.weibo.openapi.engine;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

public class ImageDownloader extends BaseEngine implements Runnable, Handler.Callback {

	public ImageDownloader(Context con) {
		super(con);

	}

	Handler mainThreadHandler = null;

	Handler imageLoadHandler = null;

	public static final String IMAGE_KEY = "imageurl";

	public void addUrl(String url) {
		// 这里是让下载线程构建好 handle
		while (true) {
			if (imageLoadHandler != null) {
				if (TextUtils.isEmpty(url)) {
					throw new RuntimeException("url not allow empty");
				}

				Message urlMessage = imageLoadHandler.obtainMessage();
				Bundle b = new Bundle();
				b.putString(IMAGE_KEY, url);
				urlMessage.setData(b);
				imageLoadHandler.sendMessage(urlMessage);
				break;
			}
		}
	}

	public void downloadImages(final Handler handler) {

		this.mainThreadHandler = handler;
		Thread thread = new Thread(this);
		thread.start();
	}

	@Override
	public void run() {
		Looper mLooper = Looper.myLooper();
		mLooper.prepare();
		imageLoadHandler = new Handler(this);
		mLooper.loop();
	}

	/**
	 * 这里做下载表情的联网工作
	 */
	@Override
	public boolean handleMessage(Message msg) {

		String url = msg.getData().getString(IMAGE_KEY);

		// TODO 这里做联网下载图片的功能
		// httpUtil.d

		Message result = Message.obtain();
		result.setData(msg.getData());
		mainThreadHandler.sendMessage(result);

		return true;
	}

	public void stopDownLoadImage() {
		imageLoadHandler.getLooper().quit();
	}

	@Override
	public void clearData() {

	}

}
