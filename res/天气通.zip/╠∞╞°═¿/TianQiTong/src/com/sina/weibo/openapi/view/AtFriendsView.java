package com.sina.weibo.openapi.view;

import java.util.ArrayList;

import sina.mobile.tianqitong.R;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.sina.weibo.openapi.engine.AtFriendsEngine;

/**
 * at 好友列表view
 * 
 * @author zhangxi
 * 
 */
public class AtFriendsView extends LinearLayout implements OnItemClickListener {
	private ListView atFriendsListView = null;
	private EditText mSearchAt = null;
	private GetAtFriendsTask mGetAtFriendsTask = null;
	private ArrayList<String> atFriendsList = new ArrayList();
	private Context mContext = null;
	private AtFriendsAdapter mAtFriendsAdapter = null;
	private onAtSelectAction onAtSelectAction = null;

	private LinearLayout mLinearLayout = null;

	private AtFriendsEngine mAtFriendsEngine = null;

	public AtFriendsView(Context context) {
		super(context);
		mContext = context;
		initViews();
	}

	public AtFriendsView(Context context, AttributeSet attrs) {
		super(context, attrs);
		mContext = context;
		initViews();
	}

	private void initViews() {
		LayoutInflater.from(mContext).inflate(R.layout.weibo_list_at_friends, this);
		atFriendsListView = (ListView) findViewById(R.id.at_frinders_list);
		mSearchAt = (EditText) findViewById(R.id.search_at);
		mSearchAt.addTextChangedListener(searchAtWathcer);
		mAtFriendsEngine = new AtFriendsEngine(mContext);

		mAtFriendsAdapter = new AtFriendsAdapter();
		atFriendsListView.setAdapter(mAtFriendsAdapter);
		atFriendsListView.setOnItemClickListener(this);
		mLinearLayout = (LinearLayout) findViewById(R.id.progress_item);

	}

	TextWatcher searchAtWathcer = new TextWatcher() {

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}

		@Override
		public void afterTextChanged(Editable s) {
			// TODO Auto-generated method stub
			System.out.println("afterTextChanged" + s.toString());

			if (mGetAtFriendsTask != null && mGetAtFriendsTask.getStatus() == AsyncTask.Status.RUNNING) {
				// 如果正在运行 进行终端处理
				mGetAtFriendsTask.cancel(true);
			}
			mGetAtFriendsTask = new GetAtFriendsTask();
			mGetAtFriendsTask.execute(s.toString());
		}

	};

	private class AtFriendsAdapter extends BaseAdapter {

		public int getCount() {
			return atFriendsList.size();
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {

			TextView textView = new TextView(mContext);
			textView.setTextColor(Color.BLACK);
			textView.setText(atFriendsList.get(position));
			textView.setPadding(10, 10, 10, 10);
			return textView;
		}
	}

	private class GetAtFriendsTask extends AsyncTask<String, Void, ArrayList<String>> {

		@Override
		protected ArrayList doInBackground(String... params) {
			return mAtFriendsEngine.getAtFriendsList(params[0]);
		}

		protected void onPreExecute() {
			mLinearLayout.setVisibility(View.VISIBLE);
		}

		protected void onCancelled() {
			mLinearLayout.setVisibility(View.GONE);
			mAtFriendsEngine.cancel();
		}

		protected void onPostExecute(ArrayList result) {
			mLinearLayout.setVisibility(View.GONE);
			atFriendsList = result;
			mAtFriendsAdapter.notifyDataSetChanged();
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		if (onAtSelectAction != null) {
			onAtSelectAction.onAtFriendsSelect("@" + atFriendsList.get(position) + " ");
		}

	}

	public void setOnAtSelectAction(onAtSelectAction onAtSelectAction) {
		this.onAtSelectAction = onAtSelectAction;
	}

	public static interface onAtSelectAction {
		public void onAtFriendsSelect(String friendName);
	}

}
