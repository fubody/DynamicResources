package com.sina.weibo.openapi.view;

import sina.mobile.tianqitong.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.sina.weibo.openapi.util.EmotionUtil;

public class EmotionView extends LinearLayout implements OnItemClickListener {

	public EmotionView(Context context) {
		super(context);
		initViews();
	}

	public EmotionView(Context context, AttributeSet attrs) {
		super(context, attrs);
		initViews();
	}

	private void initViews() {
		Context context = getContext();
		LayoutInflater.from(context).inflate(R.layout.weibo_emotion_main, this);
		mGridView = (GridView) findViewById(R.id.gridView);
		mGridView.setAdapter(new GridViewAdapter(EmotionUtil.emotionResIds));
		mGridView.setOnItemClickListener(this);
	}

	private class GridViewAdapter extends BaseAdapter {
		int[] emotionResIds;

		public int getCount() {
			return emotionResIds.length;
		}

		public Object getItem(int position) {
			return emotionResIds[position];
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			int resId = (Integer) getItem(position);
			ImageView iv = null;
			if (convertView == null) {
				iv = (ImageView) (convertView = new ImageView(getContext().getApplicationContext()));
			} else {
				iv = (ImageView) convertView;
			}
			iv.setImageResource(resId);
			iv.setBackgroundResource(R.drawable.bg_face);
			int height = getResources().getDimensionPixelSize(R.dimen.emotion_item_view_height);
			iv.setPadding(0, height, 0, height);
			return iv;
		}

		public GridViewAdapter(int[] emotionResIds) {
			super();
			this.emotionResIds = emotionResIds;
		}

	}

	private GridView mGridView;

	private EmotionAdapter mEmotionAdapter;

	public EmotionAdapter getEmotionAdapter() {
		return mEmotionAdapter;
	}

	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		if (mEmotionAdapter != null) {
			int resid = EmotionUtil.emotionResIds[position];
			mEmotionAdapter.doAction(resid, EmotionUtil.des[position]);
		}
	}

	public void reBuildViews() {
		removeAllViews();
		initViews();
		requestLayout();
		invalidate();
	}

	public void setEmotionAdapter(EmotionAdapter emotionAdapter) {
		mEmotionAdapter = emotionAdapter;
	}

	public interface EmotionAdapter {
		void doAction(int resId, String desc);
	}
}
