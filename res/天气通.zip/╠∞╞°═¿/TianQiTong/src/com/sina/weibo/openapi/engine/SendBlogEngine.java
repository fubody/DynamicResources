package com.sina.weibo.openapi.engine;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sina.weibo.openapi.constants.NetConstants;
import com.sina.weibo.openapi.entrty.Token;
import com.sina.weibo.openapi.entrty.UserInfo;
import com.sina.weibo.openapi.manager.DataStorageManager;
import com.sina.weibo.openapi.net.HttpUtil.HttpException;

import android.content.Context;
import android.text.TextUtils;

public class SendBlogEngine extends AccTokenBaseEngine {

	public SendBlogEngine(Context con) {
		super(con);

	}

	public boolean sendWeiBo(String content, String picpath) {
		try {
			if (picpath == null) {
				HashMap<String, String> paramHashMap = new HashMap();
				paramHashMap.put("status", content);
				addAcctoken(paramHashMap);
				String result = httpUtil.postRequest(NetConstants.URL_SERVER_NO_PIC, paramHashMap);
				if (result != null)
					return true;

			}
			return httpUtil.postNewMBlog(Token.getInstance().getAccessToken(), content, picpath);
		} catch (HttpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public void clearData() {

	}

}
