/** Automatically generated file. DO NOT MODIFY */
package sina.mobile.tianqitong;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}